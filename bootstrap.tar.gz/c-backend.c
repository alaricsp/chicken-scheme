/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-12-23 00:30
   Version 2.737 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann	compiled 2007-12-09 on o317b.o.pppool.de (Darwin)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[810];


/* from getsize in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1041(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1041(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1037(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1037(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8726)
static void C_ccall f_8726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8674)
static void C_ccall f_8674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_ccall f_8644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8491)
static void C_ccall f_8491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static C_word C_fcall f_8438(C_word *a,C_word t0);
C_noret_decl(f_8435)
static C_word C_fcall f_8435(C_word t0);
C_noret_decl(f_8432)
static C_word C_fcall f_8432(C_word t0);
C_noret_decl(f_7655)
static void C_ccall f_7655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7742)
static void C_fcall f_7742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_fcall f_8258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_fcall f_8200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_fcall f_8164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_fcall f_8129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_fcall f_8081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8033)
static void C_fcall f_8033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_fcall f_7985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_fcall f_7856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_fcall f_7851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_fcall f_7846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7657)
static void C_fcall f_7657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6852)
static void C_fcall f_6852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_fcall f_6879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_fcall f_7083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_fcall f_7480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_fcall f_7447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7415)
static void C_fcall f_7415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_fcall f_7380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_fcall f_7310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_fcall f_7265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_fcall f_7233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_fcall f_7201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_fcall f_7169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_fcall f_7137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_fcall f_7115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_fcall f_6824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5682)
static void C_fcall f_5682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_fcall f_5784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_fcall f_5817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_fcall f_5913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_fcall f_6545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_fcall f_6499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_fcall f_6449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_fcall f_6399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_fcall f_6360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_fcall f_6321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_fcall f_6282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_fcall f_6243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_fcall f_6183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_fcall f_6036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_fcall f_6000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_fcall f_5974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_fcall f_5612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5607)
static void C_fcall f_5607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_fcall f_5155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_fcall f_5167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_fcall f_5179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_fcall f_5219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4823)
static void C_fcall f_4823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4695)
static void C_fcall f_4695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4724)
static void C_fcall f_4724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_fcall f_4727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_fcall f_4711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_fcall f_3833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_fcall f_3927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_fcall f_4405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_fcall f_4348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_fcall f_4315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_fcall f_4324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4269)
static void C_fcall f_4269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_fcall f_3959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_fcall f_4019(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_fcall f_3591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_fcall f_3420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_fcall f_3426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_fcall f_3622(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_fcall f_3629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_fcall f_3457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_fcall f_3744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_fcall f_3821(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_fcall f_3320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_fcall f_3323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_fcall f_3369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_fcall f_3173(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_fcall f_3137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_fcall f_2883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_fcall f_2921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_fcall f_3007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_fcall f_2771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_fcall f_2789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_fcall f_2605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_fcall f_2608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_fcall f_1178(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2573)
static void C_fcall f_2573(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_fcall f_1181(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_fcall f_1825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_fcall f_1831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_fcall f_1982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_fcall f_1363(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8541(t0,t1);}

C_noret_decl(trf_7742)
static void C_fcall trf_7742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7742(t0,t1);}

C_noret_decl(trf_8258)
static void C_fcall trf_8258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8258(t0,t1);}

C_noret_decl(trf_8200)
static void C_fcall trf_8200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8200(t0,t1);}

C_noret_decl(trf_8164)
static void C_fcall trf_8164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8164(t0,t1);}

C_noret_decl(trf_8129)
static void C_fcall trf_8129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8129(t0,t1);}

C_noret_decl(trf_8081)
static void C_fcall trf_8081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8081(t0,t1);}

C_noret_decl(trf_8033)
static void C_fcall trf_8033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8033(t0,t1);}

C_noret_decl(trf_7985)
static void C_fcall trf_7985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7985(t0,t1);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7950(t0,t1);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7914(t0,t1);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7878(t0,t1);}

C_noret_decl(trf_7856)
static void C_fcall trf_7856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7856(t0,t1);}

C_noret_decl(trf_7851)
static void C_fcall trf_7851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7851(t0,t1);}

C_noret_decl(trf_7846)
static void C_fcall trf_7846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7846(t0,t1);}

C_noret_decl(trf_7657)
static void C_fcall trf_7657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7657(t0,t1);}

C_noret_decl(trf_6852)
static void C_fcall trf_6852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6852(t0,t1);}

C_noret_decl(trf_6879)
static void C_fcall trf_6879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6879(t0,t1);}

C_noret_decl(trf_7074)
static void C_fcall trf_7074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7074(t0,t1);}

C_noret_decl(trf_7083)
static void C_fcall trf_7083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7083(t0,t1);}

C_noret_decl(trf_7480)
static void C_fcall trf_7480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7480(t0,t1);}

C_noret_decl(trf_7447)
static void C_fcall trf_7447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7447(t0,t1);}

C_noret_decl(trf_7415)
static void C_fcall trf_7415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7415(t0,t1);}

C_noret_decl(trf_7380)
static void C_fcall trf_7380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7380(t0,t1);}

C_noret_decl(trf_7310)
static void C_fcall trf_7310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7310(t0,t1);}

C_noret_decl(trf_7265)
static void C_fcall trf_7265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7265(t0,t1);}

C_noret_decl(trf_7233)
static void C_fcall trf_7233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7233(t0,t1);}

C_noret_decl(trf_7201)
static void C_fcall trf_7201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7201(t0,t1);}

C_noret_decl(trf_7169)
static void C_fcall trf_7169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7169(t0,t1);}

C_noret_decl(trf_7137)
static void C_fcall trf_7137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7137(t0,t1);}

C_noret_decl(trf_7115)
static void C_fcall trf_7115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7115(t0,t1);}

C_noret_decl(trf_6824)
static void C_fcall trf_6824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6824(t0,t1);}

C_noret_decl(trf_5682)
static void C_fcall trf_5682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5682(t0,t1);}

C_noret_decl(trf_5784)
static void C_fcall trf_5784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5784(t0,t1);}

C_noret_decl(trf_5817)
static void C_fcall trf_5817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5817(t0,t1);}

C_noret_decl(trf_5913)
static void C_fcall trf_5913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5913(t0,t1);}

C_noret_decl(trf_6545)
static void C_fcall trf_6545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6545(t0,t1);}

C_noret_decl(trf_6565)
static void C_fcall trf_6565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6565(t0,t1);}

C_noret_decl(trf_6499)
static void C_fcall trf_6499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6499(t0,t1);}

C_noret_decl(trf_6449)
static void C_fcall trf_6449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6449(t0,t1);}

C_noret_decl(trf_6399)
static void C_fcall trf_6399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6399(t0,t1);}

C_noret_decl(trf_6360)
static void C_fcall trf_6360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6360(t0,t1);}

C_noret_decl(trf_6321)
static void C_fcall trf_6321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6321(t0,t1);}

C_noret_decl(trf_6282)
static void C_fcall trf_6282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6282(t0,t1);}

C_noret_decl(trf_6243)
static void C_fcall trf_6243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6243(t0,t1);}

C_noret_decl(trf_6183)
static void C_fcall trf_6183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6183(t0,t1);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6144(t0,t1);}

C_noret_decl(trf_6108)
static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6108(t0,t1);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6072(t0,t1);}

C_noret_decl(trf_6036)
static void C_fcall trf_6036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6036(t0,t1);}

C_noret_decl(trf_6000)
static void C_fcall trf_6000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6000(t0,t1);}

C_noret_decl(trf_5974)
static void C_fcall trf_5974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5974(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5974(t0,t1,t2);}

C_noret_decl(trf_5965)
static void C_fcall trf_5965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5965(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5965(t0,t1,t2);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5960(t0,t1);}

C_noret_decl(trf_5612)
static void C_fcall trf_5612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5612(t0,t1,t2);}

C_noret_decl(trf_5607)
static void C_fcall trf_5607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5607(t0,t1);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5146(t0,t1);}

C_noret_decl(trf_5155)
static void C_fcall trf_5155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5155(t0,t1);}

C_noret_decl(trf_5167)
static void C_fcall trf_5167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5167(t0,t1);}

C_noret_decl(trf_5179)
static void C_fcall trf_5179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5179(t0,t1);}

C_noret_decl(trf_5219)
static void C_fcall trf_5219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5219(t0,t1);}

C_noret_decl(trf_4823)
static void C_fcall trf_4823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4823(t0,t1);}

C_noret_decl(trf_4695)
static void C_fcall trf_4695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4695(t0,t1,t2);}

C_noret_decl(trf_4724)
static void C_fcall trf_4724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4724(t0,t1);}

C_noret_decl(trf_4727)
static void C_fcall trf_4727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4727(t0,t1);}

C_noret_decl(trf_4711)
static void C_fcall trf_4711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4711(t0,t1);}

C_noret_decl(trf_4631)
static void C_fcall trf_4631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4631(t0,t1,t2);}

C_noret_decl(trf_3833)
static void C_fcall trf_3833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3833(t0,t1);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3861(t0,t1);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4479(t0,t1);}

C_noret_decl(trf_3927)
static void C_fcall trf_3927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3927(t0,t1);}

C_noret_decl(trf_4441)
static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4441(t0,t1,t2,t3);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4384(t0,t1);}

C_noret_decl(trf_4405)
static void C_fcall trf_4405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4405(t0,t1);}

C_noret_decl(trf_4348)
static void C_fcall trf_4348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4348(t0,t1);}

C_noret_decl(trf_4315)
static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4315(t0,t1);}

C_noret_decl(trf_4324)
static void C_fcall trf_4324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4324(t0,t1);}

C_noret_decl(trf_4269)
static void C_fcall trf_4269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4269(t0,t1);}

C_noret_decl(trf_3959)
static void C_fcall trf_3959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3959(t0,t1);}

C_noret_decl(trf_4019)
static void C_fcall trf_4019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4019(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4019(t0,t1,t2,t3);}

C_noret_decl(trf_3591)
static void C_fcall trf_3591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3591(t0,t1,t2,t3);}

C_noret_decl(trf_3420)
static void C_fcall trf_3420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3420(t0,t1);}

C_noret_decl(trf_3426)
static void C_fcall trf_3426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3426(t0,t1,t2,t3);}

C_noret_decl(trf_3622)
static void C_fcall trf_3622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3622(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3622(t0,t1,t2,t3);}

C_noret_decl(trf_3629)
static void C_fcall trf_3629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3629(t0,t1);}

C_noret_decl(trf_3457)
static void C_fcall trf_3457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3457(t0,t1);}

C_noret_decl(trf_3744)
static void C_fcall trf_3744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3744(t0,t1,t2);}

C_noret_decl(trf_3759)
static void C_fcall trf_3759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3759(t0,t1,t2,t3);}

C_noret_decl(trf_3775)
static void C_fcall trf_3775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3775(t0,t1);}

C_noret_decl(trf_3821)
static void C_fcall trf_3821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3821(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3821(t0,t1,t2,t3);}

C_noret_decl(trf_3134)
static void C_fcall trf_3134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3134(t0,t1);}

C_noret_decl(trf_3320)
static void C_fcall trf_3320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3320(t0,t1);}

C_noret_decl(trf_3323)
static void C_fcall trf_3323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3323(t0,t1);}

C_noret_decl(trf_3369)
static void C_fcall trf_3369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3369(t0,t1);}

C_noret_decl(trf_3173)
static void C_fcall trf_3173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3173(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3173(t0,t1,t2);}

C_noret_decl(trf_3137)
static void C_fcall trf_3137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3137(t0,t1);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3150(t0,t1,t2,t3);}

C_noret_decl(trf_2883)
static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2883(t0,t1);}

C_noret_decl(trf_2921)
static void C_fcall trf_2921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2921(t0,t1);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2942(t0,t1);}

C_noret_decl(trf_3007)
static void C_fcall trf_3007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3007(t0,t1);}

C_noret_decl(trf_2771)
static void C_fcall trf_2771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2771(t0,t1);}

C_noret_decl(trf_2789)
static void C_fcall trf_2789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2789(t0,t1,t2,t3);}

C_noret_decl(trf_2824)
static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2824(t0,t1,t2);}

C_noret_decl(trf_2605)
static void C_fcall trf_2605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2605(t0,t1);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2631(t0,t1);}

C_noret_decl(trf_2608)
static void C_fcall trf_2608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2608(t0,t1);}

C_noret_decl(trf_1178)
static void C_fcall trf_1178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1178(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1178(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2573)
static void C_fcall trf_2573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2573(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2573(t0,t1,t2,t3);}

C_noret_decl(trf_1181)
static void C_fcall trf_1181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1181(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1181(t0,t1,t2,t3);}

C_noret_decl(trf_2474)
static void C_fcall trf_2474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2474(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2474(t0,t1,t2,t3);}

C_noret_decl(trf_1825)
static void C_fcall trf_1825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1825(t0,t1);}

C_noret_decl(trf_1831)
static void C_fcall trf_1831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1831(t0,t1);}

C_noret_decl(trf_1982)
static void C_fcall trf_1982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1982(t0,t1);}

C_noret_decl(trf_1363)
static void C_fcall trf_1363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1363(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1363(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1136)
static void C_fcall trf_1136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1136(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1136(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,810);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_static_string(C_heaptop,17,"can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_static_string(C_heaptop,13,"C_SCHEME_TRUE");
lf[17]=C_static_string(C_heaptop,14,"C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_static_string(C_heaptop,17,"C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_static_string(C_heaptop,20,"C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_static_string(C_heaptop,6,"C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_static_string(C_heaptop,20,"C_SCHEME_END_OF_FILE");
lf[26]=C_static_string(C_heaptop,13,"bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_static_string(C_heaptop,11,"((C_word)li");
lf[29]=C_static_string(C_heaptop,1,")");
lf[30]=C_static_string(C_heaptop,3,"lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_static_string(C_heaptop,5,"else{");
lf[33]=C_static_string(C_heaptop,3,")){");
lf[34]=C_static_string(C_heaptop,11,"if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_static_string(C_heaptop,8,"(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_static_string(C_heaptop,2,")[");
lf[40]=C_static_string(C_heaptop,10,"((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_static_string(C_heaptop,4,")[1]");
lf[43]=C_static_string(C_heaptop,10,"((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_static_string(C_heaptop,17,"C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_static_string(C_heaptop,2,")+");
lf[48]=C_static_string(C_heaptop,1,",");
lf[49]=C_static_string(C_heaptop,20,"C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_static_string(C_heaptop,3,",0,");
lf[52]=C_static_string(C_heaptop,17,"C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_static_string(C_heaptop,4,")+1,");
lf[55]=C_static_string(C_heaptop,20,"C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_static_string(C_heaptop,17,"tmp=(C_word)a,a+=");
lf[58]=C_static_string(C_heaptop,5,",tmp)");
lf[59]=C_static_string(C_heaptop,2,"a[");
lf[60]=C_static_string(C_heaptop,2,"]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_static_string(C_heaptop,19,"(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_static_string(C_heaptop,24,",tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_static_string(C_heaptop,25,"(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_static_string(C_heaptop,3,"lf[");
lf[71]=C_static_string(C_heaptop,1,"]");
lf[72]=C_static_string(C_heaptop,15,"C_retrieve2(lf[");
lf[73]=C_static_string(C_heaptop,2,"],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_static_string(C_heaptop,14,"*((C_word*)lf[");
lf[77]=C_static_string(C_heaptop,4,"]+1)");
lf[78]=C_static_string(C_heaptop,14,"C_retrieve(lf[");
lf[79]=C_static_string(C_heaptop,2,"])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_static_string(C_heaptop,13,"C_mutate(&lf[");
lf[82]=C_static_string(C_heaptop,2,"],");
lf[83]=C_static_string(C_heaptop,21,"C_mutate((C_word*)lf[");
lf[84]=C_static_string(C_heaptop,4,"]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_static_string(C_heaptop,3,"lf[");
lf[87]=C_static_string(C_heaptop,2,"]=");
lf[88]=C_static_string(C_heaptop,20,"C_set_block_item(lf[");
lf[89]=C_static_string(C_heaptop,4,"],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_static_string(C_heaptop,18,"C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_static_string(C_heaptop,2,");");
lf[94]=C_static_string(C_heaptop,3,",0,");
lf[95]=C_static_string(C_heaptop,10,"goto loop;");
lf[96]=C_static_string(C_heaptop,2,"c=");
lf[97]=C_static_string(C_heaptop,2,"=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_static_string(C_heaptop,2,");");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_static_string(C_heaptop,2,");");
lf[102]=C_static_string(C_heaptop,2,")(");
lf[103]=C_static_string(C_heaptop,2,",t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_static_string(C_heaptop,20,"(void*)(*((C_word*)t");
lf[106]=C_static_string(C_heaptop,4,"+1))");
lf[107]=C_static_string(C_heaptop,17,"C_retrieve_proc(t");
lf[108]=C_static_string(C_heaptop,1,")");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_static_string(C_heaptop,8,"((C_proc");
lf[111]=C_static_string(C_heaptop,1,")");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_static_string(C_heaptop,9,"C_trace(\042");
lf[114]=C_static_string(C_heaptop,3,"\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_static_string(C_heaptop,1,"\134");
lf[117]=C_static_string(C_heaptop,1,"/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_static_string(C_heaptop,3,"/* ");
lf[120]=C_static_string(C_heaptop,3," */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
tmp=C_static_string(C_heaptop,2,"*/");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"* /");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[122]=C_h_pair(C_restore,tmp);
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_static_string(C_heaptop,10,"goto loop;");
lf[127]=C_static_string(C_heaptop,2,"=t");
lf[128]=C_static_string(C_heaptop,3,"t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_static_string(C_heaptop,9,"C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_static_string(C_heaptop,2,");");
lf[133]=C_static_string(C_heaptop,2,"C_");
lf[134]=C_static_string(C_heaptop,10,"_toplevel(");
lf[135]=C_static_string(C_heaptop,20,",C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_static_string(C_heaptop,2,");");
lf[138]=C_static_string(C_heaptop,7,"return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_static_string(C_heaptop,8,"(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_static_string(C_heaptop,8,"(C_word)");
lf[143]=C_static_string(C_heaptop,4,"(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_static_string(C_heaptop,1,"a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_static_string(C_heaptop,21,"),C_SCHEME_UNDEFINED)");
lf[149]=C_static_string(C_heaptop,2,"=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_static_string(C_heaptop,0,"");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_static_string(C_heaptop,3,")))");
lf[155]=C_static_string(C_heaptop,3,"*((");
lf[156]=C_static_string(C_heaptop,17,"*)C_data_pointer(");
lf[157]=C_static_string(C_heaptop,0,"");
lf[158]=C_static_string(C_heaptop,1,"a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_static_string(C_heaptop,21,"),C_SCHEME_UNDEFINED)");
lf[161]=C_static_string(C_heaptop,3,"))=");
lf[162]=C_static_string(C_heaptop,4,"((*(");
lf[163]=C_static_string(C_heaptop,17,"*)C_data_pointer(");
lf[164]=C_static_string(C_heaptop,0,"");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_static_string(C_heaptop,8,"default:");
lf[167]=C_static_string(C_heaptop,5,"case ");
lf[168]=C_static_string(C_heaptop,2,"){");
lf[169]=C_static_string(C_heaptop,7,"switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_static_string(C_heaptop,2,")\077");
lf[172]=C_static_string(C_heaptop,9,"(C_truep(");
lf[173]=C_static_string(C_heaptop,8,"bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_static_string(C_heaptop,1,"0");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_static_string(C_heaptop,2,"*/");
lf[182]=C_static_string(C_heaptop,10,"#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_static_string(C_heaptop,1,"\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_static_string(C_heaptop,9,"   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_static_string(C_heaptop,15,"   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_static_string(C_heaptop,18,"/* Generated from ");
lf[191]=C_static_string(C_heaptop,24," by the CHICKEN compiler");
lf[192]=C_static_string(C_heaptop,48,"   http://www.call-with-current-continuation.org");
lf[193]=C_static_string(C_heaptop,3,"   ");
lf[194]=C_static_string(C_heaptop,17,"   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_static_string(C_heaptop,0,"");
lf[197]=C_static_string(C_heaptop,3,"   ");
lf[198]=C_static_string(C_heaptop,1,"\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_static_string(C_heaptop,1,"\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_static_string(C_heaptop,2,"};");
lf[207]=C_static_string(C_heaptop,22,"static C_char C_TLS li");
lf[208]=C_static_string(C_heaptop,12,"[]={C_lihdr(");
lf[209]=C_h_intern(&lf[209],23,"\003syslambda-info->string");
lf[210]=C_static_string(C_heaptop,23,"static C_TLS C_word lf[");
lf[211]=C_static_string(C_heaptop,2,"];");
lf[212]=C_static_string(C_heaptop,15,"C_noret_decl(C_");
lf[213]=C_static_string(C_heaptop,10,"_toplevel)");
lf[214]=C_static_string(C_heaptop,30,"C_externimport void C_ccall C_");
lf[215]=C_static_string(C_heaptop,46,"_toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[216]=C_static_string(C_heaptop,43,"static C_PTABLE_ENTRY *create_ptable(void);");
lf[217]=C_static_string(C_heaptop,10,") C_noret;");
lf[218]=C_h_intern(&lf[218],9,"make-list");
lf[219]=C_static_string(C_heaptop,7,",C_word");
lf[220]=C_static_string(C_heaptop,21,"typedef void (*C_proc");
lf[221]=C_static_string(C_heaptop,8,")(C_word");
lf[222]=C_h_intern(&lf[222],4,"none");
lf[223]=C_static_string(C_heaptop,9,",C_word t");
lf[224]=C_static_string(C_heaptop,10,") C_noret;");
lf[225]=C_static_string(C_heaptop,13,"C_noret_decl(");
lf[226]=C_static_string(C_heaptop,1,")");
lf[227]=C_static_string(C_heaptop,20,"static void C_ccall ");
lf[228]=C_static_string(C_heaptop,2,"r(");
lf[229]=C_static_string(C_heaptop,14,",...) C_noret;");
lf[230]=C_static_string(C_heaptop,8," C_noret");
lf[231]=C_static_string(C_heaptop,9,"C_word *a");
lf[232]=C_static_string(C_heaptop,9,"C_word c,");
lf[233]=C_h_intern(&lf[233],8,"toplevel");
lf[234]=C_static_string(C_heaptop,2,"C_");
lf[235]=C_static_string(C_heaptop,28,"C_externexport void C_ccall ");
lf[236]=C_h_intern(&lf[236],27,"\010compileremit-unsafe-marker");
lf[237]=C_static_string(C_heaptop,49,"C_externexport void C_dynamic_and_unsafe(void) {}");
lf[238]=C_static_string(C_heaptop,15,"C_noret_decl(C_");
lf[239]=C_static_string(C_heaptop,1,")");
lf[240]=C_static_string(C_heaptop,9,"_toplevel");
lf[241]=C_static_string(C_heaptop,8,"toplevel");
lf[242]=C_static_string(C_heaptop,8,"C_fcall ");
lf[243]=C_static_string(C_heaptop,8,"C_ccall ");
lf[244]=C_static_string(C_heaptop,7,"C_word ");
lf[245]=C_static_string(C_heaptop,5,"void ");
lf[246]=C_static_string(C_heaptop,7,"static ");
lf[247]=C_static_string(C_heaptop,13,"C_noret_decl(");
lf[248]=C_static_string(C_heaptop,1,")");
lf[249]=C_h_intern(&lf[249],21,"small-parameter-limit");
lf[250]=C_h_intern(&lf[250],11,"lset-adjoin");
lf[251]=C_h_intern(&lf[251],1,"=");
lf[252]=C_h_intern(&lf[252],32,"lambda-literal-callee-signatures");
lf[253]=C_h_intern(&lf[253],24,"lambda-literal-allocated");
lf[254]=C_h_intern(&lf[254],21,"lambda-literal-direct");
lf[255]=C_h_intern(&lf[255],33,"lambda-literal-rest-argument-mode");
lf[256]=C_h_intern(&lf[256],28,"lambda-literal-rest-argument");
lf[257]=C_h_intern(&lf[257],27,"\010compilermake-variable-list");
lf[258]=C_static_string(C_heaptop,1,"t");
lf[259]=C_h_intern(&lf[259],27,"lambda-literal-customizable");
lf[260]=C_h_intern(&lf[260],29,"lambda-literal-argument-count");
lf[261]=C_static_string(C_heaptop,16,"C_adjust_stack(-");
lf[262]=C_static_string(C_heaptop,2,");");
lf[263]=C_static_string(C_heaptop,8,"C_word t");
lf[264]=C_static_string(C_heaptop,8,"=C_pick(");
lf[265]=C_static_string(C_heaptop,2,");");
lf[266]=C_static_string(C_heaptop,3,");}");
lf[267]=C_h_intern(&lf[267],27,"\010compilermake-argument-list");
lf[268]=C_static_string(C_heaptop,1,"t");
lf[269]=C_static_string(C_heaptop,4,"(k)(");
lf[270]=C_static_string(C_heaptop,6,"(a,n);");
lf[271]=C_static_string(C_heaptop,7,"_vector");
lf[272]=C_static_string(C_heaptop,15,"=C_restore_rest");
lf[273]=C_static_string(C_heaptop,15,"a=C_alloc(n+1);");
lf[274]=C_static_string(C_heaptop,15,"a=C_alloc(n*3);");
lf[275]=C_static_string(C_heaptop,18,"n=C_rest_count(0);");
lf[276]=C_static_string(C_heaptop,7,"(C_proc");
lf[277]=C_static_string(C_heaptop,4," k){");
lf[278]=C_static_string(C_heaptop,6,"int n;");
lf[279]=C_static_string(C_heaptop,11,"C_word *a,t");
lf[280]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[281]=C_static_string(C_heaptop,7,"(C_proc");
lf[282]=C_static_string(C_heaptop,22," k) C_regparm C_noret;");
lf[283]=C_static_string(C_heaptop,0,"");
lf[284]=C_static_string(C_heaptop,0,"");
lf[285]=C_static_string(C_heaptop,15,"C_noret_decl(tr");
lf[286]=C_static_string(C_heaptop,1,")");
lf[287]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[288]=C_static_string(C_heaptop,3,");}");
lf[289]=C_static_string(C_heaptop,1,"t");
lf[290]=C_static_string(C_heaptop,4,"(k)(");
lf[291]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[292]=C_static_string(C_heaptop,7,"(C_proc");
lf[293]=C_static_string(C_heaptop,4," k){");
lf[294]=C_static_string(C_heaptop,15,"C_noret_decl(tr");
lf[295]=C_static_string(C_heaptop,1,")");
lf[296]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[297]=C_static_string(C_heaptop,7,"(C_proc");
lf[298]=C_static_string(C_heaptop,22," k) C_regparm C_noret;");
lf[299]=C_static_string(C_heaptop,3,");}");
lf[300]=C_static_string(C_heaptop,1,"t");
lf[301]=C_static_string(C_heaptop,32,"C_regparm static void C_fcall tr");
lf[302]=C_static_string(C_heaptop,14,"(void *dummy){");
lf[303]=C_static_string(C_heaptop,15,"C_noret_decl(tr");
lf[304]=C_static_string(C_heaptop,1,")");
lf[305]=C_static_string(C_heaptop,22,"static void C_fcall tr");
lf[306]=C_static_string(C_heaptop,32,"(void *dummy) C_regparm C_noret;");
lf[307]=C_h_intern(&lf[307],6,"vector");
lf[308]=C_h_intern(&lf[308],23,"lambda-literal-external");
lf[309]=C_h_intern(&lf[309],14,"\003syscopy-bytes");
lf[310]=C_h_intern(&lf[310],11,"make-string");
lf[311]=C_h_intern(&lf[311],6,"modulo");
lf[312]=C_h_intern(&lf[312],3,"fx/");
lf[313]=C_static_string(C_heaptop,29,"type of literal not supported");
lf[314]=C_static_string(C_heaptop,7,"=C_fix(");
lf[315]=C_static_string(C_heaptop,2,");");
lf[316]=C_static_string(C_heaptop,20,"=C_SCHEME_UNDEFINED;");
lf[317]=C_static_string(C_heaptop,13,"C_SCHEME_TRUE");
lf[318]=C_static_string(C_heaptop,14,"C_SCHEME_FALSE");
lf[319]=C_static_string(C_heaptop,18,"=C_make_character(");
lf[320]=C_static_string(C_heaptop,2,");");
lf[321]=C_static_string(C_heaptop,12,"C_h_intern(&");
lf[322]=C_static_string(C_heaptop,2,");");
lf[323]=C_static_string(C_heaptop,1,"=");
lf[324]=C_static_string(C_heaptop,22,"=C_SCHEME_END_OF_LIST;");
lf[325]=C_static_string(C_heaptop,2,");");
lf[326]=C_h_intern(&lf[326],23,"\010compilerencode-literal");
lf[327]=C_static_string(C_heaptop,28,"=C_decode_literal(C_heaptop,");
lf[328]=C_h_intern(&lf[328],32,"\010compilerblock-variable-literal\077");
lf[329]=C_h_intern(&lf[329],20,"\010compilerbig-fixnum\077");
lf[330]=C_h_intern(&lf[330],7,"sprintf");
lf[331]=C_static_string(C_heaptop,6,"lf[~s]");
lf[332]=C_h_intern(&lf[332],25,"\010compilerwords-per-flonum");
lf[333]=C_h_intern(&lf[333],6,"reduce");
lf[334]=C_h_intern(&lf[334],1,"+");
lf[335]=C_h_intern(&lf[335],12,"vector->list");
lf[336]=C_h_intern(&lf[336],14,"\010compilerwords");
lf[337]=C_h_intern(&lf[337],15,"\003sysbytevector\077");
lf[338]=C_h_intern(&lf[338],19,"\010compilerimmediate\077");
lf[339]=C_h_intern(&lf[339],19,"lambda-literal-body");
lf[340]=C_static_string(C_heaptop,18,"C_word *a=C_alloc(");
lf[341]=C_static_string(C_heaptop,2,");");
lf[342]=C_static_string(C_heaptop,8,"C_word t");
lf[343]=C_static_string(C_heaptop,11,"C_word tmp;");
lf[344]=C_static_string(C_heaptop,9,",C_word t");
lf[345]=C_static_string(C_heaptop,2,"){");
lf[346]=C_static_string(C_heaptop,20,"static void C_ccall ");
lf[347]=C_static_string(C_heaptop,2,"r(");
lf[348]=C_static_string(C_heaptop,2,",t");
lf[349]=C_static_string(C_heaptop,4,");}}");
lf[350]=C_static_string(C_heaptop,1,"t");
lf[351]=C_static_string(C_heaptop,2,"r(");
lf[352]=C_h_intern(&lf[352],4,"list");
lf[353]=C_static_string(C_heaptop,1,"t");
lf[354]=C_static_string(C_heaptop,35,"=C_restore_rest(a,C_rest_count(0));");
lf[355]=C_static_string(C_heaptop,1,"t");
lf[356]=C_static_string(C_heaptop,42,"=C_restore_rest_vector(a,C_rest_count(0));");
lf[357]=C_static_string(C_heaptop,3,");}");
lf[358]=C_static_string(C_heaptop,5,"else{");
lf[359]=C_static_string(C_heaptop,13,"a=C_alloc((c-");
lf[360]=C_static_string(C_heaptop,5,")*3);");
lf[361]=C_static_string(C_heaptop,8,",(void*)");
lf[362]=C_static_string(C_heaptop,1,"r");
lf[363]=C_static_string(C_heaptop,18,"C_save_and_reclaim");
lf[364]=C_static_string(C_heaptop,9,"C_reclaim");
lf[365]=C_static_string(C_heaptop,10,"((void*)tr");
lf[366]=C_static_string(C_heaptop,3,");}");
lf[367]=C_static_string(C_heaptop,5,",NULL");
lf[368]=C_static_string(C_heaptop,8,",(void*)");
lf[369]=C_static_string(C_heaptop,18,"C_save_and_reclaim");
lf[370]=C_static_string(C_heaptop,9,"C_reclaim");
lf[371]=C_static_string(C_heaptop,10,"((void*)tr");
lf[372]=C_static_string(C_heaptop,18,"C_register_lf2(lf,");
lf[373]=C_static_string(C_heaptop,18,",create_ptable());");
lf[374]=C_static_string(C_heaptop,19,"C_initialize_lf(lf,");
lf[375]=C_static_string(C_heaptop,2,");");
lf[376]=C_static_string(C_heaptop,10,"a=C_alloc(");
lf[377]=C_static_string(C_heaptop,2,");");
lf[378]=C_static_string(C_heaptop,15,"if(!C_demand_2(");
lf[379]=C_static_string(C_heaptop,3,")){");
lf[380]=C_static_string(C_heaptop,11,"C_save(t1);");
lf[381]=C_static_string(C_heaptop,13,"C_rereclaim2(");
lf[382]=C_static_string(C_heaptop,20,"*sizeof(C_word), 1);");
lf[383]=C_static_string(C_heaptop,14,"t1=C_restore;}");
lf[384]=C_static_string(C_heaptop,24,"C_check_nursery_minimum(");
lf[385]=C_static_string(C_heaptop,2,");");
lf[386]=C_static_string(C_heaptop,13,"if(!C_demand(");
lf[387]=C_static_string(C_heaptop,3,")){");
lf[388]=C_static_string(C_heaptop,11,"C_save(t1);");
lf[389]=C_static_string(C_heaptop,44,"C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[390]=C_static_string(C_heaptop,23,"toplevel_initialized=1;");
lf[391]=C_h_intern(&lf[391],26,"\010compilertarget-stack-size");
lf[392]=C_static_string(C_heaptop,15,"C_resize_stack(");
lf[393]=C_static_string(C_heaptop,2,");");
lf[394]=C_h_intern(&lf[394],30,"\010compilertarget-heap-shrinkage");
lf[395]=C_static_string(C_heaptop,17,"C_heap_shrinkage=");
lf[396]=C_h_intern(&lf[396],27,"\010compilertarget-heap-growth");
lf[397]=C_static_string(C_heaptop,14,"C_heap_growth=");
lf[398]=C_h_intern(&lf[398],33,"\010compilertarget-initial-heap-size");
lf[399]=C_static_string(C_heaptop,26,"C_set_or_change_heap_size(");
lf[400]=C_static_string(C_heaptop,4,",1);");
lf[401]=C_h_intern(&lf[401],25,"\010compilertarget-heap-size");
lf[402]=C_static_string(C_heaptop,26,"C_set_or_change_heap_size(");
lf[403]=C_static_string(C_heaptop,4,",1);");
lf[404]=C_static_string(C_heaptop,23,"C_heap_size_is_fixed=1;");
lf[405]=C_h_intern(&lf[405],40,"\010compilerdisable-stack-overflow-checking");
lf[406]=C_static_string(C_heaptop,27,"C_disable_overflow_check=1;");
lf[407]=C_static_string(C_heaptop,10,"C_word *a;");
lf[408]=C_static_string(C_heaptop,59,"if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[409]=C_static_string(C_heaptop,30,"else C_toplevel_entry(C_text(\042");
lf[410]=C_static_string(C_heaptop,4,"\042));");
lf[411]=C_h_intern(&lf[411],4,"fold");
lf[412]=C_static_string(C_heaptop,29,"if(!C_demand(c*C_SIZEOF_PAIR+");
lf[413]=C_static_string(C_heaptop,3,")){");
lf[414]=C_h_intern(&lf[414],28,"\010compilerinsert-timer-checks");
lf[415]=C_static_string(C_heaptop,22,"C_check_for_interrupt;");
lf[416]=C_static_string(C_heaptop,5,"if(c<");
lf[417]=C_static_string(C_heaptop,21,") C_bad_min_argc_2(c,");
lf[418]=C_static_string(C_heaptop,5,",t0);");
lf[419]=C_h_intern(&lf[419],14,"no-argc-checks");
lf[420]=C_static_string(C_heaptop,4,",c2,");
lf[421]=C_static_string(C_heaptop,2,");");
lf[422]=C_static_string(C_heaptop,1,"c");
lf[423]=C_static_string(C_heaptop,12,"C_save_rest(");
lf[424]=C_static_string(C_heaptop,15,"C_word *a,c2=c;");
lf[425]=C_static_string(C_heaptop,10,"va_list v;");
lf[426]=C_static_string(C_heaptop,22,"if(!C_stack_probe(a)){");
lf[427]=C_static_string(C_heaptop,23,"if(!C_stack_probe(&a)){");
lf[428]=C_static_string(C_heaptop,22,"C_check_for_interrupt;");
lf[429]=C_static_string(C_heaptop,5,"if(c<");
lf[430]=C_static_string(C_heaptop,21,") C_bad_min_argc_2(c,");
lf[431]=C_static_string(C_heaptop,5,",t0);");
lf[432]=C_static_string(C_heaptop,6,"if(c!=");
lf[433]=C_static_string(C_heaptop,17,") C_bad_argc_2(c,");
lf[434]=C_static_string(C_heaptop,5,",t0);");
lf[435]=C_static_string(C_heaptop,10,"C_word *a;");
lf[436]=C_static_string(C_heaptop,5,"loop:");
lf[437]=C_static_string(C_heaptop,10,"a=C_alloc(");
lf[438]=C_static_string(C_heaptop,2,");");
lf[439]=C_static_string(C_heaptop,10,"C_word ab[");
lf[440]=C_static_string(C_heaptop,8,"],*a=ab;");
lf[441]=C_static_string(C_heaptop,14,"C_stack_check;");
lf[442]=C_static_string(C_heaptop,5,"loop:");
lf[443]=C_static_string(C_heaptop,10,"C_word *a;");
lf[444]=C_static_string(C_heaptop,8,"C_word t");
lf[445]=C_static_string(C_heaptop,8,"C_word t");
lf[446]=C_static_string(C_heaptop,11,"C_word tmp;");
lf[447]=C_static_string(C_heaptop,2,"){");
lf[448]=C_static_string(C_heaptop,4,",...");
lf[449]=C_static_string(C_heaptop,9,"C_word *a");
lf[450]=C_static_string(C_heaptop,9,"C_word c,");
lf[451]=C_static_string(C_heaptop,33,"C_noret_decl(toplevel_trampoline)");
lf[452]=C_static_string(C_heaptop,71,"static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[453]=C_static_string(C_heaptop,63,"C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[454]=C_static_string(C_heaptop,2,"C_");
lf[455]=C_static_string(C_heaptop,34,"(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[456]=C_static_string(C_heaptop,15,"void C_ccall C_");
lf[457]=C_static_string(C_heaptop,18,"C_main_entry_point");
lf[458]=C_static_string(C_heaptop,40,"static C_TLS int toplevel_initialized=0;");
lf[459]=C_static_string(C_heaptop,8,"C_fcall ");
lf[460]=C_static_string(C_heaptop,8,"C_ccall ");
lf[461]=C_static_string(C_heaptop,7,"C_word ");
lf[462]=C_static_string(C_heaptop,5,"void ");
lf[463]=C_static_string(C_heaptop,7,"static ");
lf[464]=C_static_string(C_heaptop,3,"/* ");
lf[465]=C_static_string(C_heaptop,3," */");
lf[466]=C_h_intern(&lf[466],16,"\010compilercleanup");
lf[467]=C_h_intern(&lf[467],18,"\010compilerdebugging");
lf[468]=C_h_intern(&lf[468],1,"o");
lf[469]=C_static_string(C_heaptop,32,"dropping unused closure argument");
lf[470]=C_static_string(C_heaptop,9,"_toplevel");
lf[471]=C_static_string(C_heaptop,8,"toplevel");
lf[472]=C_static_string(C_heaptop,1,"t");
lf[473]=C_static_string(C_heaptop,1,"t");
lf[474]=C_h_intern(&lf[474],18,"\010compilerreal-name");
lf[475]=C_static_string(C_heaptop,17,"/* end of file */");
lf[476]=C_h_intern(&lf[476],25,"emit-procedure-table-info");
lf[477]=C_h_intern(&lf[477],31,"generate-foreign-callback-stubs");
lf[478]=C_h_intern(&lf[478],31,"\010compilergenerate-foreign-stubs");
lf[479]=C_h_intern(&lf[479],29,"\010compilerforeign-lambda-stubs");
lf[480]=C_h_intern(&lf[480],36,"\010compilergenerate-external-variables");
lf[481]=C_h_intern(&lf[481],27,"\010compilerexternal-variables");
lf[482]=C_h_intern(&lf[482],1,"p");
lf[483]=C_static_string(C_heaptop,24,"code generation phase...");
lf[484]=C_static_string(C_heaptop,1,"{");
lf[485]=C_static_string(C_heaptop,23,"#ifdef C_ENABLE_PTABLES");
lf[486]=C_static_string(C_heaptop,14,"return ptable;");
lf[487]=C_static_string(C_heaptop,5,"#else");
lf[488]=C_static_string(C_heaptop,12,"return NULL;");
lf[489]=C_static_string(C_heaptop,6,"#endif");
lf[490]=C_static_string(C_heaptop,1,"}");
lf[491]=C_static_string(C_heaptop,42,"static C_PTABLE_ENTRY *create_ptable(void)");
lf[492]=C_static_string(C_heaptop,6,"#endif");
lf[493]=C_static_string(C_heaptop,13,"{NULL,NULL}};");
lf[494]=C_static_string(C_heaptop,2,"C_");
lf[495]=C_static_string(C_heaptop,11,"_toplevel},");
lf[496]=C_static_string(C_heaptop,12,"C_toplevel},");
lf[497]=C_static_string(C_heaptop,2,"},");
lf[498]=C_static_string(C_heaptop,2,"{\042");
lf[499]=C_static_string(C_heaptop,9,"\042,(void*)");
lf[500]=C_static_string(C_heaptop,23,"#ifdef C_ENABLE_PTABLES");
lf[501]=C_static_string(C_heaptop,29,"static C_PTABLE_ENTRY ptable[");
lf[502]=C_static_string(C_heaptop,5,"] = {");
lf[503]=C_h_intern(&lf[503],11,"string-copy");
lf[504]=C_static_string(C_heaptop,7,"C_word ");
lf[505]=C_h_intern(&lf[505],13,"list-tabulate");
lf[506]=C_static_string(C_heaptop,0,"");
lf[507]=C_static_string(C_heaptop,7,"static ");
lf[508]=C_h_intern(&lf[508],41,"\010compilergenerate-foreign-callback-header");
lf[509]=C_static_string(C_heaptop,15,"C_externexport ");
lf[510]=C_static_string(C_heaptop,46,"C_k=C_restore_callback_continuation2(C_level);");
lf[511]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[512]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[513]=C_static_string(C_heaptop,11,"return C_r;");
lf[514]=C_static_string(C_heaptop,13,"#undef return");
lf[515]=C_static_string(C_heaptop,6,"C_ret:");
lf[516]=C_static_string(C_heaptop,46,"C_k=C_restore_callback_continuation2(C_level);");
lf[517]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[518]=C_static_string(C_heaptop,20,"C_kontinue(C_k,C_r);");
lf[519]=C_static_string(C_heaptop,11,"return C_r;");
lf[520]=C_static_string(C_heaptop,2,");");
lf[521]=C_h_intern(&lf[521],4,"void");
lf[522]=C_static_string(C_heaptop,1,"t");
lf[523]=C_static_string(C_heaptop,4,"C_r=");
lf[524]=C_static_string(C_heaptop,51,"int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[525]=C_static_string(C_heaptop,2,"=(");
lf[526]=C_static_string(C_heaptop,3,"C_a");
lf[527]=C_static_string(C_heaptop,2,");");
lf[528]=C_static_string(C_heaptop,0,"");
lf[529]=C_static_string(C_heaptop,3,"t~a");
lf[530]=C_static_string(C_heaptop,50,"C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[531]=C_static_string(C_heaptop,2,"){");
lf[532]=C_static_string(C_heaptop,10,") C_noret;");
lf[533]=C_static_string(C_heaptop,20,"static void C_ccall ");
lf[534]=C_static_string(C_heaptop,37,"(C_word C_c,C_word C_self,C_word C_k,");
lf[535]=C_static_string(C_heaptop,12,") C_regparm;");
lf[536]=C_static_string(C_heaptop,32,"C_regparm static C_word C_fcall ");
lf[537]=C_static_string(C_heaptop,13,"C_noret_decl(");
lf[538]=C_static_string(C_heaptop,1,")");
lf[539]=C_static_string(C_heaptop,20,"static void C_ccall ");
lf[540]=C_static_string(C_heaptop,37,"(C_word C_c,C_word C_self,C_word C_k,");
lf[541]=C_static_string(C_heaptop,22,"static C_word C_fcall ");
lf[542]=C_static_string(C_heaptop,34,"#define return(x) C_cblock C_r = (");
lf[543]=C_static_string(C_heaptop,30,"(x))); goto C_ret; C_cblockend");
lf[544]=C_static_string(C_heaptop,8,"/* from ");
lf[545]=C_static_string(C_heaptop,3," */");
lf[546]=C_h_intern(&lf[546],21,"foreign-stub-callback");
lf[547]=C_h_intern(&lf[547],16,"foreign-stub-cps");
lf[548]=C_static_string(C_heaptop,3,"C_a");
lf[549]=C_h_intern(&lf[549],27,"foreign-stub-argument-names");
lf[550]=C_h_intern(&lf[550],17,"foreign-stub-body");
lf[551]=C_h_intern(&lf[551],17,"foreign-stub-name");
lf[552]=C_h_intern(&lf[552],24,"foreign-stub-return-type");
lf[553]=C_static_string(C_heaptop,12,"C_word C_buf");
lf[554]=C_static_string(C_heaptop,3,"C_a");
lf[555]=C_h_intern(&lf[555],27,"foreign-stub-argument-types");
lf[556]=C_h_intern(&lf[556],19,"\010compilerreal-name2");
lf[557]=C_h_intern(&lf[557],15,"foreign-stub-id");
lf[558]=C_h_intern(&lf[558],5,"float");
lf[559]=C_static_string(C_heaptop,2,"+3");
lf[560]=C_h_intern(&lf[560],8,"c-string");
lf[561]=C_static_string(C_heaptop,4,"+2+(");
lf[562]=C_static_string(C_heaptop,33,"==NULL\0771:C_bytestowords(C_strlen(");
lf[563]=C_static_string(C_heaptop,3,")))");
lf[564]=C_h_intern(&lf[564],16,"nonnull-c-string");
lf[565]=C_static_string(C_heaptop,27,"+2+C_bytestowords(C_strlen(");
lf[566]=C_static_string(C_heaptop,2,"))");
lf[567]=C_h_intern(&lf[567],3,"ref");
lf[568]=C_static_string(C_heaptop,2,"+3");
lf[569]=C_h_intern(&lf[569],5,"const");
lf[570]=C_h_intern(&lf[570],7,"pointer");
lf[571]=C_h_intern(&lf[571],9,"c-pointer");
lf[572]=C_h_intern(&lf[572],15,"nonnull-pointer");
lf[573]=C_h_intern(&lf[573],17,"nonnull-c-pointer");
lf[574]=C_h_intern(&lf[574],8,"function");
lf[575]=C_h_intern(&lf[575],8,"instance");
lf[576]=C_h_intern(&lf[576],16,"nonnull-instance");
lf[577]=C_h_intern(&lf[577],12,"instance-ref");
lf[578]=C_h_intern(&lf[578],18,"\003syshash-table-ref");
lf[579]=C_h_intern(&lf[579],27,"\010compilerforeign-type-table");
lf[580]=C_h_intern(&lf[580],17,"nonnull-c-string*");
lf[581]=C_h_intern(&lf[581],25,"nonnull-unsigned-c-string");
lf[582]=C_h_intern(&lf[582],26,"nonnull-unsigned-c-string*");
lf[583]=C_h_intern(&lf[583],6,"symbol");
lf[584]=C_h_intern(&lf[584],9,"c-string*");
lf[585]=C_h_intern(&lf[585],17,"unsigned-c-string");
lf[586]=C_h_intern(&lf[586],18,"unsigned-c-string*");
lf[587]=C_h_intern(&lf[587],6,"double");
lf[588]=C_h_intern(&lf[588],16,"unsigned-integer");
lf[589]=C_h_intern(&lf[589],18,"unsigned-integer32");
lf[590]=C_h_intern(&lf[590],4,"long");
lf[591]=C_h_intern(&lf[591],7,"integer");
lf[592]=C_h_intern(&lf[592],9,"integer32");
lf[593]=C_h_intern(&lf[593],13,"unsigned-long");
lf[594]=C_h_intern(&lf[594],6,"number");
lf[595]=C_h_intern(&lf[595],9,"integer64");
lf[596]=C_h_intern(&lf[596],13,"c-string-list");
lf[597]=C_h_intern(&lf[597],14,"c-string-list*");
lf[598]=C_h_intern(&lf[598],3,"int");
lf[599]=C_h_intern(&lf[599],5,"int32");
lf[600]=C_h_intern(&lf[600],5,"short");
lf[601]=C_h_intern(&lf[601],14,"unsigned-short");
lf[602]=C_h_intern(&lf[602],13,"scheme-object");
lf[603]=C_h_intern(&lf[603],13,"unsigned-char");
lf[604]=C_h_intern(&lf[604],12,"unsigned-int");
lf[605]=C_h_intern(&lf[605],14,"unsigned-int32");
lf[606]=C_h_intern(&lf[606],4,"byte");
lf[607]=C_h_intern(&lf[607],13,"unsigned-byte");
lf[608]=C_static_string(C_heaptop,2,";}");
lf[609]=C_static_string(C_heaptop,27,"C_callback_wrapper((void *)");
lf[610]=C_static_string(C_heaptop,7,"return ");
lf[611]=C_static_string(C_heaptop,2,"x=");
lf[612]=C_static_string(C_heaptop,2,");");
lf[613]=C_static_string(C_heaptop,10,"C_save(x);");
lf[614]=C_static_string(C_heaptop,1,"a");
lf[615]=C_static_string(C_heaptop,29,"C_callback_adjust_stack(a,s);");
lf[616]=C_static_string(C_heaptop,11,"C_word x,s=");
lf[617]=C_static_string(C_heaptop,15,",*a=C_alloc(s);");
lf[618]=C_static_string(C_heaptop,0,"");
lf[619]=C_static_string(C_heaptop,8,"/* from ");
lf[620]=C_static_string(C_heaptop,3," */");
lf[621]=C_static_string(C_heaptop,1,"0");
lf[622]=C_static_string(C_heaptop,1,"t");
lf[623]=C_h_intern(&lf[623],36,"foreign-callback-stub-argument-types");
lf[624]=C_h_intern(&lf[624],33,"foreign-callback-stub-return-type");
lf[625]=C_h_intern(&lf[625],24,"foreign-callback-stub-id");
lf[626]=C_static_string(C_heaptop,0,"");
lf[627]=C_static_string(C_heaptop,1,"t");
lf[628]=C_h_intern(&lf[628],32,"foreign-callback-stub-qualifiers");
lf[629]=C_h_intern(&lf[629],26,"foreign-callback-stub-name");
lf[630]=C_h_intern(&lf[630],4,"quit");
lf[631]=C_static_string(C_heaptop,25,"illegal foreign type `~A\047");
lf[632]=C_static_string(C_heaptop,1," ");
lf[633]=C_static_string(C_heaptop,6,"C_word");
lf[634]=C_static_string(C_heaptop,6,"C_char");
lf[635]=C_static_string(C_heaptop,15,"unsigned C_char");
lf[636]=C_static_string(C_heaptop,12,"unsigned int");
lf[637]=C_static_string(C_heaptop,5,"C_u32");
lf[638]=C_static_string(C_heaptop,3,"int");
lf[639]=C_static_string(C_heaptop,5,"C_s32");
lf[640]=C_static_string(C_heaptop,5,"C_s64");
lf[641]=C_static_string(C_heaptop,5,"short");
lf[642]=C_static_string(C_heaptop,4,"long");
lf[643]=C_static_string(C_heaptop,14,"unsigned short");
lf[644]=C_static_string(C_heaptop,13,"unsigned long");
lf[645]=C_static_string(C_heaptop,5,"float");
lf[646]=C_static_string(C_heaptop,6,"double");
lf[647]=C_static_string(C_heaptop,6,"void *");
lf[648]=C_static_string(C_heaptop,6,"void *");
lf[649]=C_static_string(C_heaptop,9,"C_char **");
lf[650]=C_h_intern(&lf[650],11,"byte-vector");
lf[651]=C_h_intern(&lf[651],19,"nonnull-byte-vector");
lf[652]=C_static_string(C_heaptop,15,"unsigned char *");
lf[653]=C_h_intern(&lf[653],4,"blob");
lf[654]=C_static_string(C_heaptop,15,"unsigned char *");
lf[655]=C_h_intern(&lf[655],9,"u16vector");
lf[656]=C_h_intern(&lf[656],17,"nonnull-u16vector");
lf[657]=C_static_string(C_heaptop,16,"unsigned short *");
lf[658]=C_h_intern(&lf[658],8,"s8vector");
lf[659]=C_h_intern(&lf[659],16,"nonnull-s8vector");
lf[660]=C_static_string(C_heaptop,6,"char *");
lf[661]=C_h_intern(&lf[661],9,"u32vector");
lf[662]=C_h_intern(&lf[662],17,"nonnull-u32vector");
lf[663]=C_static_string(C_heaptop,14,"unsigned int *");
lf[664]=C_h_intern(&lf[664],9,"s16vector");
lf[665]=C_h_intern(&lf[665],17,"nonnull-s16vector");
lf[666]=C_static_string(C_heaptop,7,"short *");
lf[667]=C_h_intern(&lf[667],9,"s32vector");
lf[668]=C_h_intern(&lf[668],17,"nonnull-s32vector");
lf[669]=C_static_string(C_heaptop,5,"int *");
lf[670]=C_h_intern(&lf[670],9,"f32vector");
lf[671]=C_h_intern(&lf[671],17,"nonnull-f32vector");
lf[672]=C_static_string(C_heaptop,7,"float *");
lf[673]=C_h_intern(&lf[673],9,"f64vector");
lf[674]=C_h_intern(&lf[674],17,"nonnull-f64vector");
lf[675]=C_static_string(C_heaptop,8,"double *");
lf[676]=C_static_string(C_heaptop,6,"char *");
lf[677]=C_static_string(C_heaptop,4,"void");
lf[678]=C_static_string(C_heaptop,1,"*");
lf[679]=C_static_string(C_heaptop,1,"*");
lf[680]=C_static_string(C_heaptop,1,"&");
lf[681]=C_h_intern(&lf[681],8,"template");
lf[682]=C_static_string(C_heaptop,1,"<");
lf[683]=C_static_string(C_heaptop,2,"> ");
lf[684]=C_static_string(C_heaptop,1,",");
lf[685]=C_static_string(C_heaptop,0,"");
lf[686]=C_static_string(C_heaptop,0,"");
lf[687]=C_static_string(C_heaptop,6,"const ");
lf[688]=C_h_intern(&lf[688],6,"struct");
lf[689]=C_static_string(C_heaptop,7,"struct ");
lf[690]=C_static_string(C_heaptop,1," ");
lf[691]=C_h_intern(&lf[691],5,"union");
lf[692]=C_static_string(C_heaptop,6,"union ");
lf[693]=C_static_string(C_heaptop,1," ");
lf[694]=C_h_intern(&lf[694],4,"enum");
lf[695]=C_static_string(C_heaptop,5,"enum ");
lf[696]=C_static_string(C_heaptop,1," ");
lf[697]=C_static_string(C_heaptop,1,"&");
lf[698]=C_static_string(C_heaptop,0,"");
lf[699]=C_static_string(C_heaptop,3," (*");
lf[700]=C_static_string(C_heaptop,2,")(");
lf[701]=C_static_string(C_heaptop,1,")");
lf[702]=C_static_string(C_heaptop,1,",");
lf[703]=C_h_intern(&lf[703],3,"...");
lf[704]=C_static_string(C_heaptop,3,"...");
lf[705]=C_static_string(C_heaptop,0,"");
lf[706]=C_static_string(C_heaptop,0,"");
lf[707]=C_h_intern(&lf[707],12,"nonnull-blob");
lf[708]=C_h_intern(&lf[708],8,"u8vector");
lf[709]=C_h_intern(&lf[709],16,"nonnull-u8vector");
lf[710]=C_h_intern(&lf[710],14,"scheme-pointer");
lf[711]=C_h_intern(&lf[711],22,"nonnull-scheme-pointer");
lf[712]=C_static_string(C_heaptop,34,"illegal foreign argument type `~A\047");
lf[713]=C_static_string(C_heaptop,1,"(");
lf[714]=C_static_string(C_heaptop,25,"C_character_code((C_word)");
lf[715]=C_static_string(C_heaptop,8,"C_unfix(");
lf[716]=C_static_string(C_heaptop,8,"C_unfix(");
lf[717]=C_static_string(C_heaptop,24,"(unsigned short)C_unfix(");
lf[718]=C_static_string(C_heaptop,23,"C_num_to_unsigned_long(");
lf[719]=C_static_string(C_heaptop,11,"C_c_double(");
lf[720]=C_static_string(C_heaptop,13,"C_num_to_int(");
lf[721]=C_static_string(C_heaptop,15,"C_num_to_int64(");
lf[722]=C_static_string(C_heaptop,14,"C_num_to_long(");
lf[723]=C_static_string(C_heaptop,22,"C_num_to_unsigned_int(");
lf[724]=C_static_string(C_heaptop,23,"C_data_pointer_or_null(");
lf[725]=C_static_string(C_heaptop,15,"C_data_pointer(");
lf[726]=C_static_string(C_heaptop,23,"C_data_pointer_or_null(");
lf[727]=C_static_string(C_heaptop,15,"C_data_pointer(");
lf[728]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[729]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[730]=C_static_string(C_heaptop,23,"C_c_bytevector_or_null(");
lf[731]=C_static_string(C_heaptop,15,"C_c_bytevector(");
lf[732]=C_static_string(C_heaptop,23,"C_c_bytevector_or_null(");
lf[733]=C_static_string(C_heaptop,15,"C_c_bytevector(");
lf[734]=C_static_string(C_heaptop,21,"C_c_u8vector_or_null(");
lf[735]=C_static_string(C_heaptop,13,"C_c_u8vector(");
lf[736]=C_static_string(C_heaptop,22,"C_c_u16vector_or_null(");
lf[737]=C_static_string(C_heaptop,14,"C_c_u16vector(");
lf[738]=C_static_string(C_heaptop,22,"C_c_u32vector_or_null(");
lf[739]=C_static_string(C_heaptop,14,"C_c_u32vector(");
lf[740]=C_static_string(C_heaptop,21,"C_c_s8vector_or_null(");
lf[741]=C_static_string(C_heaptop,13,"C_c_s8vector(");
lf[742]=C_static_string(C_heaptop,22,"C_c_s16vector_or_null(");
lf[743]=C_static_string(C_heaptop,14,"C_c_s16vector(");
lf[744]=C_static_string(C_heaptop,22,"C_c_s32vector_or_null(");
lf[745]=C_static_string(C_heaptop,14,"C_c_s32vector(");
lf[746]=C_static_string(C_heaptop,22,"C_c_f32vector_or_null(");
lf[747]=C_static_string(C_heaptop,14,"C_c_f32vector(");
lf[748]=C_static_string(C_heaptop,22,"C_c_f64vector_or_null(");
lf[749]=C_static_string(C_heaptop,14,"C_c_f64vector(");
lf[750]=C_static_string(C_heaptop,17,"C_string_or_null(");
lf[751]=C_static_string(C_heaptop,11,"C_c_string(");
lf[752]=C_static_string(C_heaptop,8,"C_truep(");
lf[753]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[754]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[755]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[756]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[757]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[758]=C_static_string(C_heaptop,15,"C_c_pointer_nn(");
lf[759]=C_static_string(C_heaptop,20,"C_c_pointer_or_null(");
lf[760]=C_static_string(C_heaptop,13,"C_num_to_int(");
lf[761]=C_static_string(C_heaptop,2,"*(");
lf[762]=C_static_string(C_heaptop,16,")C_c_pointer_nn(");
lf[763]=C_static_string(C_heaptop,1,"*");
lf[764]=C_static_string(C_heaptop,2,"*(");
lf[765]=C_static_string(C_heaptop,17,"*)C_c_pointer_nn(");
lf[766]=C_static_string(C_heaptop,32,"illegal foreign return type `~A\047");
lf[767]=C_static_string(C_heaptop,25,"C_make_character((C_word)");
lf[768]=C_static_string(C_heaptop,14,"C_fix((C_word)");
lf[769]=C_static_string(C_heaptop,37,"C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[770]=C_static_string(C_heaptop,13,"C_fix((short)");
lf[771]=C_static_string(C_heaptop,21,"C_fix(0xffff&(C_word)");
lf[772]=C_static_string(C_heaptop,12,"C_fix((char)");
lf[773]=C_static_string(C_heaptop,19,"C_fix(0xff&(C_word)");
lf[774]=C_static_string(C_heaptop,13,"C_flonum(&~a,");
lf[775]=C_static_string(C_heaptop,13,"C_number(&~a,");
lf[776]=C_static_string(C_heaptop,22,"C_mpointer(&~a,(void*)");
lf[777]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~a,(void*)");
lf[778]=C_static_string(C_heaptop,17,"C_int_to_num(&~a,");
lf[779]=C_static_string(C_heaptop,22,"C_a_double_to_num(&~a,");
lf[780]=C_static_string(C_heaptop,26,"C_unsigned_int_to_num(&~a,");
lf[781]=C_static_string(C_heaptop,18,"C_long_to_num(&~a,");
lf[782]=C_static_string(C_heaptop,27,"C_unsigned_long_to_num(&~a,");
lf[783]=C_static_string(C_heaptop,10,"C_mk_bool(");
lf[784]=C_static_string(C_heaptop,9,"((C_word)");
lf[785]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~a,(void*)");
lf[786]=C_static_string(C_heaptop,22,"C_mpointer(&~A,(void*)");
lf[787]=C_static_string(C_heaptop,23,"C_mpointer(&~A,(void*)&");
lf[788]=C_static_string(C_heaptop,31,"C_mpointer_or_false(&~A,(void*)");
lf[789]=C_static_string(C_heaptop,22,"C_mpointer(&~A,(void*)");
lf[790]=C_static_string(C_heaptop,23,"C_mpointer(&~A,(void*)&");
lf[791]=C_static_string(C_heaptop,22,"C_mpointer(&~a,(void*)");
lf[792]=C_static_string(C_heaptop,17,"C_int_to_num(&~a,");
lf[793]=C_static_string(C_heaptop,3,"\377\006\001");
lf[794]=C_static_string(C_heaptop,3,"\377\006\000");
lf[795]=C_static_string(C_heaptop,2,"\377\012");
lf[796]=C_static_string(C_heaptop,2,"\377\016");
lf[797]=C_static_string(C_heaptop,2,"\377>");
lf[798]=C_static_string(C_heaptop,2,"\377\036");
lf[799]=C_static_string(C_heaptop,2,"\377\001");
lf[800]=C_static_string(C_heaptop,1,"U");
lf[801]=C_static_string(C_heaptop,1,"\000");
lf[802]=C_static_string(C_heaptop,1,"\001");
lf[803]=C_static_string(C_heaptop,32,"invalid literal - can not encode");
lf[804]=C_h_intern(&lf[804],17,"\003sysstring-append");
lf[805]=C_static_string(C_heaptop,0,"");
lf[806]=C_h_intern(&lf[806],5,"cons*");
lf[807]=C_h_intern(&lf[807],29,"\010compilerstring->c-identifier");
lf[808]=C_static_string(C_heaptop,8,"C_~X_~A_");
lf[809]=C_h_intern(&lf[809],6,"random");
C_register_lf2(lf,810,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1078 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1081 in k1078 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1084 in k1081 in k1078 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1092,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1113,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8722,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8726,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 108  random */
t9=C_retrieve(lf[809]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8724 in k1084 in k1081 in k1078 */
static void C_ccall f_8726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8730,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 108  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8728 in k8724 in k1084 in k1081 in k1078 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 108  sprintf */
t2=C_retrieve(lf[330]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[808],((C_word*)t0)[2],t1);}

/* k8720 in k1084 in k1081 in k1078 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 107  string->c-identifier */
t2=C_retrieve(lf[807]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1133,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[476]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4613,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[466]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4686,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[257]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4775,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4791,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4807,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4858,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4876,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[477]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5109,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[508]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5540,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5605,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6822,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7655,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8429,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8429,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8432,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8435,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8438,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8491,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8491(2,t8,lf[793]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8491(2,t9,lf[794]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8438(C_a_i(&a,4),t9);
/* c-backend.scm: 1358 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[795],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8491(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8491(2,t9,lf[797]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8491(2,t11,lf[798]);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8541,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1362 big-fixnum? */
t13=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}
else{
t12=t11;
f_8541(t12,C_SCHEME_FALSE);}}}}}}}}

/* k8712 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8541(t2,(C_word)C_i_not(t1));}

/* k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[6]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1363 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[5],lf[799],t13);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8605,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1370 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_i_string_length(t2);
t4=f_8438(C_a_i(&a,4),t3);
/* c-backend.scm: 1373 string-append */
t5=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[5],lf[802],t4,t2);}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[6]))){
/* c-backend.scm: 1378 bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],lf[803],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8644,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=f_8432(((C_word*)t0)[6]);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_a_i_string(&a,1,t4);
t6=f_8435(((C_word*)t0)[6]);
t7=f_8438(C_a_i(&a,4),t6);
/* c-backend.scm: 1381 string-append */
t8=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t2,t5,t7);}
else{
t2=f_8435(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8674,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=f_8432(((C_word*)t0)[6]);
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_string(&a,1,t5);
t7=f_8438(C_a_i(&a,4),t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8686,a[2]=t7,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1391 list-tabulate */
t10=C_retrieve(lf[505]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t2,t9);}}}}}}

/* a8687 in k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8688,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1391 encode-literal */
t4=C_retrieve(lf[326]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8684 in k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1388 cons* */
t2=C_retrieve(lf[806]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8672 in k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1387 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[805]);}

/* k8642 in k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1380 ##sys#string-append */
t2=C_retrieve(lf[804]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8603 in k8539 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1370 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[800],t1,lf[801]);}

/* k8489 in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_8491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8491,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1354 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static C_word C_fcall f_8438(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static C_word C_fcall f_8435(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1041(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1129 in k1084 in k1081 in k1078 */
static C_word C_fcall f_8432(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1037(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_7655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7655,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[603]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[767]);}
else{
t8=(C_word)C_eqp(t5,lf[598]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[599]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[768]);}
else{
t10=(C_word)C_eqp(t5,lf[604]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[769]);}
else{
t12=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[770]);}
else{
t13=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[771]);}
else{
t14=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[772]);}
else{
t15=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[773]);}
else{
t16=(C_word)C_eqp(t5,lf[558]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[587]));
if(C_truep(t17)){
/* c-backend.scm: 1292 sprintf */
t18=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[774],t3);}
else{
t18=(C_word)C_eqp(t5,lf[594]);
if(C_truep(t18)){
/* c-backend.scm: 1293 sprintf */
t19=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[775],t3);}
else{
t19=(C_word)C_eqp(t5,lf[564]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7742,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7742(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[560]);
if(C_truep(t21)){
t22=t20;
f_7742(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[573]);
if(C_truep(t22)){
t23=t20;
f_7742(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t23)){
t24=t20;
f_7742(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[580]);
if(C_truep(t24)){
t25=t20;
f_7742(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t25)){
t26=t20;
f_7742(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t26)){
t27=t20;
f_7742(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[581]);
if(C_truep(t27)){
t28=t20;
f_7742(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t28)){
t29=t20;
f_7742(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t29)){
t30=t20;
f_7742(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[596]);
t31=t20;
f_7742(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[597])));}}}}}}}}}}}}}}}}}}}}

/* k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7742,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1297 sprintf */
t2=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[776],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
if(C_truep(t2)){
/* c-backend.scm: 1298 sprintf */
t3=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[777],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[591]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[592]));
if(C_truep(t4)){
/* c-backend.scm: 1299 sprintf */
t5=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t5)){
/* c-backend.scm: 1300 sprintf */
t6=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[589]));
if(C_truep(t7)){
/* c-backend.scm: 1301 sprintf */
t8=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
if(C_truep(t8)){
/* c-backend.scm: 1302 sprintf */
t9=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
if(C_truep(t9)){
/* c-backend.scm: 1303 sprintf */
t10=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[783]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[521]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[602]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[784]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1307 ##sys#hash-table-ref */
t14=C_retrieve(lf[578]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[579]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7823(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7823,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1309 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7878,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7878(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7878(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7914,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7914(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7914(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[567]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7950,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7950(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7950(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7985,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7985(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7985(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7985(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[576]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8033,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8033(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8033(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8033(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[577]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8081,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8081(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8081(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8081(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[569]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8129,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8129(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8129(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[570]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8164,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8164(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8164(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[571]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8200,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8200(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8200(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[574]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1311 sprintf */
t28=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[791],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1311 g1012 */
t26=t2;
f_7846(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8258,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[694]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8258(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8258(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8258(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1311 g1012 */
t5=t2;
f_7846(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1328 err */
t2=((C_word*)t0)[2];
f_7657(t2,((C_word*)t0)[5]);}}}

/* k8256 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 sprintf */
t3=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k8198 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 g1009 */
t3=((C_word*)t0)[4];
f_7851(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[3]);}}

/* k8162 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 g1009 */
t3=((C_word*)t0)[4];
f_7851(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[3]);}}

/* k8127 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k8079 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 sprintf */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k8031 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_8033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 sprintf */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k7983 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 sprintf */
t4=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[788],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k7948 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 sprintf */
t3=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[787],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[4]);}}

/* k7912 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 g1003 */
t3=((C_word*)t0)[4];
f_7856(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[3]);}}

/* k7876 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1311 g1003 */
t3=((C_word*)t0)[4];
f_7856(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1311 g1012 */
t2=((C_word*)t0)[2];
f_7846(t2,((C_word*)t0)[3]);}}

/* g1003 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7856,NULL,2,t0,t1);}
/* c-backend.scm: 1313 sprintf */
t2=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[786],((C_word*)t0)[2]);}

/* g1009 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7851,NULL,2,t0,t1);}
/* c-backend.scm: 1324 sprintf */
t2=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[785],((C_word*)t0)[2]);}

/* g1012 in k7821 in k7740 in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7846,NULL,2,t0,t1);}
/* c-backend.scm: 1327 err */
t2=((C_word*)t0)[2];
f_7657(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7657,NULL,2,t0,t1);}
/* c-backend.scm: 1283 quit */
t2=C_retrieve(lf[630]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[766],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[602]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[713]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[603]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[714]);}
else{
t8=(C_word)C_eqp(t4,lf[606]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6852,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6852(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[598]);
if(C_truep(t10)){
t11=t9;
f_6852(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t11)){
t12=t9;
f_6852(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[605]);
t13=t9;
f_6852(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[607])));}}}}}}

/* k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6852,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[715]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[716]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[601]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[717]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[718]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6879(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
t8=t6;
f_6879(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[558])));}}}}}}

/* k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6879,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[719]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[591]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[592]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[720]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[721]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[722]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[589]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[723]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[570]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[724]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[725]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[726]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[727]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[728]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[729]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[730]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[707]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[731]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[650]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[732]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[651]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[733]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[708]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[734]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[735]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[736]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[656]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[737]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[738]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[662]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[739]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[740]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[659]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[741]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[742]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[665]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[743]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[744]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[668]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[745]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[746]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[671]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[747]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[748]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[749]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[560]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7074(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
if(C_truep(t36)){
t37=t35;
f_7074(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[585]);
t38=t35;
f_7074(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[586])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7074,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[750]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[564]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7083(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[580]);
if(C_truep(t4)){
t5=t3;
f_7083(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[581]);
if(C_truep(t5)){
t6=t3;
f_7083(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
t7=t3;
f_7083(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[583])));}}}}}

/* k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7083,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[751]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[752]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1259 ##sys#hash-table-ref */
t4=C_retrieve(lf[578]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[579]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7092(2,t4,C_SCHEME_FALSE);}}}}

/* k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1261 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[570]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7137,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7137(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7137(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7169,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7169(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7169(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[571]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7201,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7201(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7201(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7233,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7233(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7233(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7265,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7265(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7265(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7265(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[576]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7310,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7310(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7310(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7310(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[574]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[759]);}
else{
/* c-backend.scm: 1263 g939 */
t18=t2;
f_7115(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[569]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7380,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7380(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7380(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[694]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7415,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7415(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7415(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[567]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7447,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7447(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7447(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7480,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[577]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7480(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7480(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7480(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7480(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1263 g939 */
t3=t2;
f_7115(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1277 err */
t2=((C_word*)t0)[2];
f_6824(t2,((C_word*)t0)[4]);}}}

/* k7478 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1263 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[764],t2,lf[765]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7445 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7447,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1263 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[763]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7455 in k7445 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1263 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[761],t1,lf[762]);}

/* k7413 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[760]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7378 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1263 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7308 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[758]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7263 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[757]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7231 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7199 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7167 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* k7135 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[753]);}
else{
/* c-backend.scm: 1263 g939 */
t2=((C_word*)t0)[2];
f_7115(t2,((C_word*)t0)[3]);}}

/* g939 in k7090 in k7081 in k7072 in k6877 in k6850 in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_7115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7115,NULL,2,t0,t1);}
/* c-backend.scm: 1276 err */
t2=((C_word*)t0)[2];
f_6824(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6824,NULL,2,t0,t1);}
/* c-backend.scm: 1213 quit */
t2=C_retrieve(lf[630]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[712],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5605,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5612,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[602]);
if(C_truep(t7)){
/* c-backend.scm: 1133 str */
t8=t5;
f_5612(t8,t1,lf[633]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[606]));
if(C_truep(t9)){
/* c-backend.scm: 1134 str */
t10=t5;
f_5612(t10,t1,lf[634]);}
else{
t10=(C_word)C_eqp(t6,lf[603]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[607]));
if(C_truep(t11)){
/* c-backend.scm: 1135 str */
t12=t5;
f_5612(t12,t1,lf[635]);}
else{
t12=(C_word)C_eqp(t6,lf[604]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[588]));
if(C_truep(t13)){
/* c-backend.scm: 1136 str */
t14=t5;
f_5612(t14,t1,lf[636]);}
else{
t14=(C_word)C_eqp(t6,lf[605]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[589]));
if(C_truep(t15)){
/* c-backend.scm: 1137 str */
t16=t5;
f_5612(t16,t1,lf[637]);}
else{
t16=(C_word)C_eqp(t6,lf[598]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5682,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5682(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[591]);
t19=t17;
f_5682(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5682,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1138 str */
t2=((C_word*)t0)[7];
f_5612(t2,((C_word*)t0)[6],lf[638]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[592]));
if(C_truep(t3)){
/* c-backend.scm: 1139 str */
t4=((C_word*)t0)[7];
f_5612(t4,((C_word*)t0)[6],lf[639]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t4)){
/* c-backend.scm: 1140 str */
t5=((C_word*)t0)[7];
f_5612(t5,((C_word*)t0)[6],lf[640]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t5)){
/* c-backend.scm: 1141 str */
t6=((C_word*)t0)[7];
f_5612(t6,((C_word*)t0)[6],lf[641]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
/* c-backend.scm: 1142 str */
t7=((C_word*)t0)[7];
f_5612(t7,((C_word*)t0)[6],lf[642]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
if(C_truep(t7)){
/* c-backend.scm: 1143 str */
t8=((C_word*)t0)[7];
f_5612(t8,((C_word*)t0)[6],lf[643]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t8)){
/* c-backend.scm: 1144 str */
t9=((C_word*)t0)[7];
f_5612(t9,((C_word*)t0)[6],lf[644]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[558]);
if(C_truep(t9)){
/* c-backend.scm: 1145 str */
t10=((C_word*)t0)[7];
f_5612(t10,((C_word*)t0)[6],lf[645]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t11)){
/* c-backend.scm: 1146 str */
t12=((C_word*)t0)[7];
f_5612(t12,((C_word*)t0)[6],lf[646]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[570]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[572]));
if(C_truep(t13)){
/* c-backend.scm: 1148 str */
t14=((C_word*)t0)[7];
f_5612(t14,((C_word*)t0)[6],lf[647]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5784(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t16)){
t17=t15;
f_5784(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t18=t15;
f_5784(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}}}}}}}}

/* k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5784,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1149 str */
t2=((C_word*)t0)[7];
f_5612(t2,((C_word*)t0)[6],lf[648]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[597]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[649]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[650]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[651]));
if(C_truep(t5)){
/* c-backend.scm: 1152 str */
t6=((C_word*)t0)[7];
f_5612(t6,((C_word*)t0)[6],lf[652]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[653]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5817(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[707]);
if(C_truep(t8)){
t9=t7;
f_5817(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[708]);
t10=t7;
f_5817(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[709])));}}}}}}

/* k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5817,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1153 str */
t2=((C_word*)t0)[7];
f_5612(t2,((C_word*)t0)[6],lf[654]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[656]));
if(C_truep(t3)){
/* c-backend.scm: 1154 str */
t4=((C_word*)t0)[7];
f_5612(t4,((C_word*)t0)[6],lf[657]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[658]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[659]));
if(C_truep(t5)){
/* c-backend.scm: 1155 str */
t6=((C_word*)t0)[7];
f_5612(t6,((C_word*)t0)[6],lf[660]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[661]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[662]));
if(C_truep(t7)){
/* c-backend.scm: 1156 str */
t8=((C_word*)t0)[7];
f_5612(t8,((C_word*)t0)[6],lf[663]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[664]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[665]));
if(C_truep(t9)){
/* c-backend.scm: 1157 str */
t10=((C_word*)t0)[7];
f_5612(t10,((C_word*)t0)[6],lf[666]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[667]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[668]));
if(C_truep(t11)){
/* c-backend.scm: 1158 str */
t12=((C_word*)t0)[7];
f_5612(t12,((C_word*)t0)[6],lf[669]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[670]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[671]));
if(C_truep(t13)){
/* c-backend.scm: 1159 str */
t14=((C_word*)t0)[7];
f_5612(t14,((C_word*)t0)[6],lf[672]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[673]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[674]));
if(C_truep(t15)){
/* c-backend.scm: 1160 str */
t16=((C_word*)t0)[7];
f_5612(t16,((C_word*)t0)[6],lf[675]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[564]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5913(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t18)){
t19=t17;
f_5913(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[580]);
if(C_truep(t19)){
t20=t17;
f_5913(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t20)){
t21=t17;
f_5913(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[581]);
if(C_truep(t21)){
t22=t17;
f_5913(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t22)){
t23=t17;
f_5913(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
t24=t17;
f_5913(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[583])));}}}}}}}}}}}}}}}

/* k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5913,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1163 str */
t2=((C_word*)t0)[7];
f_5612(t2,((C_word*)t0)[6],lf[676]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[521]);
if(C_truep(t2)){
/* c-backend.scm: 1164 str */
t3=((C_word*)t0)[7];
f_5612(t3,((C_word*)t0)[6],lf[677]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1166 ##sys#hash-table-ref */
t4=C_retrieve(lf[578]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[579]),((C_word*)t0)[3]);}
else{
t4=t3;
f_5928(2,t4,C_SCHEME_FALSE);}}}}

/* k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5928,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1169 str */
t2=((C_word*)t0)[3];
f_5612(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5965,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[570]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6000,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6000(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6000(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[572]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6036,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6036(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6036(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[571]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6072,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6072(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6072(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[573]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6108,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6108(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6108(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[567]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6144,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6144(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6144(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[681]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6183(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6183(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[569]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6243,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6243(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6243(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[688]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6282,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6282(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6282(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[691]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6321,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6321(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6321(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[694]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6360,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6360(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6360(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[575]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6399,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6399(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6399(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6399(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[576]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6449,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6449(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6449(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6449(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[577]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6499,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6499(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6499(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6499(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6545,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[574]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6545(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6545(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6545(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1171 g862 */
t5=t2;
f_5960(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1207 err */
t2=((C_word*)t0)[2];
f_5607(t2,((C_word*)t0)[6]);}}}}

/* k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6561,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1171 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[706]);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6559 in k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6565(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6565(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6565(t3,C_SCHEME_FALSE);}}

/* k6563 in k6559 in k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6565,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[698]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6576,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6578,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6577 in k6563 in k6559 in k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6578,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[703],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[704]);}
else{
/* c-backend.scm: 1171 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[705]);}}

/* k6574 in k6563 in k6559 in k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[702]);}

/* k6570 in k6563 in k6559 in k6543 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[699],((C_word*)t0)[2],lf[700],t1,lf[701]);}

/* k6497 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6499,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1171 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6510 in k6497 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[697],((C_word*)t0)[2]);}

/* k6447 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g859 */
t4=((C_word*)t0)[4];
f_5965(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k6397 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g859 */
t4=((C_word*)t0)[4];
f_5965(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k6358 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1171 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6368 in k6358 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[695],t1,lf[696],((C_word*)t0)[2]);}

/* k6319 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6321,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1171 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6329 in k6319 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[692],t1,lf[693],((C_word*)t0)[2]);}

/* k6280 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6282,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1171 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6290 in k6280 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[689],t1,lf[690],((C_word*)t0)[2]);}

/* k6241 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6243,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1171 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6251 in k6241 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[687],t1);}

/* k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6183,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6200,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1171 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[686]);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k6198 in k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6204,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6210,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6209 in k6198 in k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6210,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[685]);}

/* k6206 in k6198 in k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[684]);}

/* k6202 in k6198 in k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[682],t1,lf[683]);}

/* k6194 in k6181 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[3];
f_5612(t2,((C_word*)t0)[2],t1);}

/* k6142 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6144,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6154,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[680],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[4]);}}

/* k6152 in k6142 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6106 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g849 */
t3=((C_word*)t0)[4];
f_5974(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k6070 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g849 */
t3=((C_word*)t0)[4];
f_5974(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k6034 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g849 */
t3=((C_word*)t0)[4];
f_5974(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* k5998 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_6000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1171 g849 */
t3=((C_word*)t0)[4];
f_5974(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1171 g862 */
t2=((C_word*)t0)[2];
f_5960(t2,((C_word*)t0)[3]);}}

/* g849 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5974,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1173 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[679],((C_word*)t0)[2]);}

/* k5980 in g849 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1173 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g859 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5965,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1187 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5971 in g859 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1187 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[678],((C_word*)t0)[2]);}

/* g862 in k5926 in k5911 in k5815 in k5782 in k5680 in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5960,NULL,2,t0,t1);}
/* c-backend.scm: 1206 err */
t2=((C_word*)t0)[2];
f_5607(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5612,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1131 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[632],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5607,NULL,2,t0,t1);}
/* c-backend.scm: 1130 quit */
t2=C_retrieve(lf[630]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[631],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5540,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5544,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1112 foreign-callback-stub-name */
t5=C_retrieve(lf[629]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1113 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[628]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1114 foreign-callback-stub-return-type */
t3=C_retrieve(lf[624]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5553,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1115 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[623]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1117 make-argument-list */
t4=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[627]);}

/* k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1118 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[626]);}

/* k5601 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1118 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5560 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5570,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1119 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5569 in k5560 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5570,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5574,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5591,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1121 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5589 in a5569 in k5560 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1121 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5572 in a5569 in k5560 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1122 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5563 in k5560 in k5557 in k5551 in k5548 in k5545 in k5542 in ##compiler#generate-foreign-callback-header in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1124 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5109,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5115,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5115,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1059 foreign-callback-stub-id */
t4=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1060 real-name2 */
t3=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5125,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1061 foreign-callback-stub-return-type */
t3=C_retrieve(lf[624]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1062 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[623]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1064 make-argument-list */
t4=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[622]);}

/* k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1091 fold */
t6=C_retrieve(lf[411]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[621],((C_word*)t0)[4],t1);}

/* k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1092 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1094 cleanup */
t4=C_retrieve(lf[466]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5481(2,t3,C_SCHEME_UNDEFINED);}}

/* k5536 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1094 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[619],t1,lf[620]);}

/* k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1095 generate-foreign-callback-header */
t3=C_retrieve(lf[508]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[618],((C_word*)t0)[2]);}

/* k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1096 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[616],((C_word*)t0)[2],lf[617]);}

/* k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1097 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[615]);}

/* k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5523,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1098 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5522 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5523,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5531,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1100 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[614]);}

/* k5529 in a5522 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1100 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[611],t1,((C_word*)t0)[2],lf[612],C_SCHEME_TRUE,lf[613]);}

/* k5491 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[521],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5496(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1105 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5519 in k5491 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[610],t1);}

/* k5494 in k5491 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1106 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[609],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5497 in k5494 in k5491 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[521],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5502(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1107 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5500 in k5497 in k5494 in k5491 in k5488 in k5485 in k5482 in k5479 in k5476 in k5473 in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1108 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[608]);}

/* compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5136,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5146,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5146(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[598]);
if(C_truep(t8)){
t9=t7;
f_5146(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[599]);
if(C_truep(t9)){
t10=t7;
f_5146(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t10)){
t11=t7;
f_5146(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5146(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[521]);
if(C_truep(t12)){
t13=t7;
f_5146(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t13)){
t14=t7;
f_5146(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t14)){
t15=t7;
f_5146(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t15)){
t16=t7;
f_5146(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t16)){
t17=t7;
f_5146(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t17)){
t18=t7;
f_5146(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[606]);
t19=t7;
f_5146(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[607])));}}}}}}}}}}}}

/* k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[558]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5155(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t4)){
t5=t3;
f_5155(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t5)){
t6=t3;
f_5155(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
if(C_truep(t6)){
t7=t3;
f_5155(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t7)){
t8=t3;
f_5155(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t8)){
t9=t3;
f_5155(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t9)){
t10=t3;
f_5155(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t10)){
t11=t3;
f_5155(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t11)){
t12=t3;
f_5155(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t12)){
t13=t3;
f_5155(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t13)){
t14=t3;
f_5155(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t14)){
t15=t3;
f_5155(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
t16=t3;
f_5155(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[597])));}}}}}}}}}}}}}}

/* k5153 in k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5155,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1073 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[559]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5167(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t4)){
t5=t3;
f_5167(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[585]);
if(C_truep(t5)){
t6=t3;
f_5167(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[585]);
t7=t3;
f_5167(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[586])));}}}}}

/* k5165 in k5153 in k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5167,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1075 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561],((C_word*)t0)[5],lf[562],((C_word*)t0)[5],lf[563]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[564]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5179(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[580]);
if(C_truep(t4)){
t5=t3;
f_5179(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[581]);
if(C_truep(t5)){
t6=t3;
f_5179(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
t7=t3;
f_5179(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[583])));}}}}}

/* k5177 in k5165 in k5153 in k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5179,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1077 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[565],((C_word*)t0)[4],lf[566]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1079 ##sys#hash-table-ref */
t3=C_retrieve(lf[578]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[579]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5185(2,t3,C_SCHEME_FALSE);}}}

/* k5183 in k5177 in k5165 in k5153 in k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1081 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5136(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[567]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5219,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5219(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[570]);
if(C_truep(t5)){
t6=t4;
f_5219(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[571]);
if(C_truep(t6)){
t7=t4;
f_5219(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t7)){
t8=t4;
f_5219(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t8)){
t9=t4;
f_5219(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t9)){
t10=t4;
f_5219(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t10)){
t11=t4;
f_5219(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[576]);
t12=t4;
f_5219(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[577])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5217 in k5183 in k5177 in k5165 in k5153 in k5144 in compute-size in k5132 in k5126 in k5123 in k5120 in k5117 in a5114 in generate-foreign-callback-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_5219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1086 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[568]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[569]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1087 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5136(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4876,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4882,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 992  foreign-stub-id */
t4=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 993  real-name2 */
t3=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 994  foreign-stub-argument-types */
t3=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5107,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 996  make-variable-list */
t5=C_retrieve(lf[257]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[554]);}

/* k5105 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[553],t1);
/* c-backend.scm: 996  intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 997  foreign-stub-return-type */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 998  foreign-stub-name */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 999  foreign-stub-body */
t3=C_retrieve(lf[550]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1000 foreign-stub-argument-names */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4913(2,t3,t1);}
else{
/* c-backend.scm: 1000 make-list */
t3=C_retrieve(lf[218]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1001 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[548]);}

/* k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1002 foreign-stub-cps */
t3=C_retrieve(lf[547]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1003 foreign-stub-callback */
t3=C_retrieve(lf[546]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1004 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1006 cleanup */
t4=C_retrieve(lf[466]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4928(2,t3,C_SCHEME_UNDEFINED);}}

/* k5094 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1006 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[544],t1,lf[545]);}

/* k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[542],((C_word*)t0)[6],lf[543]);}
else{
t3=t2;
f_4931(2,t3,C_SCHEME_UNDEFINED);}}

/* k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1011 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[537],((C_word*)t0)[2],lf[538],C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540]);}
else{
/* c-backend.scm: 1013 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],C_make_character(40));}}

/* k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[532],C_SCHEME_TRUE,lf[533],((C_word*)t0)[2],lf[534]);}
else{
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[535],C_SCHEME_TRUE,lf[536],((C_word*)t0)[2],C_make_character(40));}}

/* k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1019 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[531]);}

/* k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1020 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[530]);}

/* k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5044,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1029 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5072 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5043 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5044,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5052,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1026 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1026 sprintf */
t7=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[529],t3);}}

/* k5062 in a5043 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1024 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5050 in a5043 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1027 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[528]);}

/* k5054 in k5050 in a5043 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1028 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5058 in k5054 in k5050 in a5043 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1023 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[525],((C_word*)t0)[3],C_make_character(41),t1,lf[526],((C_word*)t0)[2],lf[527]);}

/* k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1030 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[524]);}
else{
t3=t2;
f_4955(2,t3,C_SCHEME_UNDEFINED);}}

/* k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1032 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[515]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[521]);
if(C_truep(t4)){
/* c-backend.scm: 1043 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1042 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[523],((C_word*)t0)[2]);}}}

/* k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1044 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5026,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1045 make-argument-list */
t5=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[522]);}

/* k5024 in k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1045 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5020 in k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4989 in k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[521]);
if(C_truep(t3)){
t4=t2;
f_4994(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1046 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k4992 in k4989 in k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1047 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[520]);}

/* k4995 in k4992 in k4989 in k4986 in k4983 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1049 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE,lf[517]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1051 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[518]);}
else{
/* c-backend.scm: 1052 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[519]);}}}

/* k4962 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1034 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[514],C_SCHEME_TRUE);}

/* k4965 in k4962 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1036 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE,lf[511]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1038 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512]);}
else{
/* c-backend.scm: 1039 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[513]);}}}

/* k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4929 in k4926 in k4923 in k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4887 in k4884 in a4881 in ##compiler#generate-foreign-stubs in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1053 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4864,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4863 in ##compiler#generate-foreign-callback-stub-prototypes in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 984  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4866 in a4863 in ##compiler#generate-foreign-callback-stub-prototypes in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 985  generate-foreign-callback-header */
t3=C_retrieve(lf[508]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[509],((C_word*)t0)[2]);}

/* k4869 in k4866 in a4863 in ##compiler#generate-foreign-callback-stub-prototypes in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 986  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4811,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 971  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4809 in ##compiler#generate-external-variables in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4816,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4815 in k4809 in ##compiler#generate-external-variables in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4816,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4823,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4823(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4823(t4,C_SCHEME_FALSE);}}

/* k4821 in a4815 in k4809 in ##compiler#generate-external-variables in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4823,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[506]:lf[507]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4843,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 975  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4841 in k4821 in a4815 in k4809 in ##compiler#generate-external-variables in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 975  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4791,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 963  list-tabulate */
t5=C_retrieve(lf[505]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4796 in ##compiler#make-argument-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4797,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 965  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4803 in a4796 in ##compiler#make-argument-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 965  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4775,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4781,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 958  list-tabulate */
t5=C_retrieve(lf[505]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4780 in ##compiler#make-variable-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4781,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 960  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4787 in a4780 in ##compiler#make-variable-list in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 960  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[504],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4686,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4695,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4695(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4695,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4711,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4724,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4724(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4724(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4724(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4724(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4724(t10,C_SCHEME_FALSE);}}}}}

/* k4722 in loop in ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4724,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4727(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4734,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 949  string-copy */
t4=C_retrieve(lf[503]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4711(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4732 in k4722 in loop in ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4727(t3,t2);}

/* k4725 in k4722 in loop in ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4711(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4709 in loop in ##compiler#cleanup in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 952  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4695(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4613,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4617,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 914  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[500],C_SCHEME_TRUE,lf[501],t6,lf[502]);}

/* k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4631(t6,t2,((C_word*)t0)[2]);}

/* do563 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4631,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 918  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[493]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 919  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4642 in do563 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4647,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 920  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[498],t1,((C_word*)t0)[2],lf[499]);}

/* k4645 in k4642 in do563 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[233],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 923  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[494],C_retrieve(lf[185]),lf[495]);}
else{
/* c-backend.scm: 924  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[496]);}}
else{
/* c-backend.scm: 925  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[497]);}}

/* k4648 in k4645 in k4642 in do563 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4631(t3,((C_word*)t0)[2],t2);}

/* k4618 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 926  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[492]);}

/* k4621 in k4618 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 927  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[491]);}

/* k4624 in k4621 in k4618 in k4615 in emit-procedure-table-info in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 928  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[484],C_SCHEME_TRUE,lf[485],C_SCHEME_TRUE,lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490]);}

/* ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1133,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2605,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3134,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3821,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3744,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3457,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3622,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3833,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4580,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 897  debugging */
t25=C_retrieve(lf[467]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[482],lf[483]);}

/* k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 899  header */
t4=((C_word*)t0)[2];
f_2605(t4,t3);}

/* k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 900  declarations */
t3=((C_word*)t0)[2];
f_2771(t3,t2);}

/* k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 901  generate-external-variables */
t3=C_retrieve(lf[480]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[481]));}

/* k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 902  generate-foreign-stubs */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[479]),((C_word*)t0)[3]);}

/* k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 903  prototypes */
t3=((C_word*)t0)[2];
f_2883(t3,t2);}

/* k4594 in k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 904  generate-foreign-callback-stubs */
t3=C_retrieve(lf[477]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 905  trampolines */
t3=((C_word*)t0)[2];
f_3134(t3,t2);}

/* k4600 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 906  procedures */
t3=((C_word*)t0)[2];
f_3833(t3,t2);}

/* k4603 in k4600 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 907  emit-procedure-table-info */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4606 in k4603 in k4600 in k4597 in k4594 in k4591 in k4588 in k4585 in k4582 in k4578 in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 483  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[475],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3833,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 721  lambda-literal-argument-count */
t4=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 722  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 723  real-name */
t3=C_retrieve(lf[474]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3852,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 724  lambda-literal-allocated */
t3=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 725  lambda-literal-rest-argument */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 726  lambda-literal-customizable */
t5=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 727  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3861(t3,C_SCHEME_FALSE);}}

/* k4575 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3861(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 729  make-variable-list */
t5=C_retrieve(lf[257]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[473]);}

/* k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3870,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 730  make-argument-list */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[472]);}

/* k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3873,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 731  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 732  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 733  lambda-literal-external */
t3=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 734  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 735  lambda-literal-direct */
t3=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 736  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 737  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 739  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[470]);}
else{
t3=t2;
f_3894(2,t3,lf[471]);}}

/* k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 741  debugging */
t3=C_retrieve(lf[467]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[468],lf[469],((C_word*)t0)[14]);}
else{
t3=t2;
f_3897(2,t3,C_SCHEME_UNDEFINED);}}

/* k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 742  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 743  cleanup */
t4=C_retrieve(lf[466]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4544 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 743  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[464],t1,lf[465],C_SCHEME_TRUE);}

/* k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[233],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 752  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[458]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 745  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[463]);}}

/* k4505 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[461]:lf[462]);
/* c-backend.scm: 746  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4508 in k4505 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 748  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[459]);}
else{
/* c-backend.scm: 749  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[460]);}}

/* k4511 in k4508 in k4505 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 750  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4527 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4532(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 754  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[457]);}}

/* k4530 in k4527 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 755  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[451],C_SCHEME_TRUE,lf[452],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[456],((C_word*)t0)[2]);}

/* k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3912(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 761  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}}

/* k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4479,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4479(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4479(t4,C_SCHEME_FALSE);}}

/* k4477 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4479,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 763  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}
else{
t2=((C_word*)t0)[2];
f_3915(2,t2,C_SCHEME_UNDEFINED);}}

/* k4480 in k4477 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 764  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3915(2,t2,C_SCHEME_UNDEFINED);}}

/* k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[448]);}
else{
t3=t2;
f_3921(2,t3,C_SCHEME_UNDEFINED);}}

/* k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 767  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[447]);}

/* k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[222]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_3927(t5,t4);}
else{
t4=t2;
f_3927(t4,C_SCHEME_UNDEFINED);}}

/* k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3927,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 769  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[446]);}

/* k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 771  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[444],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4441(t8,t2,((C_word*)t0)[20],t4);}}

/* do450 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4441,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4451,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 775  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[445],t2,C_make_character(59));}}

/* k4449 in do450 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4441(t4,((C_word*)t0)[2],t2,t3);}

/* k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[233],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 777  fold */
t6=C_retrieve(lf[411]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 811  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[425]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4384(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4384(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4382 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[435],C_SCHEME_TRUE,lf[436],C_SCHEME_TRUE,lf[437],((C_word*)t0)[3],lf[438]);}
else{
/* c-backend.scm: 828  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4396(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 830  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[443]);}}}

/* k4394 in k4382 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 831  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[442]);}
else{
t3=t2;
f_4399(2,t3,C_SCHEME_UNDEFINED);}}

/* k4397 in k4394 in k4382 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4405(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[405]))));}
else{
t3=t2;
f_4405(t3,C_SCHEME_FALSE);}}

/* k4403 in k4397 in k4394 in k4382 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 833  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[441]);}
else{
t2=((C_word*)t0)[2];
f_4306(2,t2,C_SCHEME_UNDEFINED);}}

/* k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4348(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[419]);
t6=t3;
f_4348(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4348(t4,C_SCHEME_FALSE);}}

/* k4346 in k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[222]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 837  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429],((C_word*)t0)[3],lf[430],((C_word*)t0)[3],lf[431]);}
else{
t4=((C_word*)t0)[2];
f_4309(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 838  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[432],((C_word*)t0)[3],lf[433],((C_word*)t0)[3],lf[434]);}}
else{
t2=((C_word*)t0)[2];
f_4309(2,t2,C_SCHEME_UNDEFINED);}}

/* k4307 in k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4315(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4315(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4315(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4313 in k4307 in k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4315,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 840  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[428]);}
else{
t3=t2;
f_4318(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_3936(2,t2,C_SCHEME_UNDEFINED);}}

/* k4316 in k4313 in k4307 in k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4324(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4324(t3,C_SCHEME_FALSE);}}

/* k4322 in k4316 in k4313 in k4307 in k4304 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 842  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[426]);}
else{
/* c-backend.scm: 843  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[427]);}}

/* k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 812  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[424]);}

/* k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 813  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[423]);}

/* k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 815  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 816  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[422]);}}

/* k4249 in k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[420],((C_word*)t0)[3],lf[421]);}

/* k4252 in k4249 in k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4269,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4269(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[419]);
if(C_truep(t5)){
t6=t3;
f_4269(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4269(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4267 in k4252 in k4249 in k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 819  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[416],((C_word*)t0)[2],lf[417],((C_word*)t0)[2],lf[418]);}
else{
t2=((C_word*)t0)[3];
f_4257(2,t2,C_SCHEME_UNDEFINED);}}

/* k4255 in k4252 in k4249 in k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 820  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[415]);}
else{
t3=t2;
f_4260(2,t3,C_SCHEME_UNDEFINED);}}

/* k4258 in k4255 in k4252 in k4249 in k4246 in k4243 in k4240 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 821  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[412],((C_word*)t0)[2],lf[413]);}

/* a4227 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4228,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4236,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 777  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3463(3,t5,t4,t2);}

/* k4234 in a4227 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4159,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 779  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[407],C_SCHEME_TRUE,lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[2],lf[410]);}

/* k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[405]))){
/* c-backend.scm: 783  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[406]);}
else{
t3=t2;
f_4162(2,t3,C_SCHEME_UNDEFINED);}}

/* k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4165(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 786  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),lf[400]);}
else{
if(C_truep(C_retrieve(lf[401]))){
/* c-backend.scm: 788  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[402],C_retrieve(lf[401]),lf[403],C_SCHEME_TRUE,lf[404]);}
else{
t4=t3;
f_4196(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4194 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 791  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4199(2,t3,C_SCHEME_UNDEFINED);}}

/* k4197 in k4194 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[394]))){
/* c-backend.scm: 793  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[395],C_retrieve(lf[394]),C_make_character(59));}
else{
t3=t2;
f_4202(2,t3,C_SCHEME_UNDEFINED);}}

/* k4200 in k4197 in k4194 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[391]))){
/* c-backend.scm: 795  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[392],C_retrieve(lf[391]),lf[393]);}
else{
t2=((C_word*)t0)[2];
f_4165(2,t2,C_SCHEME_UNDEFINED);}}

/* k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 796  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[384],((C_word*)t0)[3],lf[385],C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],C_SCHEME_TRUE,lf[389],C_SCHEME_TRUE,lf[390]);}

/* k4166 in k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 801  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379],C_SCHEME_TRUE,lf[380],C_SCHEME_TRUE,lf[381],((C_word*)t0)[2],lf[382],C_SCHEME_TRUE,lf[383]);}

/* k4169 in k4166 in k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 805  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[376],((C_word*)t0)[2],lf[377]);}

/* k4172 in k4169 in k4166 in k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3936(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 807  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[374],((C_word*)t0)[4],lf[375]);}}

/* k4181 in k4172 in k4169 in k4166 in k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 808  literal-frame */
t3=((C_word*)t0)[2];
f_3420(t3,t2);}

/* k4184 in k4181 in k4172 in k4169 in k4166 in k4163 in k4160 in k4157 in k4151 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 809  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[372],((C_word*)t0)[2],lf[373]);}

/* k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[233],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_3959(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_3959(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_3959(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_3959(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_3959(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3959,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[363]:lf[364]);
/* c-backend.scm: 854  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[365],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[369]:lf[370]);
/* c-backend.scm: 880  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[371]);}}
else{
t2=((C_word*)t0)[10];
f_3939(2,t2,C_SCHEME_UNDEFINED);}}

/* k4092 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 882  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[367]);}
else{
/* c-backend.scm: 883  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[368],((C_word*)t0)[3]);}}

/* k4095 in k4092 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4109,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 885  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4100(2,t3,C_SCHEME_UNDEFINED);}}

/* k4107 in k4095 in k4092 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4098 in k4095 in k4092 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 887  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[366]);}

/* k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[307]);
if(C_truep(t3)){
/* c-backend.scm: 855  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_3968(2,t4,C_SCHEME_UNDEFINED);}}

/* k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 856  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[361],((C_word*)t0)[5],lf[362]);}

/* k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 858  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_3974(2,t3,C_SCHEME_UNDEFINED);}}

/* k4073 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 860  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[357],C_SCHEME_TRUE,lf[358],C_SCHEME_TRUE,lf[359],((C_word*)t0)[6],lf[360]);}

/* k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[352]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 864  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[353],((C_word*)t0)[6],lf[354]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[307]);
if(C_truep(t5)){
/* c-backend.scm: 865  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t6=t2;
f_3980(2,t6,C_SCHEME_UNDEFINED);}}}

/* k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 866  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[351]);}

/* k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 867  make-argument-list */
t5=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[350]);}

/* k4046 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 867  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4042 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 868  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[348],((C_word*)t0)[5],lf[349]);}

/* k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[346],((C_word*)t0)[2],lf[347]);}

/* k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 872  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[344],((C_word*)t0)[3],lf[345]);}

/* k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 873  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[343]);}

/* k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4019(t7,t2,t3,((C_word*)t0)[2]);}

/* do494 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_4019(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4019,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4029,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 877  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[342],t2,C_make_character(59));}}

/* k4027 in do494 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4019(t4,((C_word*)t0)[2],t2,t3);}

/* k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3957 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 878  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[340],((C_word*)t0)[3],lf[341]);}
else{
t3=((C_word*)t0)[2];
f_3939(2,t3,C_SCHEME_UNDEFINED);}}

/* k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 889  lambda-literal-body */
t4=C_retrieve(lf[339]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3947 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 888  expression */
t3=((C_word*)t0)[4];
f_1178(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3898 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in k3874 in k3871 in k3868 in k3865 in k3859 in k3856 in k3853 in k3850 in k3847 in k3844 in k3841 in a3838 in procedures in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 894  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3463,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 657  immediate? */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[332]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 661  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3463(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 662  vector->list */
t6=*((C_word*)lf[335]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 663  block-variable-literal? */
t3=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3542 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 664  bad-literal */
f_3457(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 666  ##sys#bytevector? */
t3=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3560 in k3542 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 666  words */
t4=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3591(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 673  bad-literal */
f_3457(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3560 in k3542 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3591,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3613,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 672  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3463(3,t8,t6,t7);}}

/* k3611 in loop in k3560 in k3542 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 672  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3591(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3567 in k3560 in k3542 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3536 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3532 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 662  reduce */
t2=C_retrieve(lf[333]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[334]+1),C_fix(0),t1);}

/* k3528 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3499 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3505,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 661  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3463(3,t4,t2,t3);}

/* k3503 in k3499 in k3468 in literal-size in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3420,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3426(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do382 in literal-frame in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3426,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3436,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 651  sprintf */
t7=C_retrieve(lf[330]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[331],t2);}}

/* k3453 in do382 in literal-frame in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 651  gen-lit */
t2=((C_word*)t0)[4];
f_3622(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3434 in do382 in literal-frame in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3426(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3622(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3622,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 677  big-fixnum? */
t6=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3629(t5,C_SCHEME_FALSE);}}

/* k3740 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3629(t2,(C_word)C_i_not(t1));}

/* k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3629,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 678  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[314],((C_word*)t0)[4],lf[315]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 679  block-variable-literal? */
t3=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3635,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 681  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[316]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[317]:lf[318]);
/* c-backend.scm: 683  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 685  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[319],t4,lf[320]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 688  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 693  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[324]);}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[5]))){
/* c-backend.scm: 694  bad-literal */
f_3457(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t4=(C_word)C_lambdainfop(((C_word*)t0)[5]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 697  gen */
t6=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,C_SCHEME_TRUE,((C_word*)t0)[4],lf[327]);}}}}}}}}}

/* k3716 in k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3728,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 698  encode-literal */
t4=C_retrieve(lf[326]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3726 in k3716 in k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 698  gen-string-constant */
t2=((C_word*)t0)[3];
f_3744(t2,((C_word*)t0)[2],t1);}

/* k3719 in k3716 in k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 699  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[325]);}

/* k3683 in k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3691,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 690  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[323]);}

/* k3689 in k3683 in k3633 in k3627 in gen-lit in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 691  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[321],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[322]);}

/* bad-literal in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3457(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3457,NULL,2,t1,t2);}
/* c-backend.scm: 654  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[313],t2);}

/* gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3744,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3751,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 703  fx/ */
t5=*((C_word*)lf[312]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3754,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 704  modulo */
t3=*((C_word*)lf[311]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3759,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3759(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3759,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3775(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3775(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3796,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3815,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 710  string-like-substring */
f_3821(t7,((C_word*)t0)[4],t3,t8);}}

/* k3813 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 710  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3809 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 710  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3794 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3759(t4,((C_word*)t0)[2],t2,t3);}

/* k3773 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 709  string-like-substring */
f_3821(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3784 in k3773 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 709  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3780 in k3773 in do411 in k3752 in k3749 in gen-string-constant in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 709  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3821(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3821,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3828,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 714  make-string */
t7=*((C_word*)lf[310]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3826 in string-like-substring in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3831,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 715  ##sys#copy-bytes */
t3=C_retrieve(lf[309]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3829 in k3826 in string-like-substring in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3134,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3137,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3253,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3301,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3301,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3305,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 610  lambda-literal-argument-count */
t4=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3305,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 611  lambda-literal-rest-argument */
t5=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 612  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 613  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 614  lambda-literal-customizable */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 615  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3320(t3,C_SCHEME_FALSE);}}

/* k3416 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3320(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3320,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3323(t5,t4);}
else{
t3=t2;
f_3323(t3,C_SCHEME_UNDEFINED);}}

/* k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3323,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 617  lambda-literal-direct */
t3=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 619  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[303],((C_word*)t0)[9],lf[304],C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3363(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  lambda-literal-allocated */
t4=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3405 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3363(2,t3,t2);}
else{
/* c-backend.scm: 627  lambda-literal-external */
t3=C_retrieve(lf[308]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3361 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[222]);
t4=t2;
f_3369(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3369(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3367 in k3361 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3369,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[307]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 630  lset-adjoin */
t4=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[251]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 631  lset-adjoin */
t4=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[251]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 632  lset-adjoin */
t3=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[251]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3385 in k3367 in k3361 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3381 in k3367 in k3361 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3377 in k3367 in k3361 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 621  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[301],((C_word*)t0)[3],lf[302]);}

/* k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 622  restore */
f_3137(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3339 in k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 623  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3342 in k3339 in k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 624  make-argument-list */
t3=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[300]);}

/* k3345 in k3342 in k3339 in k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 625  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3355 in k3345 in k3342 in k3339 in k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3327 in k3321 in k3318 in k3315 in k3312 in k3309 in k3306 in k3303 in a3300 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 626  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[299]);}

/* k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3272,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 636  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[294],t2,lf[295],C_SCHEME_TRUE,lf[296],t2,lf[297],t2,lf[298]);}

/* k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 638  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[291],((C_word*)t0)[3],lf[292],((C_word*)t0)[3],lf[293]);}

/* k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 639  restore */
f_3137(t2,((C_word*)t0)[3]);}

/* k3280 in k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 640  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[290],((C_word*)t0)[2],C_make_character(44));}

/* k3283 in k3280 in k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 641  make-argument-list */
t5=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[289]);}

/* k3297 in k3283 in k3280 in k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 641  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3293 in k3283 in k3280 in k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3286 in k3283 in k3280 in k3277 in k3274 in a3271 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 642  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[288]);}

/* k3254 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 644  emitter */
t4=((C_word*)t0)[3];
f_3173(t4,t3,C_SCHEME_FALSE);}

/* k3268 in k3254 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3257 in k3254 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 645  emitter */
t3=((C_word*)t0)[2];
f_3173(t3,t2,C_SCHEME_TRUE);}

/* k3264 in k3257 in k3254 in k3251 in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3173(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3173,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3175 in emitter in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3175,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[283]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[284]);
/* c-backend.scm: 588  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[285],t2,C_make_character(114),t4,lf[286],C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t5);}

/* k3177 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 590  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[281],((C_word*)t0)[4],lf[282]);}

/* k3180 in k3177 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 591  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[280],((C_word*)t0)[4],C_make_character(114));}

/* k3183 in k3180 in k3177 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 592  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3188(2,t3,C_SCHEME_UNDEFINED);}}

/* k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 593  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[276],((C_word*)t0)[4],lf[277],C_SCHEME_TRUE,lf[278],C_SCHEME_TRUE,lf[279],((C_word*)t0)[4],C_make_character(59));}

/* k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 596  restore */
f_3137(t2,((C_word*)t0)[4]);}

/* k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}

/* k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 599  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[273]);}
else{
/* c-backend.scm: 600  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[274]);}}

/* k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 601  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[272]);}

/* k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 602  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[271]);}
else{
t3=t2;
f_3206(2,t3,C_SCHEME_UNDEFINED);}}

/* k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 603  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[270]);}

/* k3207 in k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 604  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[269]);}

/* k3210 in k3207 in k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 605  make-argument-list */
t6=C_retrieve(lf[267]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[268]);}

/* k3224 in k3210 in k3207 in k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 605  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3220 in k3210 in k3207 in k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3213 in k3210 in k3207 in k3204 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 in k3183 in k3180 in k3177 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 606  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[266]);}

/* restore in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3137(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3137,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3150,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3150(t8,t3,t4,C_fix(0));}

/* do331 in restore in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3160,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 583  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[263],t2,lf[264],t3,lf[265]);}}

/* k3158 in do331 in restore in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3150(t4,((C_word*)t0)[2],t2,t3);}

/* k3139 in restore in trampolines in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 584  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[261],((C_word*)t0)[2],lf[262]);}

/* prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 512  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2911,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2915,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 515  lambda-literal-argument-count */
t4=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 516  lambda-literal-customizable */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 517  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2921(t3,C_SCHEME_FALSE);}}

/* k3130 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2921(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2921,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 518  make-variable-list */
t5=C_retrieve(lf[257]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[258]);}

/* k3116 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 518  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 519  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 520  lambda-literal-rest-argument */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 521  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 522  lambda-literal-direct */
t3=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 523  lambda-literal-allocated */
t3=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[249]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 525  lset-adjoin */
t7=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[251]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2942(t5,C_SCHEME_UNDEFINED);}}

/* k3108 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2942(t3,t2);}

/* k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2942,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 526  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3103,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 531  lambda-literal-callee-signatures */
t5=C_retrieve(lf[252]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3101 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3083 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3084,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[249]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3095,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 530  lset-adjoin */
t7=C_retrieve(lf[250]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[251]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3093 in a3083 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[233],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 541  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[240]);}
else{
t5=t4;
f_3060(2,t5,lf[241]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 533  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[247],((C_word*)t0)[5],lf[248],C_SCHEME_TRUE);}}

/* k3033 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 534  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k3036 in k3033 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[244]:lf[245]);
/* c-backend.scm: 535  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3039 in k3036 in k3033 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 537  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[242]);}
else{
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[243]);}}

/* k3042 in k3039 in k3036 in k3033 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 539  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3058 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3063,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 542  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[238],t1,lf[239],C_SCHEME_TRUE);}

/* k3061 in k3058 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[236]))){
/* c-backend.scm: 544  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[237],C_SCHEME_TRUE);}
else{
t3=t2;
f_3066(2,t3,C_SCHEME_UNDEFINED);}}

/* k3064 in k3061 in k3058 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 545  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}

/* k3067 in k3064 in k3061 in k3058 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 546  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[234],((C_word*)t0)[2]);}

/* k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 547  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2957(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 548  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3007(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3007(t4,C_SCHEME_FALSE);}}

/* k3005 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_3007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3007,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=((C_word*)t0)[2];
f_2960(2,t2,C_SCHEME_UNDEFINED);}}

/* k3008 in k3005 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 551  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2960(2,t2,C_SCHEME_UNDEFINED);}}

/* k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 554  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[229]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 562  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k2993 in k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2998(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 564  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[230]);}}

/* k2996 in k2993 in k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 565  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2967 in k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[222]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 557  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[225],((C_word*)t0)[2],lf[226],C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228]);}}

/* k2976 in k2967 in k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k2979 in k2976 in k2967 in k2961 in k2958 in k2955 in k2952 in k2949 in k2946 in k2943 in k2940 in k2937 in k2934 in k2931 in k2928 in k2925 in k2922 in k2919 in k2916 in k2913 in a2910 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 560  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[223],t2,lf[224]);}

/* k2888 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2895,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2894 in k2888 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 569  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[220],t2,lf[221]);}

/* k2897 in a2894 in k2888 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 570  make-list */
t4=C_retrieve(lf[218]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[219]);}

/* k2907 in k2897 in a2894 in k2888 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2900 in k2897 in a2894 in k2888 in k2885 in prototypes in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 571  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[217]);}

/* declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2771,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2778,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 487  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[216]);}

/* k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2877,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2876 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2877,3,t0,t1,t2);}
/* c-backend.scm: 490  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[212],t2,lf[213],C_SCHEME_TRUE,lf[214],t2,lf[215]);}

/* k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2784(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 494  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[210],((C_word*)t0)[2],lf[211]);}}

/* k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2789,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2789(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2789,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2799,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 498  ##sys#lambda-info->string */
t6=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2805,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 500  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[207],((C_word*)t0)[5],lf[208],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2803 in k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2824(t6,t2,C_fix(0));}

/* do274 in k2803 in k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2834,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 507  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2832 in do274 in k2803 in k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2824(t3,((C_word*)t0)[2],t2);}

/* k2806 in k2803 in k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 508  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2809 in k2806 in k2803 in k2797 in do268 in k2782 in k2779 in k2776 in declarations in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2789(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2605,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2608,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2625,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 457  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2761 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 457  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2631(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2631(t3,C_SCHEME_FALSE);}}

/* k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2708,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 461  pad0 */
f_2608(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 461  pad0 */
f_2608(t2,((C_word*)t0)[2]);}

/* k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 461  pad0 */
f_2608(t2,((C_word*)t0)[2]);}

/* k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2720,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 461  pad0 */
f_2608(t2,((C_word*)t0)[2]);}

/* k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2724,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2730,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 464  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2740 in k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2736 in k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2729 in k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2730,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2726 in k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 462  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2722 in k2718 in k2714 in k2710 in k2706 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 459  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 467  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 468  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 469  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 471  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2695 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 472  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 473  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2659 in k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 475  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2664(2,t3,C_SCHEME_UNDEFINED);}}

/* k2662 in k2659 in k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2679,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 477  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2667(2,t3,C_SCHEME_UNDEFINED);}}

/* k2677 in k2662 in k2659 in k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2684,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2683 in k2677 in k2662 in k2659 in k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2684,3,t0,t1,t2);}
/* c-backend.scm: 478  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2665 in k2662 in k2659 in k2656 in k2653 in k2650 in k2647 in k2629 in k2623 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 480  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2608(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2608,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 455  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2620 in pad0 in header in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 455  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1178(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1178,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 450  expr */
t11=((C_word*)t6)[1];
f_1181(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2573(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2573,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2579,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 444  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2578 in expr-args in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2583(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 446  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2581 in a2578 in expr-args in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 447  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1181(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1181,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 135  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 136  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 137  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 138  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 139  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 140  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 145  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 146  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1305,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 149  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 158  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1363(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1414,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 170  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1441,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 175  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1460,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 180  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1493,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 187  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1530,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 194  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1559,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 201  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1591,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 209  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1626,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 219  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 223  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1658,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 226  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 235  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 236  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 237  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 238  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1732,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 244  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1766,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 253  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1779,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 257  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 261  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1822,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 270  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2133,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 327  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2218,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2222,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 355  find-lambda */
t41=((C_word*)t0)[2];
f_1136(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2241,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 372  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2260,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 377  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2279,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 382  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2298,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 387  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2334,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 395  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2354,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2372,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 399  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2388,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 405  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2418,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 411  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2455,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 418  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2538,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 433  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 441  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 434  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2539 in k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 435  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2542 in k2539 in k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 436  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2545 in k2542 in k2539 in k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 437  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2548 in k2545 in k2542 in k2539 in k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 438  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2551 in k2548 in k2545 in k2542 in k2539 in k2536 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 439  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 419  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1181(t4,t2,t3,((C_word*)t0)[3]);}

/* k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 420  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2474,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2474(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2474,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 424  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 427  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2495 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2498 in k2495 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2501 in k2498 in k2495 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2504 in k2501 in k2498 in k2495 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2474(t4,((C_word*)t0)[2],t2,t3);}

/* k2482 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 425  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2485 in k2482 in do215 in k2459 in k2456 in k2453 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 426  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2444 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 411  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2416 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 412  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1181(t4,t2,t3,((C_word*)t0)[3]);}

/* k2419 in k2416 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 413  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2436 in k2419 in k2416 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 413  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2422 in k2419 in k2416 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 414  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2425 in k2422 in k2419 in k2416 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 415  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2400 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2406,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 405  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2404 in k2400 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2386 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2389 in k2386 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2370 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 399  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2374 in k2370 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2352 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2355 in k2352 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 401  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2332 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 395  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2296 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 390  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2301(2,t3,C_SCHEME_UNDEFINED);}}

/* k2308 in k2296 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2573(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2299 in k2296 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 392  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2277 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 383  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2280 in k2277 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2258 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 378  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k2261 in k2258 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 379  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2239 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 373  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2242 in k2239 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 374  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2220 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 355  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 357  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2199,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 359  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2169(2,t3,C_SCHEME_UNDEFINED);}}

/* k2197 in k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 360  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2169(2,t4,C_SCHEME_UNDEFINED);}}

/* k2167 in k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2172(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2187,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 362  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2185 in k2167 in k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 363  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2172(2,t2,C_SCHEME_UNDEFINED);}}

/* k2170 in k2167 in k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 364  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2573(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2175(2,t3,C_SCHEME_UNDEFINED);}}

/* k2173 in k2170 in k2167 in k2164 in k2216 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 365  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 329  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2117,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 342  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2115 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2120(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 343  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2118 in k2115 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 344  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2121 in k2118 in k2115 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 345  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 330  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 331  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2099 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2100,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 333  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2102 in a2099 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 334  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2105 in k2102 in a2099 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 335  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2080 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2090,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 339  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2096 in k2080 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2089 in k2080 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2090,4,t0,t1,t2,t3);}
/* c-backend.scm: 338  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2083 in k2080 in k2077 in k2074 in k2131 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 340  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1825(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1825(t3,C_SCHEME_FALSE);}}

/* k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1825,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 273  find-lambda */
t6=((C_word*)t0)[2];
f_1136(t6,t5,t1);}
else{
t4=t3;
f_1831(t4,C_SCHEME_FALSE);}}

/* k2024 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 273  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2020 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1831(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1831,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 122  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1176,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 123  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1837(2,t4,C_SCHEME_UNDEFINED);}}

/* k1174 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 123  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2013 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 278  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1164 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 122  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2006 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 277  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 281  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 285  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 311  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 312  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1181(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 313  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1965 in k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1982(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_1982(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k1980 in k1965 in k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 316  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 317  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1968 in k1965 in k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 318  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1971 in k1968 in k1965 in k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 319  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 320  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1956 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 286  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1868(2,t3,C_SCHEME_FALSE);}}

/* k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 287  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1918(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 302  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1940 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 303  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1943 in k1940 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 304  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1916 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1919 in k1916 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1924(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 306  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1922 in k1919 in k1916 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1927(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 307  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1925 in k1922 in k1919 in k1916 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 308  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1928 in k1925 in k1922 in k1919 in k1916 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 288  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 289  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1900 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1901,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 291  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1903 in a1900 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 292  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1906 in k1903 in a1900 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 293  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1875 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1891,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 297  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1897 in k1875 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 295  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1890 in k1875 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1891,4,t0,t1,t2,t3);}
/* c-backend.scm: 296  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1878 in k1875 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1883(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 299  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1847 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 282  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2573(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1850 in k1847 in k1835 in k1829 in k1823 in k1820 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 283  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1777 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 258  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1780 in k1777 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 259  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1764 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 254  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1767 in k1764 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 255  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1730 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1733 in k1730 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1702 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 236  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1698 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 236  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1656 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 227  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1624 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 220  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1627 in k1624 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 221  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 215  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1615 in k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 210  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1602 in k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1603,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 212  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1605 in a1602 in k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 213  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1181(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1608 in k1605 in a1602 in k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 214  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1592 in k1589 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 216  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1557 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 202  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1560 in k1557 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 203  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1563 in k1560 in k1557 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 204  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1566 in k1563 in k1560 in k1557 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 205  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1528 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 195  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1531 in k1528 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 196  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1534 in k1531 in k1528 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 197  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1537 in k1534 in k1531 in k1528 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 198  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1491 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 188  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1181(t4,t2,t3,((C_word*)t0)[3]);}

/* k1494 in k1491 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 189  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1497 in k1494 in k1491 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 190  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1500 in k1497 in k1494 in k1491 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 191  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1458 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 181  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1181(t4,t2,t3,((C_word*)t0)[3]);}

/* k1461 in k1458 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 182  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1464 in k1461 in k1458 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 183  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1467 in k1464 in k1461 in k1458 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 184  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1439 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 176  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1442 in k1439 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 177  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1412 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 171  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1415 in k1412 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 172  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1363(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1363,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 163  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 167  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1181(t7,t1,t6,t3);}}

/* k1371 in loop in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 164  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1181(t4,t2,t3,((C_word*)t0)[6]);}

/* k1374 in k1371 in loop in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 165  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1377 in k1374 in k1371 in loop in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 166  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1363(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 150  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1306 in k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 151  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1309 in k1306 in k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 152  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1312 in k1309 in k1306 in k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 153  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1315 in k1312 in k1309 in k1306 in k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 154  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1181(t4,t2,t3,((C_word*)t0)[2]);}

/* k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in expr in expression in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 155  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1136,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1140,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 119  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1147 in find-lambda in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 119  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1154 in a1147 in find-lambda in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1138 in find-lambda in ##compiler#generate-code in k1129 in k1084 in k1081 in k1078 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 120  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1084 in k1081 in k1078 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1113,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1119,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1127,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 101  intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1125 in ##compiler#gen-list in k1084 in k1081 in k1078 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1118 in ##compiler#gen-list in k1084 in k1081 in k1078 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1119,3,t0,t1,t2);}
/* c-backend.scm: 100  display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1084 in k1081 in k1078 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1092r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1092r(t0,t1,t2);}}

static void C_ccall f_1092r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1098,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1097 in ##compiler#gen in k1084 in k1081 in k1078 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1098,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 94   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 95   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[667] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1080c-backend.scm",(void*)f_1080},
{"f_1083c-backend.scm",(void*)f_1083},
{"f_1086c-backend.scm",(void*)f_1086},
{"f_8726c-backend.scm",(void*)f_8726},
{"f_8730c-backend.scm",(void*)f_8730},
{"f_8722c-backend.scm",(void*)f_8722},
{"f_1131c-backend.scm",(void*)f_1131},
{"f_8429c-backend.scm",(void*)f_8429},
{"f_8714c-backend.scm",(void*)f_8714},
{"f_8541c-backend.scm",(void*)f_8541},
{"f_8688c-backend.scm",(void*)f_8688},
{"f_8686c-backend.scm",(void*)f_8686},
{"f_8674c-backend.scm",(void*)f_8674},
{"f_8644c-backend.scm",(void*)f_8644},
{"f_8605c-backend.scm",(void*)f_8605},
{"f_8491c-backend.scm",(void*)f_8491},
{"f_8438c-backend.scm",(void*)f_8438},
{"f_8435c-backend.scm",(void*)f_8435},
{"f_8432c-backend.scm",(void*)f_8432},
{"f_7655c-backend.scm",(void*)f_7655},
{"f_7742c-backend.scm",(void*)f_7742},
{"f_7823c-backend.scm",(void*)f_7823},
{"f_8258c-backend.scm",(void*)f_8258},
{"f_8200c-backend.scm",(void*)f_8200},
{"f_8164c-backend.scm",(void*)f_8164},
{"f_8129c-backend.scm",(void*)f_8129},
{"f_8081c-backend.scm",(void*)f_8081},
{"f_8033c-backend.scm",(void*)f_8033},
{"f_7985c-backend.scm",(void*)f_7985},
{"f_7950c-backend.scm",(void*)f_7950},
{"f_7914c-backend.scm",(void*)f_7914},
{"f_7878c-backend.scm",(void*)f_7878},
{"f_7856c-backend.scm",(void*)f_7856},
{"f_7851c-backend.scm",(void*)f_7851},
{"f_7846c-backend.scm",(void*)f_7846},
{"f_7657c-backend.scm",(void*)f_7657},
{"f_6822c-backend.scm",(void*)f_6822},
{"f_6852c-backend.scm",(void*)f_6852},
{"f_6879c-backend.scm",(void*)f_6879},
{"f_7074c-backend.scm",(void*)f_7074},
{"f_7083c-backend.scm",(void*)f_7083},
{"f_7092c-backend.scm",(void*)f_7092},
{"f_7480c-backend.scm",(void*)f_7480},
{"f_7447c-backend.scm",(void*)f_7447},
{"f_7457c-backend.scm",(void*)f_7457},
{"f_7415c-backend.scm",(void*)f_7415},
{"f_7380c-backend.scm",(void*)f_7380},
{"f_7310c-backend.scm",(void*)f_7310},
{"f_7265c-backend.scm",(void*)f_7265},
{"f_7233c-backend.scm",(void*)f_7233},
{"f_7201c-backend.scm",(void*)f_7201},
{"f_7169c-backend.scm",(void*)f_7169},
{"f_7137c-backend.scm",(void*)f_7137},
{"f_7115c-backend.scm",(void*)f_7115},
{"f_6824c-backend.scm",(void*)f_6824},
{"f_5605c-backend.scm",(void*)f_5605},
{"f_5682c-backend.scm",(void*)f_5682},
{"f_5784c-backend.scm",(void*)f_5784},
{"f_5817c-backend.scm",(void*)f_5817},
{"f_5913c-backend.scm",(void*)f_5913},
{"f_5928c-backend.scm",(void*)f_5928},
{"f_6545c-backend.scm",(void*)f_6545},
{"f_6561c-backend.scm",(void*)f_6561},
{"f_6565c-backend.scm",(void*)f_6565},
{"f_6578c-backend.scm",(void*)f_6578},
{"f_6576c-backend.scm",(void*)f_6576},
{"f_6572c-backend.scm",(void*)f_6572},
{"f_6499c-backend.scm",(void*)f_6499},
{"f_6512c-backend.scm",(void*)f_6512},
{"f_6449c-backend.scm",(void*)f_6449},
{"f_6399c-backend.scm",(void*)f_6399},
{"f_6360c-backend.scm",(void*)f_6360},
{"f_6370c-backend.scm",(void*)f_6370},
{"f_6321c-backend.scm",(void*)f_6321},
{"f_6331c-backend.scm",(void*)f_6331},
{"f_6282c-backend.scm",(void*)f_6282},
{"f_6292c-backend.scm",(void*)f_6292},
{"f_6243c-backend.scm",(void*)f_6243},
{"f_6253c-backend.scm",(void*)f_6253},
{"f_6183c-backend.scm",(void*)f_6183},
{"f_6200c-backend.scm",(void*)f_6200},
{"f_6210c-backend.scm",(void*)f_6210},
{"f_6208c-backend.scm",(void*)f_6208},
{"f_6204c-backend.scm",(void*)f_6204},
{"f_6196c-backend.scm",(void*)f_6196},
{"f_6144c-backend.scm",(void*)f_6144},
{"f_6154c-backend.scm",(void*)f_6154},
{"f_6108c-backend.scm",(void*)f_6108},
{"f_6072c-backend.scm",(void*)f_6072},
{"f_6036c-backend.scm",(void*)f_6036},
{"f_6000c-backend.scm",(void*)f_6000},
{"f_5974c-backend.scm",(void*)f_5974},
{"f_5982c-backend.scm",(void*)f_5982},
{"f_5965c-backend.scm",(void*)f_5965},
{"f_5973c-backend.scm",(void*)f_5973},
{"f_5960c-backend.scm",(void*)f_5960},
{"f_5612c-backend.scm",(void*)f_5612},
{"f_5607c-backend.scm",(void*)f_5607},
{"f_5540c-backend.scm",(void*)f_5540},
{"f_5544c-backend.scm",(void*)f_5544},
{"f_5547c-backend.scm",(void*)f_5547},
{"f_5550c-backend.scm",(void*)f_5550},
{"f_5553c-backend.scm",(void*)f_5553},
{"f_5559c-backend.scm",(void*)f_5559},
{"f_5603c-backend.scm",(void*)f_5603},
{"f_5562c-backend.scm",(void*)f_5562},
{"f_5570c-backend.scm",(void*)f_5570},
{"f_5591c-backend.scm",(void*)f_5591},
{"f_5574c-backend.scm",(void*)f_5574},
{"f_5565c-backend.scm",(void*)f_5565},
{"f_5109c-backend.scm",(void*)f_5109},
{"f_5115c-backend.scm",(void*)f_5115},
{"f_5119c-backend.scm",(void*)f_5119},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5125c-backend.scm",(void*)f_5125},
{"f_5128c-backend.scm",(void*)f_5128},
{"f_5134c-backend.scm",(void*)f_5134},
{"f_5475c-backend.scm",(void*)f_5475},
{"f_5478c-backend.scm",(void*)f_5478},
{"f_5538c-backend.scm",(void*)f_5538},
{"f_5481c-backend.scm",(void*)f_5481},
{"f_5484c-backend.scm",(void*)f_5484},
{"f_5487c-backend.scm",(void*)f_5487},
{"f_5490c-backend.scm",(void*)f_5490},
{"f_5523c-backend.scm",(void*)f_5523},
{"f_5531c-backend.scm",(void*)f_5531},
{"f_5493c-backend.scm",(void*)f_5493},
{"f_5521c-backend.scm",(void*)f_5521},
{"f_5496c-backend.scm",(void*)f_5496},
{"f_5499c-backend.scm",(void*)f_5499},
{"f_5502c-backend.scm",(void*)f_5502},
{"f_5136c-backend.scm",(void*)f_5136},
{"f_5146c-backend.scm",(void*)f_5146},
{"f_5155c-backend.scm",(void*)f_5155},
{"f_5167c-backend.scm",(void*)f_5167},
{"f_5179c-backend.scm",(void*)f_5179},
{"f_5185c-backend.scm",(void*)f_5185},
{"f_5219c-backend.scm",(void*)f_5219},
{"f_4876c-backend.scm",(void*)f_4876},
{"f_4882c-backend.scm",(void*)f_4882},
{"f_4886c-backend.scm",(void*)f_4886},
{"f_4889c-backend.scm",(void*)f_4889},
{"f_4892c-backend.scm",(void*)f_4892},
{"f_5107c-backend.scm",(void*)f_5107},
{"f_4898c-backend.scm",(void*)f_4898},
{"f_4901c-backend.scm",(void*)f_4901},
{"f_4904c-backend.scm",(void*)f_4904},
{"f_4907c-backend.scm",(void*)f_4907},
{"f_4910c-backend.scm",(void*)f_4910},
{"f_4913c-backend.scm",(void*)f_4913},
{"f_4916c-backend.scm",(void*)f_4916},
{"f_4919c-backend.scm",(void*)f_4919},
{"f_4922c-backend.scm",(void*)f_4922},
{"f_4925c-backend.scm",(void*)f_4925},
{"f_5096c-backend.scm",(void*)f_5096},
{"f_4928c-backend.scm",(void*)f_4928},
{"f_4931c-backend.scm",(void*)f_4931},
{"f_4934c-backend.scm",(void*)f_4934},
{"f_4937c-backend.scm",(void*)f_4937},
{"f_4940c-backend.scm",(void*)f_4940},
{"f_4943c-backend.scm",(void*)f_4943},
{"f_4946c-backend.scm",(void*)f_4946},
{"f_4949c-backend.scm",(void*)f_4949},
{"f_5074c-backend.scm",(void*)f_5074},
{"f_5044c-backend.scm",(void*)f_5044},
{"f_5064c-backend.scm",(void*)f_5064},
{"f_5052c-backend.scm",(void*)f_5052},
{"f_5056c-backend.scm",(void*)f_5056},
{"f_5060c-backend.scm",(void*)f_5060},
{"f_4952c-backend.scm",(void*)f_4952},
{"f_4955c-backend.scm",(void*)f_4955},
{"f_4985c-backend.scm",(void*)f_4985},
{"f_4988c-backend.scm",(void*)f_4988},
{"f_5026c-backend.scm",(void*)f_5026},
{"f_5022c-backend.scm",(void*)f_5022},
{"f_4991c-backend.scm",(void*)f_4991},
{"f_4994c-backend.scm",(void*)f_4994},
{"f_4997c-backend.scm",(void*)f_4997},
{"f_4964c-backend.scm",(void*)f_4964},
{"f_4967c-backend.scm",(void*)f_4967},
{"f_4958c-backend.scm",(void*)f_4958},
{"f_4858c-backend.scm",(void*)f_4858},
{"f_4864c-backend.scm",(void*)f_4864},
{"f_4868c-backend.scm",(void*)f_4868},
{"f_4871c-backend.scm",(void*)f_4871},
{"f_4807c-backend.scm",(void*)f_4807},
{"f_4811c-backend.scm",(void*)f_4811},
{"f_4816c-backend.scm",(void*)f_4816},
{"f_4823c-backend.scm",(void*)f_4823},
{"f_4843c-backend.scm",(void*)f_4843},
{"f_4791c-backend.scm",(void*)f_4791},
{"f_4797c-backend.scm",(void*)f_4797},
{"f_4805c-backend.scm",(void*)f_4805},
{"f_4775c-backend.scm",(void*)f_4775},
{"f_4781c-backend.scm",(void*)f_4781},
{"f_4789c-backend.scm",(void*)f_4789},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4695c-backend.scm",(void*)f_4695},
{"f_4724c-backend.scm",(void*)f_4724},
{"f_4734c-backend.scm",(void*)f_4734},
{"f_4727c-backend.scm",(void*)f_4727},
{"f_4711c-backend.scm",(void*)f_4711},
{"f_4613c-backend.scm",(void*)f_4613},
{"f_4617c-backend.scm",(void*)f_4617},
{"f_4631c-backend.scm",(void*)f_4631},
{"f_4644c-backend.scm",(void*)f_4644},
{"f_4647c-backend.scm",(void*)f_4647},
{"f_4650c-backend.scm",(void*)f_4650},
{"f_4620c-backend.scm",(void*)f_4620},
{"f_4623c-backend.scm",(void*)f_4623},
{"f_4626c-backend.scm",(void*)f_4626},
{"f_1133c-backend.scm",(void*)f_1133},
{"f_4580c-backend.scm",(void*)f_4580},
{"f_4584c-backend.scm",(void*)f_4584},
{"f_4587c-backend.scm",(void*)f_4587},
{"f_4590c-backend.scm",(void*)f_4590},
{"f_4593c-backend.scm",(void*)f_4593},
{"f_4596c-backend.scm",(void*)f_4596},
{"f_4599c-backend.scm",(void*)f_4599},
{"f_4602c-backend.scm",(void*)f_4602},
{"f_4605c-backend.scm",(void*)f_4605},
{"f_4608c-backend.scm",(void*)f_4608},
{"f_3833c-backend.scm",(void*)f_3833},
{"f_3839c-backend.scm",(void*)f_3839},
{"f_3843c-backend.scm",(void*)f_3843},
{"f_3846c-backend.scm",(void*)f_3846},
{"f_3849c-backend.scm",(void*)f_3849},
{"f_3852c-backend.scm",(void*)f_3852},
{"f_3855c-backend.scm",(void*)f_3855},
{"f_3858c-backend.scm",(void*)f_3858},
{"f_4577c-backend.scm",(void*)f_4577},
{"f_3861c-backend.scm",(void*)f_3861},
{"f_3867c-backend.scm",(void*)f_3867},
{"f_3870c-backend.scm",(void*)f_3870},
{"f_3873c-backend.scm",(void*)f_3873},
{"f_3876c-backend.scm",(void*)f_3876},
{"f_3879c-backend.scm",(void*)f_3879},
{"f_3882c-backend.scm",(void*)f_3882},
{"f_3885c-backend.scm",(void*)f_3885},
{"f_3888c-backend.scm",(void*)f_3888},
{"f_3891c-backend.scm",(void*)f_3891},
{"f_3894c-backend.scm",(void*)f_3894},
{"f_3897c-backend.scm",(void*)f_3897},
{"f_3900c-backend.scm",(void*)f_3900},
{"f_4546c-backend.scm",(void*)f_4546},
{"f_3903c-backend.scm",(void*)f_3903},
{"f_4507c-backend.scm",(void*)f_4507},
{"f_4510c-backend.scm",(void*)f_4510},
{"f_4513c-backend.scm",(void*)f_4513},
{"f_4529c-backend.scm",(void*)f_4529},
{"f_4532c-backend.scm",(void*)f_4532},
{"f_3906c-backend.scm",(void*)f_3906},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3912c-backend.scm",(void*)f_3912},
{"f_4479c-backend.scm",(void*)f_4479},
{"f_4482c-backend.scm",(void*)f_4482},
{"f_3915c-backend.scm",(void*)f_3915},
{"f_3918c-backend.scm",(void*)f_3918},
{"f_3921c-backend.scm",(void*)f_3921},
{"f_3924c-backend.scm",(void*)f_3924},
{"f_3927c-backend.scm",(void*)f_3927},
{"f_3930c-backend.scm",(void*)f_3930},
{"f_4441c-backend.scm",(void*)f_4441},
{"f_4451c-backend.scm",(void*)f_4451},
{"f_3933c-backend.scm",(void*)f_3933},
{"f_4384c-backend.scm",(void*)f_4384},
{"f_4396c-backend.scm",(void*)f_4396},
{"f_4399c-backend.scm",(void*)f_4399},
{"f_4405c-backend.scm",(void*)f_4405},
{"f_4306c-backend.scm",(void*)f_4306},
{"f_4348c-backend.scm",(void*)f_4348},
{"f_4309c-backend.scm",(void*)f_4309},
{"f_4315c-backend.scm",(void*)f_4315},
{"f_4318c-backend.scm",(void*)f_4318},
{"f_4324c-backend.scm",(void*)f_4324},
{"f_4242c-backend.scm",(void*)f_4242},
{"f_4245c-backend.scm",(void*)f_4245},
{"f_4248c-backend.scm",(void*)f_4248},
{"f_4251c-backend.scm",(void*)f_4251},
{"f_4254c-backend.scm",(void*)f_4254},
{"f_4269c-backend.scm",(void*)f_4269},
{"f_4257c-backend.scm",(void*)f_4257},
{"f_4260c-backend.scm",(void*)f_4260},
{"f_4228c-backend.scm",(void*)f_4228},
{"f_4236c-backend.scm",(void*)f_4236},
{"f_4153c-backend.scm",(void*)f_4153},
{"f_4159c-backend.scm",(void*)f_4159},
{"f_4162c-backend.scm",(void*)f_4162},
{"f_4196c-backend.scm",(void*)f_4196},
{"f_4199c-backend.scm",(void*)f_4199},
{"f_4202c-backend.scm",(void*)f_4202},
{"f_4165c-backend.scm",(void*)f_4165},
{"f_4168c-backend.scm",(void*)f_4168},
{"f_4171c-backend.scm",(void*)f_4171},
{"f_4174c-backend.scm",(void*)f_4174},
{"f_4183c-backend.scm",(void*)f_4183},
{"f_4186c-backend.scm",(void*)f_4186},
{"f_3936c-backend.scm",(void*)f_3936},
{"f_3959c-backend.scm",(void*)f_3959},
{"f_4094c-backend.scm",(void*)f_4094},
{"f_4097c-backend.scm",(void*)f_4097},
{"f_4109c-backend.scm",(void*)f_4109},
{"f_4100c-backend.scm",(void*)f_4100},
{"f_3965c-backend.scm",(void*)f_3965},
{"f_3968c-backend.scm",(void*)f_3968},
{"f_3971c-backend.scm",(void*)f_3971},
{"f_4075c-backend.scm",(void*)f_4075},
{"f_3974c-backend.scm",(void*)f_3974},
{"f_3977c-backend.scm",(void*)f_3977},
{"f_3980c-backend.scm",(void*)f_3980},
{"f_3983c-backend.scm",(void*)f_3983},
{"f_4048c-backend.scm",(void*)f_4048},
{"f_4044c-backend.scm",(void*)f_4044},
{"f_3986c-backend.scm",(void*)f_3986},
{"f_3989c-backend.scm",(void*)f_3989},
{"f_3992c-backend.scm",(void*)f_3992},
{"f_3995c-backend.scm",(void*)f_3995},
{"f_3998c-backend.scm",(void*)f_3998},
{"f_4001c-backend.scm",(void*)f_4001},
{"f_4019c-backend.scm",(void*)f_4019},
{"f_4029c-backend.scm",(void*)f_4029},
{"f_4004c-backend.scm",(void*)f_4004},
{"f_3939c-backend.scm",(void*)f_3939},
{"f_3949c-backend.scm",(void*)f_3949},
{"f_3942c-backend.scm",(void*)f_3942},
{"f_3463c-backend.scm",(void*)f_3463},
{"f_3470c-backend.scm",(void*)f_3470},
{"f_3544c-backend.scm",(void*)f_3544},
{"f_3562c-backend.scm",(void*)f_3562},
{"f_3591c-backend.scm",(void*)f_3591},
{"f_3613c-backend.scm",(void*)f_3613},
{"f_3569c-backend.scm",(void*)f_3569},
{"f_3538c-backend.scm",(void*)f_3538},
{"f_3534c-backend.scm",(void*)f_3534},
{"f_3530c-backend.scm",(void*)f_3530},
{"f_3501c-backend.scm",(void*)f_3501},
{"f_3505c-backend.scm",(void*)f_3505},
{"f_3420c-backend.scm",(void*)f_3420},
{"f_3426c-backend.scm",(void*)f_3426},
{"f_3455c-backend.scm",(void*)f_3455},
{"f_3436c-backend.scm",(void*)f_3436},
{"f_3622c-backend.scm",(void*)f_3622},
{"f_3742c-backend.scm",(void*)f_3742},
{"f_3629c-backend.scm",(void*)f_3629},
{"f_3635c-backend.scm",(void*)f_3635},
{"f_3718c-backend.scm",(void*)f_3718},
{"f_3728c-backend.scm",(void*)f_3728},
{"f_3721c-backend.scm",(void*)f_3721},
{"f_3685c-backend.scm",(void*)f_3685},
{"f_3691c-backend.scm",(void*)f_3691},
{"f_3457c-backend.scm",(void*)f_3457},
{"f_3744c-backend.scm",(void*)f_3744},
{"f_3751c-backend.scm",(void*)f_3751},
{"f_3754c-backend.scm",(void*)f_3754},
{"f_3759c-backend.scm",(void*)f_3759},
{"f_3815c-backend.scm",(void*)f_3815},
{"f_3811c-backend.scm",(void*)f_3811},
{"f_3796c-backend.scm",(void*)f_3796},
{"f_3775c-backend.scm",(void*)f_3775},
{"f_3786c-backend.scm",(void*)f_3786},
{"f_3782c-backend.scm",(void*)f_3782},
{"f_3821c-backend.scm",(void*)f_3821},
{"f_3828c-backend.scm",(void*)f_3828},
{"f_3831c-backend.scm",(void*)f_3831},
{"f_3134c-backend.scm",(void*)f_3134},
{"f_3301c-backend.scm",(void*)f_3301},
{"f_3305c-backend.scm",(void*)f_3305},
{"f_3308c-backend.scm",(void*)f_3308},
{"f_3311c-backend.scm",(void*)f_3311},
{"f_3314c-backend.scm",(void*)f_3314},
{"f_3317c-backend.scm",(void*)f_3317},
{"f_3418c-backend.scm",(void*)f_3418},
{"f_3320c-backend.scm",(void*)f_3320},
{"f_3323c-backend.scm",(void*)f_3323},
{"f_3329c-backend.scm",(void*)f_3329},
{"f_3407c-backend.scm",(void*)f_3407},
{"f_3363c-backend.scm",(void*)f_3363},
{"f_3369c-backend.scm",(void*)f_3369},
{"f_3387c-backend.scm",(void*)f_3387},
{"f_3383c-backend.scm",(void*)f_3383},
{"f_3379c-backend.scm",(void*)f_3379},
{"f_3335c-backend.scm",(void*)f_3335},
{"f_3338c-backend.scm",(void*)f_3338},
{"f_3341c-backend.scm",(void*)f_3341},
{"f_3344c-backend.scm",(void*)f_3344},
{"f_3347c-backend.scm",(void*)f_3347},
{"f_3357c-backend.scm",(void*)f_3357},
{"f_3350c-backend.scm",(void*)f_3350},
{"f_3253c-backend.scm",(void*)f_3253},
{"f_3272c-backend.scm",(void*)f_3272},
{"f_3276c-backend.scm",(void*)f_3276},
{"f_3279c-backend.scm",(void*)f_3279},
{"f_3282c-backend.scm",(void*)f_3282},
{"f_3285c-backend.scm",(void*)f_3285},
{"f_3299c-backend.scm",(void*)f_3299},
{"f_3295c-backend.scm",(void*)f_3295},
{"f_3288c-backend.scm",(void*)f_3288},
{"f_3256c-backend.scm",(void*)f_3256},
{"f_3270c-backend.scm",(void*)f_3270},
{"f_3259c-backend.scm",(void*)f_3259},
{"f_3266c-backend.scm",(void*)f_3266},
{"f_3173c-backend.scm",(void*)f_3173},
{"f_3175c-backend.scm",(void*)f_3175},
{"f_3179c-backend.scm",(void*)f_3179},
{"f_3182c-backend.scm",(void*)f_3182},
{"f_3185c-backend.scm",(void*)f_3185},
{"f_3188c-backend.scm",(void*)f_3188},
{"f_3191c-backend.scm",(void*)f_3191},
{"f_3194c-backend.scm",(void*)f_3194},
{"f_3197c-backend.scm",(void*)f_3197},
{"f_3200c-backend.scm",(void*)f_3200},
{"f_3203c-backend.scm",(void*)f_3203},
{"f_3206c-backend.scm",(void*)f_3206},
{"f_3209c-backend.scm",(void*)f_3209},
{"f_3212c-backend.scm",(void*)f_3212},
{"f_3226c-backend.scm",(void*)f_3226},
{"f_3222c-backend.scm",(void*)f_3222},
{"f_3215c-backend.scm",(void*)f_3215},
{"f_3137c-backend.scm",(void*)f_3137},
{"f_3150c-backend.scm",(void*)f_3150},
{"f_3160c-backend.scm",(void*)f_3160},
{"f_3141c-backend.scm",(void*)f_3141},
{"f_2883c-backend.scm",(void*)f_2883},
{"f_2887c-backend.scm",(void*)f_2887},
{"f_2911c-backend.scm",(void*)f_2911},
{"f_2915c-backend.scm",(void*)f_2915},
{"f_2918c-backend.scm",(void*)f_2918},
{"f_3132c-backend.scm",(void*)f_3132},
{"f_2921c-backend.scm",(void*)f_2921},
{"f_3118c-backend.scm",(void*)f_3118},
{"f_2924c-backend.scm",(void*)f_2924},
{"f_2927c-backend.scm",(void*)f_2927},
{"f_2930c-backend.scm",(void*)f_2930},
{"f_2933c-backend.scm",(void*)f_2933},
{"f_2936c-backend.scm",(void*)f_2936},
{"f_2939c-backend.scm",(void*)f_2939},
{"f_3110c-backend.scm",(void*)f_3110},
{"f_2942c-backend.scm",(void*)f_2942},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_3103c-backend.scm",(void*)f_3103},
{"f_3084c-backend.scm",(void*)f_3084},
{"f_3095c-backend.scm",(void*)f_3095},
{"f_2948c-backend.scm",(void*)f_2948},
{"f_3035c-backend.scm",(void*)f_3035},
{"f_3038c-backend.scm",(void*)f_3038},
{"f_3041c-backend.scm",(void*)f_3041},
{"f_3044c-backend.scm",(void*)f_3044},
{"f_3060c-backend.scm",(void*)f_3060},
{"f_3063c-backend.scm",(void*)f_3063},
{"f_3066c-backend.scm",(void*)f_3066},
{"f_3069c-backend.scm",(void*)f_3069},
{"f_2951c-backend.scm",(void*)f_2951},
{"f_2954c-backend.scm",(void*)f_2954},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_3007c-backend.scm",(void*)f_3007},
{"f_3010c-backend.scm",(void*)f_3010},
{"f_2960c-backend.scm",(void*)f_2960},
{"f_2963c-backend.scm",(void*)f_2963},
{"f_2995c-backend.scm",(void*)f_2995},
{"f_2998c-backend.scm",(void*)f_2998},
{"f_2969c-backend.scm",(void*)f_2969},
{"f_2978c-backend.scm",(void*)f_2978},
{"f_2981c-backend.scm",(void*)f_2981},
{"f_2890c-backend.scm",(void*)f_2890},
{"f_2895c-backend.scm",(void*)f_2895},
{"f_2899c-backend.scm",(void*)f_2899},
{"f_2909c-backend.scm",(void*)f_2909},
{"f_2902c-backend.scm",(void*)f_2902},
{"f_2771c-backend.scm",(void*)f_2771},
{"f_2778c-backend.scm",(void*)f_2778},
{"f_2877c-backend.scm",(void*)f_2877},
{"f_2781c-backend.scm",(void*)f_2781},
{"f_2784c-backend.scm",(void*)f_2784},
{"f_2789c-backend.scm",(void*)f_2789},
{"f_2799c-backend.scm",(void*)f_2799},
{"f_2805c-backend.scm",(void*)f_2805},
{"f_2824c-backend.scm",(void*)f_2824},
{"f_2834c-backend.scm",(void*)f_2834},
{"f_2808c-backend.scm",(void*)f_2808},
{"f_2811c-backend.scm",(void*)f_2811},
{"f_2605c-backend.scm",(void*)f_2605},
{"f_2763c-backend.scm",(void*)f_2763},
{"f_2625c-backend.scm",(void*)f_2625},
{"f_2631c-backend.scm",(void*)f_2631},
{"f_2708c-backend.scm",(void*)f_2708},
{"f_2712c-backend.scm",(void*)f_2712},
{"f_2716c-backend.scm",(void*)f_2716},
{"f_2720c-backend.scm",(void*)f_2720},
{"f_2742c-backend.scm",(void*)f_2742},
{"f_2738c-backend.scm",(void*)f_2738},
{"f_2730c-backend.scm",(void*)f_2730},
{"f_2728c-backend.scm",(void*)f_2728},
{"f_2724c-backend.scm",(void*)f_2724},
{"f_2649c-backend.scm",(void*)f_2649},
{"f_2652c-backend.scm",(void*)f_2652},
{"f_2655c-backend.scm",(void*)f_2655},
{"f_2697c-backend.scm",(void*)f_2697},
{"f_2658c-backend.scm",(void*)f_2658},
{"f_2661c-backend.scm",(void*)f_2661},
{"f_2664c-backend.scm",(void*)f_2664},
{"f_2679c-backend.scm",(void*)f_2679},
{"f_2684c-backend.scm",(void*)f_2684},
{"f_2667c-backend.scm",(void*)f_2667},
{"f_2608c-backend.scm",(void*)f_2608},
{"f_2622c-backend.scm",(void*)f_2622},
{"f_1178c-backend.scm",(void*)f_1178},
{"f_2573c-backend.scm",(void*)f_2573},
{"f_2579c-backend.scm",(void*)f_2579},
{"f_2583c-backend.scm",(void*)f_2583},
{"f_1181c-backend.scm",(void*)f_1181},
{"f_2538c-backend.scm",(void*)f_2538},
{"f_2541c-backend.scm",(void*)f_2541},
{"f_2544c-backend.scm",(void*)f_2544},
{"f_2547c-backend.scm",(void*)f_2547},
{"f_2550c-backend.scm",(void*)f_2550},
{"f_2553c-backend.scm",(void*)f_2553},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_2458c-backend.scm",(void*)f_2458},
{"f_2461c-backend.scm",(void*)f_2461},
{"f_2474c-backend.scm",(void*)f_2474},
{"f_2497c-backend.scm",(void*)f_2497},
{"f_2500c-backend.scm",(void*)f_2500},
{"f_2503c-backend.scm",(void*)f_2503},
{"f_2506c-backend.scm",(void*)f_2506},
{"f_2484c-backend.scm",(void*)f_2484},
{"f_2487c-backend.scm",(void*)f_2487},
{"f_2446c-backend.scm",(void*)f_2446},
{"f_2418c-backend.scm",(void*)f_2418},
{"f_2421c-backend.scm",(void*)f_2421},
{"f_2438c-backend.scm",(void*)f_2438},
{"f_2424c-backend.scm",(void*)f_2424},
{"f_2427c-backend.scm",(void*)f_2427},
{"f_2402c-backend.scm",(void*)f_2402},
{"f_2406c-backend.scm",(void*)f_2406},
{"f_2388c-backend.scm",(void*)f_2388},
{"f_2391c-backend.scm",(void*)f_2391},
{"f_2372c-backend.scm",(void*)f_2372},
{"f_2376c-backend.scm",(void*)f_2376},
{"f_2354c-backend.scm",(void*)f_2354},
{"f_2357c-backend.scm",(void*)f_2357},
{"f_2334c-backend.scm",(void*)f_2334},
{"f_2298c-backend.scm",(void*)f_2298},
{"f_2310c-backend.scm",(void*)f_2310},
{"f_2301c-backend.scm",(void*)f_2301},
{"f_2279c-backend.scm",(void*)f_2279},
{"f_2282c-backend.scm",(void*)f_2282},
{"f_2260c-backend.scm",(void*)f_2260},
{"f_2263c-backend.scm",(void*)f_2263},
{"f_2241c-backend.scm",(void*)f_2241},
{"f_2244c-backend.scm",(void*)f_2244},
{"f_2222c-backend.scm",(void*)f_2222},
{"f_2218c-backend.scm",(void*)f_2218},
{"f_2166c-backend.scm",(void*)f_2166},
{"f_2199c-backend.scm",(void*)f_2199},
{"f_2169c-backend.scm",(void*)f_2169},
{"f_2187c-backend.scm",(void*)f_2187},
{"f_2172c-backend.scm",(void*)f_2172},
{"f_2175c-backend.scm",(void*)f_2175},
{"f_2133c-backend.scm",(void*)f_2133},
{"f_2117c-backend.scm",(void*)f_2117},
{"f_2120c-backend.scm",(void*)f_2120},
{"f_2123c-backend.scm",(void*)f_2123},
{"f_2076c-backend.scm",(void*)f_2076},
{"f_2079c-backend.scm",(void*)f_2079},
{"f_2100c-backend.scm",(void*)f_2100},
{"f_2104c-backend.scm",(void*)f_2104},
{"f_2107c-backend.scm",(void*)f_2107},
{"f_2082c-backend.scm",(void*)f_2082},
{"f_2098c-backend.scm",(void*)f_2098},
{"f_2090c-backend.scm",(void*)f_2090},
{"f_2085c-backend.scm",(void*)f_2085},
{"f_1822c-backend.scm",(void*)f_1822},
{"f_1825c-backend.scm",(void*)f_1825},
{"f_2026c-backend.scm",(void*)f_2026},
{"f_2022c-backend.scm",(void*)f_2022},
{"f_1831c-backend.scm",(void*)f_1831},
{"f_1176c-backend.scm",(void*)f_1176},
{"f_2015c-backend.scm",(void*)f_2015},
{"f_1166c-backend.scm",(void*)f_1166},
{"f_2008c-backend.scm",(void*)f_2008},
{"f_1837c-backend.scm",(void*)f_1837},
{"f_1961c-backend.scm",(void*)f_1961},
{"f_1964c-backend.scm",(void*)f_1964},
{"f_1967c-backend.scm",(void*)f_1967},
{"f_1982c-backend.scm",(void*)f_1982},
{"f_1970c-backend.scm",(void*)f_1970},
{"f_1973c-backend.scm",(void*)f_1973},
{"f_1976c-backend.scm",(void*)f_1976},
{"f_1958c-backend.scm",(void*)f_1958},
{"f_1868c-backend.scm",(void*)f_1868},
{"f_1942c-backend.scm",(void*)f_1942},
{"f_1945c-backend.scm",(void*)f_1945},
{"f_1918c-backend.scm",(void*)f_1918},
{"f_1921c-backend.scm",(void*)f_1921},
{"f_1924c-backend.scm",(void*)f_1924},
{"f_1927c-backend.scm",(void*)f_1927},
{"f_1930c-backend.scm",(void*)f_1930},
{"f_1871c-backend.scm",(void*)f_1871},
{"f_1874c-backend.scm",(void*)f_1874},
{"f_1901c-backend.scm",(void*)f_1901},
{"f_1905c-backend.scm",(void*)f_1905},
{"f_1908c-backend.scm",(void*)f_1908},
{"f_1877c-backend.scm",(void*)f_1877},
{"f_1899c-backend.scm",(void*)f_1899},
{"f_1891c-backend.scm",(void*)f_1891},
{"f_1880c-backend.scm",(void*)f_1880},
{"f_1883c-backend.scm",(void*)f_1883},
{"f_1849c-backend.scm",(void*)f_1849},
{"f_1852c-backend.scm",(void*)f_1852},
{"f_1779c-backend.scm",(void*)f_1779},
{"f_1782c-backend.scm",(void*)f_1782},
{"f_1766c-backend.scm",(void*)f_1766},
{"f_1769c-backend.scm",(void*)f_1769},
{"f_1732c-backend.scm",(void*)f_1732},
{"f_1735c-backend.scm",(void*)f_1735},
{"f_1704c-backend.scm",(void*)f_1704},
{"f_1700c-backend.scm",(void*)f_1700},
{"f_1658c-backend.scm",(void*)f_1658},
{"f_1626c-backend.scm",(void*)f_1626},
{"f_1629c-backend.scm",(void*)f_1629},
{"f_1591c-backend.scm",(void*)f_1591},
{"f_1617c-backend.scm",(void*)f_1617},
{"f_1603c-backend.scm",(void*)f_1603},
{"f_1607c-backend.scm",(void*)f_1607},
{"f_1610c-backend.scm",(void*)f_1610},
{"f_1594c-backend.scm",(void*)f_1594},
{"f_1559c-backend.scm",(void*)f_1559},
{"f_1562c-backend.scm",(void*)f_1562},
{"f_1565c-backend.scm",(void*)f_1565},
{"f_1568c-backend.scm",(void*)f_1568},
{"f_1530c-backend.scm",(void*)f_1530},
{"f_1533c-backend.scm",(void*)f_1533},
{"f_1536c-backend.scm",(void*)f_1536},
{"f_1539c-backend.scm",(void*)f_1539},
{"f_1493c-backend.scm",(void*)f_1493},
{"f_1496c-backend.scm",(void*)f_1496},
{"f_1499c-backend.scm",(void*)f_1499},
{"f_1502c-backend.scm",(void*)f_1502},
{"f_1460c-backend.scm",(void*)f_1460},
{"f_1463c-backend.scm",(void*)f_1463},
{"f_1466c-backend.scm",(void*)f_1466},
{"f_1469c-backend.scm",(void*)f_1469},
{"f_1441c-backend.scm",(void*)f_1441},
{"f_1444c-backend.scm",(void*)f_1444},
{"f_1414c-backend.scm",(void*)f_1414},
{"f_1417c-backend.scm",(void*)f_1417},
{"f_1363c-backend.scm",(void*)f_1363},
{"f_1373c-backend.scm",(void*)f_1373},
{"f_1376c-backend.scm",(void*)f_1376},
{"f_1379c-backend.scm",(void*)f_1379},
{"f_1305c-backend.scm",(void*)f_1305},
{"f_1308c-backend.scm",(void*)f_1308},
{"f_1311c-backend.scm",(void*)f_1311},
{"f_1314c-backend.scm",(void*)f_1314},
{"f_1317c-backend.scm",(void*)f_1317},
{"f_1320c-backend.scm",(void*)f_1320},
{"f_1136c-backend.scm",(void*)f_1136},
{"f_1148c-backend.scm",(void*)f_1148},
{"f_1156c-backend.scm",(void*)f_1156},
{"f_1140c-backend.scm",(void*)f_1140},
{"f_1113c-backend.scm",(void*)f_1113},
{"f_1127c-backend.scm",(void*)f_1127},
{"f_1119c-backend.scm",(void*)f_1119},
{"f_1092c-backend.scm",(void*)f_1092},
{"f_1098c-backend.scm",(void*)f_1098},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
