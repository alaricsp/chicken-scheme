/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-09-10 08:05
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[822];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2341(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2341(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9033)
static void C_ccall f_9033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8738)
static C_word C_fcall f_8738(C_word *a,C_word t0);
C_noret_decl(f_8735)
static C_word C_fcall f_8735(C_word t0);
C_noret_decl(f_8732)
static C_word C_fcall f_8732(C_word t0);
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8418)
static void C_fcall f_8418(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8499)
static void C_ccall f_8499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_fcall f_8521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_fcall f_8333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7876)
static void C_fcall f_7876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_fcall f_7903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8098)
static void C_fcall f_8098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_fcall f_8107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_fcall f_8138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_fcall f_7848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7087)
static void C_fcall f_7087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_fcall f_7222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7318)
static void C_fcall f_7318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_fcall f_7373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_fcall f_7390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_fcall f_7407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_fcall f_7446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_fcall f_7463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_fcall f_7480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_fcall f_7497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_fcall f_7514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_fcall f_7531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_fcall f_7548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7418)
static void C_ccall f_7418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_ccall f_7401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_fcall f_7017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7012)
static void C_fcall f_7012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6551)
static void C_fcall f_6551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_fcall f_6560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_fcall f_6572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_fcall f_6584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_fcall f_6624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6269)
static void C_ccall f_6269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6119)
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6148)
static void C_fcall f_6148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6151)
static void C_fcall f_6151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_fcall f_6135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_ccall f_6029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_fcall f_5257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_fcall f_5903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_fcall f_5351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_fcall f_5865(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_fcall f_5808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_fcall f_5829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_fcall f_5772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_fcall f_5739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_fcall f_5748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_fcall f_5693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_fcall f_5383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_ccall f_5472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_fcall f_5443(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_fcall f_4995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_fcall f_4824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_fcall f_5026(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_fcall f_5033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_fcall f_5122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_fcall f_4861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_fcall f_5168(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_fcall f_5183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_fcall f_5199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_fcall f_5245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_fcall f_4538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_fcall f_4724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_fcall f_4727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_fcall f_4773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_fcall f_4577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_fcall f_4554(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_fcall f_4287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_fcall f_4325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_fcall f_4346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_fcall f_4411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_fcall f_4138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_fcall f_4159(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_fcall f_4228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_fcall f_3991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_fcall f_3994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3959)
static void C_fcall f_3959(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_fcall f_3845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_fcall f_3348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_fcall f_2464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8418)
static void C_fcall trf_8418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8418(t0,t1);}

C_noret_decl(trf_8521)
static void C_fcall trf_8521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8521(t0,t1);}

C_noret_decl(trf_8333)
static void C_fcall trf_8333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8333(t0,t1);}

C_noret_decl(trf_7876)
static void C_fcall trf_7876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7876(t0,t1);}

C_noret_decl(trf_7903)
static void C_fcall trf_7903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7903(t0,t1);}

C_noret_decl(trf_8098)
static void C_fcall trf_8098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8098(t0,t1);}

C_noret_decl(trf_8107)
static void C_fcall trf_8107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8107(t0,t1);}

C_noret_decl(trf_8138)
static void C_fcall trf_8138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8138(t0,t1);}

C_noret_decl(trf_7848)
static void C_fcall trf_7848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7848(t0,t1);}

C_noret_decl(trf_7087)
static void C_fcall trf_7087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7087(t0,t1);}

C_noret_decl(trf_7189)
static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7189(t0,t1);}

C_noret_decl(trf_7222)
static void C_fcall trf_7222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7222(t0,t1);}

C_noret_decl(trf_7318)
static void C_fcall trf_7318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7318(t0,t1);}

C_noret_decl(trf_7373)
static void C_fcall trf_7373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7373(t0,t1);}

C_noret_decl(trf_7390)
static void C_fcall trf_7390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7390(t0,t1);}

C_noret_decl(trf_7407)
static void C_fcall trf_7407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7407(t0,t1);}

C_noret_decl(trf_7446)
static void C_fcall trf_7446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7446(t0,t1);}

C_noret_decl(trf_7463)
static void C_fcall trf_7463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7463(t0,t1);}

C_noret_decl(trf_7480)
static void C_fcall trf_7480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7480(t0,t1);}

C_noret_decl(trf_7497)
static void C_fcall trf_7497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7497(t0,t1);}

C_noret_decl(trf_7514)
static void C_fcall trf_7514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7514(t0,t1);}

C_noret_decl(trf_7531)
static void C_fcall trf_7531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7531(t0,t1);}

C_noret_decl(trf_7548)
static void C_fcall trf_7548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7548(t0,t1);}

C_noret_decl(trf_7017)
static void C_fcall trf_7017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7017(t0,t1,t2);}

C_noret_decl(trf_7012)
static void C_fcall trf_7012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7012(t0,t1);}

C_noret_decl(trf_6551)
static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6551(t0,t1);}

C_noret_decl(trf_6560)
static void C_fcall trf_6560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6560(t0,t1);}

C_noret_decl(trf_6572)
static void C_fcall trf_6572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6572(t0,t1);}

C_noret_decl(trf_6584)
static void C_fcall trf_6584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6584(t0,t1);}

C_noret_decl(trf_6624)
static void C_fcall trf_6624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6624(t0,t1);}

C_noret_decl(trf_6119)
static void C_fcall trf_6119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6119(t0,t1,t2);}

C_noret_decl(trf_6148)
static void C_fcall trf_6148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6148(t0,t1);}

C_noret_decl(trf_6151)
static void C_fcall trf_6151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6151(t0,t1);}

C_noret_decl(trf_6135)
static void C_fcall trf_6135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6135(t0,t1);}

C_noret_decl(trf_6055)
static void C_fcall trf_6055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6055(t0,t1,t2);}

C_noret_decl(trf_5257)
static void C_fcall trf_5257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5257(t0,t1);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5285(t0,t1);}

C_noret_decl(trf_5903)
static void C_fcall trf_5903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5903(t0,t1);}

C_noret_decl(trf_5351)
static void C_fcall trf_5351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5351(t0,t1);}

C_noret_decl(trf_5865)
static void C_fcall trf_5865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5865(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5865(t0,t1,t2,t3);}

C_noret_decl(trf_5808)
static void C_fcall trf_5808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5808(t0,t1);}

C_noret_decl(trf_5829)
static void C_fcall trf_5829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5829(t0,t1);}

C_noret_decl(trf_5772)
static void C_fcall trf_5772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5772(t0,t1);}

C_noret_decl(trf_5739)
static void C_fcall trf_5739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5739(t0,t1);}

C_noret_decl(trf_5748)
static void C_fcall trf_5748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5748(t0,t1);}

C_noret_decl(trf_5693)
static void C_fcall trf_5693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5693(t0,t1);}

C_noret_decl(trf_5383)
static void C_fcall trf_5383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5383(t0,t1);}

C_noret_decl(trf_5443)
static void C_fcall trf_5443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5443(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5443(t0,t1,t2,t3);}

C_noret_decl(trf_4995)
static void C_fcall trf_4995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4995(t0,t1,t2,t3);}

C_noret_decl(trf_4824)
static void C_fcall trf_4824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4824(t0,t1);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4830(t0,t1,t2,t3);}

C_noret_decl(trf_5026)
static void C_fcall trf_5026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5026(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5026(t0,t1,t2,t3);}

C_noret_decl(trf_5033)
static void C_fcall trf_5033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5033(t0,t1);}

C_noret_decl(trf_5122)
static void C_fcall trf_5122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5122(t0,t1);}

C_noret_decl(trf_4861)
static void C_fcall trf_4861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4861(t0,t1);}

C_noret_decl(trf_5168)
static void C_fcall trf_5168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5168(t0,t1,t2);}

C_noret_decl(trf_5183)
static void C_fcall trf_5183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5183(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5183(t0,t1,t2,t3);}

C_noret_decl(trf_5199)
static void C_fcall trf_5199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5199(t0,t1);}

C_noret_decl(trf_5245)
static void C_fcall trf_5245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5245(t0,t1,t2,t3);}

C_noret_decl(trf_4538)
static void C_fcall trf_4538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4538(t0,t1);}

C_noret_decl(trf_4724)
static void C_fcall trf_4724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4724(t0,t1);}

C_noret_decl(trf_4727)
static void C_fcall trf_4727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4727(t0,t1);}

C_noret_decl(trf_4773)
static void C_fcall trf_4773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4773(t0,t1);}

C_noret_decl(trf_4577)
static void C_fcall trf_4577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4577(t0,t1,t2);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4541(t0,t1);}

C_noret_decl(trf_4554)
static void C_fcall trf_4554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4554(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4554(t0,t1,t2,t3);}

C_noret_decl(trf_4287)
static void C_fcall trf_4287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4287(t0,t1);}

C_noret_decl(trf_4325)
static void C_fcall trf_4325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4325(t0,t1);}

C_noret_decl(trf_4346)
static void C_fcall trf_4346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4346(t0,t1);}

C_noret_decl(trf_4411)
static void C_fcall trf_4411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4411(t0,t1);}

C_noret_decl(trf_4138)
static void C_fcall trf_4138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4138(t0,t1);}

C_noret_decl(trf_4159)
static void C_fcall trf_4159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4159(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4159(t0,t1,t2,t3);}

C_noret_decl(trf_4228)
static void C_fcall trf_4228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4228(t0,t1,t2);}

C_noret_decl(trf_4201)
static void C_fcall trf_4201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4201(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4201(t0,t1,t2);}

C_noret_decl(trf_3991)
static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3991(t0,t1);}

C_noret_decl(trf_3994)
static void C_fcall trf_3994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3994(t0,t1);}

C_noret_decl(trf_2506)
static void C_fcall trf_2506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2506(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2506(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3959)
static void C_fcall trf_3959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3959(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3959(t0,t1,t2,t3);}

C_noret_decl(trf_2509)
static void C_fcall trf_2509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2509(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2509(t0,t1,t2,t3);}

C_noret_decl(trf_3845)
static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3845(t0,t1,t2,t3);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3186(t0,t1);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3192(t0,t1);}

C_noret_decl(trf_3348)
static void C_fcall trf_3348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3348(t0,t1);}

C_noret_decl(trf_2691)
static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2691(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2496(t0,t1);}

C_noret_decl(trf_2464)
static void C_fcall trf_2464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2464(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,822);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],15,"\010compileroutput");
lf[3]=C_h_intern(&lf[3],12,"\010compilergen");
lf[4]=C_h_intern(&lf[4],7,"newline");
lf[5]=C_h_intern(&lf[5],7,"display");
lf[6]=C_h_intern(&lf[6],12,"\003sysfor-each");
lf[7]=C_h_intern(&lf[7],17,"\010compilergen-list");
lf[8]=C_h_intern(&lf[8],11,"intersperse");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunique-id");
lf[10]=C_h_intern(&lf[10],22,"\010compilergenerate-code");
lf[11]=C_h_intern(&lf[11],13,"\010compilerbomb");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[13]=C_h_intern(&lf[13],17,"lambda-literal-id");
lf[14]=C_h_intern(&lf[14],4,"find");
lf[15]=C_h_intern(&lf[15],17,"string-translate*");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[17]=C_h_intern(&lf[17],8,"->string");
lf[18]=C_h_intern(&lf[18],14,"\004coreimmediate");
lf[19]=C_h_intern(&lf[19],4,"bool");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[22]=C_h_intern(&lf[22],4,"char");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[24]=C_h_intern(&lf[24],3,"nil");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[26]=C_h_intern(&lf[26],3,"fix");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[28]=C_h_intern(&lf[28],3,"eof");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[31]=C_h_intern(&lf[31],12,"\004coreliteral");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[35]=C_h_intern(&lf[35],2,"if");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[39]=C_h_intern(&lf[39],9,"\004coreproc");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[41]=C_h_intern(&lf[41],9,"\004corebind");
lf[42]=C_h_intern(&lf[42],8,"\004coreref");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[45]=C_h_intern(&lf[45],10,"\004coreunbox");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[48]=C_h_intern(&lf[48],13,"\004coreupdate_i");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[50]=C_h_intern(&lf[50],11,"\004coreupdate");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[54]=C_h_intern(&lf[54],16,"\004coreupdatebox_i");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[57]=C_h_intern(&lf[57],14,"\004coreupdatebox");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[60]=C_h_intern(&lf[60],12,"\004coreclosure");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[65]=C_h_intern(&lf[65],8,"for-each");
lf[66]=C_h_intern(&lf[66],4,"iota");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[68]=C_h_intern(&lf[68],8,"\004corebox");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[71]=C_h_intern(&lf[71],10,"\004corelocal");
lf[72]=C_h_intern(&lf[72],13,"\004coresetlocal");
lf[73]=C_h_intern(&lf[73],11,"\004coreglobal");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[78]=C_h_intern(&lf[78],21,"\010compilerc-ify-string");
lf[79]=C_h_intern(&lf[79],14,"symbol->string");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[84]=C_h_intern(&lf[84],14,"\004coresetglobal");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[91]=C_h_intern(&lf[91],16,"\004coresetglobal_i");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[98]=C_h_intern(&lf[98],14,"\004coreundefined");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[100]=C_h_intern(&lf[100],9,"\004corecall");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[106]=C_h_intern(&lf[106],26,"lambda-literal-temporaries");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_h_intern(&lf[108],22,"lambda-literal-looping");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[112]=C_h_intern(&lf[112],6,"unsafe");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[117]=C_h_intern(&lf[117],19,"no-procedure-checks");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[120]=C_h_intern(&lf[120],24,"\010compileremit-trace-info");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[123]=C_h_intern(&lf[123],16,"string-translate");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[128]=C_h_intern(&lf[128],27,"lambda-literal-closure-size");
lf[129]=C_h_intern(&lf[129],28,"\010compilersource-info->string");
lf[130]=C_h_intern(&lf[130],12,"\004corerecurse");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[134]=C_h_intern(&lf[134],16,"\004coredirect_call");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[136]=C_h_intern(&lf[136],13,"\004corecallunit");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[141]=C_h_intern(&lf[141],11,"\004corereturn");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[144]=C_h_intern(&lf[144],11,"\004coreinline");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[146]=C_h_intern(&lf[146],20,"\004coreinline_allocate");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[149]=C_h_intern(&lf[149],15,"\004coreinline_ref");
lf[150]=C_h_intern(&lf[150],34,"\010compilerforeign-result-conversion");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[152]=C_h_intern(&lf[152],18,"\004coreinline_update");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[155]=C_h_intern(&lf[155],36,"\010compilerforeign-argument-conversion");
lf[156]=C_h_intern(&lf[156],33,"\010compilerforeign-type-declaration");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_h_intern(&lf[158],19,"\004coreinline_loc_ref");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[164]=C_h_intern(&lf[164],22,"\004coreinline_loc_update");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_h_intern(&lf[170],11,"\004coreswitch");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[175]=C_h_intern(&lf[175],9,"\004corecond");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[179]=C_h_intern(&lf[179],13,"pair-for-each");
lf[180]=C_h_intern(&lf[180],13,"string-append");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[182]=C_h_intern(&lf[182],30,"\010compilerexternal-protos-first");
lf[183]=C_h_intern(&lf[183],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[184]=C_h_intern(&lf[184],22,"foreign-callback-stubs");
lf[185]=C_h_intern(&lf[185],29,"\010compilerforeign-declarations");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[188]=C_h_intern(&lf[188],28,"\010compilertarget-include-file");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[190]=C_h_intern(&lf[190],18,"\010compilerunit-name");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[192]=C_h_intern(&lf[192],19,"\010compilerused-units");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[194]=C_h_intern(&lf[194],27,"\010compilercompiler-arguments");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[200]=C_h_intern(&lf[200],18,"string-intersperse");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[204]=C_h_intern(&lf[204],7,"\003sysmap");
lf[205]=C_h_intern(&lf[205],12,"string-split");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[207]=C_h_intern(&lf[207],15,"chicken-version");
lf[208]=C_h_intern(&lf[208],18,"\003sysdecode-seconds");
lf[209]=C_h_intern(&lf[209],15,"current-seconds");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[214]=C_h_intern(&lf[214],23,"\003syslambda-info->string");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[224]=C_h_intern(&lf[224],9,"make-list");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[228]=C_h_intern(&lf[228],4,"none");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[239]=C_h_intern(&lf[239],8,"toplevel");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[242]=C_h_intern(&lf[242],27,"\010compileremit-unsafe-marker");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[255]=C_h_intern(&lf[255],21,"small-parameter-limit");
lf[256]=C_h_intern(&lf[256],11,"lset-adjoin");
lf[257]=C_h_intern(&lf[257],1,"=");
lf[258]=C_h_intern(&lf[258],32,"lambda-literal-callee-signatures");
lf[259]=C_h_intern(&lf[259],24,"lambda-literal-allocated");
lf[260]=C_h_intern(&lf[260],21,"lambda-literal-direct");
lf[261]=C_h_intern(&lf[261],33,"lambda-literal-rest-argument-mode");
lf[262]=C_h_intern(&lf[262],28,"lambda-literal-rest-argument");
lf[263]=C_h_intern(&lf[263],27,"\010compilermake-variable-list");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[265]=C_h_intern(&lf[265],27,"lambda-literal-customizable");
lf[266]=C_h_intern(&lf[266],29,"lambda-literal-argument-count");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[273]=C_h_intern(&lf[273],27,"\010compilermake-argument-list");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[313]=C_h_intern(&lf[313],6,"vector");
lf[314]=C_h_intern(&lf[314],23,"lambda-literal-external");
lf[315]=C_h_intern(&lf[315],14,"\003syscopy-bytes");
lf[316]=C_h_intern(&lf[316],11,"make-string");
lf[317]=C_h_intern(&lf[317],6,"modulo");
lf[318]=C_h_intern(&lf[318],3,"fx/");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[322]=C_h_intern(&lf[322],19,"\003sysundefined-value");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[333]=C_h_intern(&lf[333],23,"\010compilerencode-literal");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[335]=C_h_intern(&lf[335],32,"\010compilerblock-variable-literal\077");
lf[336]=C_h_intern(&lf[336],20,"\010compilerbig-fixnum\077");
lf[337]=C_h_intern(&lf[337],7,"sprintf");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[339]=C_h_intern(&lf[339],25,"\010compilerwords-per-flonum");
lf[340]=C_h_intern(&lf[340],6,"reduce");
lf[341]=C_h_intern(&lf[341],1,"+");
lf[342]=C_h_intern(&lf[342],12,"vector->list");
lf[343]=C_h_intern(&lf[343],14,"\010compilerwords");
lf[344]=C_h_intern(&lf[344],15,"\003sysbytevector\077");
lf[345]=C_h_intern(&lf[345],19,"\010compilerimmediate\077");
lf[346]=C_h_intern(&lf[346],19,"lambda-literal-body");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[359]=C_h_intern(&lf[359],4,"list");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[398]=C_h_intern(&lf[398],26,"\010compilertarget-stack-size");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_h_intern(&lf[401],30,"\010compilertarget-heap-shrinkage");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[403]=C_h_intern(&lf[403],27,"\010compilertarget-heap-growth");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[405]=C_h_intern(&lf[405],33,"\010compilertarget-initial-heap-size");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[408]=C_h_intern(&lf[408],25,"\010compilertarget-heap-size");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[412]=C_h_intern(&lf[412],40,"\010compilerdisable-stack-overflow-checking");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[418]=C_h_intern(&lf[418],4,"fold");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[421]=C_h_intern(&lf[421],28,"\010compilerinsert-timer-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[426]=C_h_intern(&lf[426],14,"no-argc-checks");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[473]=C_h_intern(&lf[473],16,"\010compilercleanup");
lf[474]=C_h_intern(&lf[474],18,"\010compilerdebugging");
lf[475]=C_h_intern(&lf[475],1,"o");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[481]=C_h_intern(&lf[481],18,"\010compilerreal-name");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[483]=C_h_intern(&lf[483],25,"emit-procedure-table-info");
lf[484]=C_h_intern(&lf[484],31,"generate-foreign-callback-stubs");
lf[485]=C_h_intern(&lf[485],31,"\010compilergenerate-foreign-stubs");
lf[486]=C_h_intern(&lf[486],29,"\010compilerforeign-lambda-stubs");
lf[487]=C_h_intern(&lf[487],36,"\010compilergenerate-external-variables");
lf[488]=C_h_intern(&lf[488],27,"\010compilerexternal-variables");
lf[489]=C_h_intern(&lf[489],1,"p");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[510]=C_h_intern(&lf[510],11,"string-copy");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[512]=C_h_intern(&lf[512],13,"list-tabulate");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[515]=C_h_intern(&lf[515],41,"\010compilergenerate-foreign-callback-header");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[528]=C_h_intern(&lf[528],4,"void");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[553]=C_h_intern(&lf[553],21,"foreign-stub-callback");
lf[554]=C_h_intern(&lf[554],16,"foreign-stub-cps");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[556]=C_h_intern(&lf[556],27,"foreign-stub-argument-names");
lf[557]=C_h_intern(&lf[557],17,"foreign-stub-body");
lf[558]=C_h_intern(&lf[558],17,"foreign-stub-name");
lf[559]=C_h_intern(&lf[559],24,"foreign-stub-return-type");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[562]=C_h_intern(&lf[562],27,"foreign-stub-argument-types");
lf[563]=C_h_intern(&lf[563],19,"\010compilerreal-name2");
lf[564]=C_h_intern(&lf[564],15,"foreign-stub-id");
lf[565]=C_h_intern(&lf[565],5,"float");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[567]=C_h_intern(&lf[567],8,"c-string");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[571]=C_h_intern(&lf[571],16,"nonnull-c-string");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[574]=C_h_intern(&lf[574],3,"ref");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[576]=C_h_intern(&lf[576],5,"const");
lf[577]=C_h_intern(&lf[577],7,"pointer");
lf[578]=C_h_intern(&lf[578],9,"c-pointer");
lf[579]=C_h_intern(&lf[579],15,"nonnull-pointer");
lf[580]=C_h_intern(&lf[580],17,"nonnull-c-pointer");
lf[581]=C_h_intern(&lf[581],8,"function");
lf[582]=C_h_intern(&lf[582],8,"instance");
lf[583]=C_h_intern(&lf[583],16,"nonnull-instance");
lf[584]=C_h_intern(&lf[584],12,"instance-ref");
lf[585]=C_h_intern(&lf[585],18,"\003syshash-table-ref");
lf[586]=C_h_intern(&lf[586],27,"\010compilerforeign-type-table");
lf[587]=C_h_intern(&lf[587],17,"nonnull-c-string*");
lf[588]=C_h_intern(&lf[588],25,"nonnull-unsigned-c-string");
lf[589]=C_h_intern(&lf[589],26,"nonnull-unsigned-c-string*");
lf[590]=C_h_intern(&lf[590],6,"symbol");
lf[591]=C_h_intern(&lf[591],9,"c-string*");
lf[592]=C_h_intern(&lf[592],17,"unsigned-c-string");
lf[593]=C_h_intern(&lf[593],18,"unsigned-c-string*");
lf[594]=C_h_intern(&lf[594],6,"double");
lf[595]=C_h_intern(&lf[595],16,"unsigned-integer");
lf[596]=C_h_intern(&lf[596],18,"unsigned-integer32");
lf[597]=C_h_intern(&lf[597],4,"long");
lf[598]=C_h_intern(&lf[598],7,"integer");
lf[599]=C_h_intern(&lf[599],9,"integer32");
lf[600]=C_h_intern(&lf[600],13,"unsigned-long");
lf[601]=C_h_intern(&lf[601],6,"number");
lf[602]=C_h_intern(&lf[602],9,"integer64");
lf[603]=C_h_intern(&lf[603],13,"c-string-list");
lf[604]=C_h_intern(&lf[604],14,"c-string-list*");
lf[605]=C_h_intern(&lf[605],3,"int");
lf[606]=C_h_intern(&lf[606],5,"int32");
lf[607]=C_h_intern(&lf[607],5,"short");
lf[608]=C_h_intern(&lf[608],14,"unsigned-short");
lf[609]=C_h_intern(&lf[609],13,"scheme-object");
lf[610]=C_h_intern(&lf[610],13,"unsigned-char");
lf[611]=C_h_intern(&lf[611],12,"unsigned-int");
lf[612]=C_h_intern(&lf[612],14,"unsigned-int32");
lf[613]=C_h_intern(&lf[613],4,"byte");
lf[614]=C_h_intern(&lf[614],13,"unsigned-byte");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[626]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[627]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],36,"foreign-callback-stub-argument-types");
lf[631]=C_h_intern(&lf[631],33,"foreign-callback-stub-return-type");
lf[632]=C_h_intern(&lf[632],24,"foreign-callback-stub-id");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[635]=C_h_intern(&lf[635],32,"foreign-callback-stub-qualifiers");
lf[636]=C_h_intern(&lf[636],26,"foreign-callback-stub-name");
lf[637]=C_h_intern(&lf[637],4,"quit");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[657]=C_h_intern(&lf[657],11,"byte-vector");
lf[658]=C_h_intern(&lf[658],19,"nonnull-byte-vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[660]=C_h_intern(&lf[660],4,"blob");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[662]=C_h_intern(&lf[662],9,"u16vector");
lf[663]=C_h_intern(&lf[663],17,"nonnull-u16vector");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[665]=C_h_intern(&lf[665],8,"s8vector");
lf[666]=C_h_intern(&lf[666],16,"nonnull-s8vector");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[668]=C_h_intern(&lf[668],9,"u32vector");
lf[669]=C_h_intern(&lf[669],17,"nonnull-u32vector");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[671]=C_h_intern(&lf[671],9,"s16vector");
lf[672]=C_h_intern(&lf[672],17,"nonnull-s16vector");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[674]=C_h_intern(&lf[674],9,"s32vector");
lf[675]=C_h_intern(&lf[675],17,"nonnull-s32vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[677]=C_h_intern(&lf[677],9,"f32vector");
lf[678]=C_h_intern(&lf[678],17,"nonnull-f32vector");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[680]=C_h_intern(&lf[680],9,"f64vector");
lf[681]=C_h_intern(&lf[681],17,"nonnull-f64vector");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[710]=C_h_intern(&lf[710],9,"\003syserror");
lf[711]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[712]=C_h_intern(&lf[712],4,"enum");
lf[713]=C_h_intern(&lf[713],5,"union");
lf[714]=C_h_intern(&lf[714],6,"struct");
lf[715]=C_h_intern(&lf[715],8,"template");
lf[716]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[717]=C_h_intern(&lf[717],12,"nonnull-blob");
lf[718]=C_h_intern(&lf[718],8,"u8vector");
lf[719]=C_h_intern(&lf[719],16,"nonnull-u8vector");
lf[720]=C_h_intern(&lf[720],14,"scheme-pointer");
lf[721]=C_h_intern(&lf[721],22,"nonnull-scheme-pointer");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[816]=C_h_intern(&lf[816],17,"\003sysstring-append");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[818]=C_h_intern(&lf[818],5,"cons*");
lf[819]=C_h_intern(&lf[819],29,"\010compilerstring->c-identifier");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[821]=C_h_intern(&lf[821],6,"random");
C_register_lf2(lf,822,create_ptable());
t2=C_mutate(&lf[0] /* c2031 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2400 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2403 in k2400 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2406 in k2403 in k2400 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2417,2,t0,t1);}
t2=C_set_block_item(lf[2] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[3]+1 /* gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2420,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2441,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9029,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9033,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t8=C_retrieve(lf[821]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix(16777216));}

/* k9031 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_9033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9037,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9035 in k9031 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[337]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[820],((C_word*)t0)[2],t1);}

/* k9027 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[819]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[10]+1 /* generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2461,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[483]+1 /* emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6037,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[473]+1 /* cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6110,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[263]+1 /* make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6199,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[273]+1 /* make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6215,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[487]+1 /* generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6231,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[183]+1 /* generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6263,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[485]+1 /* generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6281,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[484]+1 /* generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6514,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[515]+1 /* generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6945,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[156]+1 /* foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7010,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[155]+1 /* foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7846,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[150]+1 /* foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8331,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[333]+1 /* encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8729,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8729,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8732,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8735,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8738,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8791(2,t8,lf[803]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8791(2,t9,lf[804]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8738(C_a_i(&a,4),t9);
/* c-backend.scm: 1381 string-append */
t11=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[805],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8791(2,t9,lf[806]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8791(2,t9,lf[807]);}
else{
t9=C_retrieve(lf[322]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8791(2,t11,lf[808]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8909,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1386 big-fixnum? */
t12=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8922,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1395 number->string */
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8738(C_a_i(&a,4),t12);
/* c-backend.scm: 1398 string-append */
t14=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[814],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1403 bomb */
t11=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[815],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8732(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8735(t2);
t16=f_8738(C_a_i(&a,4),t15);
/* c-backend.scm: 1406 string-append */
t17=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8735(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8991,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8732(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8738(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9003,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9005,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1416 list-tabulate */
t19=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a9004 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9005,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1416 encode-literal */
t4=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k9001 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1413 cons* */
t2=C_retrieve(lf[818]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8989 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1412 string-intersperse */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[817]);}

/* k8959 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1405 ##sys#string-append */
t2=C_retrieve(lf[816]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8920 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1395 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[812],t1,lf[813]);}

/* k8907 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8909,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8905,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1393 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1387 string-append */
t14=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[811],t13);}}

/* k8903 in k8907 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1393 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[809],t1,lf[810]);}

/* k8789 in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8791,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1377 string-append */
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static C_word C_fcall f_8738(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static C_word C_fcall f_8735(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub2346(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static C_word C_fcall f_8732(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub2341(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8331,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8333,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[22]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[610]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[777]);}
else{
t8=(C_word)C_eqp(t5,lf[605]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[606]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[778]);}
else{
t10=(C_word)C_eqp(t5,lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[612]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[779]);}
else{
t12=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[780]);}
else{
t13=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[781]);}
else{
t14=(C_word)C_eqp(t5,lf[613]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[782]);}
else{
t15=(C_word)C_eqp(t5,lf[614]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[783]);}
else{
t16=(C_word)C_eqp(t5,lf[565]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[594]));
if(C_truep(t17)){
/* c-backend.scm: 1315 sprintf */
t18=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[784],t3);}
else{
t18=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t18)){
/* c-backend.scm: 1316 sprintf */
t19=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[785],t3);}
else{
t19=(C_word)C_eqp(t5,lf[571]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8418,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8418(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[567]);
if(C_truep(t21)){
t22=t20;
f_8418(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[580]);
if(C_truep(t22)){
t23=t20;
f_8418(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[591]);
if(C_truep(t23)){
t24=t20;
f_8418(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t24)){
t25=t20;
f_8418(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[592]);
if(C_truep(t25)){
t26=t20;
f_8418(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[593]);
if(C_truep(t26)){
t27=t20;
f_8418(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t27)){
t28=t20;
f_8418(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[589]);
if(C_truep(t28)){
t29=t20;
f_8418(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[590]);
if(C_truep(t29)){
t30=t20;
f_8418(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[603]);
t31=t20;
f_8418(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[604])));}}}}}}}}}}}}}}}}}}}}

/* k8416 in ##compiler#foreign-result-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8418(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8418,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1320 sprintf */
t2=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[786],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[578]);
if(C_truep(t2)){
/* c-backend.scm: 1321 sprintf */
t3=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[787],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[599]));
if(C_truep(t4)){
/* c-backend.scm: 1322 sprintf */
t5=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[788],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1323 sprintf */
t6=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[789],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[596]));
if(C_truep(t7)){
/* c-backend.scm: 1324 sprintf */
t8=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[790],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t8)){
/* c-backend.scm: 1325 sprintf */
t9=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[791],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t9)){
/* c-backend.scm: 1326 sprintf */
t10=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[792],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[19]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[793]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[528]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[609]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[794]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1330 ##sys#hash-table-ref */
t14=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8499(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8497 in k8416 in ##compiler#foreign-result-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8499,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1332 foreign-result-conversion */
t4=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8521(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8521(t3,C_SCHEME_FALSE);}}}

/* k8519 in k8497 in k8416 in ##compiler#foreign-result-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[579]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[580]));
if(C_truep(t4)){
/* c-backend.scm: 1336 sprintf */
t5=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],lf[795],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t5)){
/* c-backend.scm: 1338 sprintf */
t6=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[4],lf[796],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t6)){
/* c-backend.scm: 1340 sprintf */
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[4],lf[797],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[583]);
if(C_truep(t7)){
/* c-backend.scm: 1342 sprintf */
t8=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[4],lf[798],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[584]);
if(C_truep(t8)){
/* c-backend.scm: 1344 sprintf */
t9=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[4],lf[799],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1345 foreign-result-conversion */
t11=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t11))(4,t11,((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[578]));
if(C_truep(t11)){
/* c-backend.scm: 1347 sprintf */
t12=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[4],lf[800],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t12)){
/* c-backend.scm: 1348 sprintf */
t13=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t13))(4,t13,((C_word*)t0)[4],lf[801],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[712]);
if(C_truep(t13)){
/* c-backend.scm: 1349 sprintf */
t14=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[4],lf[802],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1350 err */
t14=((C_word*)t0)[2];
f_8333(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1351 err */
t2=((C_word*)t0)[2];
f_8333(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8333,NULL,2,t0,t1);}
/* c-backend.scm: 1306 quit */
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[776],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7846,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[609]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[723]);}
else{
t6=(C_word)C_eqp(t4,lf[22]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[610]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[724]);}
else{
t8=(C_word)C_eqp(t4,lf[613]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7876,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_7876(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[605]);
if(C_truep(t10)){
t11=t9;
f_7876(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[611]);
if(C_truep(t11)){
t12=t9;
f_7876(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[612]);
t13=t9;
f_7876(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[614])));}}}}}}

/* k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7876,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[725]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[607]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[726]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[727]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[728]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7903(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[601]);
t8=t6;
f_7903(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[565])));}}}}}}

/* k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7903,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[729]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[730]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[731]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[732]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[596]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[733]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[577]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[734]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[579]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[735]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[720]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[736]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[721]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[737]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[578]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[738]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[580]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[739]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[740]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[717]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[741]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[742]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[743]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[718]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[744]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[719]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[745]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[662]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[746]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[747]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[668]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[748]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[749]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[665]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[750]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[751]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[671]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[752]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[753]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[754]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[755]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[756]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[678]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[757]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[758]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[681]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[759]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[567]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8098(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[591]);
if(C_truep(t36)){
t37=t35;
f_8098(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
t38=t35;
f_8098(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[593])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8096 in k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8098,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[760]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8107(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
if(C_truep(t4)){
t5=t3;
f_8107(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
if(C_truep(t5)){
t6=t3;
f_8107(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t7=t3;
f_8107(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[590])));}}}}}

/* k8105 in k8096 in k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8107,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[761]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[19]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1279 ##sys#hash-table-ref */
t4=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8116(2,t4,C_SCHEME_FALSE);}}}}

/* k8114 in k8105 in k8096 in k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8116,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1281 foreign-argument-conversion */
t4=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8138(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8138(t3,C_SCHEME_FALSE);}}}

/* k8136 in k8114 in k8105 in k8096 in k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_8138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8138,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[763]);}
else{
t4=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[764]);}
else{
t5=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[765]);}
else{
t6=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[766]);}
else{
t7=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[767]);}
else{
t8=(C_word)C_eqp(t2,lf[583]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[768]);}
else{
t9=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[769]);}
else{
t10=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1292 foreign-argument-conversion */
t12=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t12))(3,t12,((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[712]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[770]);}
else{
t12=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1295 foreign-type-declaration */
t15=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,lf[773]);}
else{
t13=(C_word)C_eqp(t2,lf[584]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1298 string-append */
t15=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,((C_word*)t0)[3],lf[774],t14,lf[775]);}
else{
/* c-backend.scm: 1299 err */
t14=((C_word*)t0)[2];
f_7848(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1300 err */
t2=((C_word*)t0)[2];
f_7848(t2,((C_word*)t0)[3]);}}

/* k8213 in k8136 in k8114 in k8105 in k8096 in k7901 in k7874 in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1295 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[771],t1,lf[772]);}

/* err in ##compiler#foreign-argument-conversion in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7848,NULL,2,t0,t1);}
/* c-backend.scm: 1233 quit */
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[722],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7010,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[609]);
if(C_truep(t7)){
/* c-backend.scm: 1141 str */
t8=t5;
f_7017(t8,t1,lf[640]);}
else{
t8=(C_word)C_eqp(t6,lf[22]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=t5;
f_7017(t10,t1,lf[641]);}
else{
t10=(C_word)C_eqp(t6,lf[610]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[614]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=t5;
f_7017(t12,t1,lf[642]);}
else{
t12=(C_word)C_eqp(t6,lf[611]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[595]));
if(C_truep(t13)){
/* c-backend.scm: 1144 str */
t14=t5;
f_7017(t14,t1,lf[643]);}
else{
t14=(C_word)C_eqp(t6,lf[612]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[596]));
if(C_truep(t15)){
/* c-backend.scm: 1145 str */
t16=t5;
f_7017(t16,t1,lf[644]);}
else{
t16=(C_word)C_eqp(t6,lf[605]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7087,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7087(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[598]);
t19=t17;
f_7087(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[19])));}}}}}}}

/* k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7087,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_7017(t2,((C_word*)t0)[6],lf[645]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
/* c-backend.scm: 1147 str */
t4=((C_word*)t0)[7];
f_7017(t4,((C_word*)t0)[6],lf[646]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t4)){
/* c-backend.scm: 1148 str */
t5=((C_word*)t0)[7];
f_7017(t5,((C_word*)t0)[6],lf[647]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[607]);
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_7017(t6,((C_word*)t0)[6],lf[648]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t6)){
/* c-backend.scm: 1150 str */
t7=((C_word*)t0)[7];
f_7017(t7,((C_word*)t0)[6],lf[649]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t7)){
/* c-backend.scm: 1151 str */
t8=((C_word*)t0)[7];
f_7017(t8,((C_word*)t0)[6],lf[650]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t8)){
/* c-backend.scm: 1152 str */
t9=((C_word*)t0)[7];
f_7017(t9,((C_word*)t0)[6],lf[651]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
if(C_truep(t9)){
/* c-backend.scm: 1153 str */
t10=((C_word*)t0)[7];
f_7017(t10,((C_word*)t0)[6],lf[652]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[601]));
if(C_truep(t11)){
/* c-backend.scm: 1154 str */
t12=((C_word*)t0)[7];
f_7017(t12,((C_word*)t0)[6],lf[653]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[577]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[579]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_7017(t14,((C_word*)t0)[6],lf[654]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7189(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[580]);
if(C_truep(t16)){
t17=t15;
f_7189(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[720]);
t18=t15;
f_7189(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[721])));}}}}}}}}}}}}}

/* k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1157 str */
t2=((C_word*)t0)[7];
f_7017(t2,((C_word*)t0)[6],lf[655]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[604]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[656]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t5)){
/* c-backend.scm: 1160 str */
t6=((C_word*)t0)[7];
f_7017(t6,((C_word*)t0)[6],lf[659]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7222(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[717]);
if(C_truep(t8)){
t9=t7;
f_7222(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[718]);
t10=t7;
f_7222(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[719])));}}}}}}

/* k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7222,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1161 str */
t2=((C_word*)t0)[7];
f_7017(t2,((C_word*)t0)[6],lf[661]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[662]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[663]));
if(C_truep(t3)){
/* c-backend.scm: 1162 str */
t4=((C_word*)t0)[7];
f_7017(t4,((C_word*)t0)[6],lf[664]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[665]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[666]));
if(C_truep(t5)){
/* c-backend.scm: 1163 str */
t6=((C_word*)t0)[7];
f_7017(t6,((C_word*)t0)[6],lf[667]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[668]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[669]));
if(C_truep(t7)){
/* c-backend.scm: 1164 str */
t8=((C_word*)t0)[7];
f_7017(t8,((C_word*)t0)[6],lf[670]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[671]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[672]));
if(C_truep(t9)){
/* c-backend.scm: 1165 str */
t10=((C_word*)t0)[7];
f_7017(t10,((C_word*)t0)[6],lf[673]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t11)){
/* c-backend.scm: 1166 str */
t12=((C_word*)t0)[7];
f_7017(t12,((C_word*)t0)[6],lf[676]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[678]));
if(C_truep(t13)){
/* c-backend.scm: 1167 str */
t14=((C_word*)t0)[7];
f_7017(t14,((C_word*)t0)[6],lf[679]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[680]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[681]));
if(C_truep(t15)){
/* c-backend.scm: 1168 str */
t16=((C_word*)t0)[7];
f_7017(t16,((C_word*)t0)[6],lf[682]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7318(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[567]);
if(C_truep(t18)){
t19=t17;
f_7318(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t19)){
t20=t17;
f_7318(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t20)){
t21=t17;
f_7318(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
if(C_truep(t21)){
t22=t17;
f_7318(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t22)){
t23=t17;
f_7318(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
t24=t17;
f_7318(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[590])));}}}}}}}}}}}}}}}

/* k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7318,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[7];
f_7017(t2,((C_word*)t0)[6],lf[683]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[528]);
if(C_truep(t2)){
/* c-backend.scm: 1172 str */
t3=((C_word*)t0)[7];
f_7017(t3,((C_word*)t0)[6],lf[684]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1174 ##sys#hash-table-ref */
t4=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7333(2,t4,C_SCHEME_FALSE);}}}}

/* k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1176 foreign-type-declaration */
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1177 str */
t2=((C_word*)t0)[3];
f_7017(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7373,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7373(t6,(C_word)C_i_memq(t5,lf[716]));}
else{
t5=t3;
f_7373(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1227 err */
t2=((C_word*)t0)[2];
f_7012(t2,((C_word*)t0)[6]);}}}}

/* k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7384,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 string-append */
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[685],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7390(t5,(C_word)C_eqp(lf[574],t4));}
else{
t4=t2;
f_7390(t4,C_SCHEME_FALSE);}}}

/* k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7390,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7401,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1187 string-append */
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[686],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7407(t4,(C_word)C_eqp(lf[715],t3));}
else{
t3=t2;
f_7407(t3,C_SCHEME_FALSE);}}}

/* k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7407,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7418,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1192 foreign-type-declaration */
t5=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[691]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7446(t5,(C_word)C_eqp(lf[576],t4));}
else{
t4=t2;
f_7446(t4,C_SCHEME_FALSE);}}}

/* k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7446,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1199 foreign-type-declaration */
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7463(t5,(C_word)C_eqp(lf[714],t4));}
else{
t4=t2;
f_7463(t4,C_SCHEME_FALSE);}}}

/* k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7463,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1201 ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7480(t5,(C_word)C_eqp(lf[713],t4));}
else{
t4=t2;
f_7480(t4,C_SCHEME_FALSE);}}}

/* k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7480,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7487,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1203 ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7497(t5,(C_word)C_eqp(lf[712],t4));}
else{
t4=t2;
f_7497(t4,C_SCHEME_FALSE);}}}

/* k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7497,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1205 ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7514(t5,(C_word)C_i_memq(t4,lf[711]));}
else{
t4=t2;
f_7514(t4,C_SCHEME_FALSE);}}}

/* k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7514,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1207 ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7531(t5,(C_word)C_eqp(lf[584],t4));}
else{
t4=t2;
f_7531(t4,C_SCHEME_FALSE);}}}

/* k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7538,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1209 ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7548(t4,(C_word)C_eqp(lf[581],t3));}
else{
t3=t2;
f_7548(t3,C_SCHEME_FALSE);}}}

/* k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7548,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7560,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7560(2,t6,lf[709]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7560(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[710]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[1],t4);}}}
else{
/* c-backend.scm: 1226 err */
t2=((C_word*)t0)[2];
f_7012(t2,((C_word*)t0)[4]);}}

/* k7558 in k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1215 foreign-type-declaration */
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[708]);}

/* k7565 in k7558 in k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7577,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7576 in k7565 in k7558 in k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7577,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1222 foreign-type-declaration */
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k7573 in k7565 in k7558 in k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1218 string-intersperse */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k7569 in k7565 in k7558 in k7546 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1214 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k7536 in k7529 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1209 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[700],((C_word*)t0)[2]);}

/* k7519 in k7512 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1207 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k7502 in k7495 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1205 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k7485 in k7478 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1203 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[695],t1,lf[696],((C_word*)t0)[2]);}

/* k7468 in k7461 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1201 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[693],t1,lf[694],((C_word*)t0)[2]);}

/* k7451 in k7444 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1199 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[692],t1);}

/* k7416 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7422,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7428,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7427 in k7416 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7428,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[690]);}

/* k7424 in k7416 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1194 string-intersperse */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[689]);}

/* k7420 in k7416 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1191 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[687],t1,lf[688]);}

/* k7412 in k7405 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1190 str */
t2=((C_word*)t0)[3];
f_7017(t2,((C_word*)t0)[2],t1);}

/* k7399 in k7388 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1187 foreign-type-declaration */
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7382 in k7371 in k7331 in k7316 in k7220 in k7187 in k7085 in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 foreign-type-declaration */
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7017,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1139 string-append */
t3=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[639],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_7012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7012,NULL,2,t0,t1);}
/* c-backend.scm: 1138 quit */
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[638],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6945,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6949,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1120 foreign-callback-stub-name */
t5=C_retrieve(lf[636]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1121 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[635]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1122 foreign-callback-stub-return-type */
t3=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6958,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1123 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6958,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1125 make-argument-list */
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[634]);}

/* k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6967,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1126 foreign-type-declaration */
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[633]);}

/* k7006 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1126 gen */
t2=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k6965 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6970,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6975,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1127 pair-for-each */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6974 in k6965 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6975,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6979,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6996,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1129 foreign-type-declaration */
t8=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k6994 in a6974 in k6965 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1129 gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6977 in a6974 in k6965 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1130 gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6968 in k6965 in k6962 in k6956 in k6953 in k6950 in k6947 in ##compiler#generate-foreign-callback-header in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1132 gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6514,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6520,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1067 foreign-callback-stub-id */
t4=C_retrieve(lf[632]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1068 real-name2 */
t3=C_retrieve(lf[563]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6530,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1069 foreign-callback-stub-return-type */
t3=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1070 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1072 make-argument-list */
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6541,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1099 fold */
t6=C_retrieve(lf[418]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[628],((C_word*)t0)[4],t1);}

/* k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1100 gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6943,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 cleanup */
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6886(2,t3,C_SCHEME_UNDEFINED);}}

/* k6941 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[626],t1,lf[627]);}

/* k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1103 generate-foreign-callback-header */
t3=C_retrieve(lf[515]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[625],((C_word*)t0)[2]);}

/* k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1104 gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[623],((C_word*)t0)[2],lf[624]);}

/* k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1105 gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[622]);}

/* k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6928,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1106 for-each */
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6927 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6928,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6936,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1108 foreign-result-conversion */
t5=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[621]);}

/* k6934 in a6927 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1108 gen */
t2=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[618],t1,((C_word*)t0)[2],lf[619],C_SCHEME_TRUE,lf[620]);}

/* k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[528],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_6901(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6926,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1113 foreign-argument-conversion */
t5=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k6924 in k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1113 gen */
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[617],t1);}

/* k6899 in k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1114 gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[616],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k6902 in k6899 in k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[528],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_6907(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1115 gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6905 in k6902 in k6899 in k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1116 gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[615]);}

/* compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6541,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[22]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6551,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6551(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t8)){
t9=t7;
f_6551(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t9)){
t10=t7;
f_6551(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t10)){
t11=t7;
f_6551(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t11)){
t12=t7;
f_6551(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[528]);
if(C_truep(t12)){
t13=t7;
f_6551(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t13)){
t14=t7;
f_6551(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t14)){
t15=t7;
f_6551(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t15)){
t16=t7;
f_6551(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[611]);
if(C_truep(t16)){
t17=t7;
f_6551(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[612]);
if(C_truep(t17)){
t18=t7;
f_6551(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[613]);
t19=t7;
f_6551(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[614])));}}}}}}}}}}}}

/* k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6560(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t4)){
t5=t3;
f_6560(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
if(C_truep(t5)){
t6=t3;
f_6560(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t6)){
t7=t3;
f_6560(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t7)){
t8=t3;
f_6560(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t8)){
t9=t3;
f_6560(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
if(C_truep(t9)){
t10=t3;
f_6560(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
if(C_truep(t10)){
t11=t3;
f_6560(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t11)){
t12=t3;
f_6560(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[580]);
if(C_truep(t12)){
t13=t3;
f_6560(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
if(C_truep(t13)){
t14=t3;
f_6560(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t14)){
t15=t3;
f_6560(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
t16=t3;
f_6560(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[604])));}}}}}}}}}}}}}}

/* k6558 in k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6560,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1081 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[566]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[567]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6572(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t4)){
t5=t3;
f_6572(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t5)){
t6=t3;
f_6572(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
t7=t3;
f_6572(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[593])));}}}}}

/* k6570 in k6558 in k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6572,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[568],((C_word*)t0)[5],lf[569],((C_word*)t0)[5],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6584(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
if(C_truep(t4)){
t5=t3;
f_6584(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
if(C_truep(t5)){
t6=t3;
f_6584(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t7=t3;
f_6584(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[590])));}}}}}

/* k6582 in k6570 in k6558 in k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6584,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1085 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[572],((C_word*)t0)[4],lf[573]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1087 ##sys#hash-table-ref */
t3=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[586]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6590(2,t3,C_SCHEME_FALSE);}}}

/* k6588 in k6582 in k6570 in k6558 in k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6590,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1089 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6541(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[574]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6624(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t5)){
t6=t4;
f_6624(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t6)){
t7=t4;
f_6624(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t7)){
t8=t4;
f_6624(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t8)){
t9=t4;
f_6624(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t9)){
t10=t4;
f_6624(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t10)){
t11=t4;
f_6624(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[583]);
t12=t4;
f_6624(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[584])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6622 in k6588 in k6582 in k6570 in k6558 in k6549 in compute-size in k6537 in k6531 in k6528 in k6525 in k6522 in a6519 in generate-foreign-callback-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1094 string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[575]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[576]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1095 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6541(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6281,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6287,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6287,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1000 foreign-stub-id */
t4=C_retrieve(lf[564]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1001 real-name2 */
t3=C_retrieve(lf[563]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1002 foreign-stub-argument-types */
t3=C_retrieve(lf[562]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6512,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1004 make-variable-list */
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[561]);}

/* k6510 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6512,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[560],t1);
/* c-backend.scm: 1004 intersperse */
t3=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1005 foreign-stub-return-type */
t3=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1006 foreign-stub-name */
t3=C_retrieve(lf[558]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1007 foreign-stub-body */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1008 foreign-stub-argument-names */
t3=C_retrieve(lf[556]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6318(2,t3,t1);}
else{
/* c-backend.scm: 1008 make-list */
t3=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1009 foreign-result-conversion */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[555]);}

/* k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1010 foreign-stub-cps */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1011 foreign-stub-callback */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1012 gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6501,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1014 cleanup */
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6333(2,t3,C_SCHEME_UNDEFINED);}}

/* k6499 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1014 gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[551],t1,lf[552]);}

/* k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1016 gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[549],((C_word*)t0)[6],lf[550]);}
else{
t3=t2;
f_6336(2,t3,C_SCHEME_UNDEFINED);}}

/* k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1019 gen */
t3=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[2],lf[545],C_SCHEME_TRUE,lf[546],((C_word*)t0)[2],lf[547]);}
else{
/* c-backend.scm: 1021 gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[548],((C_word*)t0)[2],C_make_character(40));}}

/* k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[3]);}

/* k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1024 gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[539],C_SCHEME_TRUE,lf[540],((C_word*)t0)[2],lf[541]);}
else{
/* c-backend.scm: 1025 gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[542],C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1027 gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[538]);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1028 gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[537]);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6449,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1037 iota */
t5=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k6477 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1029 for-each */
t2=*((C_word*)lf[65]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6448 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6449,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6457,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6469,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1034 symbol->string */
t7=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1034 sprintf */
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[536],t3);}}

/* k6467 in a6448 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1032 foreign-type-declaration */
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6455 in a6448 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1035 foreign-type-declaration */
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[535]);}

/* k6459 in k6455 in a6448 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1036 foreign-argument-conversion */
t3=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6463 in k6459 in k6455 in a6448 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1031 gen */
t2=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[532],((C_word*)t0)[3],C_make_character(41),t1,lf[533],((C_word*)t0)[2],lf[534]);}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1038 gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[531]);}
else{
t3=t2;
f_6360(2,t3,C_SCHEME_UNDEFINED);}}

/* k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6369,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1040 gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[522]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[528]);
if(C_truep(t4)){
/* c-backend.scm: 1051 gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1050 gen */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[530],((C_word*)t0)[2]);}}}

/* k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1052 gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6431,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1053 make-argument-list */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[529]);}

/* k6429 in k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1053 intersperse */
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k6425 in k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k6394 in k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[528]);
if(C_truep(t3)){
t4=t2;
f_6399(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1054 gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6397 in k6394 in k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1055 gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[527]);}

/* k6400 in k6397 in k6394 in k6391 in k6388 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1057 gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[523],C_SCHEME_TRUE,lf[524]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1059 gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[525]);}
else{
/* c-backend.scm: 1060 gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[526]);}}}

/* k6367 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1042 gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[521],C_SCHEME_TRUE);}

/* k6370 in k6367 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1044 gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[517],C_SCHEME_TRUE,lf[518]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1046 gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[519]);}
else{
/* c-backend.scm: 1047 gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[520]);}}}

/* k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6295 in k6292 in k6289 in a6286 in ##compiler#generate-foreign-stubs in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1061 gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6269,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6268 in ##compiler#generate-foreign-callback-stub-prototypes in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6273,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 992  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6271 in a6268 in ##compiler#generate-foreign-callback-stub-prototypes in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  generate-foreign-callback-header */
t3=C_retrieve(lf[515]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[516],((C_word*)t0)[2]);}

/* k6274 in k6271 in a6268 in ##compiler#generate-foreign-callback-stub-prototypes in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 994  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6235,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 977  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6233 in ##compiler#generate-external-variables in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6240,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6239 in k6233 in ##compiler#generate-external-variables in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6240,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[513]:lf[514]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6261,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 983  foreign-type-declaration */
t8=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t4,t3);}

/* k6259 in a6239 in k6233 in ##compiler#generate-external-variables in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6215,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 969  list-tabulate */
t5=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6220 in ##compiler#make-argument-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 971  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6227 in a6220 in ##compiler#make-argument-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 971  string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6199,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6205,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 964  list-tabulate */
t5=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6204 in ##compiler#make-variable-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6205,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 966  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6211 in a6204 in ##compiler#make-variable-list in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 966  string-append */
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[511],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6110,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6119,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6119(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6119,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6135,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6148,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6148(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6148(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6148(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6148(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6148(t10,C_SCHEME_FALSE);}}}}}

/* k6146 in loop in ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6151(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6158,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 955  string-copy */
t4=C_retrieve(lf[510]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6135(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6156 in k6146 in loop in ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6151(t3,t2);}

/* k6149 in k6146 in loop in ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6135(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6133 in loop in ##compiler#cleanup in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6135(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 958  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6119(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6037,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6041,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 920  gen */
t7=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[507],C_SCHEME_TRUE,lf[508],t6,lf[509]);}

/* k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6055(t6,t2,((C_word*)t0)[2]);}

/* doloop1225 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6055,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 924  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[500]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 925  lambda-literal-id */
t5=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k6066 in doloop1225 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6071,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 926  gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[505],t1,((C_word*)t0)[2],lf[506]);}

/* k6069 in k6066 in doloop1225 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[190]))){
/* c-backend.scm: 929  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[501],C_retrieve(lf[190]),lf[502]);}
else{
/* c-backend.scm: 930  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[503]);}}
else{
/* c-backend.scm: 931  gen */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[504]);}}

/* k6072 in k6069 in k6066 in doloop1225 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6055(t3,((C_word*)t0)[2],t2);}

/* k6042 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 932  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[499]);}

/* k6045 in k6042 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 933  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[498]);}

/* k6048 in k6045 in k6042 in k6039 in emit-procedure-table-info in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 934  gen */
t2=*((C_word*)lf[3]+1);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[491],C_SCHEME_TRUE,lf[492],C_SCHEME_TRUE,lf[493],C_SCHEME_TRUE,lf[494],C_SCHEME_TRUE,lf[495],C_SCHEME_TRUE,lf[496],C_SCHEME_TRUE,lf[497]);}

/* ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2461,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2496,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3991,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5245,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4861,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5026,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4824,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5257,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6004,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 903  debugging */
t26=C_retrieve(lf[474]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[489],lf[490]);}

/* k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6004,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 905  header */
t4=((C_word*)t0)[2];
f_3991(t4,t3);}

/* k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 906  declarations */
t3=((C_word*)t0)[2];
f_4138(t3,t2);}

/* k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 907  generate-external-variables */
t3=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[488]));}

/* k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 908  generate-foreign-stubs */
t3=C_retrieve(lf[485]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[486]),((C_word*)t0)[3]);}

/* k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 909  prototypes */
t3=((C_word*)t0)[2];
f_4287(t3,t2);}

/* k6018 in k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 910  generate-foreign-callback-stubs */
t3=C_retrieve(lf[484]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[184]),((C_word*)t0)[2]);}

/* k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 911  trampolines */
t3=((C_word*)t0)[2];
f_4538(t3,t2);}

/* k6024 in k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 912  procedures */
t3=((C_word*)t0)[2];
f_5257(t3,t2);}

/* k6027 in k6024 in k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 913  emit-procedure-table-info */
t3=C_retrieve(lf[483]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6030 in k6027 in k6024 in k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6002 in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 484  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[482],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5257,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 727  lambda-literal-argument-count */
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 728  lambda-literal-id */
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 729  real-name */
t3=C_retrieve(lf[481]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5276,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 730  lambda-literal-allocated */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 731  lambda-literal-rest-argument */
t3=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 732  lambda-literal-customizable */
t5=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 733  lambda-literal-closure-size */
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5285(t3,C_SCHEME_FALSE);}}

/* k5999 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5285(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5285,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5291,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 735  make-variable-list */
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[480]);}

/* k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5294,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 736  make-argument-list */
t3=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[479]);}

/* k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5297,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 737  intersperse */
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 738  intersperse */
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 739  lambda-literal-external */
t3=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 740  lambda-literal-looping */
t3=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 741  lambda-literal-direct */
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 742  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 743  lambda-literal-temporaries */
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[190]))){
/* c-backend.scm: 745  string-append */
t3=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[190]),lf[477]);}
else{
t3=t2;
f_5318(2,t3,lf[478]);}}

/* k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 747  debugging */
t3=C_retrieve(lf[474]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[475],lf[476],((C_word*)t0)[14]);}
else{
t3=t2;
f_5321(2,t3,C_SCHEME_UNDEFINED);}}

/* k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 748  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 749  cleanup */
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5968 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 749  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[471],t1,lf[472],C_SCHEME_TRUE);}

/* k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 758  gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 751  gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[470]);}}

/* k5929 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[468]:lf[469]);
/* c-backend.scm: 752  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5932 in k5929 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 754  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[466]);}
else{
/* c-backend.scm: 755  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[467]);}}

/* k5935 in k5932 in k5929 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 756  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5951 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[190]))){
t3=t2;
f_5956(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 760  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[464]);}}

/* k5954 in k5951 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 761  gen */
t2=*((C_word*)lf[3]+1);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],C_SCHEME_TRUE,lf[461],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[463],((C_word*)t0)[2]);}

/* k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5336(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 767  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[457]);}}

/* k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5903,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_5903(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5903(t4,C_SCHEME_FALSE);}}

/* k5901 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5903,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 769  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[456]);}
else{
t2=((C_word*)t0)[2];
f_5339(2,t2,C_SCHEME_UNDEFINED);}}

/* k5904 in k5901 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 770  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5339(2,t2,C_SCHEME_UNDEFINED);}}

/* k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[15]);}

/* k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 772  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[455]);}
else{
t3=t2;
f_5345(2,t3,C_SCHEME_UNDEFINED);}}

/* k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 773  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[454]);}

/* k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[228]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5351(t5,t4);}
else{
t4=t2;
f_5351(t4,C_SCHEME_UNDEFINED);}}

/* k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5351,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 775  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[453]);}

/* k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 777  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[451],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5865,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5865(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop977 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5865(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5865,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5875,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 781  gen */
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[452],t2,C_make_character(59));}}

/* k5873 in doloop977 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5865(t4,((C_word*)t0)[2],t2,t3);}

/* k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 783  fold */
t6=C_retrieve(lf[418]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 817  gen */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[432]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5808(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5808(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5806 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5808,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 831  gen */
t2=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[442],C_SCHEME_TRUE,lf[443],C_SCHEME_TRUE,lf[444],((C_word*)t0)[3],lf[445]);}
else{
/* c-backend.scm: 834  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[446],((C_word*)t0)[3],lf[447]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5820(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 836  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[450]);}}}

/* k5818 in k5806 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 837  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[449]);}
else{
t3=t2;
f_5823(2,t3,C_SCHEME_UNDEFINED);}}

/* k5821 in k5818 in k5806 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5829,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[112]);
t4=t2;
f_5829(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[412]))));}
else{
t3=t2;
f_5829(t3,C_SCHEME_FALSE);}}

/* k5827 in k5821 in k5818 in k5806 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[448]);}
else{
t2=((C_word*)t0)[2];
f_5730(2,t2,C_SCHEME_UNDEFINED);}}

/* k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5772,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[112]);
if(C_truep(t4)){
t5=t3;
f_5772(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[426]);
t6=t3;
f_5772(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5772(t4,C_SCHEME_FALSE);}}

/* k5770 in k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 843  gen */
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[436],((C_word*)t0)[3],lf[437],((C_word*)t0)[3],lf[438]);}
else{
t4=((C_word*)t0)[2];
f_5733(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 844  gen */
t3=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440],((C_word*)t0)[3],lf[441]);}}
else{
t2=((C_word*)t0)[2];
f_5733(2,t2,C_SCHEME_UNDEFINED);}}

/* k5731 in k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5739(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5739(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5739(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5737 in k5731 in k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 846  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[435]);}
else{
t3=t2;
f_5742(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5360(2,t2,C_SCHEME_UNDEFINED);}}

/* k5740 in k5737 in k5731 in k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5748(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5748(t3,C_SCHEME_FALSE);}}

/* k5746 in k5740 in k5737 in k5731 in k5728 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 848  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[433]);}
else{
/* c-backend.scm: 849  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434]);}}

/* k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 818  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[431]);}

/* k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 819  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}

/* k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 821  gen */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 822  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[429]);}}

/* k5673 in k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 823  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[427],((C_word*)t0)[3],lf[428]);}

/* k5676 in k5673 in k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[112]);
if(C_truep(t4)){
t5=t3;
f_5693(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[426]);
if(C_truep(t5)){
t6=t3;
f_5693(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5693(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5691 in k5676 in k5673 in k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 825  gen */
t2=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[423],((C_word*)t0)[2],lf[424],((C_word*)t0)[2],lf[425]);}
else{
t2=((C_word*)t0)[3];
f_5681(2,t2,C_SCHEME_UNDEFINED);}}

/* k5679 in k5676 in k5673 in k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 826  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[422]);}
else{
t3=t2;
f_5684(2,t3,C_SCHEME_UNDEFINED);}}

/* k5682 in k5679 in k5676 in k5673 in k5670 in k5667 in k5664 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 827  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[419],((C_word*)t0)[2],lf[420]);}

/* a5651 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5652,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5660,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 783  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4867(3,t5,t4,t2);}

/* k5658 in a5651 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5583,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 785  gen */
t4=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[414],C_SCHEME_TRUE,lf[415],C_SCHEME_TRUE,lf[416],((C_word*)t0)[2],lf[417]);}

/* k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[412]))){
/* c-backend.scm: 789  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[413]);}
else{
t3=t2;
f_5586(2,t3,C_SCHEME_UNDEFINED);}}

/* k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[190]))){
t3=t2;
f_5589(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[405]))){
/* c-backend.scm: 792  gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[406],C_retrieve(lf[405]),lf[407]);}
else{
if(C_truep(C_retrieve(lf[408]))){
/* c-backend.scm: 794  gen */
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[409],C_retrieve(lf[408]),lf[410],C_SCHEME_TRUE,lf[411]);}
else{
t4=t3;
f_5620(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5618 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 797  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),C_make_character(59));}
else{
t3=t2;
f_5623(2,t3,C_SCHEME_UNDEFINED);}}

/* k5621 in k5618 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[401]))){
/* c-backend.scm: 799  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[402],C_retrieve(lf[401]),C_make_character(59));}
else{
t3=t2;
f_5626(2,t3,C_SCHEME_UNDEFINED);}}

/* k5624 in k5621 in k5618 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 801  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),lf[400]);}
else{
t2=((C_word*)t0)[2];
f_5589(2,t2,C_SCHEME_UNDEFINED);}}

/* k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 802  gen */
t3=*((C_word*)lf[3]+1);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[391],((C_word*)t0)[3],lf[392],C_SCHEME_TRUE,lf[393],((C_word*)t0)[3],lf[394],C_SCHEME_TRUE,lf[395],C_SCHEME_TRUE,lf[396],C_SCHEME_TRUE,lf[397]);}

/* k5590 in k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 807  gen */
t3=*((C_word*)lf[3]+1);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[385],((C_word*)t0)[2],lf[386],C_SCHEME_TRUE,lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[2],lf[389],C_SCHEME_TRUE,lf[390]);}

/* k5593 in k5590 in k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 811  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384]);}

/* k5596 in k5593 in k5590 in k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5360(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 813  gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[381],((C_word*)t0)[4],lf[382]);}}

/* k5605 in k5596 in k5593 in k5590 in k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 814  literal-frame */
t3=((C_word*)t0)[2];
f_4824(t3,t2);}

/* k5608 in k5605 in k5596 in k5593 in k5590 in k5587 in k5584 in k5581 in k5575 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 815  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[379],((C_word*)t0)[2],lf[380]);}

/* k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5363,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[239],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5383(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5383(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5383(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5383(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5383(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5383,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[370]:lf[371]);
/* c-backend.scm: 860  gen */
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[372],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[376]:lf[377]);
/* c-backend.scm: 886  gen */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[378]);}}
else{
t2=((C_word*)t0)[10];
f_5363(2,t2,C_SCHEME_UNDEFINED);}}

/* k5516 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 888  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[374]);}
else{
/* c-backend.scm: 889  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[375],((C_word*)t0)[3]);}}

/* k5519 in k5516 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 891  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5524(2,t3,C_SCHEME_UNDEFINED);}}

/* k5531 in k5519 in k5516 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5522 in k5519 in k5516 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 893  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[373]);}

/* k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[313]);
if(C_truep(t3)){
/* c-backend.scm: 861  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_5392(2,t4,C_SCHEME_UNDEFINED);}}

/* k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 862  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[368],((C_word*)t0)[5],lf[369]);}

/* k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 864  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5398(2,t3,C_SCHEME_UNDEFINED);}}

/* k5497 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 866  gen */
t3=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[364],C_SCHEME_TRUE,lf[365],C_SCHEME_TRUE,lf[366],((C_word*)t0)[6],lf[367]);}

/* k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[359]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 870  gen */
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[360],((C_word*)t0)[6],lf[361]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[313]);
if(C_truep(t5)){
/* c-backend.scm: 871  gen */
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[362],((C_word*)t0)[6],lf[363]);}
else{
t6=t2;
f_5404(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 872  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[358]);}

/* k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5472,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 873  make-argument-list */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[357]);}

/* k5470 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 873  intersperse */
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5466 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 874  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[355],((C_word*)t0)[5],lf[356]);}

/* k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 876  gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[353],((C_word*)t0)[2],lf[354]);}

/* k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 878  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[351],((C_word*)t0)[3],lf[352]);}

/* k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 879  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[350]);}

/* k5423 in k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5443(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1142 in k5423 in k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5443(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5443,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5453,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 883  gen */
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[349],t2,C_make_character(59));}}

/* k5451 in doloop1142 in k5423 in k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5443(t4,((C_word*)t0)[2],t2,t3);}

/* k5426 in k5423 in k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5381 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 884  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[347],((C_word*)t0)[3],lf[348]);}
else{
t3=((C_word*)t0)[2];
f_5363(2,t3,C_SCHEME_UNDEFINED);}}

/* k5361 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5366,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 895  lambda-literal-body */
t4=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5371 in k5361 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 894  expression */
t3=((C_word*)t0)[4];
f_2506(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in a5262 in procedures in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 900  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4867,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  immediate? */
t4=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[339]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4867(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4938,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 667  vector->list */
t6=*((C_word*)lf[342]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 668  block-variable-literal? */
t3=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k4946 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 669  bad-literal */
f_4861(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 671  ##sys#bytevector? */
t3=*((C_word*)lf[344]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k4964 in k4946 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 671  words */
t4=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4995(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 678  bad-literal */
f_4861(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k4964 in k4946 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4995(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4995,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5017,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 677  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4867(3,t8,t6,t7);}}

/* k5015 in loop in k4964 in k4946 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 677  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4995(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4971 in k4964 in k4946 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k4940 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4936 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 667  reduce */
t2=C_retrieve(lf[340]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[341]+1),C_fix(0),t1);}

/* k4932 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k4903 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4909,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4867(3,t4,t2,t3);}

/* k4907 in k4903 in k4872 in literal-size in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4824,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4830(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop786 in literal-frame in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4830(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4830,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4840,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4859,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 656  sprintf */
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[338],t2);}}

/* k4857 in doloop786 in literal-frame in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 656  gen-lit */
t2=((C_word*)t0)[4];
f_5026(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4838 in doloop786 in literal-frame in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4830(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5026(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5026,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5166,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 682  big-fixnum? */
t6=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_5033(t5,C_SCHEME_FALSE);}}

/* k5164 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5033(t2,(C_word)C_i_not(t1));}

/* k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5033,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 683  gen */
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[320],((C_word*)t0)[4],lf[321]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 684  block-variable-literal? */
t3=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[322]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 686  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[323]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[324]:lf[325]);
/* c-backend.scm: 688  gen */
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 690  gen */
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326],t4,lf[327]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  c-ify-string */
t6=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 698  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[331]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5122(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5122(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5120 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5122,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 702  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[334]);}
else{
/* c-backend.scm: 705  bad-literal */
f_4861(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5123 in k5120 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5135,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 703  encode-literal */
t4=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5133 in k5123 in k5120 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 703  gen-string-constant */
t2=((C_word*)t0)[3];
f_5168(t2,((C_word*)t0)[2],t1);}

/* k5126 in k5123 in k5120 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 704  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[332]);}

/* k5087 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5095,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 695  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[330]);}

/* k5093 in k5087 in k5037 in k5031 in gen-lit in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 696  gen */
t2=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[328],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[329]);}

/* bad-literal in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4861(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4861,NULL,2,t1,t2);}
/* c-backend.scm: 659  bomb */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[319],t2);}

/* gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5168,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5175,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 709  fx/ */
t5=*((C_word*)lf[318]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5178,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 710  modulo */
t3=*((C_word*)lf[317]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5183,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5183(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5183,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5199(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5199(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5220,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5235,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5239,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 716  string-like-substring */
f_5245(t7,((C_word*)t0)[4],t3,t8);}}

/* k5237 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  c-ify-string */
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5233 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5218 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5183(t4,((C_word*)t0)[2],t2,t3);}

/* k5197 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5199,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 715  string-like-substring */
f_5245(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5208 in k5197 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  c-ify-string */
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5204 in k5197 in doloop872 in k5176 in k5173 in gen-string-constant in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_5245(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5245,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5252,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 720  make-string */
t7=*((C_word*)lf[316]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k5250 in string-like-substring in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 721  ##sys#copy-bytes */
t3=C_retrieve(lf[315]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5253 in k5250 in string-like-substring in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4538,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4541,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4657,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4705,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4705,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4709,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 615  lambda-literal-argument-count */
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 616  lambda-literal-rest-argument */
t5=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 617  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 618  lambda-literal-id */
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 619  lambda-literal-customizable */
t3=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  lambda-literal-closure-size */
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4724(t3,C_SCHEME_FALSE);}}

/* k4820 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4724(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4724,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4727(t5,t4);}
else{
t3=t2;
f_4727(t3,C_SCHEME_UNDEFINED);}}

/* k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4727,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 622  lambda-literal-direct */
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 624  gen */
t3=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[309],((C_word*)t0)[9],lf[310],C_SCHEME_TRUE,lf[311],((C_word*)t0)[9],lf[312]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4767(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 632  lambda-literal-allocated */
t4=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k4809 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4767(2,t3,t2);}
else{
/* c-backend.scm: 632  lambda-literal-external */
t3=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4765 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[228]);
t4=t2;
f_4773(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4773(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4771 in k4765 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[313]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  lset-adjoin */
t4=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  lset-adjoin */
t4=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 637  lset-adjoin */
t3=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4789 in k4771 in k4765 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4785 in k4771 in k4765 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4781 in k4771 in k4765 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 626  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[307],((C_word*)t0)[3],lf[308]);}

/* k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 627  restore */
f_4541(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4743 in k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4746 in k4743 in k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 629  make-argument-list */
t3=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[306]);}

/* k4749 in k4746 in k4743 in k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 630  intersperse */
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k4759 in k4749 in k4746 in k4743 in k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4731 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in a4704 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 631  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[305]);}

/* k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4676,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 641  gen */
t4=*((C_word*)lf[3]+1);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[300],t2,lf[301],C_SCHEME_TRUE,lf[302],t2,lf[303],t2,lf[304]);}

/* k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 643  gen */
t3=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[297],((C_word*)t0)[3],lf[298],((C_word*)t0)[3],lf[299]);}

/* k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 644  restore */
f_4541(t2,((C_word*)t0)[3]);}

/* k4684 in k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 645  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[296],((C_word*)t0)[2],C_make_character(44));}

/* k4687 in k4684 in k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4699,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4703,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 646  make-argument-list */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[295]);}

/* k4701 in k4687 in k4684 in k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 646  intersperse */
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4697 in k4687 in k4684 in k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4690 in k4687 in k4684 in k4681 in k4678 in a4675 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[294]);}

/* k4658 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 649  emitter */
t4=((C_word*)t0)[3];
f_4577(t4,t3,C_SCHEME_FALSE);}

/* k4672 in k4658 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4661 in k4658 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 650  emitter */
t3=((C_word*)t0)[2];
f_4577(t3,t2,C_SCHEME_TRUE);}

/* k4668 in k4661 in k4658 in k4655 in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4577,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4579 in emitter in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[289]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[290]);
/* c-backend.scm: 593  gen */
t6=*((C_word*)lf[3]+1);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[291],t2,C_make_character(114),t4,lf[292],C_SCHEME_TRUE,lf[293],t2,C_make_character(114),t5);}

/* k4581 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 595  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[287],((C_word*)t0)[4],lf[288]);}

/* k4584 in k4581 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 596  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[286],((C_word*)t0)[4],C_make_character(114));}

/* k4587 in k4584 in k4581 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 597  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_4592(2,t3,C_SCHEME_UNDEFINED);}}

/* k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 598  gen */
t3=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[282],((C_word*)t0)[4],lf[283],C_SCHEME_TRUE,lf[284],C_SCHEME_TRUE,lf[285],((C_word*)t0)[4],C_make_character(59));}

/* k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 601  restore */
f_4541(t2,((C_word*)t0)[4]);}

/* k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 602  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[281]);}

/* k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 604  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[279]);}
else{
/* c-backend.scm: 605  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[280]);}}

/* k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 606  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[278]);}

/* k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 607  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[277]);}
else{
t3=t2;
f_4610(2,t3,C_SCHEME_UNDEFINED);}}

/* k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 608  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[276]);}

/* k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 609  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}

/* k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4630,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 610  make-argument-list */
t6=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[274]);}

/* k4628 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 610  intersperse */
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4624 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4617 in k4614 in k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 611  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[272]);}

/* restore in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4541(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4541,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4554,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4554(t8,t3,t4,C_fix(0));}

/* doloop687 in restore in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4554(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4554,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4564,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 588  gen */
t5=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[269],t2,lf[270],t3,lf[271]);}}

/* k4562 in doloop687 in restore in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4554(t4,((C_word*)t0)[2],t2,t3);}

/* k4543 in restore in trampolines in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 589  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[267],((C_word*)t0)[2],lf[268]);}

/* prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4287,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4291,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 517  gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4315,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4319,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 520  lambda-literal-argument-count */
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 521  lambda-literal-customizable */
t3=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 522  lambda-literal-closure-size */
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4325(t3,C_SCHEME_FALSE);}}

/* k4534 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4325(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4325,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 523  make-variable-list */
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[264]);}

/* k4520 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 523  intersperse */
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 524  lambda-literal-id */
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 525  lambda-literal-rest-argument */
t3=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 526  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 527  lambda-literal-direct */
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 528  lambda-literal-allocated */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[255]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4514,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 530  lset-adjoin */
t7=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4346(t5,C_SCHEME_UNDEFINED);}}

/* k4512 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4346(t3,t2);}

/* k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4346,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 531  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4507,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 536  lambda-literal-callee-signatures */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4505 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4487 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4488,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[255]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 535  lset-adjoin */
t7=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4497 in a4487 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[190]))){
/* c-backend.scm: 546  string-append */
t5=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[190]),lf[246]);}
else{
t5=t4;
f_4464(2,t5,lf[247]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 538  gen */
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[253],((C_word*)t0)[5],lf[254],C_SCHEME_TRUE);}}

/* k4437 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 539  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[252]);}

/* k4440 in k4437 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[250]:lf[251]);
/* c-backend.scm: 540  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4443 in k4440 in k4437 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 542  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}
else{
/* c-backend.scm: 543  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}}

/* k4446 in k4443 in k4440 in k4437 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 544  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4462 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 547  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[244],t1,lf[245],C_SCHEME_TRUE);}

/* k4465 in k4462 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[242]))){
/* c-backend.scm: 549  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[243],C_SCHEME_TRUE);}
else{
t3=t2;
f_4470(2,t3,C_SCHEME_UNDEFINED);}}

/* k4468 in k4465 in k4462 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 550  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[241]);}

/* k4471 in k4468 in k4465 in k4462 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 551  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2]);}

/* k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 552  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4361(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 553  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[238]);}}

/* k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4411,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4411(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4411(t4,C_SCHEME_FALSE);}}

/* k4409 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 555  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}
else{
t2=((C_word*)t0)[2];
f_4364(2,t2,C_SCHEME_UNDEFINED);}}

/* k4412 in k4409 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 556  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4364(2,t2,C_SCHEME_UNDEFINED);}}

/* k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[4]);}

/* k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 559  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 567  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k4397 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4402(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 569  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k4400 in k4397 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 570  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k4371 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 562  gen */
t4=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[231],((C_word*)t0)[2],lf[232],C_SCHEME_TRUE,lf[233],((C_word*)t0)[2],lf[234]);}}

/* k4380 in k4371 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k4383 in k4380 in k4371 in k4365 in k4362 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in a4314 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 565  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[229],t2,lf[230]);}

/* k4292 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4299,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4298 in k4292 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4299,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 574  gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[226],t2,lf[227]);}

/* k4301 in a4298 in k4292 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 575  make-list */
t4=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[225]);}

/* k4311 in k4301 in a4298 in k4292 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4304 in k4301 in a4298 in k4292 in k4289 in prototypes in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 576  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[223]);}

/* declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4138,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 488  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[222]);}

/* k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4281,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[192]));}

/* a4280 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4281,3,t0,t1,t2);}
/* c-backend.scm: 491  gen */
t3=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[218],t2,lf[219],C_SCHEME_TRUE,lf[220],t2,lf[221]);}

/* k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4151(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 495  gen */
t4=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[216],((C_word*)t0)[2],lf[217]);}}

/* k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 496  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[215]);}

/* k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4159(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4159(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4159,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4169,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 500  ##sys#lambda-info->string */
t6=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4175,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 502  gen */
t8=*((C_word*)lf[3]+1);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[212],((C_word*)t0)[5],lf[213],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4228(t6,t2,C_fix(0));}

/* doloop557 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4228,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4238,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 509  gen */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k4236 in doloop557 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4228(t3,((C_word*)t0)[2],t2);}

/* k4176 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4201,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4201(t9,t2,t5);}

/* doloop569 in k4176 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4201,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 512  gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[211]);}}

/* k4209 in doloop569 in k4176 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4201(t3,((C_word*)t0)[2],t2);}

/* k4179 in k4176 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 513  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[210]);}

/* k4182 in k4179 in k4176 in k4173 in k4167 in doloop541 in k4152 in k4149 in k4146 in k4143 in declarations in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4159(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3991,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3994,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4130,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 454  current-seconds */
t5=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4128 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  ##sys#decode-seconds */
t2=C_retrieve(lf[208]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4088,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 462  pad0 */
f_3994(t9,t10);}

/* k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 462  pad0 */
f_3994(t2,((C_word*)t0)[2]);}

/* k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 462  pad0 */
f_3994(t2,((C_word*)t0)[2]);}

/* k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4100,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 462  pad0 */
f_3994(t2,((C_word*)t0)[2]);}

/* k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4104,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4110,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4118,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  chicken-version */
t7=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k4120 in k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 465  string-split */
t2=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[206]);}

/* k4116 in k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4109 in k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4110,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[202],t2,lf[203]);}

/* k4106 in k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 463  string-intersperse */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k4102 in k4098 in k4094 in k4090 in k4086 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 460  gen */
t2=*((C_word*)lf[3]+1);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[195],((C_word*)t0)[7],lf[196],C_SCHEME_TRUE,lf[197],C_SCHEME_TRUE,lf[198],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[199]);}

/* k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 468  gen-list */
t3=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[194]));}

/* k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[190]))){
/* c-backend.scm: 470  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[191],C_retrieve(lf[190]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 472  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[193]);}}

/* k4075 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 473  gen-list */
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[192]));}

/* k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 474  gen */
t3=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[186],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[187],C_retrieve(lf[188]),lf[189]);}

/* k4039 in k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[182]))){
/* c-backend.scm: 476  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[184]));}
else{
t3=t2;
f_4044(2,t3,C_SCHEME_UNDEFINED);}}

/* k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[185])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 478  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4047(2,t3,C_SCHEME_UNDEFINED);}}

/* k4057 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4064,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[185]));}

/* a4063 in k4057 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4064,3,t0,t1,t2);}
/* c-backend.scm: 479  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4009 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[182]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 481  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[184]));}}

/* pad0 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3994(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3994,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 452  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4006 in pad0 in header in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 452  string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[181],t1);}

/* expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2506,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 447  expr */
t11=((C_word*)t6)[1];
f_2509(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3959(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3959,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3965,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 441  pair-for-each */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a3964 in expr-args in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_3969(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 443  gen */
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k3967 in a3964 in expr-args in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 444  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_2509(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2509,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2513,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3953,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3953 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3953,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3948 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3948,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3943,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3943 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3943,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word ab[228],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[18]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_eqp(t3,lf[19]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[10]);
t6=(C_truep(t5)?lf[20]:lf[21]);
/* c-backend.scm: 127  gen */
t7=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],t6);}
else{
t5=(C_word)C_eqp(t3,lf[22]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[10]);
t7=(C_word)C_fix((C_word)C_character_code(t6));
/* c-backend.scm: 128  gen */
t8=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[9],lf[23],t7,C_make_character(41));}
else{
t6=(C_word)C_eqp(t3,lf[24]);
if(C_truep(t6)){
/* c-backend.scm: 129  gen */
t7=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],lf[25]);}
else{
t7=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 130  gen */
t9=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,((C_word*)t0)[9],lf[27],t8,C_make_character(41));}
else{
t8=(C_word)C_eqp(t3,lf[28]);
if(C_truep(t8)){
/* c-backend.scm: 131  gen */
t9=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[29]);}
else{
/* c-backend.scm: 132  bomb */
t9=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[30]);}}}}}}
else{
t3=(C_word)C_eqp(t1,lf[31]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_vectorp(t4))){
t5=(C_word)C_i_vector_ref(t4,C_fix(0));
/* c-backend.scm: 137  gen */
t6=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[32],t5,lf[33]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 138  gen */
t6=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[34],t5,C_make_character(93));}}
else{
t4=(C_word)C_eqp(t1,lf[35]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[38]);}
else{
t5=(C_word)C_eqp(t1,lf[39]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 150  gen */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[9],lf[40],t6);}
else{
t6=(C_word)C_eqp(t1,lf[41]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[7],a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_2691(t11,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6],t7);}
else{
t7=(C_word)C_eqp(t1,lf[42]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t9=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[44]);}
else{
t8=(C_word)C_eqp(t1,lf[45]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t10=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[47]);}
else{
t9=(C_word)C_eqp(t1,lf[48]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t11=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,lf[49]);}
else{
t10=(C_word)C_eqp(t1,lf[50]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t12=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[53]);}
else{
t11=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t13=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,lf[56]);}
else{
t12=(C_word)C_eqp(t1,lf[57]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t14=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[59]);}
else{
t13=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=t14,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t16=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,lf[67],t14,C_make_character(44));}
else{
t14=(C_word)C_eqp(t1,lf[68]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t16=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[70]);}
else{
t15=(C_word)C_eqp(t1,lf[71]);
if(C_truep(t15)){
t16=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 215  gen */
t17=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,((C_word*)t0)[9],C_make_character(116),t16);}
else{
t16=(C_word)C_eqp(t1,lf[72]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 218  gen */
t19=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t19))(5,t19,t17,C_make_character(116),t18,C_make_character(61));}
else{
t17=(C_word)C_eqp(t1,lf[73]);
if(C_truep(t17)){
t18=(C_word)C_i_car(((C_word*)t0)[10]);
t19=(C_word)C_i_cadr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_caddr(((C_word*)t0)[10]))){
if(C_truep(t19)){
/* c-backend.scm: 227  gen */
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[74],t18,lf[75]);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t18,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadddr(((C_word*)t0)[10]);
/* c-backend.scm: 228  symbol->string */
t23=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}}
else{
if(C_truep(t19)){
/* c-backend.scm: 229  gen */
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[80],t18,lf[81]);}
else{
/* c-backend.scm: 230  gen */
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[82],t18,lf[83]);}}}
else{
t18=(C_word)C_eqp(t1,lf[84]);
if(C_truep(t18)){
t19=(C_word)C_i_car(((C_word*)t0)[10]);
t20=(C_word)C_i_cadr(((C_word*)t0)[10]);
t21=(C_word)C_i_caddr(((C_word*)t0)[10]);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3063,a[2]=t21,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t20)){
/* c-backend.scm: 237  gen */
t23=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[87],t19,lf[88]);}
else{
/* c-backend.scm: 238  gen */
t23=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[89],t19,lf[90]);}}
else{
t19=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t19)){
t20=(C_word)C_i_car(((C_word*)t0)[10]);
t21=(C_word)C_i_cadr(((C_word*)t0)[10]);
t22=(C_word)C_i_caddr(((C_word*)t0)[10]);
if(C_truep(t21)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3129,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 249  symbol->string */
t26=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}
else{
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3150,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 254  symbol->string */
t26=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}}
else{
t20=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t20)){
/* c-backend.scm: 258  gen */
t21=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[9],lf[99]);}
else{
t21=(C_word)C_eqp(t1,lf[100]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(((C_word*)t0)[8]);
t23=(C_word)C_i_length(t22);
t24=((C_word*)t0)[6];
t25=(C_word)C_fixnum_increase(t23);
t26=(C_word)C_i_cdr(((C_word*)t0)[10]);
t27=(C_word)C_i_pairp(t26);
t28=(C_truep(t27)?(C_word)C_i_cadr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t29=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3183,a[2]=t27,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t28,a[6]=t24,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=t25,a[11]=((C_word*)t0)[6],a[12]=t22,a[13]=((C_word*)t0)[4],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[10],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 267  source-info->string */
t30=C_retrieve(lf[129]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t29,t28);}
else{
t22=(C_word)C_eqp(t1,lf[130]);
if(C_truep(t22)){
t23=(C_word)C_i_length(((C_word*)t0)[8]);
t24=(C_word)C_fixnum_increase(t23);
t25=(C_word)C_i_car(((C_word*)t0)[10]);
t26=(C_word)C_i_cadr(((C_word*)t0)[10]);
t27=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3504,a[2]=t26,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t24,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=((C_word*)t0)[9],a[11]=t25,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 324  lambda-literal-closure-size */
t28=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,((C_word*)t0)[3]);}
else{
t23=(C_word)C_eqp(t1,lf[134]);
if(C_truep(t23)){
t24=(C_word)C_i_cdr(((C_word*)t0)[8]);
t25=(C_word)C_i_length(t24);
t26=(C_word)C_fixnum_increase(t25);
t27=(C_word)C_i_caddr(((C_word*)t0)[10]);
t28=(C_word)C_i_cadddr(((C_word*)t0)[10]);
t29=(C_word)C_eqp(t28,C_fix(0));
t30=(C_word)C_i_not(t29);
t31=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3589,a[2]=t27,a[3]=t28,a[4]=t30,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],a[8]=t24,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3593,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 352  find-lambda */
t33=((C_word*)t0)[2];
f_2464(t33,t32,t27);}
else{
t24=(C_word)C_eqp(t1,lf[136]);
if(C_truep(t24)){
t25=(C_word)C_i_length(((C_word*)t0)[8]);
t26=(C_word)C_fixnum_plus(t25,C_fix(1));
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3612,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 369  gen */
t29=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t29))(8,t29,t27,C_SCHEME_TRUE,lf[138],t28,lf[139],t26,lf[140]);}
else{
t25=(C_word)C_eqp(t1,lf[141]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 374  gen */
t27=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t26,C_SCHEME_TRUE,lf[143]);}
else{
t26=(C_word)C_eqp(t1,lf[144]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 379  gen */
t29=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t29))(5,t29,t27,lf[145],t28,C_make_character(40));}
else{
t27=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3669,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t29=(C_word)C_i_car(((C_word*)t0)[10]);
t30=(C_word)C_i_length(((C_word*)t0)[8]);
/* c-backend.scm: 384  gen */
t31=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t31))(6,t31,t28,lf[147],t29,lf[148],t30);}
else{
t28=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 392  foreign-result-conversion */
t31=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t31))(4,t31,t29,t30,lf[151]);}
else{
t29=(C_word)C_eqp(t1,lf[152]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3743,a[2]=t30,a[3]=t32,a[4]=t31,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 396  foreign-type-declaration */
t34=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t30,lf[157]);}
else{
t30=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t30)){
t31=(C_word)C_i_car(((C_word*)t0)[10]);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3773,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 402  foreign-result-conversion */
t34=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t31,lf[163]);}
else{
t31=(C_word)C_eqp(t1,lf[164]);
if(C_truep(t31)){
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3789,a[2]=t32,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 408  foreign-type-declaration */
t35=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,t32,lf[169]);}
else{
t32=(C_word)C_eqp(t1,lf[170]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3826,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 415  gen */
t34=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,C_SCHEME_TRUE,lf[174]);}
else{
t33=(C_word)C_eqp(t1,lf[175]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 430  gen */
t35=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t35))(3,t35,t34,lf[177]);}
else{
/* c-backend.scm: 438  bomb */
t34=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t34))(3,t34,((C_word*)t0)[9],lf[178]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 431  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3910 in k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 432  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[176]);}

/* k3913 in k3910 in k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 433  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3916 in k3913 in k3910 in k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 434  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3919 in k3916 in k3913 in k3910 in k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 435  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 436  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 416  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2509(t4,t2,t3,((C_word*)t0)[3]);}

/* k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 417  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[173]);}

/* k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3845,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3845(t7,((C_word*)t0)[2],t2,t3);}

/* doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3845,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 421  gen */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[171]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 424  gen */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[172]);}}

/* k3866 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 425  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3869 in k3866 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 426  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3872 in k3869 in k3866 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 427  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3875 in k3872 in k3869 in k3866 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3845(t4,((C_word*)t0)[2],t2,t3);}

/* k3853 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3856 in k3853 in doloop446 in k3830 in k3827 in k3824 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 423  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k3815 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 408  gen */
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[167],t1,lf[168]);}

/* k3787 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 409  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2509(t4,t2,t3,((C_word*)t0)[3]);}

/* k3790 in k3787 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3809,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 410  foreign-argument-conversion */
t4=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3807 in k3790 in k3787 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 410  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[166],t1);}

/* k3793 in k3790 in k3787 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3796 in k3793 in k3790 in k3787 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 412  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[165]);}

/* k3771 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 402  foreign-type-declaration */
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[162]);}

/* k3775 in k3771 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 402  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[160],t1,lf[161]);}

/* k3757 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 403  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3760 in k3757 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 404  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[159]);}

/* k3741 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3747,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 396  foreign-argument-conversion */
t3=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3745 in k3741 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 396  gen */
t2=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[154],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3723 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 397  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3726 in k3723 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 398  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[153]);}

/* k3703 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 392  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3667 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 387  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_3672(2,t3,C_SCHEME_UNDEFINED);}}

/* k3679 in k3667 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 388  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3959(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3670 in k3667 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 389  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3648 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 380  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3651 in k3648 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 381  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3629 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 375  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3632 in k3629 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[142]);}

/* k3610 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 370  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3613 in k3610 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k3591 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 352  lambda-literal-closure-size */
t2=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 354  gen */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3570,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 356  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[135],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3540(2,t3,C_SCHEME_UNDEFINED);}}

/* k3568 in k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 357  gen */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3540(2,t4,C_SCHEME_UNDEFINED);}}

/* k3538 in k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3543(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 359  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3556 in k3538 in k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 360  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3543(2,t2,C_SCHEME_UNDEFINED);}}

/* k3541 in k3538 in k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 361  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3959(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3546(2,t3,C_SCHEME_UNDEFINED);}}

/* k3544 in k3541 in k3538 in k3535 in k3587 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 362  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 326  lambda-literal-temporaries */
t4=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3488,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 339  gen */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3486 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3491(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 340  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[133]);}}

/* k3489 in k3486 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 341  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3492 in k3489 in k3486 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 342  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 327  iota */
t4=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 328  for-each */
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3470 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3471,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 330  gen */
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3473 in a3470 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 331  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3476 in k3473 in a3470 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3451 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3461,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 336  iota */
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3467 in k3451 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 334  for-each */
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3460 in k3451 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3461,4,t0,t1,t2,t3);}
/* c-backend.scm: 335  gen */
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[132],t2,C_make_character(59));}

/* k3454 in k3451 in k3448 in k3445 in k3502 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[131]);}

/* k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3186(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3186(t3,C_SCHEME_FALSE);}}

/* k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 270  find-lambda */
t6=((C_word*)t0)[2];
f_2464(t6,t5,t1);}
else{
t4=t3;
f_3192(t4,C_SCHEME_FALSE);}}

/* k3395 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  lambda-literal-closure-size */
t2=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3391 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3192(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3192,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[120]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3379,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 275  uncommentify */
f_2496(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3198(2,t4,C_SCHEME_UNDEFINED);}}

/* k3384 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126],t1,lf[127]);}

/* k2492 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[124],lf[125]);}

/* k3377 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 274  gen */
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[121],t1,lf[122]);}

/* k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3365,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_3365 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3365,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=(C_word)C_eqp(lf[39],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3221,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}
else{
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 282  lambda-literal-id */
t5=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 308  gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 309  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2509(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 310  gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[118],((C_word*)t0)[4],lf[119]);}

/* k3331 in k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[112]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3348,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3348(t5,t3);}
else{
t5=C_retrieve(lf[117]);
t6=t4;
f_3348(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3346 in k3331 in k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_3348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 313  gen */
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[113],((C_word*)t0)[2],lf[114]);}
else{
/* c-backend.scm: 314  gen */
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[115],((C_word*)t0)[2],lf[116]);}}

/* k3334 in k3331 in k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 315  gen */
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[110],((C_word*)t0)[3],lf[111],((C_word*)t0)[2],C_make_character(44));}

/* k3337 in k3334 in k3331 in k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3342,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 316  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3340 in k3337 in k3334 in k3331 in k3328 in k3325 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 317  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[109]);}

/* k3322 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 283  lambda-literal-looping */
t3=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3234(2,t3,C_SCHEME_FALSE);}}

/* k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 284  lambda-literal-temporaries */
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3284(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 299  gen */
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3306 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3309 in k3306 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3282 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 302  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3285 in k3282 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3290(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 303  gen */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3288 in k3285 in k3282 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3293(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 304  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3291 in k3288 in k3285 in k3282 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 305  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3294 in k3291 in k3288 in k3285 in k3282 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 306  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}

/* k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 285  iota */
t4=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 286  for-each */
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3266 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3267,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 288  gen */
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3269 in a3266 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 289  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3272 in k3269 in a3266 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3241 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3257,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 294  iota */
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3263 in k3241 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 292  for-each */
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3256 in k3241 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3257,4,t0,t1,t2,t3);}
/* c-backend.scm: 293  gen */
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[105],t2,C_make_character(59));}

/* k3244 in k3241 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3249(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 295  gen */
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[104],((C_word*)t0)[2],C_make_character(59));}}

/* k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[103]);}

/* f_3221 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3221,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3205 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(t1);
/* c-backend.scm: 278  gen */
t4=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,t3,C_make_character(40),((C_word*)t0)[2],lf[102]);}

/* k3208 in k3205 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 279  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3959(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3211 in k3208 in k3205 in k3362 in k3196 in k3190 in k3184 in k3181 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 280  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k3148 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  uncommentify */
f_2496(((C_word*)t0)[2],t1);}

/* k3144 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 253  gen */
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[95],((C_word*)t0)[2],lf[96],t1,lf[97]);}

/* k3130 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 255  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3133 in k3130 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 256  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3127 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  uncommentify */
f_2496(((C_word*)t0)[2],t1);}

/* k3123 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 248  gen */
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],lf[93],t1,lf[94]);}

/* k3109 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3112 in k3109 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3061 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 239  symbol->string */
t5=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3082 in k3061 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  uncommentify */
f_2496(((C_word*)t0)[2],t1);}

/* k3078 in k3061 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[85],t1,lf[86]);}

/* k3064 in k3061 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 240  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k3067 in k3064 in k3061 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 241  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3030 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3026 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[76],((C_word*)t0)[2],lf[77],t1,C_make_character(41));}

/* k2984 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2952 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2955 in k2952 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[69]);}

/* k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2943 in k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2930 in k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2931,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[63],t3,lf[64]);}

/* k2933 in a2930 in k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2509(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2936 in k2933 in a2930 in k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k2920 in k2917 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[61],t2,lf[62]);}

/* k2885 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2888 in k2885 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k2891 in k2888 in k2885 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2894 in k2891 in k2888 in k2885 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2856 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2859 in k2856 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k2862 in k2859 in k2856 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2865 in k2862 in k2859 in k2856 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2819 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2509(t4,t2,t3,((C_word*)t0)[3]);}

/* k2822 in k2819 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[51],t4,lf[52]);}

/* k2825 in k2822 in k2819 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2828 in k2825 in k2822 in k2819 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2786 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2509(t4,t2,t3,((C_word*)t0)[3]);}

/* k2789 in k2786 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k2792 in k2789 in k2786 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2795 in k2792 in k2789 in k2786 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2767 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2770 in k2767 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[46]);}

/* k2740 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2743 in k2740 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[43],t3,C_make_character(93));}

/* loop in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2691,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2509(t7,t1,t6,t3);}}

/* k2699 in loop in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2509(t4,t2,t3,((C_word*)t0)[6]);}

/* k2702 in k2699 in loop in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k2705 in k2702 in k2699 in loop in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2691(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2634 in k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[37]);}

/* k2637 in k2634 in k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2640 in k2637 in k2634 in k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[36]);}

/* k2643 in k2640 in k2637 in k2634 in k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2509(t4,t2,t3,((C_word*)t0)[2]);}

/* k2646 in k2643 in k2640 in k2637 in k2634 in k2631 in k2517 in k2514 in k2511 in expr in expression in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_2496(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2502 in uncommentify in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[16]);}

/* find-lambda in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_fcall f_2464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2464,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[14]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a2475 in find-lambda in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2482 in a2475 in find-lambda in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2466 in find-lambda in ##compiler#generate-code in k2457 in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2441,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2447,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k2453 in ##compiler#gen-list in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2446 in ##compiler#gen-list in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2447,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[5]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[2]+1));}

/* ##compiler#gen in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2420r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2420r(t0,t1,t2);}}

static void C_ccall f_2420r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2426,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2425 in ##compiler#gen in k2415 in k2412 in k2409 in k2406 in k2403 in k2400 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2426,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,*((C_word*)lf[2]+1));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[5]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,*((C_word*)lf[2]+1));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[662] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_2402c-backend.scm",(void*)f_2402},
{"f_2405c-backend.scm",(void*)f_2405},
{"f_2408c-backend.scm",(void*)f_2408},
{"f_2411c-backend.scm",(void*)f_2411},
{"f_2414c-backend.scm",(void*)f_2414},
{"f_2417c-backend.scm",(void*)f_2417},
{"f_9033c-backend.scm",(void*)f_9033},
{"f_9037c-backend.scm",(void*)f_9037},
{"f_9029c-backend.scm",(void*)f_9029},
{"f_2459c-backend.scm",(void*)f_2459},
{"f_8729c-backend.scm",(void*)f_8729},
{"f_9005c-backend.scm",(void*)f_9005},
{"f_9003c-backend.scm",(void*)f_9003},
{"f_8991c-backend.scm",(void*)f_8991},
{"f_8961c-backend.scm",(void*)f_8961},
{"f_8922c-backend.scm",(void*)f_8922},
{"f_8909c-backend.scm",(void*)f_8909},
{"f_8905c-backend.scm",(void*)f_8905},
{"f_8791c-backend.scm",(void*)f_8791},
{"f_8738c-backend.scm",(void*)f_8738},
{"f_8735c-backend.scm",(void*)f_8735},
{"f_8732c-backend.scm",(void*)f_8732},
{"f_8331c-backend.scm",(void*)f_8331},
{"f_8418c-backend.scm",(void*)f_8418},
{"f_8499c-backend.scm",(void*)f_8499},
{"f_8521c-backend.scm",(void*)f_8521},
{"f_8333c-backend.scm",(void*)f_8333},
{"f_7846c-backend.scm",(void*)f_7846},
{"f_7876c-backend.scm",(void*)f_7876},
{"f_7903c-backend.scm",(void*)f_7903},
{"f_8098c-backend.scm",(void*)f_8098},
{"f_8107c-backend.scm",(void*)f_8107},
{"f_8116c-backend.scm",(void*)f_8116},
{"f_8138c-backend.scm",(void*)f_8138},
{"f_8215c-backend.scm",(void*)f_8215},
{"f_7848c-backend.scm",(void*)f_7848},
{"f_7010c-backend.scm",(void*)f_7010},
{"f_7087c-backend.scm",(void*)f_7087},
{"f_7189c-backend.scm",(void*)f_7189},
{"f_7222c-backend.scm",(void*)f_7222},
{"f_7318c-backend.scm",(void*)f_7318},
{"f_7333c-backend.scm",(void*)f_7333},
{"f_7373c-backend.scm",(void*)f_7373},
{"f_7390c-backend.scm",(void*)f_7390},
{"f_7407c-backend.scm",(void*)f_7407},
{"f_7446c-backend.scm",(void*)f_7446},
{"f_7463c-backend.scm",(void*)f_7463},
{"f_7480c-backend.scm",(void*)f_7480},
{"f_7497c-backend.scm",(void*)f_7497},
{"f_7514c-backend.scm",(void*)f_7514},
{"f_7531c-backend.scm",(void*)f_7531},
{"f_7548c-backend.scm",(void*)f_7548},
{"f_7560c-backend.scm",(void*)f_7560},
{"f_7567c-backend.scm",(void*)f_7567},
{"f_7577c-backend.scm",(void*)f_7577},
{"f_7575c-backend.scm",(void*)f_7575},
{"f_7571c-backend.scm",(void*)f_7571},
{"f_7538c-backend.scm",(void*)f_7538},
{"f_7521c-backend.scm",(void*)f_7521},
{"f_7504c-backend.scm",(void*)f_7504},
{"f_7487c-backend.scm",(void*)f_7487},
{"f_7470c-backend.scm",(void*)f_7470},
{"f_7453c-backend.scm",(void*)f_7453},
{"f_7418c-backend.scm",(void*)f_7418},
{"f_7428c-backend.scm",(void*)f_7428},
{"f_7426c-backend.scm",(void*)f_7426},
{"f_7422c-backend.scm",(void*)f_7422},
{"f_7414c-backend.scm",(void*)f_7414},
{"f_7401c-backend.scm",(void*)f_7401},
{"f_7384c-backend.scm",(void*)f_7384},
{"f_7017c-backend.scm",(void*)f_7017},
{"f_7012c-backend.scm",(void*)f_7012},
{"f_6945c-backend.scm",(void*)f_6945},
{"f_6949c-backend.scm",(void*)f_6949},
{"f_6952c-backend.scm",(void*)f_6952},
{"f_6955c-backend.scm",(void*)f_6955},
{"f_6958c-backend.scm",(void*)f_6958},
{"f_6964c-backend.scm",(void*)f_6964},
{"f_7008c-backend.scm",(void*)f_7008},
{"f_6967c-backend.scm",(void*)f_6967},
{"f_6975c-backend.scm",(void*)f_6975},
{"f_6996c-backend.scm",(void*)f_6996},
{"f_6979c-backend.scm",(void*)f_6979},
{"f_6970c-backend.scm",(void*)f_6970},
{"f_6514c-backend.scm",(void*)f_6514},
{"f_6520c-backend.scm",(void*)f_6520},
{"f_6524c-backend.scm",(void*)f_6524},
{"f_6527c-backend.scm",(void*)f_6527},
{"f_6530c-backend.scm",(void*)f_6530},
{"f_6533c-backend.scm",(void*)f_6533},
{"f_6539c-backend.scm",(void*)f_6539},
{"f_6880c-backend.scm",(void*)f_6880},
{"f_6883c-backend.scm",(void*)f_6883},
{"f_6943c-backend.scm",(void*)f_6943},
{"f_6886c-backend.scm",(void*)f_6886},
{"f_6889c-backend.scm",(void*)f_6889},
{"f_6892c-backend.scm",(void*)f_6892},
{"f_6895c-backend.scm",(void*)f_6895},
{"f_6928c-backend.scm",(void*)f_6928},
{"f_6936c-backend.scm",(void*)f_6936},
{"f_6898c-backend.scm",(void*)f_6898},
{"f_6926c-backend.scm",(void*)f_6926},
{"f_6901c-backend.scm",(void*)f_6901},
{"f_6904c-backend.scm",(void*)f_6904},
{"f_6907c-backend.scm",(void*)f_6907},
{"f_6541c-backend.scm",(void*)f_6541},
{"f_6551c-backend.scm",(void*)f_6551},
{"f_6560c-backend.scm",(void*)f_6560},
{"f_6572c-backend.scm",(void*)f_6572},
{"f_6584c-backend.scm",(void*)f_6584},
{"f_6590c-backend.scm",(void*)f_6590},
{"f_6624c-backend.scm",(void*)f_6624},
{"f_6281c-backend.scm",(void*)f_6281},
{"f_6287c-backend.scm",(void*)f_6287},
{"f_6291c-backend.scm",(void*)f_6291},
{"f_6294c-backend.scm",(void*)f_6294},
{"f_6297c-backend.scm",(void*)f_6297},
{"f_6512c-backend.scm",(void*)f_6512},
{"f_6303c-backend.scm",(void*)f_6303},
{"f_6306c-backend.scm",(void*)f_6306},
{"f_6309c-backend.scm",(void*)f_6309},
{"f_6312c-backend.scm",(void*)f_6312},
{"f_6315c-backend.scm",(void*)f_6315},
{"f_6318c-backend.scm",(void*)f_6318},
{"f_6321c-backend.scm",(void*)f_6321},
{"f_6324c-backend.scm",(void*)f_6324},
{"f_6327c-backend.scm",(void*)f_6327},
{"f_6330c-backend.scm",(void*)f_6330},
{"f_6501c-backend.scm",(void*)f_6501},
{"f_6333c-backend.scm",(void*)f_6333},
{"f_6336c-backend.scm",(void*)f_6336},
{"f_6339c-backend.scm",(void*)f_6339},
{"f_6342c-backend.scm",(void*)f_6342},
{"f_6345c-backend.scm",(void*)f_6345},
{"f_6348c-backend.scm",(void*)f_6348},
{"f_6351c-backend.scm",(void*)f_6351},
{"f_6354c-backend.scm",(void*)f_6354},
{"f_6479c-backend.scm",(void*)f_6479},
{"f_6449c-backend.scm",(void*)f_6449},
{"f_6469c-backend.scm",(void*)f_6469},
{"f_6457c-backend.scm",(void*)f_6457},
{"f_6461c-backend.scm",(void*)f_6461},
{"f_6465c-backend.scm",(void*)f_6465},
{"f_6357c-backend.scm",(void*)f_6357},
{"f_6360c-backend.scm",(void*)f_6360},
{"f_6390c-backend.scm",(void*)f_6390},
{"f_6393c-backend.scm",(void*)f_6393},
{"f_6431c-backend.scm",(void*)f_6431},
{"f_6427c-backend.scm",(void*)f_6427},
{"f_6396c-backend.scm",(void*)f_6396},
{"f_6399c-backend.scm",(void*)f_6399},
{"f_6402c-backend.scm",(void*)f_6402},
{"f_6369c-backend.scm",(void*)f_6369},
{"f_6372c-backend.scm",(void*)f_6372},
{"f_6363c-backend.scm",(void*)f_6363},
{"f_6263c-backend.scm",(void*)f_6263},
{"f_6269c-backend.scm",(void*)f_6269},
{"f_6273c-backend.scm",(void*)f_6273},
{"f_6276c-backend.scm",(void*)f_6276},
{"f_6231c-backend.scm",(void*)f_6231},
{"f_6235c-backend.scm",(void*)f_6235},
{"f_6240c-backend.scm",(void*)f_6240},
{"f_6261c-backend.scm",(void*)f_6261},
{"f_6215c-backend.scm",(void*)f_6215},
{"f_6221c-backend.scm",(void*)f_6221},
{"f_6229c-backend.scm",(void*)f_6229},
{"f_6199c-backend.scm",(void*)f_6199},
{"f_6205c-backend.scm",(void*)f_6205},
{"f_6213c-backend.scm",(void*)f_6213},
{"f_6110c-backend.scm",(void*)f_6110},
{"f_6119c-backend.scm",(void*)f_6119},
{"f_6148c-backend.scm",(void*)f_6148},
{"f_6158c-backend.scm",(void*)f_6158},
{"f_6151c-backend.scm",(void*)f_6151},
{"f_6135c-backend.scm",(void*)f_6135},
{"f_6037c-backend.scm",(void*)f_6037},
{"f_6041c-backend.scm",(void*)f_6041},
{"f_6055c-backend.scm",(void*)f_6055},
{"f_6068c-backend.scm",(void*)f_6068},
{"f_6071c-backend.scm",(void*)f_6071},
{"f_6074c-backend.scm",(void*)f_6074},
{"f_6044c-backend.scm",(void*)f_6044},
{"f_6047c-backend.scm",(void*)f_6047},
{"f_6050c-backend.scm",(void*)f_6050},
{"f_2461c-backend.scm",(void*)f_2461},
{"f_6004c-backend.scm",(void*)f_6004},
{"f_6008c-backend.scm",(void*)f_6008},
{"f_6011c-backend.scm",(void*)f_6011},
{"f_6014c-backend.scm",(void*)f_6014},
{"f_6017c-backend.scm",(void*)f_6017},
{"f_6020c-backend.scm",(void*)f_6020},
{"f_6023c-backend.scm",(void*)f_6023},
{"f_6026c-backend.scm",(void*)f_6026},
{"f_6029c-backend.scm",(void*)f_6029},
{"f_6032c-backend.scm",(void*)f_6032},
{"f_5257c-backend.scm",(void*)f_5257},
{"f_5263c-backend.scm",(void*)f_5263},
{"f_5267c-backend.scm",(void*)f_5267},
{"f_5270c-backend.scm",(void*)f_5270},
{"f_5273c-backend.scm",(void*)f_5273},
{"f_5276c-backend.scm",(void*)f_5276},
{"f_5279c-backend.scm",(void*)f_5279},
{"f_5282c-backend.scm",(void*)f_5282},
{"f_6001c-backend.scm",(void*)f_6001},
{"f_5285c-backend.scm",(void*)f_5285},
{"f_5291c-backend.scm",(void*)f_5291},
{"f_5294c-backend.scm",(void*)f_5294},
{"f_5297c-backend.scm",(void*)f_5297},
{"f_5300c-backend.scm",(void*)f_5300},
{"f_5303c-backend.scm",(void*)f_5303},
{"f_5306c-backend.scm",(void*)f_5306},
{"f_5309c-backend.scm",(void*)f_5309},
{"f_5312c-backend.scm",(void*)f_5312},
{"f_5315c-backend.scm",(void*)f_5315},
{"f_5318c-backend.scm",(void*)f_5318},
{"f_5321c-backend.scm",(void*)f_5321},
{"f_5324c-backend.scm",(void*)f_5324},
{"f_5970c-backend.scm",(void*)f_5970},
{"f_5327c-backend.scm",(void*)f_5327},
{"f_5931c-backend.scm",(void*)f_5931},
{"f_5934c-backend.scm",(void*)f_5934},
{"f_5937c-backend.scm",(void*)f_5937},
{"f_5953c-backend.scm",(void*)f_5953},
{"f_5956c-backend.scm",(void*)f_5956},
{"f_5330c-backend.scm",(void*)f_5330},
{"f_5333c-backend.scm",(void*)f_5333},
{"f_5336c-backend.scm",(void*)f_5336},
{"f_5903c-backend.scm",(void*)f_5903},
{"f_5906c-backend.scm",(void*)f_5906},
{"f_5339c-backend.scm",(void*)f_5339},
{"f_5342c-backend.scm",(void*)f_5342},
{"f_5345c-backend.scm",(void*)f_5345},
{"f_5348c-backend.scm",(void*)f_5348},
{"f_5351c-backend.scm",(void*)f_5351},
{"f_5354c-backend.scm",(void*)f_5354},
{"f_5865c-backend.scm",(void*)f_5865},
{"f_5875c-backend.scm",(void*)f_5875},
{"f_5357c-backend.scm",(void*)f_5357},
{"f_5808c-backend.scm",(void*)f_5808},
{"f_5820c-backend.scm",(void*)f_5820},
{"f_5823c-backend.scm",(void*)f_5823},
{"f_5829c-backend.scm",(void*)f_5829},
{"f_5730c-backend.scm",(void*)f_5730},
{"f_5772c-backend.scm",(void*)f_5772},
{"f_5733c-backend.scm",(void*)f_5733},
{"f_5739c-backend.scm",(void*)f_5739},
{"f_5742c-backend.scm",(void*)f_5742},
{"f_5748c-backend.scm",(void*)f_5748},
{"f_5666c-backend.scm",(void*)f_5666},
{"f_5669c-backend.scm",(void*)f_5669},
{"f_5672c-backend.scm",(void*)f_5672},
{"f_5675c-backend.scm",(void*)f_5675},
{"f_5678c-backend.scm",(void*)f_5678},
{"f_5693c-backend.scm",(void*)f_5693},
{"f_5681c-backend.scm",(void*)f_5681},
{"f_5684c-backend.scm",(void*)f_5684},
{"f_5652c-backend.scm",(void*)f_5652},
{"f_5660c-backend.scm",(void*)f_5660},
{"f_5577c-backend.scm",(void*)f_5577},
{"f_5583c-backend.scm",(void*)f_5583},
{"f_5586c-backend.scm",(void*)f_5586},
{"f_5620c-backend.scm",(void*)f_5620},
{"f_5623c-backend.scm",(void*)f_5623},
{"f_5626c-backend.scm",(void*)f_5626},
{"f_5589c-backend.scm",(void*)f_5589},
{"f_5592c-backend.scm",(void*)f_5592},
{"f_5595c-backend.scm",(void*)f_5595},
{"f_5598c-backend.scm",(void*)f_5598},
{"f_5607c-backend.scm",(void*)f_5607},
{"f_5610c-backend.scm",(void*)f_5610},
{"f_5360c-backend.scm",(void*)f_5360},
{"f_5383c-backend.scm",(void*)f_5383},
{"f_5518c-backend.scm",(void*)f_5518},
{"f_5521c-backend.scm",(void*)f_5521},
{"f_5533c-backend.scm",(void*)f_5533},
{"f_5524c-backend.scm",(void*)f_5524},
{"f_5389c-backend.scm",(void*)f_5389},
{"f_5392c-backend.scm",(void*)f_5392},
{"f_5395c-backend.scm",(void*)f_5395},
{"f_5499c-backend.scm",(void*)f_5499},
{"f_5398c-backend.scm",(void*)f_5398},
{"f_5401c-backend.scm",(void*)f_5401},
{"f_5404c-backend.scm",(void*)f_5404},
{"f_5407c-backend.scm",(void*)f_5407},
{"f_5472c-backend.scm",(void*)f_5472},
{"f_5468c-backend.scm",(void*)f_5468},
{"f_5410c-backend.scm",(void*)f_5410},
{"f_5413c-backend.scm",(void*)f_5413},
{"f_5416c-backend.scm",(void*)f_5416},
{"f_5419c-backend.scm",(void*)f_5419},
{"f_5422c-backend.scm",(void*)f_5422},
{"f_5425c-backend.scm",(void*)f_5425},
{"f_5443c-backend.scm",(void*)f_5443},
{"f_5453c-backend.scm",(void*)f_5453},
{"f_5428c-backend.scm",(void*)f_5428},
{"f_5363c-backend.scm",(void*)f_5363},
{"f_5373c-backend.scm",(void*)f_5373},
{"f_5366c-backend.scm",(void*)f_5366},
{"f_4867c-backend.scm",(void*)f_4867},
{"f_4874c-backend.scm",(void*)f_4874},
{"f_4948c-backend.scm",(void*)f_4948},
{"f_4966c-backend.scm",(void*)f_4966},
{"f_4995c-backend.scm",(void*)f_4995},
{"f_5017c-backend.scm",(void*)f_5017},
{"f_4973c-backend.scm",(void*)f_4973},
{"f_4942c-backend.scm",(void*)f_4942},
{"f_4938c-backend.scm",(void*)f_4938},
{"f_4934c-backend.scm",(void*)f_4934},
{"f_4905c-backend.scm",(void*)f_4905},
{"f_4909c-backend.scm",(void*)f_4909},
{"f_4824c-backend.scm",(void*)f_4824},
{"f_4830c-backend.scm",(void*)f_4830},
{"f_4859c-backend.scm",(void*)f_4859},
{"f_4840c-backend.scm",(void*)f_4840},
{"f_5026c-backend.scm",(void*)f_5026},
{"f_5166c-backend.scm",(void*)f_5166},
{"f_5033c-backend.scm",(void*)f_5033},
{"f_5039c-backend.scm",(void*)f_5039},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5125c-backend.scm",(void*)f_5125},
{"f_5135c-backend.scm",(void*)f_5135},
{"f_5128c-backend.scm",(void*)f_5128},
{"f_5089c-backend.scm",(void*)f_5089},
{"f_5095c-backend.scm",(void*)f_5095},
{"f_4861c-backend.scm",(void*)f_4861},
{"f_5168c-backend.scm",(void*)f_5168},
{"f_5175c-backend.scm",(void*)f_5175},
{"f_5178c-backend.scm",(void*)f_5178},
{"f_5183c-backend.scm",(void*)f_5183},
{"f_5239c-backend.scm",(void*)f_5239},
{"f_5235c-backend.scm",(void*)f_5235},
{"f_5220c-backend.scm",(void*)f_5220},
{"f_5199c-backend.scm",(void*)f_5199},
{"f_5210c-backend.scm",(void*)f_5210},
{"f_5206c-backend.scm",(void*)f_5206},
{"f_5245c-backend.scm",(void*)f_5245},
{"f_5252c-backend.scm",(void*)f_5252},
{"f_5255c-backend.scm",(void*)f_5255},
{"f_4538c-backend.scm",(void*)f_4538},
{"f_4705c-backend.scm",(void*)f_4705},
{"f_4709c-backend.scm",(void*)f_4709},
{"f_4712c-backend.scm",(void*)f_4712},
{"f_4715c-backend.scm",(void*)f_4715},
{"f_4718c-backend.scm",(void*)f_4718},
{"f_4721c-backend.scm",(void*)f_4721},
{"f_4822c-backend.scm",(void*)f_4822},
{"f_4724c-backend.scm",(void*)f_4724},
{"f_4727c-backend.scm",(void*)f_4727},
{"f_4733c-backend.scm",(void*)f_4733},
{"f_4811c-backend.scm",(void*)f_4811},
{"f_4767c-backend.scm",(void*)f_4767},
{"f_4773c-backend.scm",(void*)f_4773},
{"f_4791c-backend.scm",(void*)f_4791},
{"f_4787c-backend.scm",(void*)f_4787},
{"f_4783c-backend.scm",(void*)f_4783},
{"f_4739c-backend.scm",(void*)f_4739},
{"f_4742c-backend.scm",(void*)f_4742},
{"f_4745c-backend.scm",(void*)f_4745},
{"f_4748c-backend.scm",(void*)f_4748},
{"f_4751c-backend.scm",(void*)f_4751},
{"f_4761c-backend.scm",(void*)f_4761},
{"f_4754c-backend.scm",(void*)f_4754},
{"f_4657c-backend.scm",(void*)f_4657},
{"f_4676c-backend.scm",(void*)f_4676},
{"f_4680c-backend.scm",(void*)f_4680},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4689c-backend.scm",(void*)f_4689},
{"f_4703c-backend.scm",(void*)f_4703},
{"f_4699c-backend.scm",(void*)f_4699},
{"f_4692c-backend.scm",(void*)f_4692},
{"f_4660c-backend.scm",(void*)f_4660},
{"f_4674c-backend.scm",(void*)f_4674},
{"f_4663c-backend.scm",(void*)f_4663},
{"f_4670c-backend.scm",(void*)f_4670},
{"f_4577c-backend.scm",(void*)f_4577},
{"f_4579c-backend.scm",(void*)f_4579},
{"f_4583c-backend.scm",(void*)f_4583},
{"f_4586c-backend.scm",(void*)f_4586},
{"f_4589c-backend.scm",(void*)f_4589},
{"f_4592c-backend.scm",(void*)f_4592},
{"f_4595c-backend.scm",(void*)f_4595},
{"f_4598c-backend.scm",(void*)f_4598},
{"f_4601c-backend.scm",(void*)f_4601},
{"f_4604c-backend.scm",(void*)f_4604},
{"f_4607c-backend.scm",(void*)f_4607},
{"f_4610c-backend.scm",(void*)f_4610},
{"f_4613c-backend.scm",(void*)f_4613},
{"f_4616c-backend.scm",(void*)f_4616},
{"f_4630c-backend.scm",(void*)f_4630},
{"f_4626c-backend.scm",(void*)f_4626},
{"f_4619c-backend.scm",(void*)f_4619},
{"f_4541c-backend.scm",(void*)f_4541},
{"f_4554c-backend.scm",(void*)f_4554},
{"f_4564c-backend.scm",(void*)f_4564},
{"f_4545c-backend.scm",(void*)f_4545},
{"f_4287c-backend.scm",(void*)f_4287},
{"f_4291c-backend.scm",(void*)f_4291},
{"f_4315c-backend.scm",(void*)f_4315},
{"f_4319c-backend.scm",(void*)f_4319},
{"f_4322c-backend.scm",(void*)f_4322},
{"f_4536c-backend.scm",(void*)f_4536},
{"f_4325c-backend.scm",(void*)f_4325},
{"f_4522c-backend.scm",(void*)f_4522},
{"f_4328c-backend.scm",(void*)f_4328},
{"f_4331c-backend.scm",(void*)f_4331},
{"f_4334c-backend.scm",(void*)f_4334},
{"f_4337c-backend.scm",(void*)f_4337},
{"f_4340c-backend.scm",(void*)f_4340},
{"f_4343c-backend.scm",(void*)f_4343},
{"f_4514c-backend.scm",(void*)f_4514},
{"f_4346c-backend.scm",(void*)f_4346},
{"f_4349c-backend.scm",(void*)f_4349},
{"f_4507c-backend.scm",(void*)f_4507},
{"f_4488c-backend.scm",(void*)f_4488},
{"f_4499c-backend.scm",(void*)f_4499},
{"f_4352c-backend.scm",(void*)f_4352},
{"f_4439c-backend.scm",(void*)f_4439},
{"f_4442c-backend.scm",(void*)f_4442},
{"f_4445c-backend.scm",(void*)f_4445},
{"f_4448c-backend.scm",(void*)f_4448},
{"f_4464c-backend.scm",(void*)f_4464},
{"f_4467c-backend.scm",(void*)f_4467},
{"f_4470c-backend.scm",(void*)f_4470},
{"f_4473c-backend.scm",(void*)f_4473},
{"f_4355c-backend.scm",(void*)f_4355},
{"f_4358c-backend.scm",(void*)f_4358},
{"f_4361c-backend.scm",(void*)f_4361},
{"f_4411c-backend.scm",(void*)f_4411},
{"f_4414c-backend.scm",(void*)f_4414},
{"f_4364c-backend.scm",(void*)f_4364},
{"f_4367c-backend.scm",(void*)f_4367},
{"f_4399c-backend.scm",(void*)f_4399},
{"f_4402c-backend.scm",(void*)f_4402},
{"f_4373c-backend.scm",(void*)f_4373},
{"f_4382c-backend.scm",(void*)f_4382},
{"f_4385c-backend.scm",(void*)f_4385},
{"f_4294c-backend.scm",(void*)f_4294},
{"f_4299c-backend.scm",(void*)f_4299},
{"f_4303c-backend.scm",(void*)f_4303},
{"f_4313c-backend.scm",(void*)f_4313},
{"f_4306c-backend.scm",(void*)f_4306},
{"f_4138c-backend.scm",(void*)f_4138},
{"f_4145c-backend.scm",(void*)f_4145},
{"f_4281c-backend.scm",(void*)f_4281},
{"f_4148c-backend.scm",(void*)f_4148},
{"f_4151c-backend.scm",(void*)f_4151},
{"f_4154c-backend.scm",(void*)f_4154},
{"f_4159c-backend.scm",(void*)f_4159},
{"f_4169c-backend.scm",(void*)f_4169},
{"f_4175c-backend.scm",(void*)f_4175},
{"f_4228c-backend.scm",(void*)f_4228},
{"f_4238c-backend.scm",(void*)f_4238},
{"f_4178c-backend.scm",(void*)f_4178},
{"f_4201c-backend.scm",(void*)f_4201},
{"f_4211c-backend.scm",(void*)f_4211},
{"f_4181c-backend.scm",(void*)f_4181},
{"f_4184c-backend.scm",(void*)f_4184},
{"f_3991c-backend.scm",(void*)f_3991},
{"f_4130c-backend.scm",(void*)f_4130},
{"f_4011c-backend.scm",(void*)f_4011},
{"f_4088c-backend.scm",(void*)f_4088},
{"f_4092c-backend.scm",(void*)f_4092},
{"f_4096c-backend.scm",(void*)f_4096},
{"f_4100c-backend.scm",(void*)f_4100},
{"f_4122c-backend.scm",(void*)f_4122},
{"f_4118c-backend.scm",(void*)f_4118},
{"f_4110c-backend.scm",(void*)f_4110},
{"f_4108c-backend.scm",(void*)f_4108},
{"f_4104c-backend.scm",(void*)f_4104},
{"f_4029c-backend.scm",(void*)f_4029},
{"f_4032c-backend.scm",(void*)f_4032},
{"f_4035c-backend.scm",(void*)f_4035},
{"f_4077c-backend.scm",(void*)f_4077},
{"f_4038c-backend.scm",(void*)f_4038},
{"f_4041c-backend.scm",(void*)f_4041},
{"f_4044c-backend.scm",(void*)f_4044},
{"f_4059c-backend.scm",(void*)f_4059},
{"f_4064c-backend.scm",(void*)f_4064},
{"f_4047c-backend.scm",(void*)f_4047},
{"f_3994c-backend.scm",(void*)f_3994},
{"f_4008c-backend.scm",(void*)f_4008},
{"f_2506c-backend.scm",(void*)f_2506},
{"f_3959c-backend.scm",(void*)f_3959},
{"f_3965c-backend.scm",(void*)f_3965},
{"f_3969c-backend.scm",(void*)f_3969},
{"f_2509c-backend.scm",(void*)f_2509},
{"f_3953c-backend.scm",(void*)f_3953},
{"f_2513c-backend.scm",(void*)f_2513},
{"f_3948c-backend.scm",(void*)f_3948},
{"f_2516c-backend.scm",(void*)f_2516},
{"f_3943c-backend.scm",(void*)f_3943},
{"f_2519c-backend.scm",(void*)f_2519},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3912c-backend.scm",(void*)f_3912},
{"f_3915c-backend.scm",(void*)f_3915},
{"f_3918c-backend.scm",(void*)f_3918},
{"f_3921c-backend.scm",(void*)f_3921},
{"f_3924c-backend.scm",(void*)f_3924},
{"f_3826c-backend.scm",(void*)f_3826},
{"f_3829c-backend.scm",(void*)f_3829},
{"f_3832c-backend.scm",(void*)f_3832},
{"f_3845c-backend.scm",(void*)f_3845},
{"f_3868c-backend.scm",(void*)f_3868},
{"f_3871c-backend.scm",(void*)f_3871},
{"f_3874c-backend.scm",(void*)f_3874},
{"f_3877c-backend.scm",(void*)f_3877},
{"f_3855c-backend.scm",(void*)f_3855},
{"f_3858c-backend.scm",(void*)f_3858},
{"f_3817c-backend.scm",(void*)f_3817},
{"f_3789c-backend.scm",(void*)f_3789},
{"f_3792c-backend.scm",(void*)f_3792},
{"f_3809c-backend.scm",(void*)f_3809},
{"f_3795c-backend.scm",(void*)f_3795},
{"f_3798c-backend.scm",(void*)f_3798},
{"f_3773c-backend.scm",(void*)f_3773},
{"f_3777c-backend.scm",(void*)f_3777},
{"f_3759c-backend.scm",(void*)f_3759},
{"f_3762c-backend.scm",(void*)f_3762},
{"f_3743c-backend.scm",(void*)f_3743},
{"f_3747c-backend.scm",(void*)f_3747},
{"f_3725c-backend.scm",(void*)f_3725},
{"f_3728c-backend.scm",(void*)f_3728},
{"f_3705c-backend.scm",(void*)f_3705},
{"f_3669c-backend.scm",(void*)f_3669},
{"f_3681c-backend.scm",(void*)f_3681},
{"f_3672c-backend.scm",(void*)f_3672},
{"f_3650c-backend.scm",(void*)f_3650},
{"f_3653c-backend.scm",(void*)f_3653},
{"f_3631c-backend.scm",(void*)f_3631},
{"f_3634c-backend.scm",(void*)f_3634},
{"f_3612c-backend.scm",(void*)f_3612},
{"f_3615c-backend.scm",(void*)f_3615},
{"f_3593c-backend.scm",(void*)f_3593},
{"f_3589c-backend.scm",(void*)f_3589},
{"f_3537c-backend.scm",(void*)f_3537},
{"f_3570c-backend.scm",(void*)f_3570},
{"f_3540c-backend.scm",(void*)f_3540},
{"f_3558c-backend.scm",(void*)f_3558},
{"f_3543c-backend.scm",(void*)f_3543},
{"f_3546c-backend.scm",(void*)f_3546},
{"f_3504c-backend.scm",(void*)f_3504},
{"f_3488c-backend.scm",(void*)f_3488},
{"f_3491c-backend.scm",(void*)f_3491},
{"f_3494c-backend.scm",(void*)f_3494},
{"f_3447c-backend.scm",(void*)f_3447},
{"f_3450c-backend.scm",(void*)f_3450},
{"f_3471c-backend.scm",(void*)f_3471},
{"f_3475c-backend.scm",(void*)f_3475},
{"f_3478c-backend.scm",(void*)f_3478},
{"f_3453c-backend.scm",(void*)f_3453},
{"f_3469c-backend.scm",(void*)f_3469},
{"f_3461c-backend.scm",(void*)f_3461},
{"f_3456c-backend.scm",(void*)f_3456},
{"f_3183c-backend.scm",(void*)f_3183},
{"f_3186c-backend.scm",(void*)f_3186},
{"f_3397c-backend.scm",(void*)f_3397},
{"f_3393c-backend.scm",(void*)f_3393},
{"f_3192c-backend.scm",(void*)f_3192},
{"f_3386c-backend.scm",(void*)f_3386},
{"f_2494c-backend.scm",(void*)f_2494},
{"f_3379c-backend.scm",(void*)f_3379},
{"f_3198c-backend.scm",(void*)f_3198},
{"f_3365c-backend.scm",(void*)f_3365},
{"f_3364c-backend.scm",(void*)f_3364},
{"f_3327c-backend.scm",(void*)f_3327},
{"f_3330c-backend.scm",(void*)f_3330},
{"f_3333c-backend.scm",(void*)f_3333},
{"f_3348c-backend.scm",(void*)f_3348},
{"f_3336c-backend.scm",(void*)f_3336},
{"f_3339c-backend.scm",(void*)f_3339},
{"f_3342c-backend.scm",(void*)f_3342},
{"f_3324c-backend.scm",(void*)f_3324},
{"f_3234c-backend.scm",(void*)f_3234},
{"f_3308c-backend.scm",(void*)f_3308},
{"f_3311c-backend.scm",(void*)f_3311},
{"f_3284c-backend.scm",(void*)f_3284},
{"f_3287c-backend.scm",(void*)f_3287},
{"f_3290c-backend.scm",(void*)f_3290},
{"f_3293c-backend.scm",(void*)f_3293},
{"f_3296c-backend.scm",(void*)f_3296},
{"f_3237c-backend.scm",(void*)f_3237},
{"f_3240c-backend.scm",(void*)f_3240},
{"f_3267c-backend.scm",(void*)f_3267},
{"f_3271c-backend.scm",(void*)f_3271},
{"f_3274c-backend.scm",(void*)f_3274},
{"f_3243c-backend.scm",(void*)f_3243},
{"f_3265c-backend.scm",(void*)f_3265},
{"f_3257c-backend.scm",(void*)f_3257},
{"f_3246c-backend.scm",(void*)f_3246},
{"f_3249c-backend.scm",(void*)f_3249},
{"f_3221c-backend.scm",(void*)f_3221},
{"f_3207c-backend.scm",(void*)f_3207},
{"f_3210c-backend.scm",(void*)f_3210},
{"f_3213c-backend.scm",(void*)f_3213},
{"f_3150c-backend.scm",(void*)f_3150},
{"f_3146c-backend.scm",(void*)f_3146},
{"f_3132c-backend.scm",(void*)f_3132},
{"f_3135c-backend.scm",(void*)f_3135},
{"f_3129c-backend.scm",(void*)f_3129},
{"f_3125c-backend.scm",(void*)f_3125},
{"f_3111c-backend.scm",(void*)f_3111},
{"f_3114c-backend.scm",(void*)f_3114},
{"f_3063c-backend.scm",(void*)f_3063},
{"f_3084c-backend.scm",(void*)f_3084},
{"f_3080c-backend.scm",(void*)f_3080},
{"f_3066c-backend.scm",(void*)f_3066},
{"f_3069c-backend.scm",(void*)f_3069},
{"f_3032c-backend.scm",(void*)f_3032},
{"f_3028c-backend.scm",(void*)f_3028},
{"f_2986c-backend.scm",(void*)f_2986},
{"f_2954c-backend.scm",(void*)f_2954},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_2919c-backend.scm",(void*)f_2919},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_2931c-backend.scm",(void*)f_2931},
{"f_2935c-backend.scm",(void*)f_2935},
{"f_2938c-backend.scm",(void*)f_2938},
{"f_2922c-backend.scm",(void*)f_2922},
{"f_2887c-backend.scm",(void*)f_2887},
{"f_2890c-backend.scm",(void*)f_2890},
{"f_2893c-backend.scm",(void*)f_2893},
{"f_2896c-backend.scm",(void*)f_2896},
{"f_2858c-backend.scm",(void*)f_2858},
{"f_2861c-backend.scm",(void*)f_2861},
{"f_2864c-backend.scm",(void*)f_2864},
{"f_2867c-backend.scm",(void*)f_2867},
{"f_2821c-backend.scm",(void*)f_2821},
{"f_2824c-backend.scm",(void*)f_2824},
{"f_2827c-backend.scm",(void*)f_2827},
{"f_2830c-backend.scm",(void*)f_2830},
{"f_2788c-backend.scm",(void*)f_2788},
{"f_2791c-backend.scm",(void*)f_2791},
{"f_2794c-backend.scm",(void*)f_2794},
{"f_2797c-backend.scm",(void*)f_2797},
{"f_2769c-backend.scm",(void*)f_2769},
{"f_2772c-backend.scm",(void*)f_2772},
{"f_2742c-backend.scm",(void*)f_2742},
{"f_2745c-backend.scm",(void*)f_2745},
{"f_2691c-backend.scm",(void*)f_2691},
{"f_2701c-backend.scm",(void*)f_2701},
{"f_2704c-backend.scm",(void*)f_2704},
{"f_2707c-backend.scm",(void*)f_2707},
{"f_2633c-backend.scm",(void*)f_2633},
{"f_2636c-backend.scm",(void*)f_2636},
{"f_2639c-backend.scm",(void*)f_2639},
{"f_2642c-backend.scm",(void*)f_2642},
{"f_2645c-backend.scm",(void*)f_2645},
{"f_2648c-backend.scm",(void*)f_2648},
{"f_2496c-backend.scm",(void*)f_2496},
{"f_2504c-backend.scm",(void*)f_2504},
{"f_2464c-backend.scm",(void*)f_2464},
{"f_2476c-backend.scm",(void*)f_2476},
{"f_2484c-backend.scm",(void*)f_2484},
{"f_2468c-backend.scm",(void*)f_2468},
{"f_2441c-backend.scm",(void*)f_2441},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_2447c-backend.scm",(void*)f_2447},
{"f_2420c-backend.scm",(void*)f_2420},
{"f_2426c-backend.scm",(void*)f_2426},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
