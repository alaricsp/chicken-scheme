/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 17:54
   Version 3.0.6 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 9498	compiled 2008-03-11 on tablet (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[577];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10110)
static void C_ccall f_10110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11176)
static void C_ccall f_11176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10967)
static void C_fcall f_10967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10200)
static void C_fcall f_10200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10956)
static void C_ccall f_10956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10866)
static void C_fcall f_10866(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10943)
static void C_ccall f_10943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10924)
static void C_ccall f_10924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10887)
static void C_fcall f_10887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10890)
static void C_ccall f_10890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10838)
static void C_fcall f_10838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10807)
static void C_fcall f_10807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10798)
static void C_fcall f_10798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_ccall f_10801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10675)
static void C_ccall f_10675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10764)
static void C_ccall f_10764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10709)
static void C_fcall f_10709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10691)
static void C_ccall f_10691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10634)
static void C_ccall f_10634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10638)
static void C_ccall f_10638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10450)
static void C_ccall f_10450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10602)
static void C_ccall f_10602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10583)
static void C_fcall f_10583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10457)
static void C_ccall f_10457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10463)
static void C_ccall f_10463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10466)
static void C_ccall f_10466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10504)
static void C_ccall f_10504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10530)
static void C_ccall f_10530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10511)
static void C_fcall f_10511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10515)
static void C_ccall f_10515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10488)
static void C_ccall f_10488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10403)
static void C_fcall f_10403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10397)
static void C_fcall f_10397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10351)
static void C_ccall f_10351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10334)
static void C_ccall f_10334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10330)
static void C_ccall f_10330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10306)
static void C_ccall f_10306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10113)
static void C_fcall f_10113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10117)
static void C_ccall f_10117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10132)
static void C_ccall f_10132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_fcall f_10147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10192)
static void C_ccall f_10192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10151)
static void C_ccall f_10151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_fcall f_10157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10167)
static void C_ccall f_10167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11038)
static void C_ccall f_11038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11073)
static void C_fcall f_11073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11077)
static void C_ccall f_11077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11087)
static void C_ccall f_11087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_fcall f_11059(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11067)
static void C_ccall f_11067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11105)
static void C_fcall f_11105(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11118)
static void C_ccall f_11118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10101)
static void C_ccall f_10101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10074)
static void C_ccall f_10074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10056)
static void C_ccall f_10056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10047)
static void C_ccall f_10047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10038)
static void C_ccall f_10038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10029)
static void C_ccall f_10029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10020)
static void C_ccall f_10020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10011)
static void C_ccall f_10011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10002)
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9993)
static void C_ccall f_9993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9984)
static void C_ccall f_9984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9975)
static void C_ccall f_9975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9966)
static void C_ccall f_9966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9957)
static void C_ccall f_9957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9948)
static void C_ccall f_9948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9939)
static void C_ccall f_9939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9930)
static void C_ccall f_9930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9912)
static void C_ccall f_9912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9894)
static void C_ccall f_9894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9885)
static void C_ccall f_9885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9876)
static void C_ccall f_9876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9867)
static void C_ccall f_9867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_ccall f_9801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9807)
static void C_ccall f_9807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9820)
static void C_ccall f_9820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_fcall f_9647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8958)
static void C_fcall f_8958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8977)
static void C_fcall f_8977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_fcall f_9010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9537)
static void C_ccall f_9537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_fcall f_9526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9383)
static void C_ccall f_9383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9483)
static void C_ccall f_9483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9470)
static void C_ccall f_9470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9392)
static void C_ccall f_9392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9443)
static void C_ccall f_9443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_ccall f_9415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_fcall f_9134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9253)
static void C_ccall f_9253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9190)
static void C_ccall f_9190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9182)
static void C_ccall f_9182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9050)
static void C_ccall f_9050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8989)
static void C_ccall f_8989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9659)
static void C_fcall f_9659(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9666)
static void C_ccall f_9666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_ccall f_9682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8624)
static void C_fcall f_8624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8643)
static void C_fcall f_8643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9698)
static void C_ccall f_9698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9736)
static void C_fcall f_9736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9748)
static void C_fcall f_9748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9727)
static void C_ccall f_9727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9696)
static void C_ccall f_9696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8847)
static void C_ccall f_8847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_fcall f_8745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8763)
static void C_fcall f_8763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8781)
static void C_fcall f_8781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8769)
static void C_ccall f_8769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_fcall f_8733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_fcall f_8723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8681)
static void C_ccall f_8681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8668)
static void C_ccall f_8668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_fcall f_8613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8608)
static void C_ccall f_8608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_fcall f_8597(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8446)
static void C_fcall f_8446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8392)
static void C_fcall f_8392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8407)
static void C_fcall f_8407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_fcall f_8401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_fcall f_8341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_fcall f_8297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_fcall f_8309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_fcall f_8198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8284)
static void C_ccall f_8284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8280)
static void C_ccall f_8280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_fcall f_8266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8220)
static void C_ccall f_8220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8226)
static void C_fcall f_8226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8162)
static void C_fcall f_8162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_fcall f_8150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_fcall f_8135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8056)
static void C_fcall f_8056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_fcall f_7906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_fcall f_7927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_fcall f_7948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_fcall f_7887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_fcall f_7843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7798)
static void C_fcall f_7798(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7784)
static void C_fcall f_7784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7082)
static void C_fcall f_7082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7104)
static void C_fcall f_7104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_fcall f_7540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_fcall f_7555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_ccall f_7559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_fcall f_7546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_ccall f_7401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_fcall f_7420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_fcall f_7453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_fcall f_7423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7248)
static void C_ccall f_7248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_ccall f_7159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_fcall f_7675(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7688)
static void C_fcall f_7688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7748)
static void C_ccall f_7748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_fcall f_7697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_fcall f_7778(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7075)
static C_word C_fcall f_7075(C_word t0);
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6854)
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6860)
static void C_fcall f_6860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_fcall f_6838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6713)
static void C_fcall f_6713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_fcall f_6339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6361)
static void C_fcall f_6361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_fcall f_6627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_ccall f_6828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6432)
static void C_ccall f_6432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6295)
static void C_fcall f_6295(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6234)
static void C_fcall f_6234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_fcall f_6205(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6211)
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6125)
static void C_fcall f_6125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_fcall f_6128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_fcall f_6131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_fcall f_5829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5758)
static void C_ccall f_5758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4756)
static void C_fcall f_4756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_fcall f_5430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_fcall f_5124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_fcall f_4841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_fcall f_4718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_fcall f_4647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_fcall f_4523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_fcall f_4544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_fcall f_2345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_fcall f_4281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_fcall f_4230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static C_word C_fcall f_4029(C_word *a,C_word t0);
C_noret_decl(f_4024)
static void C_fcall f_4024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static C_word C_fcall f_3987(C_word *a,C_word t0);
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_fcall f_3581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_fcall f_3478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_fcall f_3006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_fcall f_2645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_fcall f_2635(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_fcall f_2392(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1994)
static void C_fcall f_1994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_fcall f_1963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1951)
static C_word C_fcall f_1951(C_word t0,C_word t1);
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10967)
static void C_fcall trf_10967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10967(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10967(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10200)
static void C_fcall trf_10200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10200(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10200(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10866)
static void C_fcall trf_10866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10866(t0,t1);}

C_noret_decl(trf_10887)
static void C_fcall trf_10887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10887(t0,t1);}

C_noret_decl(trf_10838)
static void C_fcall trf_10838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10838(t0,t1);}

C_noret_decl(trf_10807)
static void C_fcall trf_10807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10807(t0,t1);}

C_noret_decl(trf_10798)
static void C_fcall trf_10798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10798(t0,t1);}

C_noret_decl(trf_10709)
static void C_fcall trf_10709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10709(t0,t1);}

C_noret_decl(trf_10583)
static void C_fcall trf_10583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10583(t0,t1);}

C_noret_decl(trf_10511)
static void C_fcall trf_10511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10511(t0,t1);}

C_noret_decl(trf_10403)
static void C_fcall trf_10403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10403(t0,t1);}

C_noret_decl(trf_10397)
static void C_fcall trf_10397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10397(t0,t1);}

C_noret_decl(trf_10113)
static void C_fcall trf_10113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10113(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10113(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10147)
static void C_fcall trf_10147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10147(t0,t1,t2,t3);}

C_noret_decl(trf_10157)
static void C_fcall trf_10157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10157(t0,t1);}

C_noret_decl(trf_10979)
static void C_fcall trf_10979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10979(t0,t1,t2);}

C_noret_decl(trf_11073)
static void C_fcall trf_11073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11073(t0,t1,t2);}

C_noret_decl(trf_11059)
static void C_fcall trf_11059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11059(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11059(t0,t1,t2);}

C_noret_decl(trf_11105)
static void C_fcall trf_11105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11105(t0,t1);}

C_noret_decl(trf_9647)
static void C_fcall trf_9647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9647(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9647(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8958)
static void C_fcall trf_8958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8958(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8958(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8977)
static void C_fcall trf_8977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8977(t0,t1);}

C_noret_decl(trf_9010)
static void C_fcall trf_9010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9010(t0,t1);}

C_noret_decl(trf_9526)
static void C_fcall trf_9526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9526(t0,t1);}

C_noret_decl(trf_9134)
static void C_fcall trf_9134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9134(t0,t1);}

C_noret_decl(trf_9659)
static void C_fcall trf_9659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9659(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9659(t0,t1,t2,t3);}

C_noret_decl(trf_8624)
static void C_fcall trf_8624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8624(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8624(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8643)
static void C_fcall trf_8643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8643(t0,t1);}

C_noret_decl(trf_9736)
static void C_fcall trf_9736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9736(t0,t1);}

C_noret_decl(trf_9748)
static void C_fcall trf_9748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9748(t0,t1);}

C_noret_decl(trf_8745)
static void C_fcall trf_8745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8745(t0,t1);}

C_noret_decl(trf_8763)
static void C_fcall trf_8763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8763(t0,t1);}

C_noret_decl(trf_8781)
static void C_fcall trf_8781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8781(t0,t1);}

C_noret_decl(trf_8733)
static void C_fcall trf_8733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8733(t0,t1);}

C_noret_decl(trf_8723)
static void C_fcall trf_8723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8723(t0,t1);}

C_noret_decl(trf_8613)
static void C_fcall trf_8613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8613(t0,t1,t2);}

C_noret_decl(trf_8603)
static void C_fcall trf_8603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8603(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8603(t0,t1,t2,t3);}

C_noret_decl(trf_8597)
static void C_fcall trf_8597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8597(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8597(t0,t1,t2,t3);}

C_noret_decl(trf_8446)
static void C_fcall trf_8446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8446(t0,t1);}

C_noret_decl(trf_8392)
static void C_fcall trf_8392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8392(t0,t1);}

C_noret_decl(trf_8407)
static void C_fcall trf_8407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8407(t0,t1);}

C_noret_decl(trf_8401)
static void C_fcall trf_8401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8401(t0,t1);}

C_noret_decl(trf_8341)
static void C_fcall trf_8341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8341(t0,t1);}

C_noret_decl(trf_8297)
static void C_fcall trf_8297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8297(t0,t1);}

C_noret_decl(trf_8309)
static void C_fcall trf_8309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8309(t0,t1);}

C_noret_decl(trf_8198)
static void C_fcall trf_8198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8198(t0,t1);}

C_noret_decl(trf_8266)
static void C_fcall trf_8266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8266(t0,t1);}

C_noret_decl(trf_8226)
static void C_fcall trf_8226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8226(t0,t1);}

C_noret_decl(trf_8162)
static void C_fcall trf_8162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8162(t0,t1);}

C_noret_decl(trf_8150)
static void C_fcall trf_8150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8150(t0,t1);}

C_noret_decl(trf_8135)
static void C_fcall trf_8135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8135(t0,t1);}

C_noret_decl(trf_8056)
static void C_fcall trf_8056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8056(t0,t1);}

C_noret_decl(trf_7906)
static void C_fcall trf_7906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7906(t0,t1);}

C_noret_decl(trf_7927)
static void C_fcall trf_7927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7927(t0,t1);}

C_noret_decl(trf_7948)
static void C_fcall trf_7948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7948(t0,t1);}

C_noret_decl(trf_7887)
static void C_fcall trf_7887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7887(t0,t1);}

C_noret_decl(trf_7843)
static void C_fcall trf_7843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7843(t0,t1);}

C_noret_decl(trf_7798)
static void C_fcall trf_7798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7798(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7798(t0,t1,t2,t3);}

C_noret_decl(trf_7784)
static void C_fcall trf_7784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7784(t0,t1,t2,t3);}

C_noret_decl(trf_7663)
static void C_fcall trf_7663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7663(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7663(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7082)
static void C_fcall trf_7082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7082(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7082(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7104)
static void C_fcall trf_7104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7104(t0,t1);}

C_noret_decl(trf_7540)
static void C_fcall trf_7540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7540(t0,t1);}

C_noret_decl(trf_7555)
static void C_fcall trf_7555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7555(t0,t1);}

C_noret_decl(trf_7546)
static void C_fcall trf_7546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7546(t0,t1);}

C_noret_decl(trf_7420)
static void C_fcall trf_7420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7420(t0,t1);}

C_noret_decl(trf_7453)
static void C_fcall trf_7453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7453(t0,t1);}

C_noret_decl(trf_7423)
static void C_fcall trf_7423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7423(t0,t1);}

C_noret_decl(trf_7295)
static void C_fcall trf_7295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7295(t0,t1,t2,t3);}

C_noret_decl(trf_7675)
static void C_fcall trf_7675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7675(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7675(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7688)
static void C_fcall trf_7688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7688(t0,t1);}

C_noret_decl(trf_7697)
static void C_fcall trf_7697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7697(t0,t1);}

C_noret_decl(trf_7778)
static void C_fcall trf_7778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7778(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7778(t0,t1,t2,t3);}

C_noret_decl(trf_6854)
static void C_fcall trf_6854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6854(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6854(t0,t1,t2,t3);}

C_noret_decl(trf_6860)
static void C_fcall trf_6860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6860(t0,t1,t2,t3);}

C_noret_decl(trf_6838)
static void C_fcall trf_6838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6838(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6838(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6713)
static void C_fcall trf_6713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6713(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6713(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6339)
static void C_fcall trf_6339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6339(t0,t1,t2,t3);}

C_noret_decl(trf_6361)
static void C_fcall trf_6361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6361(t0,t1);}

C_noret_decl(trf_6627)
static void C_fcall trf_6627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6627(t0,t1);}

C_noret_decl(trf_6467)
static void C_fcall trf_6467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6467(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6467(t0,t1,t2,t3);}

C_noret_decl(trf_6295)
static void C_fcall trf_6295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6295(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6295(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6234)
static void C_fcall trf_6234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6234(t0,t1,t2);}

C_noret_decl(trf_6205)
static void C_fcall trf_6205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6205(t0,t1,t2);}

C_noret_decl(trf_6211)
static void C_fcall trf_6211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6211(t0,t1,t2);}

C_noret_decl(trf_6125)
static void C_fcall trf_6125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6125(t0,t1);}

C_noret_decl(trf_6128)
static void C_fcall trf_6128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6128(t0,t1);}

C_noret_decl(trf_6131)
static void C_fcall trf_6131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6131(t0,t1);}

C_noret_decl(trf_5829)
static void C_fcall trf_5829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5829(t0,t1);}

C_noret_decl(trf_4756)
static void C_fcall trf_4756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4756(t0,t1);}

C_noret_decl(trf_5430)
static void C_fcall trf_5430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5430(t0,t1);}

C_noret_decl(trf_5124)
static void C_fcall trf_5124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5124(t0,t1);}

C_noret_decl(trf_4841)
static void C_fcall trf_4841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4841(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4705(t0,t1,t2,t3);}

C_noret_decl(trf_4718)
static void C_fcall trf_4718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4718(t0,t1);}

C_noret_decl(trf_4647)
static void C_fcall trf_4647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4647(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4647(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2120(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4523)
static void C_fcall trf_4523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4523(t0,t1);}

C_noret_decl(trf_4544)
static void C_fcall trf_4544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4544(t0,t1);}

C_noret_decl(trf_2345)
static void C_fcall trf_2345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2345(t0,t1);}

C_noret_decl(trf_4281)
static void C_fcall trf_4281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4281(t0,t1);}

C_noret_decl(trf_4230)
static void C_fcall trf_4230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4230(t0,t1);}

C_noret_decl(trf_4180)
static void C_fcall trf_4180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4180(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4180(t0,t1,t2,t3);}

C_noret_decl(trf_4024)
static void C_fcall trf_4024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4024(t0,t1);}

C_noret_decl(trf_3581)
static void C_fcall trf_3581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3581(t0,t1);}

C_noret_decl(trf_3478)
static void C_fcall trf_3478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3478(t0,t1);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3210(t0,t1,t2);}

C_noret_decl(trf_3006)
static void C_fcall trf_3006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3006(t0,t1);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2775(t0,t1);}

C_noret_decl(trf_2625)
static void C_fcall trf_2625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2625(t0,t1);}

C_noret_decl(trf_2645)
static void C_fcall trf_2645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2645(t0,t1);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2678(t0,t1);}

C_noret_decl(trf_2635)
static void C_fcall trf_2635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2635(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2635(t0,t1,t2);}

C_noret_decl(trf_2392)
static void C_fcall trf_2392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2392(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2392(t0,t1,t2);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2440(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2029(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1994)
static void C_fcall trf_1994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1994(t0,t1);}

C_noret_decl(trf_1963)
static void C_fcall trf_1963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1963(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5582)){
C_save(t1);
C_rereclaim2(5582*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,577);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],28,"\010compilerinitialize-compiler");
lf[94]=C_h_intern(&lf[94],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],11,"make-vector");
lf[96]=C_h_intern(&lf[96],25,"\010compilermake-random-name");
lf[97]=C_h_intern(&lf[97],12,"profile-info");
lf[98]=C_h_intern(&lf[98],32,"\010compilercanonicalize-expression");
lf[99]=C_h_intern(&lf[99],23,"\010compilerset-real-name!");
lf[100]=C_h_intern(&lf[100],8,"for-each");
lf[101]=C_h_intern(&lf[101],5,"quote");
lf[102]=C_h_intern(&lf[102],15,"\004coreinline_ref");
lf[103]=C_h_intern(&lf[103],36,"\010compilerforeign-type-convert-result");
lf[104]=C_h_intern(&lf[104],30,"\010compilerfinish-foreign-result");
lf[105]=C_h_intern(&lf[105],27,"\010compilerfinal-foreign-type");
lf[106]=C_h_intern(&lf[106],19,"\004coreinline_loc_ref");
lf[107]=C_h_intern(&lf[107],18,"\003syshash-table-ref");
lf[108]=C_h_intern(&lf[108],21,"\003sysalias-global-hook");
lf[109]=C_h_intern(&lf[109],12,"syntax-error");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[111]=C_h_intern(&lf[111],24,"\003syssyntax-error-culprit");
lf[112]=C_h_intern(&lf[112],2,"if");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[114]=C_h_intern(&lf[114],16,"\003syscheck-syntax");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[117]=C_h_intern(&lf[117],10,"\004corecheck");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[119]=C_h_intern(&lf[119],14,"\004coreimmutable");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],6,"gensym");
lf[122]=C_h_intern(&lf[122],1,"c");
lf[123]=C_h_intern(&lf[123],6,"cadadr");
lf[124]=C_h_intern(&lf[124],14,"\004coreundefined");
lf[125]=C_h_intern(&lf[125],23,"\004corerequire-for-syntax");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[127]=C_h_intern(&lf[127],10,"lset-union");
lf[128]=C_h_intern(&lf[128],3,"eq\077");
lf[129]=C_h_intern(&lf[129],22,"\003syshash-table-update!");
lf[130]=C_h_intern(&lf[130],19,"syntax-requirements");
lf[131]=C_h_intern(&lf[131],11,"\003sysrequire");
lf[132]=C_h_intern(&lf[132],7,"\003sysmap");
lf[133]=C_h_intern(&lf[133],4,"eval");
lf[134]=C_h_intern(&lf[134],22,"\004corerequire-extension");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[136]=C_h_intern(&lf[136],22,"\003sysdo-the-right-thing");
lf[137]=C_h_intern(&lf[137],5,"begin");
lf[138]=C_h_intern(&lf[138],28,"\010compilerlookup-exports-file");
lf[139]=C_h_intern(&lf[139],7,"exports");
lf[140]=C_h_intern(&lf[140],19,"\003syshash-table-set!");
lf[141]=C_h_intern(&lf[141],12,"\003sysfor-each");
lf[142]=C_h_intern(&lf[142],25,"\003sysextension-information");
lf[143]=C_h_intern(&lf[143],25,"\010compilercompiler-warning");
lf[144]=C_h_intern(&lf[144],3,"ext");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[146]=C_h_intern(&lf[146],18,"\003sysfind-extension");
lf[147]=C_h_intern(&lf[147],31,"\003syscanonicalize-extension-path");
lf[148]=C_h_intern(&lf[148],17,"require-extension");
lf[149]=C_h_intern(&lf[149],8,"feature\077");
lf[150]=C_h_intern(&lf[150],5,"cadar");
lf[151]=C_h_intern(&lf[151],3,"let");
lf[152]=C_h_intern(&lf[152],21,"\003syscanonicalize-body");
lf[153]=C_h_intern(&lf[153],3,"map");
lf[154]=C_h_intern(&lf[154],6,"append");
lf[155]=C_h_intern(&lf[155],4,"cons");
lf[156]=C_h_intern(&lf[156],6,"unzip1");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[158]=C_h_intern(&lf[158],6,"lambda");
lf[159]=C_h_intern(&lf[159],20,"\004coreinternal-lambda");
lf[160]=C_h_intern(&lf[160],30,"\010compilerexpand-profile-lambda");
lf[161]=C_h_intern(&lf[161],37,"\010compilerprocess-lambda-documentation");
lf[162]=C_h_intern(&lf[162],6,"cddadr");
lf[163]=C_h_intern(&lf[163],5,"cdadr");
lf[164]=C_h_intern(&lf[164],5,"caadr");
lf[165]=C_h_intern(&lf[165],26,"\010compilerbuild-lambda-list");
lf[166]=C_h_intern(&lf[166],13,"\010compilerposq");
lf[167]=C_h_intern(&lf[167],30,"\010compilerdecompose-lambda-list");
lf[168]=C_h_intern(&lf[168],31,"\003sysexpand-extended-lambda-list");
lf[169]=C_h_intern(&lf[169],9,"\003syserror");
lf[170]=C_h_intern(&lf[170],25,"\003sysextended-lambda-list\077");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[172]=C_h_intern(&lf[172],17,"\004corenamed-lambda");
lf[173]=C_h_intern(&lf[173],16,"\004coreloop-lambda");
lf[174]=C_h_intern(&lf[174],4,"set!");
lf[175]=C_h_intern(&lf[175],9,"\004coreset!");
lf[176]=C_h_intern(&lf[176],18,"\004coreinline_update");
lf[177]=C_h_intern(&lf[177],27,"\010compilerforeign-type-check");
lf[178]=C_h_intern(&lf[178],38,"\010compilerforeign-type-convert-argument");
lf[179]=C_h_intern(&lf[179],22,"\004coreinline_loc_update");
lf[180]=C_h_intern(&lf[180],6,"syntax");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[182]=C_h_intern(&lf[182],8,"keyword\077");
lf[183]=C_h_intern(&lf[183],15,"undefine-macro!");
lf[184]=C_h_intern(&lf[184],3,"var");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[186]=C_h_intern(&lf[186],7,"sprintf");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[189]=C_h_intern(&lf[189],6,"macro\077");
lf[190]=C_h_intern(&lf[190],11,"lset-adjoin");
lf[191]=C_h_intern(&lf[191],17,"\010compilerget-line");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[193]=C_h_intern(&lf[193],11,"\004coreinline");
lf[194]=C_h_intern(&lf[194],20,"\004coreinline_allocate");
lf[195]=C_h_intern(&lf[195],19,"\004corecompiletimetoo");
lf[196]=C_h_intern(&lf[196],23,"\004coreelaborationtimetoo");
lf[197]=C_h_intern(&lf[197],20,"\004corecompiletimeonly");
lf[198]=C_h_intern(&lf[198],24,"\004coreelaborationtimeonly");
lf[199]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[200]=C_h_intern(&lf[200],32,"\010compilercanonicalize-begin-body");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[203]=C_h_intern(&lf[203],19,"\004coreforeign-lambda");
lf[204]=C_h_intern(&lf[204],30,"\010compilerexpand-foreign-lambda");
lf[205]=C_h_intern(&lf[205],28,"\004coreforeign-callback-lambda");
lf[206]=C_h_intern(&lf[206],39,"\010compilerexpand-foreign-callback-lambda");
lf[207]=C_h_intern(&lf[207],20,"\004coreforeign-lambda*");
lf[208]=C_h_intern(&lf[208],31,"\010compilerexpand-foreign-lambda*");
lf[209]=C_h_intern(&lf[209],29,"\004coreforeign-callback-lambda*");
lf[210]=C_h_intern(&lf[210],40,"\010compilerexpand-foreign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],22,"\004coreforeign-primitive");
lf[212]=C_h_intern(&lf[212],33,"\010compilerexpand-foreign-primitive");
lf[213]=C_h_intern(&lf[213],28,"\004coredefine-foreign-variable");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[215]=C_h_intern(&lf[215],14,"symbol->string");
lf[216]=C_h_intern(&lf[216],24,"\004coredefine-foreign-type");
lf[217]=C_h_intern(&lf[217],10,"\003sysvalues");
lf[218]=C_h_intern(&lf[218],5,"cons*");
lf[219]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[220]=C_h_intern(&lf[220],29,"\004coredefine-external-variable");
lf[221]=C_h_intern(&lf[221],9,"c-pointer");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[223]=C_h_intern(&lf[223],13,"string-append");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[225]=C_h_intern(&lf[225],5,"fifth");
lf[226]=C_h_intern(&lf[226],17,"\004corelet-location");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[228]=C_h_intern(&lf[228],10,"\003sysappend");
lf[229]=C_h_intern(&lf[229],14,"\010compilerwords");
lf[230]=C_h_intern(&lf[230],46,"\010compilerestimate-foreign-result-location-size");
lf[231]=C_h_intern(&lf[231],18,"\004coredefine-inline");
lf[232]=C_h_intern(&lf[232],34,"\010compilerextract-mutable-constants");
lf[233]=C_h_intern(&lf[233],20,"\004coredefine-constant");
lf[234]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[236]=C_h_intern(&lf[236],29,"\010compilercollapsable-literal\077");
lf[237]=C_h_intern(&lf[237],4,"quit");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[239]=C_h_intern(&lf[239],22,"with-exception-handler");
lf[240]=C_h_intern(&lf[240],30,"call-with-current-continuation");
lf[241]=C_h_intern(&lf[241],12,"\004coredeclare");
lf[242]=C_h_intern(&lf[242],28,"\010compilerprocess-declaration");
lf[243]=C_h_intern(&lf[243],29,"\004coreforeign-callback-wrapper");
lf[244]=C_h_intern(&lf[244],8,"split-at");
lf[245]=C_h_intern(&lf[245],1,"r");
lf[246]=C_h_intern(&lf[246],17,"\003sysmake-c-string");
lf[247]=C_h_intern(&lf[247],3,"and");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[251]=C_h_intern(&lf[251],25,"nonnull-unsigned-c-string");
lf[252]=C_h_intern(&lf[252],16,"nonnull-c-string");
lf[253]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[255]=C_h_intern(&lf[255],18,"unsigned-c-string*");
lf[256]=C_h_intern(&lf[256],9,"c-string*");
lf[257]=C_h_intern(&lf[257],13,"c-string-list");
lf[258]=C_h_intern(&lf[258],14,"c-string-list*");
lf[259]=C_h_intern(&lf[259],8,"c-string");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[261]=C_h_intern(&lf[261],17,"unsigned-c-string");
lf[262]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[265]=C_h_intern(&lf[265],28,"\010compilervalid-c-identifier\077");
lf[266]=C_h_intern(&lf[266],8,"location");
lf[267]=C_h_intern(&lf[267],17,"\003sysmake-locative");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[269]=C_h_intern(&lf[269],13,"\004corecallunit");
lf[270]=C_h_intern(&lf[270],14,"\004coreprimitive");
lf[271]=C_h_intern(&lf[271],37,"\010compilerupdate-line-number-database!");
lf[272]=C_h_intern(&lf[272],23,"\003sysmacroexpand-1-local");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[275]=C_h_intern(&lf[275],31,"\010compileremit-syntax-trace-info");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[277]=C_h_intern(&lf[277],4,"list");
lf[278]=C_h_intern(&lf[278],1,"t");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[280]=C_h_intern(&lf[280],4,"caar");
lf[281]=C_h_intern(&lf[281],18,"\010compilerconstant\077");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[283]=C_h_intern(&lf[283],26,"\010compilerinternal-bindings");
lf[284]=C_h_intern(&lf[284],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[285]=C_h_intern(&lf[285],7,"reverse");
lf[286]=C_h_intern(&lf[286],22,"\003sysclear-trace-buffer");
lf[287]=C_h_intern(&lf[287],26,"\010compilerdebugging-chicken");
lf[288]=C_h_intern(&lf[288],12,"pretty-print");
lf[289]=C_h_intern(&lf[289],7,"newline");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[292]=C_h_intern(&lf[292],4,"uses");
lf[293]=C_h_intern(&lf[293],29,"\010compilerstring->c-identifier");
lf[294]=C_h_intern(&lf[294],18,"\010compilerstringify");
lf[295]=C_h_intern(&lf[295],17,"register-feature!");
lf[296]=C_h_intern(&lf[296],4,"unit");
lf[297]=C_h_intern(&lf[297],5,"usage");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[299]=C_h_intern(&lf[299],34,"\010compilerdefault-standard-bindings");
lf[300]=C_h_intern(&lf[300],34,"\010compilerdefault-extended-bindings");
lf[301]=C_h_intern(&lf[301],18,"usual-integrations");
lf[302]=C_h_intern(&lf[302],17,"lset-intersection");
lf[303]=C_h_intern(&lf[303],6,"fixnum");
lf[304]=C_h_intern(&lf[304],17,"fixnum-arithmetic");
lf[305]=C_h_intern(&lf[305],23,"\005matchset-error-control");
lf[306]=C_h_intern(&lf[306],12,"\000unspecified");
lf[307]=C_h_intern(&lf[307],4,"safe");
lf[308]=C_h_intern(&lf[308],18,"interrupts-enabled");
lf[309]=C_h_intern(&lf[309],18,"disable-interrupts");
lf[310]=C_h_intern(&lf[310],15,"disable-warning");
lf[311]=C_h_intern(&lf[311],26,"\010compilerdisabled-warnings");
lf[312]=C_h_intern(&lf[312],12,"safe-globals");
lf[313]=C_h_intern(&lf[313],38,"no-procedure-checks-for-usual-bindings");
lf[314]=C_h_intern(&lf[314],18,"bound-to-procedure");
lf[315]=C_h_intern(&lf[315],15,"foreign-declare");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[317]=C_h_intern(&lf[317],5,"every");
lf[318]=C_h_intern(&lf[318],7,"string\077");
lf[319]=C_h_intern(&lf[319],14,"custom-declare");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[321]=C_h_intern(&lf[321],35,"\010compilerprocess-custom-declaration");
lf[322]=C_h_intern(&lf[322],9,"c-options");
lf[323]=C_h_intern(&lf[323],31,"\010compileremit-control-file-item");
lf[324]=C_h_intern(&lf[324],12,"link-options");
lf[325]=C_h_intern(&lf[325],12,"post-process");
lf[326]=C_h_intern(&lf[326],17,"string-substitute");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[328]=C_h_intern(&lf[328],24,"pathname-strip-extension");
lf[329]=C_h_intern(&lf[329],5,"block");
lf[330]=C_h_intern(&lf[330],8,"separate");
lf[331]=C_h_intern(&lf[331],20,"keep-shadowed-macros");
lf[332]=C_h_intern(&lf[332],6,"unused");
lf[333]=C_h_intern(&lf[333],3,"not");
lf[334]=C_h_intern(&lf[334],15,"lset-difference");
lf[335]=C_h_intern(&lf[335],6,"inline");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[337]=C_h_intern(&lf[337],15,"run-time-macros");
lf[338]=C_h_intern(&lf[338],25,"\003sysenable-runtime-macros");
lf[339]=C_h_intern(&lf[339],12,"block-global");
lf[340]=C_h_intern(&lf[340],4,"hide");
lf[341]=C_h_intern(&lf[341],6,"export");
lf[342]=C_h_intern(&lf[342],12,"emit-exports");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[344]=C_h_intern(&lf[344],30,"emit-external-prototypes-first");
lf[345]=C_h_intern(&lf[345],11,"lambda-lift");
lf[346]=C_h_intern(&lf[346],12,"inline-limit");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[348]=C_h_intern(&lf[348],8,"constant");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[350]=C_h_intern(&lf[350],7,"symbol\077");
lf[351]=C_h_intern(&lf[351],6,"import");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[353]=C_h_intern(&lf[353],9,"partition");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[357]=C_h_intern(&lf[357],17,"make-foreign-stub");
lf[358]=C_h_intern(&lf[358],12,"foreign-stub");
lf[359]=C_h_intern(&lf[359],13,"foreign-stub\077");
lf[360]=C_h_intern(&lf[360],20,"foreign-stub-id-set!");
lf[361]=C_h_intern(&lf[361],14,"\003sysblock-set!");
lf[362]=C_h_intern(&lf[362],15,"foreign-stub-id");
lf[363]=C_h_intern(&lf[363],29,"foreign-stub-return-type-set!");
lf[364]=C_h_intern(&lf[364],24,"foreign-stub-return-type");
lf[365]=C_h_intern(&lf[365],22,"foreign-stub-name-set!");
lf[366]=C_h_intern(&lf[366],17,"foreign-stub-name");
lf[367]=C_h_intern(&lf[367],32,"foreign-stub-argument-types-set!");
lf[368]=C_h_intern(&lf[368],27,"foreign-stub-argument-types");
lf[369]=C_h_intern(&lf[369],32,"foreign-stub-argument-names-set!");
lf[370]=C_h_intern(&lf[370],27,"foreign-stub-argument-names");
lf[371]=C_h_intern(&lf[371],22,"foreign-stub-body-set!");
lf[372]=C_h_intern(&lf[372],17,"foreign-stub-body");
lf[373]=C_h_intern(&lf[373],21,"foreign-stub-cps-set!");
lf[374]=C_h_intern(&lf[374],16,"foreign-stub-cps");
lf[375]=C_h_intern(&lf[375],26,"foreign-stub-callback-set!");
lf[376]=C_h_intern(&lf[376],21,"foreign-stub-callback");
lf[377]=C_h_intern(&lf[377],28,"\010compilercreate-foreign-stub");
lf[378]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[381]=C_h_intern(&lf[381],37,"\010compilerestimate-foreign-result-size");
lf[382]=C_h_intern(&lf[382],4,"stub");
lf[383]=C_h_intern(&lf[383],1,"a");
lf[384]=C_h_intern(&lf[384],13,"list-tabulate");
lf[385]=C_h_intern(&lf[385],6,"second");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[388]=C_h_intern(&lf[388],4,"cadr");
lf[389]=C_h_intern(&lf[389],3,"car");
lf[390]=C_h_intern(&lf[390],4,"void");
lf[391]=C_h_intern(&lf[391],24,"\003sysline-number-database");
lf[392]=C_h_intern(&lf[392],31,"\010compilerperform-cps-conversion");
lf[393]=C_h_intern(&lf[393],4,"node");
lf[394]=C_h_intern(&lf[394],11,"\004corelambda");
lf[395]=C_h_intern(&lf[395],9,"\004corecall");
lf[396]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[397]=C_h_intern(&lf[397],16,"\010compilervarnode");
lf[398]=C_h_intern(&lf[398],1,"k");
lf[399]=C_h_intern(&lf[399],13,"\004corevariable");
lf[400]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[401]=C_h_intern(&lf[401],2,"f_");
lf[402]=C_h_intern(&lf[402],26,"make-foreign-callback-stub");
lf[403]=C_h_intern(&lf[403],13,"\010compilerbomb");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[405]=C_h_intern(&lf[405],15,"\004coreglobal-ref");
lf[406]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[407]=C_h_intern(&lf[407],6,"values");
lf[408]=C_h_intern(&lf[408],21,"foreign-callback-stub");
lf[409]=C_h_intern(&lf[409],22,"foreign-callback-stub\077");
lf[410]=C_h_intern(&lf[410],29,"foreign-callback-stub-id-set!");
lf[411]=C_h_intern(&lf[411],24,"foreign-callback-stub-id");
lf[412]=C_h_intern(&lf[412],31,"foreign-callback-stub-name-set!");
lf[413]=C_h_intern(&lf[413],26,"foreign-callback-stub-name");
lf[414]=C_h_intern(&lf[414],37,"foreign-callback-stub-qualifiers-set!");
lf[415]=C_h_intern(&lf[415],32,"foreign-callback-stub-qualifiers");
lf[416]=C_h_intern(&lf[416],38,"foreign-callback-stub-return-type-set!");
lf[417]=C_h_intern(&lf[417],33,"foreign-callback-stub-return-type");
lf[418]=C_h_intern(&lf[418],41,"foreign-callback-stub-argument-types-set!");
lf[419]=C_h_intern(&lf[419],36,"foreign-callback-stub-argument-types");
lf[420]=C_h_intern(&lf[420],27,"\010compileranalyze-expression");
lf[421]=C_h_intern(&lf[421],17,"\010compilercollect!");
lf[422]=C_h_intern(&lf[422],10,"references");
lf[423]=C_h_intern(&lf[423],13,"\010compilerput!");
lf[424]=C_h_intern(&lf[424],9,"undefined");
lf[425]=C_h_intern(&lf[425],7,"unknown");
lf[426]=C_h_intern(&lf[426],5,"value");
lf[427]=C_h_intern(&lf[427],12,"\010compilerget");
lf[428]=C_h_intern(&lf[428],4,"home");
lf[429]=C_h_intern(&lf[429],16,"\010compilerget-all");
lf[430]=C_h_intern(&lf[430],8,"captured");
lf[431]=C_h_intern(&lf[431],6,"global");
lf[432]=C_h_intern(&lf[432],12,"\004corerecurse");
lf[433]=C_h_intern(&lf[433],44,"\010compileroptimizable-rest-argument-operators");
lf[434]=C_h_intern(&lf[434],15,"\010compilercount!");
lf[435]=C_h_intern(&lf[435],16,"o-r/access-count");
lf[436]=C_h_intern(&lf[436],14,"rest-parameter");
lf[437]=C_h_intern(&lf[437],16,"standard-binding");
lf[438]=C_h_intern(&lf[438],10,"call-sites");
lf[439]=C_h_intern(&lf[439],18,"\004coredirect_lambda");
lf[440]=C_h_intern(&lf[440],6,"simple");
lf[441]=C_h_intern(&lf[441],28,"\010compilersimple-lambda-node\077");
lf[442]=C_h_intern(&lf[442],6,"vector");
lf[443]=C_h_intern(&lf[443],12,"contained-in");
lf[444]=C_h_intern(&lf[444],8,"contains");
lf[445]=C_h_intern(&lf[445],8,"assigned");
lf[446]=C_h_intern(&lf[446],16,"assigned-locally");
lf[447]=C_h_intern(&lf[447],15,"potential-value");
lf[448]=C_h_intern(&lf[448],5,"redef");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[451]=C_h_intern(&lf[451],16,"extended-binding");
lf[452]=C_h_intern(&lf[452],9,"\004coreproc");
lf[453]=C_h_intern(&lf[453],3,"any");
lf[454]=C_h_intern(&lf[454],9,"replacing");
lf[455]=C_h_intern(&lf[455],10,"replacable");
lf[456]=C_h_intern(&lf[456],9,"removable");
lf[457]=C_h_intern(&lf[457],37,"\010compilerexpression-has-side-effects\077");
lf[458]=C_h_intern(&lf[458],21,"has-unused-parameters");
lf[459]=C_h_intern(&lf[459],13,"explicit-rest");
lf[460]=C_h_intern(&lf[460],11,"collapsable");
lf[461]=C_h_intern(&lf[461],12,"contractable");
lf[462]=C_h_intern(&lf[462],9,"inlinable");
lf[463]=C_h_intern(&lf[463],28,"\010compilerscan-free-variables");
lf[464]=C_h_intern(&lf[464],5,"boxed");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[467]=C_h_intern(&lf[467],23,"\003syshash-table-for-each");
lf[468]=C_h_intern(&lf[468],18,"\010compilerdebugging");
lf[469]=C_h_intern(&lf[469],1,"p");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[472]=C_h_intern(&lf[472],37,"\010compilerinitialize-analysis-database");
lf[473]=C_h_intern(&lf[473],35,"\010compilerperform-closure-conversion");
lf[474]=C_h_intern(&lf[474],12,"customizable");
lf[475]=C_h_intern(&lf[475],20,"node-parameters-set!");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[477]=C_h_intern(&lf[477],28,"\010compilersource-info->string");
lf[478]=C_h_intern(&lf[478],8,"toplevel");
lf[479]=C_h_intern(&lf[479],18,"captured-variables");
lf[480]=C_h_intern(&lf[480],12,"closure-size");
lf[481]=C_h_intern(&lf[481],8,"\004coreref");
lf[482]=C_h_intern(&lf[482],10,"\004coreunbox");
lf[483]=C_h_intern(&lf[483],8,"\004corebox");
lf[484]=C_h_intern(&lf[484],12,"\004coreclosure");
lf[485]=C_h_intern(&lf[485],14,"\010compilerqnode");
lf[486]=C_h_intern(&lf[486],20,"\003sysmake-lambda-info");
lf[487]=C_h_intern(&lf[487],1,"\077");
lf[488]=C_h_intern(&lf[488],8,"->string");
lf[489]=C_h_intern(&lf[489],18,"\010compilerreal-name");
lf[490]=C_h_intern(&lf[490],10,"fold-right");
lf[491]=C_h_intern(&lf[491],10,"boxed-rest");
lf[492]=C_h_intern(&lf[492],6,"filter");
lf[493]=C_h_intern(&lf[493],16,"\004coreupdatebox_i");
lf[494]=C_h_intern(&lf[494],14,"\004coreupdatebox");
lf[495]=C_h_intern(&lf[495],13,"\004coreupdate_i");
lf[496]=C_h_intern(&lf[496],11,"\004coreupdate");
lf[497]=C_h_intern(&lf[497],19,"\010compilerimmediate\077");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[499]=C_h_intern(&lf[499],11,"\004coreswitch");
lf[500]=C_h_intern(&lf[500],9,"\004corecond");
lf[501]=C_h_intern(&lf[501],16,"\004coredirect_call");
lf[502]=C_h_intern(&lf[502],11,"\004corereturn");
lf[503]=C_h_intern(&lf[503],1,"o");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[505]=C_h_intern(&lf[505],16,"\003sysmake-promise");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[509]=C_h_intern(&lf[509],19,"make-lambda-literal");
lf[510]=C_h_intern(&lf[510],14,"lambda-literal");
lf[511]=C_h_intern(&lf[511],15,"lambda-literal\077");
lf[512]=C_h_intern(&lf[512],22,"lambda-literal-id-set!");
lf[513]=C_h_intern(&lf[513],17,"lambda-literal-id");
lf[514]=C_h_intern(&lf[514],28,"lambda-literal-external-set!");
lf[515]=C_h_intern(&lf[515],23,"lambda-literal-external");
lf[516]=C_h_intern(&lf[516],29,"lambda-literal-arguments-set!");
lf[517]=C_h_intern(&lf[517],24,"lambda-literal-arguments");
lf[518]=C_h_intern(&lf[518],34,"lambda-literal-argument-count-set!");
lf[519]=C_h_intern(&lf[519],29,"lambda-literal-argument-count");
lf[520]=C_h_intern(&lf[520],33,"lambda-literal-rest-argument-set!");
lf[521]=C_h_intern(&lf[521],28,"lambda-literal-rest-argument");
lf[522]=C_h_intern(&lf[522],31,"lambda-literal-temporaries-set!");
lf[523]=C_h_intern(&lf[523],26,"lambda-literal-temporaries");
lf[524]=C_h_intern(&lf[524],37,"lambda-literal-callee-signatures-set!");
lf[525]=C_h_intern(&lf[525],32,"lambda-literal-callee-signatures");
lf[526]=C_h_intern(&lf[526],29,"lambda-literal-allocated-set!");
lf[527]=C_h_intern(&lf[527],24,"lambda-literal-allocated");
lf[528]=C_h_intern(&lf[528],35,"lambda-literal-directly-called-set!");
lf[529]=C_h_intern(&lf[529],30,"lambda-literal-directly-called");
lf[530]=C_h_intern(&lf[530],32,"lambda-literal-closure-size-set!");
lf[531]=C_h_intern(&lf[531],27,"lambda-literal-closure-size");
lf[532]=C_h_intern(&lf[532],27,"lambda-literal-looping-set!");
lf[533]=C_h_intern(&lf[533],22,"lambda-literal-looping");
lf[534]=C_h_intern(&lf[534],32,"lambda-literal-customizable-set!");
lf[535]=C_h_intern(&lf[535],27,"lambda-literal-customizable");
lf[536]=C_h_intern(&lf[536],38,"lambda-literal-rest-argument-mode-set!");
lf[537]=C_h_intern(&lf[537],33,"lambda-literal-rest-argument-mode");
lf[538]=C_h_intern(&lf[538],24,"lambda-literal-body-set!");
lf[539]=C_h_intern(&lf[539],19,"lambda-literal-body");
lf[540]=C_h_intern(&lf[540],26,"lambda-literal-direct-set!");
lf[541]=C_h_intern(&lf[541],21,"lambda-literal-direct");
lf[542]=C_h_intern(&lf[542],36,"\010compilerprepare-for-code-generation");
lf[543]=C_h_intern(&lf[543],14,"\004coreimmediate");
lf[544]=C_h_intern(&lf[544],3,"fix");
lf[545]=C_h_intern(&lf[545],4,"bool");
lf[546]=C_h_intern(&lf[546],4,"char");
lf[547]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[548]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[550]=C_h_intern(&lf[550],36,"\010compilermake-block-variable-literal");
lf[551]=C_h_intern(&lf[551],36,"\010compilerblock-variable-literal-name");
lf[552]=C_h_intern(&lf[552],32,"\010compilerblock-variable-literal\077");
lf[553]=C_h_intern(&lf[553],10,"list-index");
lf[554]=C_h_intern(&lf[554],11,"\004coreglobal");
lf[555]=C_h_intern(&lf[555],10,"\004corelocal");
lf[556]=C_h_intern(&lf[556],12,"\004coreliteral");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[559]=C_h_intern(&lf[559],4,"none");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[562]=C_h_intern(&lf[562],7,"butlast");
lf[563]=C_h_intern(&lf[563],9,"\004corebind");
lf[564]=C_h_intern(&lf[564],13,"\004coresetlocal");
lf[565]=C_h_intern(&lf[565],16,"\004coresetglobal_i");
lf[566]=C_h_intern(&lf[566],14,"\004coresetglobal");
lf[567]=C_h_intern(&lf[567],1,"=");
lf[568]=C_h_intern(&lf[568],4,"type");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[571]=C_h_intern(&lf[571],20,"\010compilerbig-fixnum\077");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[576]=C_h_intern(&lf[576],14,"make-parameter");
C_register_lf2(lf,577,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1757 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1760 in k1757 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1763 in k1760 in k1757 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 311  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1877,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1948,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4702,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[357]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5647,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[359]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5653,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5659,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5677,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5686,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5695,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5704,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5713,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5722,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5731,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5740,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5749,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5758,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5767,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5776,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5785,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5794,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5803,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[204]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5957,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6002,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6047,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6084,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6121,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6202,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[392]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6292,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[402]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6967,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[409]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6973,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[410]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6979,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6988,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6997,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7006,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7015,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7024,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7033,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7042,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7051,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7060,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7069,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[473]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8594,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[509]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9828,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[511]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9834,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9840,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9849,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9858,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9867,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9876,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9885,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9894,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9903,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9912,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9921,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9930,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9939,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9948,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9957,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9966,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9975,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9984,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9993,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10002,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10011,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10020,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10029,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10038,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10047,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10056,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10065,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10074,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10083,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10092,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10101,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10110,tmp=(C_word)a,a+=2,tmp));
t162=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t162+1)))(2,t162,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10110,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11105,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11059,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11073,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10979,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10147,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10113,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10200,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10967,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11167,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2307 debugging */
t37=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[469],lf[575]);}

/* k11165 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2308 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10200(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11168 in k11165 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2309 debugging */
t3=C_retrieve(lf[468]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[503],lf[574],((C_word*)((C_word*)t0)[2])[1]);}

/* k11171 in k11168 in k11165 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2310 debugging */
t3=C_retrieve(lf[468]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[503],lf[573],((C_word*)((C_word*)t0)[2])[1]);}

/* k11174 in k11171 in k11168 in k11165 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2311 debugging */
t3=C_retrieve(lf[468]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[503],lf[572],((C_word*)((C_word*)t0)[2])[1]);}

/* k11177 in k11174 in k11171 in k11168 in k11165 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2312 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10967(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10967,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10973,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a10972 in mapwalk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10973,3,t0,t1,t2);}
/* compiler.scm: 2265 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10200(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10200,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[124]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[452]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[399]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2099 walk-var */
t16=((C_word*)t0)[16];
f_10113(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[405]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2102 walk-global */
t17=((C_word*)t0)[15];
f_10147(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[501]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10258,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2106 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_10967(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[194]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10278,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2110 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_10967(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10302,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10306,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2113 estimate-foreign-result-size */
t22=C_retrieve(lf[381]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[106]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10330,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10334,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2117 estimate-foreign-result-size */
t23=C_retrieve(lf[381]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[484]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10351,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2122 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10967(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[483]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10378,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2126 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[494]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10394,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2130 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10967(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[394]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[439]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[439]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10450,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2150 decompose-lambda-list */
t36=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[151]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[483],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10634,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2207 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[174]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10675,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2213 posq */
t30=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[395]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10795,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2237 lset-adjoin */
t31=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[567]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[432]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10838,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10838(t32,t31);}
else{
t30=t29;
f_10838(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[101]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10866,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10953,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2248 big-fixnum? */
t33=C_retrieve(lf[571]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10866(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10956,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2262 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_10967(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10954 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10956,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10951 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10866(t2,(C_word)C_i_not(t1));}

/* k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10866,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2249 immediate-literal */
f_11105(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[303],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10914,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2252 big-fixnum? */
t5=C_retrieve(lf[571]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10887(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10924,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2258 literal */
t4=((C_word*)t0)[2];
f_10979(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2259 immediate? */
t3=C_retrieve(lf[497]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10928 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10930,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2259 immediate-literal */
f_11105(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10943,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2260 literal */
t3=((C_word*)t0)[2];
f_10979(t3,t2,((C_word*)t0)[3]);}}

/* k10941 in k10928 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10943,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[556],t2,C_SCHEME_END_OF_LIST));}

/* k10922 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10924,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[556],t2,C_SCHEME_END_OF_LIST));}

/* k10912 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10887(t2,(C_word)C_i_not(t1));}

/* k10885 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10887,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2253 compiler-warning */
t4=C_retrieve(lf[143]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[568],lf[569],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2257 quit */
t2=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[570],((C_word*)t0)[4]);}}

/* k10888 in k10885 in k10864 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2256 immediate-literal */
f_11105(((C_word*)t0)[2],t2);}

/* k10836 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10838,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10841,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2244 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10967(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10839 in k10836 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10793 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10795,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10807,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10807(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10807(t6,C_SCHEME_FALSE);}}

/* k10805 in k10793 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10798(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10798(t2,C_SCHEME_UNDEFINED);}}

/* k10796 in k10793 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10798,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10801,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2240 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10967(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10799 in k10796 in k10793 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10801,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10675,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10691,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2215 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10200(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10764,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10764(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10764(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10764(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10776,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2221 get */
t8=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[437]);}}}}}

/* k10774 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10764(2,t2,t1);}
else{
/* compiler.scm: 2222 get */
t2=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[451]);}}

/* k10762 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10764,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[101]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2224 immediate? */
t8=C_retrieve(lf[497]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10703(2,t6,C_SCHEME_FALSE);}}

/* k10701 in k10762 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10703,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[124],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10709(t6,t5);}
else{
t4=t3;
f_10709(t4,C_SCHEME_UNDEFINED);}}

/* k10707 in k10701 in k10762 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10709,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[565]:lf[566]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2230 blockvar-literal */
t4=((C_word*)t0)[4];
f_11073(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2231 literal */
t4=((C_word*)t0)[2];
f_10979(t4,t3,((C_word*)t0)[3]);}}

/* k10731 in k10707 in k10701 in k10762 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10733,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10725,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2233 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10200(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10723 in k10731 in k10707 in k10701 in k10762 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10725,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10689 in k10673 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10691,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[564],((C_word*)t0)[2],t2));}

/* k10632 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10638,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2208 append */
t5=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10644 in k10632 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10650,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2208 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10648 in k10644 in k10632 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2208 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10200(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10636 in k10632 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10638,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[563],((C_word*)t0)[2],t2));}

/* a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10450,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10571,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2156 get */
t8=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[422]);}
else{
t7=t6;
f_10457(2,t7,C_SCHEME_FALSE);}}

/* k10569 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10577,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2157 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[445]);}

/* k10575 in k10569 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10577,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10457(2,t2,lf[277]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10602,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2158 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[491]);}}

/* k10600 in k10575 in k10569 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10583(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10583(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10581 in k10575 in k10569 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10457(2,t2,lf[559]);}
else{
/* compiler.scm: 2159 get */
t2=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}}

/* k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10460,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10562,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[559],t1);
if(C_truep(t5)){
/* compiler.scm: 2163 butlast */
t6=C_retrieve(lf[562]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10562(2,t6,((C_word*)t0)[7]);}}

/* k10560 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2160 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10200(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10463,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[559]);
if(C_truep(t3)){
/* compiler.scm: 2168 debugging */
t4=C_retrieve(lf[468]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[503],lf[560],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[442]);
if(C_truep(t4)){
/* compiler.scm: 2169 debugging */
t5=C_retrieve(lf[468]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[503],lf[561],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10463(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2171 bomb */
t4=C_retrieve(lf[403]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[558],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10466(2,t4,C_SCHEME_UNDEFINED);}}

/* k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10488,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10504,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2183 get */
t7=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[480]);}

/* k10502 in k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10504,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10511(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10530,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2187 debugging */
t7=C_retrieve(lf[468]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[503],lf[557],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10511(t6,C_SCHEME_FALSE);}}}

/* k10528 in k10502 in k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10511(t2,C_SCHEME_TRUE);}

/* k10509 in k10502 in k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10511,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10515(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2189 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[474]);}}

/* k10513 in k10509 in k10502 in k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2173 make-lambda-literal */
t2=C_retrieve(lf[509]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10486 in k10464 in k10461 in k10458 in k10455 in a10449 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[393],lf[452],t9,C_SCHEME_END_OF_LIST));}

/* k10392 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10397,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10403,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[399],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10403(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10403(t6,C_SCHEME_FALSE);}}

/* k10401 in k10392 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10397(t4,lf[493]);}
else{
t2=((C_word*)t0)[3];
f_10397(t2,((C_word*)t0)[2]);}}

/* k10395 in k10392 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10397,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10376 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[483],((C_word*)t0)[2],t2));}

/* k10349 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10351,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],lf[484],((C_word*)t0)[2],t1));}

/* k10332 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2117 words */
t2=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10328 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10330,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10323,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2118 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_10967(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10321 in k10328 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10304 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2113 words */
t2=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10300 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10302,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10276 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10278,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10256 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10258,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10113,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10117,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2067 posq */
t6=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10115 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10117,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[555],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2068 keyword? */
t3=C_retrieve(lf[182]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10130 in k10115 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10132,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10142,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2068 literal */
t3=((C_word*)t0)[5];
f_10979(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2069 walk-global */
t2=((C_word*)t0)[3];
f_10147(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10140 in k10130 in k10115 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[556],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10147,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10151(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10151(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10151(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10151(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10192,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2076 get */
t9=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[437]);}}}}}

/* k10190 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10151(2,t2,t1);}
else{
/* compiler.scm: 2077 get */
t2=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[451]);}}

/* k10149 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10151,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10157(t6,t5);}
else{
t4=t3;
f_10157(t4,C_SCHEME_UNDEFINED);}}

/* k10155 in k10149 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10157,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2083 blockvar-literal */
t3=((C_word*)t0)[3];
f_11073(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2084 literal */
t3=((C_word*)t0)[2];
f_10979(t3,t2,((C_word*)t0)[5]);}}

/* k10165 in k10155 in k10149 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10167,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[554],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10979,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2268 immediate? */
t4=C_retrieve(lf[497]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10984 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10986,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2268 immediate-literal */
f_11105(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11012,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2271 list-index */
t4=C_retrieve(lf[553]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_10998(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11038,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2277 append */
t5=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11048,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2279 posq */
t3=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11046 in k10984 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2280 new-literal */
t2=((C_word*)t0)[3];
f_11059(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11036 in k10984 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11038,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11011 in k10984 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11012,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10996 in k10984 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2273 new-literal */
t2=((C_word*)t0)[3];
f_11059(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11073,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11077,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11089,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2288 list-index */
t5=C_retrieve(lf[553]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11088 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11089,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11096,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2290 block-variable-literal? */
t4=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11094 in a11088 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11096,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2291 block-variable-literal-name */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11101 in k11094 in a11088 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11075 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11077,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2293 make-block-variable-literal */
t3=C_retrieve(lf[550]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11085 in k11075 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2293 new-literal */
t2=((C_word*)t0)[3];
f_11059(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11059,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11067,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2284 append */
t6=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11065 in new-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11105(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11105,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[393],lf[124],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11118,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11118(2,t6,(C_word)C_a_i_list(&a,2,lf[544],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11118(2,t6,(C_word)C_a_i_list(&a,2,lf[545],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11118(2,t6,(C_word)C_a_i_list(&a,2,lf[546],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11118(2,t6,lf[547]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11118(2,t6,lf[548]);}
else{
/* compiler.scm: 2304 bomb */
t6=C_retrieve(lf[403]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[549]);}}}}}}}

/* k11116 in immediate-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11118,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],lf[543],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10101,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10092,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10083,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10074,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10065,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10056,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10047,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10038,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10029,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10020,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10011,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10002,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9993,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9984,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9975,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9966,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9957,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9948,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9939,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9930,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9921,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9912,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9903,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9894,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9885,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9876,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9867,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9858,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9849,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[510]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9840,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[510]);
/* compiler.scm: 2037 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9834,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[510]));}

/* make-lambda-literal in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9828,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[510],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8594,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8597,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8603,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8613,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8624,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9659,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8958,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9647,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9795,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2025 debugging */
t22=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[469],lf[508]);}

/* k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2026 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8624(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2027 debugging */
t3=C_retrieve(lf[468]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[503],lf[507],((C_word*)((C_word*)t0)[2])[1]);}

/* k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2028 debugging */
t3=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[469],lf[506]);}

/* k9802 in k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2029 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8958(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9805 in k9802 in k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9810,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9810(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9820,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9822,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2031 ##sys#make-promise */
t6=*((C_word*)lf[505]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9821 in k9805 in k9802 in k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9818 in k9805 in k9802 in k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2031 debugging */
t2=C_retrieve(lf[468]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[503],lf[504],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9808 in k9805 in k9802 in k9799 in k9796 in k9793 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9647,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9653,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9652 in maptransform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9653,3,t0,t1,t2);}
/* compiler.scm: 1997 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8958(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8958,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[101]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8977(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[124]);
if(C_truep(t13)){
t14=t12;
f_8977(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[452]);
t15=t12;
f_8977(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[405])));}}}

/* k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8977,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[399]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8989,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1872 ref-var */
f_9659(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[112]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9010(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[395]);
if(C_truep(t5)){
t6=t4;
f_9010(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[193]);
if(C_truep(t6)){
t7=t4;
f_9010(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t7)){
t8=t4;
f_9010(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[269]);
if(C_truep(t8)){
t9=t4;
f_9010(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[102]);
if(C_truep(t9)){
t10=t4;
f_9010(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[176]);
if(C_truep(t10)){
t11=t4;
f_9010(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[499]);
if(C_truep(t11)){
t12=t4;
f_9010(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[500]);
if(C_truep(t12)){
t13=t4;
f_9010(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[501]);
if(C_truep(t13)){
t14=t4;
f_9010(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[432]);
if(C_truep(t14)){
t15=t4;
f_9010(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t15)){
t16=t4;
f_9010(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[106]);
t17=t4;
f_9010(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[179])));}}}}}}}}}}}}}}}

/* k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9016,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1880 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9647(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[151]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1884 test */
t5=((C_word*)t0)[4];
f_8597(t5,t4,t3,lf[464]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[394]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[439]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1900 decompose-lambda-list */
t7=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[174]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9377,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[101],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1960 immediate? */
t13=C_retrieve(lf[497]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9377(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[270]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[393],lf[452],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9526,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9533,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9537,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1991 ##sys#make-lambda-info */
t16=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9526(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 1994 bomb */
t7=C_retrieve(lf[403]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[498]);}}}}}}

/* k9535 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1991 qnode */
t2=C_retrieve(lf[485]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9531 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9533,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9526(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9524 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9526,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[484],((C_word*)t0)[2],t2));}

/* k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[124],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1962 posq */
t4=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9383,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9392,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1964 test */
t3=((C_word*)t0)[3];
f_8597(t3,t2,((C_word*)t0)[2],lf[464]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1976 test */
t3=((C_word*)t0)[3];
f_8597(t3,t2,((C_word*)t0)[2],lf[464]);}}

/* k9451 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[493]:lf[494]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1980 varnode */
t4=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9483,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1984 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8958(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9481 in k9451 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9483,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[174],((C_word*)t0)[2],t2));}

/* k9464 in k9451 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9470,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1981 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8958(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9468 in k9464 in k9451 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9470,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9390 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9392,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[493]:lf[494]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1968 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[495]:lf[496]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1974 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9437 in k9390 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9443,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1975 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8958(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9441 in k9437 in k9390 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9443,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9417 in k9390 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9419,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[481],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9415,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1969 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8958(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9413 in k9417 in k9390 in k9381 in k9375 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9415,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9106,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1903 filter */
t7=C_retrieve(lf[492]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9354 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9355,3,t0,t1,t2);}
/* compiler.scm: 1903 test */
t3=((C_word*)t0)[2];
f_8597(t3,t1,t2,lf[464]);}

/* k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9353,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[121]),t1);}

/* k9351 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1904 map */
t2=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[155]+1),((C_word*)t0)[2],t1);}

/* k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1905 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[122]);}

/* k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9116,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[478]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1907 test */
t4=((C_word*)t0)[2];
f_8597(t4,t3,t2,lf[479]);}

/* k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1908 test */
t4=((C_word*)t0)[2];
f_8597(t4,t3,((C_word*)t0)[17],lf[480]);}

/* k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9128,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9134(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9134(t4,C_SCHEME_FALSE);}}

/* k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9134,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1914 test */
t4=((C_word*)t0)[2];
f_8597(t4,t3,((C_word*)t0)[6],lf[464]);}
else{
t3=t2;
f_9137(2,t3,C_SCHEME_FALSE);}}

/* k9318 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9320,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1915 test */
t3=((C_word*)t0)[2];
f_8597(t3,t2,((C_word*)t0)[6],lf[436]);}
else{
t2=((C_word*)t0)[4];
f_9137(2,t2,C_SCHEME_FALSE);}}

/* k9321 in k9318 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1916 put! */
t4=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[491],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9137(2,t2,C_SCHEME_FALSE);}}

/* k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9137,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9281,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9296,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9295 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9296,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9279 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1926 build-lambda-list */
t4=C_retrieve(lf[165]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9277,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1935 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8958(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9222,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9236,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1940 unzip1 */
t5=C_retrieve(lf[156]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9214(2,t3,t1);}}

/* k9234 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9240,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9242,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9241 in k9234 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9253,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1941 varnode */
t5=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9251 in a9241 in k9234 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9253,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[483],C_SCHEME_END_OF_LIST,t2));}

/* k9238 in k9234 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1937 fold-right */
t2=C_retrieve(lf[490]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9221 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9222,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[393],lf[151],t5,t6));}

/* k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9214,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9160,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9198 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9199,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1944 varnode */
t4=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9205 in a9198 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1944 ref-var */
f_9659(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9174,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9178,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9182,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9190,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1952 real-name */
t7=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9163(2,t3,t1);}}

/* k9188 in k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9190,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[487]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1952 ->string */
t5=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9180 in k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1951 ##sys#make-lambda-info */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9176 in k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1950 qnode */
t2=C_retrieve(lf[485]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9172 in k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9174,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1947 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9161 in k9158 in k9212 in k9209 in k9275 in k9135 in k9132 in k9126 in k9120 in k9114 in k9111 in k9108 in a9105 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[484],((C_word*)t0)[2],t2));}

/* k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1885 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9032 in k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9050,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1889 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8958(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1896 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9647(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9084 in k9032 in k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t1));}

/* k9048 in k9032 in k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9050,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1892 varnode */
t4=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9077 in k9048 in k9032 in k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9079,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[483],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1893 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8958(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9069 in k9077 in k9048 in k9032 in k9029 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t4));}

/* k9014 in k9008 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9016,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k8987 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1873 test */
t3=((C_word*)t0)[3];
f_8597(t3,t2,((C_word*)t0)[2],lf[464]);}

/* k8993 in k8987 in k8975 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[482],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9659(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9659,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9666,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2001 posq */
t9=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9664 in ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9666,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9682,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2004 varnode */
t5=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9680 in k9664 in ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9682,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[481],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8624,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[101]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8643(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[399]);
if(C_truep(t13)){
t14=t12;
f_8643(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[124]);
if(C_truep(t14)){
t15=t12;
f_8643(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[452]);
if(C_truep(t15)){
t16=t12;
f_8643(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[270]);
t17=t12;
f_8643(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[405])));}}}}}

/* k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8643,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[151]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1809 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[395]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[399],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8706,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8723,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8733,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8847,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1825 test */
t19=((C_word*)t0)[3];
f_8597(t19,t18,t16,lf[425]);}
else{
t15=t14;
f_8733(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8723(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[394]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[439]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1849 decompose-lambda-list */
t8=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8922,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8921 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8922,3,t0,t1,t2);}
/* compiler.scm: 1859 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8624(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8883,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[478]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9698,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9698(3,t14,t10,t6);}

/* walk in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9698,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[399]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9727,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2016 lset-adjoin */
t12=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[128]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[101]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9736(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[124]);
if(C_truep(t12)){
t13=t11;
f_9736(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[270]);
if(C_truep(t13)){
t14=t11;
f_9736(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[452]);
if(C_truep(t14)){
t15=t11;
f_9736(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[102]);
t16=t11;
f_9736(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[405])));}}}}}}

/* k9734 in walk in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9736,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9748,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9762,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2020 lset-adjoin */
t6=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[128]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9748(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9760 in k9734 in walk in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9748(t3,t2);}

/* k9746 in k9734 in walk in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2021 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9698(3,t3,((C_word*)t0)[2],t2);}

/* k9725 in walk in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9694 in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9696,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8896,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1855 put! */
t5=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[480],t3);}

/* k8894 in k9694 in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8899,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1856 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[479],((C_word*)t0)[2]);}

/* k8897 in k8894 in k9694 in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8899,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1857 append */
t4=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8908 in k8897 in k8894 in k9694 in a8882 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1857 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8624(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8845 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8739(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1825 test */
t2=((C_word*)t0)[3];
f_8597(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[426]);}}

/* k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8745(t4,(C_word)C_eqp(lf[394],t3));}
else{
t3=t2;
f_8745(t3,C_SCHEME_FALSE);}}

/* k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8745,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1830 test */
t6=((C_word*)t0)[2];
f_8597(t6,t5,((C_word*)t0)[6],lf[422]);}
else{
t2=((C_word*)t0)[8];
f_8733(t2,C_SCHEME_END_OF_LIST);}}

/* k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8760,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1831 test */
t3=((C_word*)t0)[2];
f_8597(t3,t2,((C_word*)t0)[7],lf[438]);}

/* k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8763(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8763(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8763(t3,C_SCHEME_FALSE);}}

/* k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8763,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8781,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8781(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8781(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8781(t4,C_SCHEME_FALSE);}}

/* k8779 in k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8781,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1839 source-info->string */
t3=C_retrieve(lf[477]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8766(2,t2,C_SCHEME_UNDEFINED);}}

/* k8786 in k8779 in k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1837 quit */
t2=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[476],t1);}

/* k8764 in k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1840 register-direct-call! */
t3=((C_word*)t0)[2];
f_8613(t3,t2,((C_word*)t0)[6]);}

/* k8767 in k8764 in k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1841 register-customizable! */
t3=((C_word*)t0)[3];
f_8603(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8772(2,t3,C_SCHEME_UNDEFINED);}}

/* k8770 in k8767 in k8764 in k8761 in k8758 in k8755 in k8743 in k8737 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8772,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8733(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8731 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8733,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8723(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8721 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8723,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1818 node-parameters-set! */
t3=C_retrieve(lf[475]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8704 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8710 in k8704 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8711,3,t0,t1,t2);}
/* compiler.scm: 1846 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8624(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8663 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8664,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8680 in a8663 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8681,3,t0,t1,t2);}
/* compiler.scm: 1810 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8624(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8666 in a8663 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8668,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1811 append */
t4=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8677 in k8666 in a8663 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1811 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8624(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8653 in k8641 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1809 split-at */
t3=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8613,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1796 lset-adjoin */
t6=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[128]+1),C_retrieve(lf[63]),t2);}

/* k8620 in register-direct-call! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8603,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8608,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1791 lset-adjoin */
t5=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[128]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8606 in register-customizable! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1792 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[474],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8597(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8597,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1788 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7069,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7073,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1409 make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7073,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7075,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7778,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7675,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7082,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7663,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7784,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7798,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1579 initialize-analysis-database */
t18=C_retrieve(lf[472]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1582 debugging */
t3=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[469],lf[471]);}

/* k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7826,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1584 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7082(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1587 debugging */
t3=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[469],lf[470]);}

/* k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1588 ##sys#hash-table-for-each */
t4=C_retrieve(lf[467]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7846,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7850,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8481,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8480 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8481,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[422]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[430]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[447]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[438]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[445]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[446]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[424]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[426]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[435]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8446,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8446(t10,(C_word)C_eqp(lf[394],t9));}
else{
t7=t6;
f_8446(t7,C_SCHEME_FALSE);}}

/* k8444 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1634 set-real-name! */
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7857(2,t2,C_SCHEME_UNDEFINED);}}

/* k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8392(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8392(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8392(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8392(t4,C_SCHEME_FALSE);}}

/* k8390 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8392,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1643 compiler-warning */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[184],lf[466],((C_word*)t0)[3]);}
else{
t3=t2;
f_8395(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7860(2,t2,C_SCHEME_UNDEFINED);}}

/* k8393 in k8390 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8407,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8407(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8407(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8407(t5,C_SCHEME_FALSE);}}}

/* k8405 in k8393 in k8390 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8401(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8401(t2,C_SCHEME_FALSE);}}

/* k8399 in k8393 in k8390 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1647 compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[184],lf[465],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7860(2,t2,C_SCHEME_UNDEFINED);}}

/* k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1651 quick-put! */
f_7784(t2,((C_word*)t0)[8],lf[464],C_SCHEME_TRUE);}
else{
t4=t2;
f_7863(2,t4,C_SCHEME_UNDEFINED);}}

/* k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[394],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8335(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8367,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8375,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1660 scan-free-variables */
t13=C_retrieve(lf[463]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8335(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7866(2,t3,C_SCHEME_UNDEFINED);}}

/* k8373 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1660 every */
t2=C_retrieve(lf[317]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8366 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8367,3,t0,t1,t2);}
/* compiler.scm: 1660 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[431]);}

/* k8333 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8341(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8341(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* k8339 in k8333 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1662 quick-put! */
f_7784(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1663 quick-put! */
f_7784(((C_word*)t0)[3],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE);}}

/* k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8297(t6,(C_word)C_eqp(lf[101],t5));}
else{
t4=t3;
f_8297(t4,C_SCHEME_FALSE);}}

/* k8295 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8297,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1671 collapsable-literal? */
t6=C_retrieve(lf[236]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k8304 in k8295 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8309(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8309(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8307 in k8304 in k8295 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1673 quick-put! */
f_7784(((C_word*)t0)[3],((C_word*)t0)[2],lf[460],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8198,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[394],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8198(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8198(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7872(2,t3,C_SCHEME_UNDEFINED);}}

/* k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8198,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1687 decompose-lambda-list */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7872(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7872(2,t2,C_SCHEME_UNDEFINED);}}

/* a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8216,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8220(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8259,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8258 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8259,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8266,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1693 get */
t5=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[422]);}

/* k8282 in a8258 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8284,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8266(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8280,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1694 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[445]);}}

/* k8278 in k8282 in a8258 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8266(t2,(C_word)C_i_not(t1));}

/* k8264 in a8258 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8266,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8269,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1695 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[332],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8267 in k8264 in a8258 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8218 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8226(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8226(t3,C_SCHEME_FALSE);}}

/* k8224 in k8218 in a8215 in k8196 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8226,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1701 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[458],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1704 put! */
t5=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[459],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8135,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8135(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8150,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[399],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8162,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8162(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8176,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1712 get */
t15=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[431]);}}
else{
t6=t5;
f_8150(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8135(t5,C_SCHEME_FALSE);}}}

/* k8174 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8162(t2,(C_word)C_i_not(t1));}

/* k8160 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8162,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1713 expression-has-side-effects? */
t3=C_retrieve(lf[457]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8150(t2,C_SCHEME_FALSE);}}

/* k8167 in k8160 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8150(t2,(C_word)C_i_not(t1));}

/* k8148 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8135(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8133 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8135(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1715 quick-put! */
f_7784(((C_word*)t0)[3],((C_word*)t0)[2],lf[456],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7875(2,t2,C_SCHEME_UNDEFINED);}}

/* k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[399],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8047,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1727 get */
t11=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[422]);}
else{
t7=t2;
f_7878(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7878(2,t4,C_SCHEME_UNDEFINED);}}

/* k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8053,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8121,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1728 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[425]);}

/* k8119 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8053(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1728 get */
t2=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[426]);}}

/* k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8056,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8056(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1729 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[430]);}}

/* k8109 in k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8056(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8056(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1733 get */
t6=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[445]);}}
else{
t4=((C_word*)t0)[6];
f_8056(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8056(t2,C_SCHEME_FALSE);}}}

/* k8101 in k8109 in k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8103,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8056(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8056(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1734 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[431]);}}}

/* k8097 in k8101 in k8109 in k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8056(t2,(C_word)C_i_not(t1));}

/* k8054 in k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8056,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1735 quick-put! */
f_7784(t2,((C_word*)t0)[2],lf[455],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7878(2,t2,C_SCHEME_UNDEFINED);}}

/* k8057 in k8054 in k8051 in k8045 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1736 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454],C_SCHEME_TRUE);}

/* k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7906(t6,(C_word)C_eqp(lf[394],t5));}
else{
t4=t3;
f_7906(t4,C_SCHEME_FALSE);}}

/* k7904 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7906,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7881(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7927,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7927(t11,(C_word)C_eqp(lf[395],t10));}
else{
t10=t8;
f_7927(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7927(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7881(2,t2,C_SCHEME_UNDEFINED);}}

/* k7925 in k7904 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7927,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[399],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[399],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7948(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7948(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7948(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7881(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7881(2,t2,C_SCHEME_UNDEFINED);}}

/* k7946 in k7925 in k7904 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7948,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7954,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1756 quick-put! */
f_7784(t4,((C_word*)t0)[2],lf[455],t3);}
else{
t2=((C_word*)t0)[5];
f_7881(2,t2,C_SCHEME_UNDEFINED);}}

/* k7952 in k7946 in k7925 in k7904 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1757 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454],C_SCHEME_TRUE);}

/* k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7887(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7887(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7887(t3,C_SCHEME_FALSE);}}

/* k7885 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7887,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1767 lset-adjoin */
t3=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[128]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7889 in k7885 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7848 in a7845 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1768 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],lf[442]);}

/* k7834 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1774 lset-difference */
t3=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[128]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7838 in k7834 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7840,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7843(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7843(t5,t4);}}

/* k7841 in k7838 in k7834 in k7831 in k7828 in k7824 in k7821 in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7798(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7798,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7808,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1574 get */
t6=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[444]);}}

/* k7806 in contains? in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1576 any */
t3=C_retrieve(lf[453]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7815 in k7806 in contains? in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7816,3,t0,t1,t2);}
/* compiler.scm: 1576 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7798(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7784(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7784,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7792,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1569 alist-cons */
t7=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7790 in quick-put! in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7663,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7669,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7668 in walkeach in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7669,3,t0,t1,t2);}
/* compiler.scm: 1543 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7082(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7082,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7075(C_fix(1));
t13=(C_word)C_eqp(t11,lf[101]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7104(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[124]);
t16=t14;
f_7104(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[452])));}}

/* k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7104,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[399]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1425 ref */
t5=((C_word*)t0)[8];
f_7778(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[405]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7159,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1433 ref */
t6=((C_word*)t0)[8];
f_7778(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[269]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[432]));
if(C_truep(t5)){
t6=f_7075(C_fix(1));
/* compiler.scm: 1439 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7663(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[395]);
if(C_truep(t6)){
t7=f_7075(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[399],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7218,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1446 collect! */
t16=C_retrieve(lf[421]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[438],t15);}
else{
t12=t9;
f_7195(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[151]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7290,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1460 append */
t9=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[158]);
if(C_truep(t8)){
t9=f_7075(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1473 decompose-lambda-list */
t12=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[394]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[439]));
if(C_truep(t10)){
t11=f_7075(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7401,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1486 decompose-lambda-list */
t14=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[174]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7586,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7592,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1517 get */
t17=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[437]);}
else{
t15=t14;
f_7511(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[270]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[193]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7625,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1536 ##sys#hash-table-ref */
t17=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7625(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7625(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7625(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1540 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7663(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7623 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1537 set-real-name! */
t2=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7619(2,t2,C_SCHEME_UNDEFINED);}}

/* k7617 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1538 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7663(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7590 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7592,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1518 compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[448],lf[449],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1519 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[451]);}}

/* k7599 in k7590 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1520 compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[448],lf[450],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7586(2,t2,C_SCHEME_UNDEFINED);}}

/* k7584 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1521 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[447],((C_word*)t0)[2]);}

/* k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7540(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7540(t5,(C_word)C_i_not(t4));}}

/* k7538 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7540,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7075(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7555(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7555(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7555(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7546(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7514(2,t2,C_SCHEME_UNDEFINED);}}

/* k7553 in k7538 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7559,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1527 lset-adjoin */
t3=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[128]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7546(t2,C_SCHEME_UNDEFINED);}}

/* k7557 in k7553 in k7538 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7546(t3,t2);}

/* k7544 in k7538 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1528 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[431],C_SCHEME_TRUE);}

/* k7512 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7517,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1529 append */
t4=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7535 in k7512 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1529 assign */
t2=((C_word*)t0)[6];
f_7675(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7515 in k7512 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7520(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1530 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446],C_SCHEME_TRUE);}}

/* k7518 in k7515 in k7512 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1531 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[445],C_SCHEME_TRUE);}

/* k7521 in k7518 in k7515 in k7512 in k7509 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1532 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7082(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7401,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1492 collect! */
t9=C_retrieve(lf[421]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[444],t5);}
else{
t8=t7;
f_7408(2,t8,C_SCHEME_UNDEFINED);}}

/* k7491 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1493 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[443],((C_word*)t0)[2]);}

/* k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7482 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7483,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7487,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1496 put! */
t4=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[428],((C_word*)t0)[2]);}

/* k7485 in a7482 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1497 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[425],C_SCHEME_TRUE);}

/* k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[442]:lf[277]);
/* compiler.scm: 1500 put! */
t5=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[436],t4);}
else{
t3=t2;
f_7414(2,t3,C_SCHEME_UNDEFINED);}}

/* k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7468,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1504 simple-lambda-node? */
t4=C_retrieve(lf[441]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7466 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1504 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[440],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7417(2,t2,C_SCHEME_UNDEFINED);}}

/* k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7420(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7420(t5,t4);}}

/* k7418 in k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7420,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7453,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7453(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7453(t4,C_SCHEME_FALSE);}}

/* k7451 in k7418 in k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7423(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7423(t2,C_SCHEME_UNDEFINED);}}

/* k7421 in k7418 in k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7423,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7426,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1509 append */
t5=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7448 in k7421 in k7418 in k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1509 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7082(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7424 in k7421 in k7418 in k7415 in k7412 in k7409 in k7406 in a7400 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7356 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7357,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7375 in a7356 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7376,3,t0,t1,t2);}
/* compiler.scm: 1477 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[425],C_SCHEME_TRUE);}

/* k7359 in a7356 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7361,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1481 append */
t7=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7372 in k7359 in a7356 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1481 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7082(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7363 in k7359 in a7356 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7290,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7295(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7295,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1463 append */
t6=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7322,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1466 put! */
t7=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[428],((C_word*)t0)[8]);}}

/* k7320 in loop in k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7325,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1467 assign */
t3=((C_word*)t0)[4];
f_7675(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7323 in k7320 in loop in k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7328,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1468 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7082(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7326 in k7323 in k7320 in loop in k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1469 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7295(t4,((C_word*)t0)[2],t2,t3);}

/* k7311 in loop in k7288 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1463 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7082(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7216 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1448 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[437]);}

/* k7264 in k7216 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[433])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7195(2,t3,C_SCHEME_UNDEFINED);}}

/* a7228 in k7264 in k7216 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7229,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[399],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7248,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1454 get */
t10=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[436]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7246 in a7228 in k7264 in k7216 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1454 count! */
t2=C_retrieve(lf[434]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[435]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7193 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1456 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7082(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7196 in k7193 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1457 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7663(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7157 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7075(C_fix(1));
/* compiler.scm: 1435 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[431],C_SCHEME_TRUE);}

/* k7114 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7075(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1428 put! */
t3=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[430],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1429 get */
t4=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[431]);}}}

/* k7145 in k7114 in k7102 in walk in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1429 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[431],C_SCHEME_TRUE);}}

/* assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7675(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7675,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[124],t7);
if(C_truep(t8)){
/* compiler.scm: 1547 put! */
t9=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[424],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7688,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[399],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7688(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7688(t13,C_SCHEME_FALSE);}}}

/* k7686 in assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7697(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7697(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7748,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1552 get */
t6=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[348]);}}}}

/* k7746 in k7686 in assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7697(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7695 in k7686 in assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7697,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1555 get-all */
t3=C_retrieve(lf[429]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[425],lf[426]);}
else{
/* compiler.scm: 1563 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[425],C_SCHEME_TRUE);}}

/* k7698 in k7695 in k7686 in assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1556 get */
t3=C_retrieve(lf[427]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[428]);}

/* k7701 in k7698 in k7695 in k7686 in assign in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[425],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[426],((C_word*)t0)[7]))){
/* compiler.scm: 1559 put! */
t2=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[425],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1561 put! */
t4=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1562 put! */
t4=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[425],C_SCHEME_TRUE);}}}}

/* ref in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7778(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7778,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1566 collect! */
t4=C_retrieve(lf[421]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[422],t3);}

/* grow in k7071 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_7075(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7060,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[408]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7051,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[408]);
/* compiler.scm: 1398 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7042,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[408]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7033,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[408]);
/* compiler.scm: 1398 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7024,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[408]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7015,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[408]);
/* compiler.scm: 1398 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7006,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[408]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6997,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[408]);
/* compiler.scm: 1398 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6988,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[408]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6979,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[408]);
/* compiler.scm: 1398 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6973,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[408]));}

/* make-foreign-callback-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6967,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[408],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6292,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6295,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6339,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6713,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6838,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6854,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6939,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1393 walk */
t21=((C_word*)t6)[1];
f_6339(t21,t1,t2,*((C_word*)lf[407]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6939,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[406]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[193]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[102]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[176]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[106]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[179]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1391 every */
t8=C_retrieve(lf[317]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6854,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6860(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6860,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6874,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1374 reverse */
t5=*((C_word*)lf[285]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1375 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6939(3,t6,t4,t5);}}

/* k6878 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1376 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6860(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1378 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}}

/* k6896 in k6878 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1379 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6339(t4,((C_word*)t0)[2],t2,t3);}

/* a6906 in k6896 in k6878 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6907,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6921,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6933,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1384 varnode */
t7=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6931 in a6906 in k6896 in k6878 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1383 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6860(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6919 in a6906 in k6896 in k6878 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t2));}

/* k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1374 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6838,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6844,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1367 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6854(t7,t1,t4,t6);}

/* a6843 in walk-inline-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6844,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[393],t3,t4,t2);
/* compiler.scm: 1370 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6713,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6717,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1343 gensym */
t7=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[398]);}

/* k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1344 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}

/* k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6720,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[401]);}

/* k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6774,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6770,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1348 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6768 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1348 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6766,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[394],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6743,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1349 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6854(t6,t4,((C_word*)t0)[2],t5);}

/* a6744 in k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6745,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1352 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6339(t4,t1,((C_word*)t0)[2],t3);}

/* a6750 in a6744 in k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6751,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6755,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1354 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6760 in a6750 in a6744 in k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1354 cons* */
t2=C_retrieve(lf[218]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6753 in a6750 in a6744 in k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[393],lf[395],((C_word*)t0)[2],t1));}

/* k6741 in k6764 in k6772 in k6718 in k6715 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6743,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6339,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[399]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6361(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[101]);
if(C_truep(t14)){
t15=t13;
f_6361(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[124]);
if(C_truep(t15)){
t16=t13;
f_6361(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[270]);
t17=t13;
f_6361(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[405])));}}}}

/* k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6361,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1300 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[112]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1301 gensym */
t4=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[398]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[151]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6467,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6467(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[158]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[401]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[174]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6542,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1323 gensym */
t7=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[278]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[243]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[401]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[193]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6627(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
if(C_truep(t9)){
t10=t8;
f_6627(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[102]);
if(C_truep(t10)){
t11=t8;
f_6627(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[176]);
if(C_truep(t11)){
t12=t8;
f_6627(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[106]);
t13=t8;
f_6627(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[179])));}}}}}}}}}}}

/* k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6627,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1337 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6838(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[395]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1338 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6713(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[269]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6784,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1357 gensym */
t8=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[398]);}
else{
/* compiler.scm: 1340 bomb */
t4=C_retrieve(lf[403]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[404]);}}}}

/* k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1358 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}

/* k6785 in k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[401]);}

/* k6830 in k6785 in k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6832,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6828,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1362 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6826 in k6830 in k6785 in k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1362 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6822 in k6830 in k6785 in k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6824,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[394],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1364 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6818 in k6822 in k6830 in k6785 in k6782 in k6625 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[269],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t4));}

/* k6590 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6592,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[402]),t1,((C_word*)t0)[2]);}

/* k6616 in k6590 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1334 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6295(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6540 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6542,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1324 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6339(t4,((C_word*)t0)[2],t2,t3);}

/* a6550 in k6540 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6551,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[393],lf[174],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6575,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6579,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1328 varnode */
t10=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6577 in a6550 in k6540 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1328 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6573 in a6550 in k6540 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6575,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t2));}

/* k6527 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1322 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6295(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6467,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1316 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6339(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1317 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6339(t6,t1,t4,t5);}}

/* a6489 in loop in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6490,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6504,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1321 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6467(t8,t5,t6,t7);}

/* k6502 in a6489 in loop in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6504,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t2));}

/* k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1302 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}

/* k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6377,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[401]);}

/* k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6448,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1307 varnode */
t6=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6446 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1307 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6442 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[394],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1308 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6339(t7,t4,t5,t6);}

/* a6416 in k6442 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6417,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1312 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6339(t5,t3,t4,((C_word*)t0)[2]);}

/* k6426 in a6416 in k6442 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1313 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6339(t4,t2,t3,((C_word*)t0)[2]);}

/* k6430 in k6426 in a6416 in k6442 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6432,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[112],C_SCHEME_END_OF_LIST,t2));}

/* k6409 in k6442 in k6450 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[151],((C_word*)t0)[2],t2));}

/* k1 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6377,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6388,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1303 varnode */
t4=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6386 in k1 in k6374 in k6371 in k6359 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6388,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[395],lf[400],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6295(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6295,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6299,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1288 gensym */
t7=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[398]);}

/* k6297 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6322,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1291 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6339(t7,t4,t5,t6);}

/* a6321 in k6297 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6322,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6333,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1293 varnode */
t4=C_retrieve(lf[397]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6331 in a6321 in k6297 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[393],lf[395],lf[396],t2));}

/* k6314 in k6297 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6316,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[393],lf[394],((C_word*)t0)[4],t2);
/* compiler.scm: 1289 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6202,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6205,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6234,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1280 walk */
t10=((C_word*)t7)[1];
f_6234(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6234,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1275 ##sys#hash-table-ref */
t7=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[391]),t5);}
else{
/* compiler.scm: 1279 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6205(t5,t1,t2);}}}

/* k6251 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6253,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6259(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1277 alist-cons */
t5=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6274 in k6251 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1277 ##sys#hash-table-set! */
t2=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[391]),((C_word*)t0)[2],t1);}

/* k6257 in k6251 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1278 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6205(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6205(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6205,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6211(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6211,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6221,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1269 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6234(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6219 in loop in mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1270 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6211(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6121,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6125,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6125(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6125(t5,C_SCHEME_FALSE);}}

/* k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6125,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6128(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6128(t3,lf[390]);}}

/* k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6128,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6131(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6131(t4,(C_word)C_i_cadr(t3));}}

/* k6129 in k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6131,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6134,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6147,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[388]+1),t4);}

/* k6145 in k6129 in k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[223]+1),t1);}

/* k6132 in k6129 in k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6135 in k6132 in k6129 in k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[388]+1),((C_word*)t0)[2]);}

/* k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1259 create-foreign-stub */
t2=C_retrieve(lf[377]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6084,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6094,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6107,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[388]+1),t9);}

/* k6105 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[223]+1),t1);}

/* k6092 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6095 in k6092 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6100,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[388]+1),((C_word*)t0)[2]);}

/* k6098 in k6095 in k6092 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1250 create-foreign-stub */
t2=C_retrieve(lf[377]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6047,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6057,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[388]+1),t9);}

/* k6068 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[223]+1),t1);}

/* k6055 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6058 in k6055 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6063,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[388]+1),((C_word*)t0)[2]);}

/* k6061 in k6058 in k6055 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1242 create-foreign-stub */
t2=C_retrieve(lf[377]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6002,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1229 symbol->string */
t6=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6009(2,t6,t4);}
else{
/* compiler.scm: 1231 quit */
t6=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[387],t4);}}}

/* k6007 in ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6009,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6015,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[385]+1),t5);}

/* k6013 in k6007 in ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1234 create-foreign-stub */
t2=C_retrieve(lf[377]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5957,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5964,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1220 symbol->string */
t6=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5964(2,t6,t4);}
else{
/* compiler.scm: 1222 quit */
t6=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[386],t4);}}}

/* k5962 in ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5970,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[385]+1),t5);}

/* k5968 in k5962 in ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1225 create-foreign-stub */
t2=C_retrieve(lf[377]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5803,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5807,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5951,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1193 list-tabulate */
t12=C_retrieve(lf[384]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5950 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5951,3,t0,t1,t2);}
/* compiler.scm: 1193 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[383]);}

/* k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1194 gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1195 gensym */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1196 estimate-foreign-result-size */
t3=C_retrieve(lf[381]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1197 set-real-name! */
t3=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1199 make-foreign-stub */
t3=C_retrieve(lf[357]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5829,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[270],((C_word*)t0)[2]);
t7=t5;
f_5829(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5829(t6,(C_word)C_a_i_list(&a,2,lf[193],((C_word*)t0)[2]));}}

/* k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5829,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5920,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1205 map */
t4=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5919 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5920,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5928,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1205 foreign-type-convert-argument */
t5=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5926 in a5919 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1205 foreign-type-check */
t2=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5843,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[378]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5855,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[379],t1);
/* compiler.scm: 1210 append */
t8=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1211 final-foreign-type */
t7=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5870 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1212 words */
t3=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5873 in k5870 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[380],t2);
t4=(C_word)C_a_i_list(&a,2,lf[101],t1);
t5=(C_word)C_a_i_list(&a,3,lf[194],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1215 append */
t12=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5892 in k5873 in k5870 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1215 finish-foreign-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5888 in k5873 in k5870 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1214 foreign-type-convert-result */
t2=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5884 in k5873 in k5870 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5855(2,t2,(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[2],t1));}

/* k5863 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1210 foreign-type-convert-result */
t2=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5853 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5841 in k5830 in k5827 in k5943 in k5817 in k5814 in k5811 in k5808 in k5805 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[158],t2));}

/* foreign-stub-callback in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5794,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5785,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5776,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5767,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5758,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5749,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5740,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5731,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5722,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5713,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5704,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5695,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5686,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5677,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5668,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5659,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[358]);
/* compiler.scm: 1182 ##sys#block-set! */
t5=*((C_word*)lf[361]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5653,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[358]));}

/* make-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5647,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[358],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4705,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4756,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4756(t5,t1);}

/* a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4756,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4760(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1018 syntax-error */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[356],((C_word*)t0)[3]);}}

/* k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[292]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[295]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[296]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1030 check-decl */
f_4705(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[299]));
t9=t3;
f_4766(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4872,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1040 append */
t10=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[300]));
t10=t3;
f_4766(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4897,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1044 append */
t11=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[301]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[299]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[300]));
t12=t3;
f_4766(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4926,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1051 lset-intersection */
t12=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[128]+1),t10,C_retrieve(lf[299]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4943,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1054 check-decl */
f_4705(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[303]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[304]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[303]);
t13=t3;
f_4766(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4766(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1060 ##match#set-error-control */
t15=C_retrieve(lf[305]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[306]);}
else{
t14=(C_word)C_eqp(t2,lf[307]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4766(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4766(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4766(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4766(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4766(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4766(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5026,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1067 append */
t23=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[311]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5040,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1068 append */
t24=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4766(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5061,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1072 append */
t25=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[299]),C_retrieve(lf[300]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1076 append */
t27=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1080 every */
t28=C_retrieve(lf[317]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[318]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[319]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5124(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5124(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5124(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[322]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[322],t28);
/* compiler.scm: 1088 emit-control-file-item */
t30=C_retrieve(lf[323]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[324],t29);
/* compiler.scm: 1090 emit-control-file-item */
t31=C_retrieve(lf[323]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[325]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1093 pathname-strip-extension */
t31=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4766(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4766(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4766(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5262,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1099 append */
t36=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1101 check-decl */
f_4705(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t35)){
t36=C_set_block_item(lf[338],0,C_SCHEME_TRUE);
t37=t3;
f_4766(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[339]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[340]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5430,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1135 lset-difference */
t41=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[128]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5430(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[341]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5451,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1139 lset-difference */
t41=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[128]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1143 quit */
t41=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[343],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4766(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4766(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4766(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4766(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4766(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4766(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1152 lset-union */
t46=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[128]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5542,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1154 check-decl */
f_4705(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[348]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1162 every */
t47=C_retrieve(lf[317]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[350]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[351]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5588,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5616,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1166 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1176 compiler-warning */
t46=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[180],lf[355],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5615 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5616,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5621,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5626,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5625 in a5615 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5626,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[354]);}

/* k5619 in a5615 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[138]),((C_word*)t0)[2]);}

/* a5587 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5594,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1167 partition */
t4=C_retrieve(lf[353]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5593 in a5587 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5594,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1171 quit */
t3=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[352],t2);}}}

/* k5568 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1163 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1164 quit */
t2=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[349],((C_word*)t0)[2]);}}

/* k5572 in k5568 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5540 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5549(2,t4,t2);}
else{
/* compiler.scm: 1159 quit */
t4=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[347],((C_word*)t0)[3]);}}

/* k5547 in k5540 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5523 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5449 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5451,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1140 lset-union */
t6=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[128]+1),((C_word*)t0)[2],t5);}

/* k5453 in k5449 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5436 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5430(t3,t2);}

/* k5428 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5434,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1136 lset-union */
t3=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[128]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5432 in k5428 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4766(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5295,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1106 lset-difference */
t7=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[128]+1),C_retrieve(lf[299]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4766(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1110 lset-difference */
t8=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[128]+1),C_retrieve(lf[300]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4766(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1114 lset-union */
t9=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[128]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[301]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4766(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5374,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1121 lset-difference */
t10=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[128]+1),C_retrieve(lf[299]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1124 check-decl */
f_4705(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5383 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4766(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[307]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1129 ##match#set-error-control */
t6=C_retrieve(lf[305]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[306]);}
else{
/* compiler.scm: 1130 compiler-warning */
t5=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[180],lf[336],((C_word*)t0)[3]);}}}

/* k5372 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5374,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5378,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1122 lset-difference */
t4=C_retrieve(lf[334]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[128]+1),C_retrieve(lf[300]),((C_word*)t0)[2]);}

/* k5376 in k5372 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5343 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5318 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5293 in k5273 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5260 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5212 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5222 in k5212 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5223,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[326]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[327],((C_word*)t0)[2],t2);}

/* k5219 in k5212 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[325],t1);
/* compiler.scm: 1092 emit-control-file-item */
t3=C_retrieve(lf[323]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5122 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1085 syntax-error */
t2=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[320],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1086 process-custom-declaration */
t4=C_retrieve(lf[321]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5100 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1081 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1082 syntax-error */
t2=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[316],((C_word*)t0)[2]);}}

/* k5104 in k5100 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5073 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1077 append */
t5=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5077 in k5073 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5059 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1074 append */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[299]),C_retrieve(lf[300]),C_retrieve(lf[17]));}

/* k5063 in k5059 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5038 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k5024 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[311]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4941 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4766(2,t4,t3);}

/* k4924 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1052 lset-intersection */
t4=C_retrieve(lf[302]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[128]+1),((C_word*)t0)[2],C_retrieve(lf[300]));}

/* k4928 in k4924 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4895 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4870 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1032 stringify */
t5=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4853 in k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1032 string->c-identifier */
t2=C_retrieve(lf[293]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4829 in k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1033 ##sys#hash-table-set! */
t3=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[296],((C_word*)t0)[2]);}

/* k4832 in k4829 in k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4841,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4841(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4841(t4,C_SCHEME_FALSE);}}

/* k4839 in k4832 in k4829 in k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1035 compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[297],lf[298]);}
else{
t2=((C_word*)t0)[2];
f_4837(2,t2,C_SCHEME_UNDEFINED);}}

/* k4835 in k4832 in k4829 in k4823 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[138]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4778(2,t3,C_SCHEME_UNDEFINED);}}

/* k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1026 ##sys#hash-table-update! */
t5=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[292],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4766(2,t2,C_SCHEME_UNDEFINED);}}

/* a4811 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4805 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4806,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[128]+1),((C_word*)t0)[2],t2);}

/* k4785 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4796,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4795 in k4785 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4804,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1027 stringify */
t4=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4802 in a4795 in k4785 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1027 string->c-identifier */
t2=C_retrieve(lf[293]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4788 in k4785 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1028 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4792 in k4788 in k4785 in k4776 in k4773 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4766(2,t3,t2);}

/* k4764 in k4758 in a4755 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[291]);}

/* check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4705(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4718,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4718(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4728,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4728(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4728(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1013 ##sys#error */
t11=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4726 in check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4718(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4716 in check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1014 syntax-error */
t2=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[290],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1951,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1963,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1987,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2120,a[2]=t5,a[3]=t11,a[4]=t4,a[5]=t9,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4647,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4660,a[2]=t2,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[122],C_retrieve(lf[287])))){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4697,a[2]=t2,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 996  newline */
t17=*((C_word*)lf[289]+1);
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t16=t15;
f_4660(2,t16,C_SCHEME_UNDEFINED);}}

/* k4695 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 996  pretty-print */
t2=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 997  ##sys#clear-trace-buffer */
t3=C_retrieve(lf[286]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4661 in k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1001 reverse */
t4=*((C_word*)lf[285]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4676 in k4661 in k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4687,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1004 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4685 in k4676 in k4661 in k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1005 append */
t3=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[283]),C_retrieve(lf[13]));}

/* k4689 in k4685 in k4676 in k4661 in k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 451  ##sys#append */
t4=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4672 in k4661 in k4658 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
/* compiler.scm: 999  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2120(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4647(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4647,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4652 in mapwalk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4653,3,t0,t1,t2);}
/* compiler.scm: 994  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2120(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 499  resolve-atom */
t9=((C_word*)((C_word*)t0)[7])[1];
f_2029(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 501  resolve-atom */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2029(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 503  constant? */
t7=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2157(2,t7,C_SCHEME_FALSE);}}}

/* k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2157,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[101],((C_word*)t0)[10]));}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 504  syntax-error */
t2=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[110],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 508  get-line */
t6=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 970  constant? */
t5=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 968  syntax-error */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[282],((C_word*)t0)[10]);}}}}}

/* k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 971  emit-syntax-trace-info */
t3=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 975  caar */
t5=*((C_word*)lf[280]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4523(t4,C_SCHEME_FALSE);}}}

/* k4621 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4523(t2,(C_word)C_eqp(lf[158],t1));}

/* k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4523,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 978  emit-syntax-trace-info */
t5=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 990  emit-syntax-trace-info */
t3=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4608 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 991  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4647(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4530 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 979  ##sys#check-syntax */
t3=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[158],((C_word*)t0)[9],lf[279]);}

/* k4533 in k4530 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4544(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4544(t4,C_SCHEME_FALSE);}}

/* k4542 in k4533 in k4530 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4544,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 982  map */
t3=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[277]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 983  gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[278]);}}

/* k4564 in k4542 in k4533 in k4530 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[151],t4,t6);
/* compiler.scm: 984  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2120(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4557 in k4542 in k4533 in k4530 in k4521 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[151],t3);
/* compiler.scm: 982  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2120(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4509 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 972  compiler-warning */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[180],lf[276],((C_word*)t0)[4]);}

/* k4512 in k4509 in k4506 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 973  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4647(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=f_1951(((C_word*)t0)[12],((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2190,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t2,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 510  emit-syntax-trace-info */
t4=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[10],C_SCHEME_FALSE);}

/* k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[14]))){
t3=t2;
f_2193(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 513  sprintf */
t4=C_retrieve(lf[186]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[273],((C_word*)t0)[2]);}
else{
/* compiler.scm: 514  syntax-error */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[274],((C_word*)t0)[14]);}}}

/* k4488 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 513  syntax-error */
t2=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 517  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[8]);}

/* k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[14],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 521  ##sys#hash-table-ref */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[7]);}
else{
t4=t3;
f_2218(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t1,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 519  update-line-number-database! */
t4=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2209(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2207 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 520  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2120(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[13]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 523  walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_2120(t4,((C_word*)t0)[11],t3,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[112]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 528  ##sys#check-syntax */
t4=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[112],((C_word*)t0)[13],lf[115]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[101]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 536  ##sys#check-syntax */
t5=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[101],((C_word*)t0)[13],lf[116]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[117]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[118]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* compiler.scm: 542  walk */
t6=((C_word*)((C_word*)t0)[12])[1];
f_2120(t6,((C_word*)t0)[11],t5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[119]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 545  cadadr */
t7=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[124]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2345(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[269]);
if(C_truep(t8)){
t9=t7;
f_2345(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[270]);
if(C_truep(t9)){
t10=t7;
f_2345(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[102]);
t11=t7;
f_2345(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[7],lf[106])));}}}}}}}}}

/* k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2345,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[125]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[133]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[134]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2392(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[151]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 593  ##sys#check-syntax */
t6=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[151],((C_word*)t0)[12],lf[157]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[158]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[159]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 607  ##sys#check-syntax */
t8=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[158],((C_word*)t0)[12],lf[171]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[172]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[158],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 642  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2120(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[121]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[175]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 658  ##sys#check-syntax */
t12=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[174],((C_word*)t0)[12],lf[192]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[193]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 697  unquotify */
t14=((C_word*)t0)[3];
f_1987(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[176]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 705  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2120(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[179]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 710  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2120(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[196]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 715  eval */
t19=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[197]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[198]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 719  eval */
t21=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[137]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 723  ##sys#check-syntax */
t21=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[137],((C_word*)t0)[12],lf[202]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[203]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 735  expand-foreign-lambda */
t22=C_retrieve(lf[204]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[205]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 738  expand-foreign-callback-lambda */
t23=C_retrieve(lf[206]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[207]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 741  expand-foreign-lambda* */
t24=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[209]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 744  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[211]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 747  expand-foreign-primitive */
t26=C_retrieve(lf[212]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[213]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3325(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 754  symbol->string */
t32=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[216]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3392,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 765  gensym */
t33=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 778  ##sys#hash-table-set! */
t33=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[220]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3466,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 783  symbol->string */
t31=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[226]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 798  gensym */
t34=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[231]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3668,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[233]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3809,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  call-with-current-continuation */
t37=*((C_word*)lf[240]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[241]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3884,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[243]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 865  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4281,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[266],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 940  ##sys#check-syntax */
t36=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[266],((C_word*)t0)[12],lf[268]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 958  ##sys#hash-table-ref */
t36=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4410(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4410(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4408 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 960  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 965  handle-call */
t2=((C_word*)t0)[7];
f_4281(t2,((C_word*)t0)[6]);}}

/* k4414 in k4408 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 962  handle-call */
t2=((C_word*)t0)[7];
f_4281(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 963  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2120(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4319 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1951(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[101],lf[266]);
t7=(C_word)C_a_i_list(&a,5,lf[267],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 945  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2120(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 949  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2120(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 951  symbol->string */
t7=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[101],lf[266]);
t7=(C_word)C_a_i_list(&a,5,lf[267],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 953  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2120(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[101],lf[266]);
t4=(C_word)C_a_i_list(&a,5,lf[267],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 954  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2120(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4379 in k4319 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[221]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[102],t2));}

/* handle-call in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4281,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 929  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4647(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4283 in handle-call in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4291,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 931  ##sys#hash-table-ref */
t4=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4289 in k4283 in handle-call in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 936  alist-cons */
t5=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4294(2,t3,C_SCHEME_UNDEFINED);}}

/* k4303 in k4289 in k4283 in handle-call in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 933  ##sys#hash-table-set! */
t3=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4292 in k4289 in k4283 in handle-call in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3917,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3939,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4265,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 872  valid-c-identifier? */
t14=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4263 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4265,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3939(2,t4,t3);}
else{
/* compiler.scm: 874  quit */
t2=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[264],((C_word*)t0)[3]);}}

/* k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4230(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4230(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4230(t11,(C_word)C_i_not(t10));}}}

/* k4228 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 879  syntax-error */
t2=C_retrieve(lf[109]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[263],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3942(2,t2,C_SCHEME_UNDEFINED);}}

/* k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 883  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4647(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3961,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4180,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4180(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4180,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4220,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 895  final-foreign-type */
t9=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4222 in loop in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 895  finish-foreign-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4218 in loop in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 894  foreign-type-convert-result */
t2=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4214 in loop in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 897  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4180(t6,t3,t4,t5);}

/* k4202 in k4214 in loop in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[249]))){
/* compiler.scm: 900  g293 */
t7=t6;
f_4052(2,t7,f_4029(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[250]))){
/* compiler.scm: 900  g293 */
t7=t6;
f_4052(2,t7,f_4029(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[251]);
if(C_truep(t7)){
/* compiler.scm: 900  g293 */
t8=t6;
f_4052(2,t8,f_4029(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[252]);
if(C_truep(t8)){
/* compiler.scm: 900  g293 */
t9=t6;
f_4052(2,t9,f_4029(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[253]))){
/* compiler.scm: 900  g294 */
t9=t4;
f_4024(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 900  g294 */
t9=t4;
f_4024(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[255]);
if(C_truep(t9)){
/* compiler.scm: 900  g294 */
t10=t4;
f_4024(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t10)){
/* compiler.scm: 900  g294 */
t11=t4;
f_4024(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t11)){
/* compiler.scm: 900  g294 */
t12=t4;
f_4024(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t12)){
/* compiler.scm: 900  g294 */
t13=t4;
f_4024(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t13)){
/* compiler.scm: 900  g295 */
t14=t6;
f_4052(2,t14,f_3987(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[260]))){
/* compiler.scm: 900  g295 */
t14=t6;
f_4052(2,t14,f_3987(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[261]);
/* compiler.scm: 900  g295 */
t15=t6;
f_4052(2,t15,(C_truep(t14)?f_3987(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[262]))?f_3987(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4050 in k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[151],t2);
/* compiler.scm: 898  foreign-type-convert-argument */
t4=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g293 in k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_4029(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[151],t2);
t4=(C_word)C_a_i_list(&a,2,lf[246],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g294 in k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4024,NULL,2,t0,t1);}
/* compiler.scm: 912  syntax-error */
t2=C_retrieve(lf[109]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[248],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g295 in k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_3987(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[151],t2);
t4=(C_word)C_a_i_list(&a,2,lf[245],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[246],lf[245]);
t7=(C_word)C_a_i_list(&a,3,lf[247],lf[245],t6);
t8=(C_word)C_a_i_list(&a,3,lf[151],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k3975 in k3971 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[6],t2);
/* compiler.scm: 884  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2120(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3959 in k3951 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 451  ##sys#append */
t3=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3947 in k3940 in k3937 in a3916 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3949,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[243],t1));}

/* a3906 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 865  split-at */
t3=C_retrieve(lf[244]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3883 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3884,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 860  process-declaration */
t4=C_retrieve(lf[242]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3880 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
/* compiler.scm: 858  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2120(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3817,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3829,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  with-exception-handler */
t5=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3828 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3850 in a3828 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3851r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3851r(t0,t1,t2);}}

static void C_ccall f_3851r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  g256 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3856 in a3850 in a3828 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3834 in a3828 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 841  collapsable-literal? */
t3=C_retrieve(lf[236]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3840 in a3834 in a3828 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[151],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 843  eval */
t3=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3816 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  g256 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3822 in a3816 in a3810 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
/* compiler.scm: 839  quit */
t2=C_retrieve(lf[237]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[238],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3807 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[101],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 846  collapsable-literal? */
t8=C_retrieve(lf[236]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3756 in k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 847  ##sys#hash-table-set! */
t4=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 850  gensym */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}}

/* k3766 in k3756 in k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 851  ##sys#hash-table-set! */
t4=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3769 in k3766 in k3756 in k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 852  alist-cons */
t3=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3773 in k3769 in k3766 in k3756 in k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[101],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[175],((C_word*)t0)[7],t7);
/* compiler.scm: 855  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2120(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3759 in k3756 in k3745 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[234]);}

/* a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3690,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 827  ##sys#hash-table-set! */
t5=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3688 in a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 828  unzip1 */
t4=C_retrieve(lf[156]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3726 in k3688 in a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 828  append */
t2=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3692 in k3688 in a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3708,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3707 in k3692 in k3688 in a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3708,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[101],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[175],t3,t5));}

/* k3704 in k3692 in k3688 in a3685 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
/* compiler.scm: 830  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2120(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3667 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[159],t3);
/* compiler.scm: 826  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2120(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3674 in a3667 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 825  extract-mutable-constants */
t2=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 799  gensym */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 801  set-real-name! */
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 804  estimate-foreign-result-location-size */
t7=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3627 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 804  words */
t2=C_retrieve(lf[229]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[227],t2);
t4=(C_word)C_a_i_list(&a,2,lf[101],t1);
t5=(C_word)C_a_i_list(&a,3,lf[194],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[175],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3581(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3581(t11,C_SCHEME_END_OF_LIST);}}

/* k3579 in k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3581,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3589,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 817  fifth */
t3=C_retrieve(lf[225]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3589(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3587 in k3579 in k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 451  ##sys#append */
t3=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3575 in k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 818  alist-cons */
t4=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3571 in k3575 in k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 812  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3563 in k3604 in k3548 in k3542 in k3539 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[2],t1));}

/* k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 786  make-random-name */
t9=C_retrieve(lf[96]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3478(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3506,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 787  fifth */
t5=C_retrieve(lf[225]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3512 in k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 787  symbol->string */
t3=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3504 in k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3478(t3,t2);}

/* k3476 in k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3478,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  string-append */
t6=*((C_word*)lf[223]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[224],((C_word*)((C_word*)t0)[7])[1]);}

/* k3496 in k3476 in k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[221],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 792  alist-cons */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3488 in k3496 in k3476 in k3473 in k3464 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[222]);}

/* k3444 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[219]);}

/* k3390 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 766  gensym */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3393 in k3390 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 767  ##sys#hash-table-set! */
t4=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3396 in k3393 in k3390 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 768  cons* */
t3=C_retrieve(lf[218]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3400 in k3396 in k3393 in k3390 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 769  cons* */
t4=C_retrieve(lf[218]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3404 in k3400 in k3396 in k3393 in k3390 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3406,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[175],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[217]);
t8=(C_word)C_a_i_list(&a,3,lf[175],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[137],t4,t8);
/* compiler.scm: 770  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2120(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3323 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3337(2,t3,t1);}
else{
/* compiler.scm: 756  symbol->string */
t3=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3335 in k3323 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[214]);}

/* k3308 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 747  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3295 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 744  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3282 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 741  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3269 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 738  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3256 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 735  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3210,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3210(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[201]);}}

/* fold in k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 730  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2120(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3237,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 731  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2120(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3235 in fold in k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3241,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 731  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3210(t3,t2,((C_word*)t0)[2]);}

/* k3239 in k3235 in fold in k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3228 in fold in k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3202 in k3189 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 725  canonicalize-begin-body */
t2=C_retrieve(lf[200]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3176 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[199]);}

/* k3161 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 716  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2120(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3134 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 711  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2120(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3138 in k3134 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[179],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3113 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[2],t1));}

/* k3084 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 702  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4647(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3088 in k3084 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k3055 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 697  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4647(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3059 in k3055 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[193],t2));}

/* k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1951(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 661  get-line */
t7=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2895,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 662  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2120(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2898,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 664  ##sys#alias-global-hook */
t5=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2898(2,t4,C_SCHEME_UNDEFINED);}}

/* k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 667  lset-adjoin */
t5=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[128]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3006(t4,C_SCHEME_UNDEFINED);}}

/* k3030 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 668  lset-adjoin */
t4=C_retrieve(lf[190]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[128]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3034 in k3030 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3006(t3,t2);}

/* k3004 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3006,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 669  macro? */
t3=C_retrieve(lf[189]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3010 in k3004 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 673  sprintf */
t4=C_retrieve(lf[186]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[187],((C_word*)t0)[2]);}
else{
t4=t3;
f_3025(2,t4,lf[188]);}}
else{
t2=((C_word*)t0)[4];
f_2898(2,t2,C_SCHEME_UNDEFINED);}}

/* k3023 in k3010 in k3004 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 670  compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[184],lf[185],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3013 in k3010 in k3004 in k3001 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 674  undefine-macro! */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2898(2,t2,C_SCHEME_UNDEFINED);}}

/* k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 675  keyword? */
t4=C_retrieve(lf[182]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2991 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 676  compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[180],lf[181],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2901(2,t2,C_SCHEME_UNDEFINED);}}

/* k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 680  gensym */
t5=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  gensym */
t6=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[174],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2954 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 689  foreign-type-convert-argument */
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2985 in k2954 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2979,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 693  foreign-type-check */
t7=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2977 in k2985 in k2954 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[179],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[2],t2));}

/* k2911 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 681  foreign-type-convert-argument */
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2942 in k2911 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2932,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 684  foreign-type-check */
t7=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2930 in k2942 in k2911 in k2899 in k2896 in k2893 in k2890 in k2881 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[2],t2));}

/* k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  map */
t4=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[155]+1),((C_word*)t0)[7],t1);}

/* k2869 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 648  append */
t2=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2846 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 651  ##sys#canonicalize-body */
t5=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2862 in k2846 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2863,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2859 in k2846 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 650  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2120(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2849 in k2846 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2854,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 654  set-real-names! */
f_1963(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2852 in k2849 in k2846 in k2843 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[158],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2589,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 610  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2793 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 611  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2589(2,t2,C_SCHEME_UNDEFINED);}}

/* a2805 in k2793 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2806,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2799 in k2793 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
/* compiler.scm: 613  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[168]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[169]+1));}

/* k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 616  decompose-lambda-list */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2594,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[121]),t2);}

/* k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 620  map */
t4=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[155]+1),((C_word*)t0)[7],t1);}

/* k2790 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 620  append */
t2=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 621  ##sys#canonicalize-body */
t4=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2783 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2784,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 622  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2120(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 626  posq */
t5=C_retrieve(lf[166]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2775(t4,C_SCHEME_FALSE);}}

/* k2780 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2775(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2773 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 624  build-lambda-list */
t2=C_retrieve(lf[165]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[158],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 628  set-real-names! */
f_1963(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2625(t4,t2);}
else{
t4=f_1951(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2625(t6,(C_word)C_i_not(t5));}}

/* k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2625,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[158],((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 633  expand-profile-lambda */
t3=C_retrieve(lf[160]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2645(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2645(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2645(t5,C_SCHEME_FALSE);}}}}

/* k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2645,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 635  g162 */
t6=((C_word*)t0)[4];
f_2635(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 635  caadr */
t6=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2678(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2727 in k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[101]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 635  cdadr */
t4=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2678(t3,C_SCHEME_FALSE);}}

/* k2723 in k2727 in k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 635  cddadr */
t3=*((C_word*)lf[162]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2678(t2,C_SCHEME_FALSE);}}

/* k2719 in k2723 in k2727 in k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2678(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2678(t2,C_SCHEME_FALSE);}}

/* k2676 in k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 635  cadadr */
t3=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2683 in k2676 in k2643 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 635  g162 */
t3=((C_word*)t0)[3];
f_2635(t3,((C_word*)t0)[2],t1);}

/* g162 in k2623 in k2614 in k2608 in k2605 in k2602 in k2599 in k2596 in a2593 in k2587 in k2578 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2635(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2635,NULL,3,t0,t1,t2);}
/* compiler.scm: 637  process-lambda-documentation */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 595  unzip1 */
t4=C_retrieve(lf[156]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2515,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[121]),t1);}

/* k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 597  map */
t4=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[155]+1),((C_word*)t0)[2],t1);}

/* k2566 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 597  append */
t2=*((C_word*)lf[154]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 598  set-real-names! */
f_1963(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 599  map */
t4=*((C_word*)lf[153]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2547 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2548,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2556,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 600  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2120(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2554 in a2547 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2526 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 602  ##sys#canonicalize-body */
t6=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2541 in k2526 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2534 in k2526 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 602  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2530 in k2526 in k2519 in k2516 in k2513 in k2510 in k2504 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[151],((C_word*)t0)[2],t1));}

/* loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2392(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2392,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[135]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2402,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 570  cadar */
t4=*((C_word*)lf[150]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2413,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2413,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2478(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 574  feature? */
t7=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2478(2,t6,C_SCHEME_FALSE);}}}

/* k2485 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2478(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 576  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[148]);}}

/* k2495 in k2485 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 575  ##sys#find-extension */
t2=C_retrieve(lf[146]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2476 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 582  ##sys#extension-information */
t4=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2440(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2440(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 578  compiler-warning */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[144],lf[145],((C_word*)t0)[2]);}}

/* k2450 in k2476 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[139],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2440(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2440(t2,C_SCHEME_FALSE);}}

/* a2465 in k2450 in k2476 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2466,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[140]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2462 in k2450 in k2476 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2440(t2,C_SCHEME_TRUE);}

/* k2438 in k2476 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2417(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 588  lookup-exports-file */
t2=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2415 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 589  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2392(t4,t2,t3);}

/* k2422 in k2415 in a2412 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[137],((C_word*)t0)[2],t1));}

/* a2406 in k2400 in loop in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
/* compiler.scm: 571  ##sys#do-the-right-thing */
t2=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2384 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 566  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2120(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2352 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[131]),t1);}

/* k2355 in k2352 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 560  ##sys#hash-table-update! */
t5=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[130],t3,t4);}

/* a2367 in k2355 in k2352 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2361 in k2355 in k2352 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2362,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[127]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[128]+1),t2,((C_word*)t0)[2]);}

/* k2358 in k2355 in k2352 in k2343 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[126]);}

/* k2310 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 548  gensym */
t4=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[122]);}}

/* k2322 in k2310 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 549  alist-cons */
t3=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2326 in k2322 in k2310 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2285 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2239 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 529  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2120(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2246 in k2239 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2120(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2250 in k2246 in k2239 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2256,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2256(2,t4,lf[113]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 533  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2120(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2254 in k2250 in k2246 in k2239 in k2216 in k2198 in k2191 in k2188 in k2182 in k2155 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[112],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2143 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 502  ##sys#alias-global-hook */
t2=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2137 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2033,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 471  ##sys#hash-table-ref */
t7=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2033(2,t7,C_SCHEME_FALSE);}}

/* k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 472  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2120(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 473  ##sys#hash-table-ref */
t3=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2046(2,t3,C_SCHEME_FALSE);}}}

/* k2044 in k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 475  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2120(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 479  final-foreign-type */
t5=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 487  final-foreign-type */
t6=C_retrieve(lf[105]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2092 in k2044 in k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[106],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 490  finish-foreign-result */
t6=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2102 in k2092 in k2044 in k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 489  foreign-type-convert-result */
t2=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2062 in k2044 in k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[102],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 482  finish-foreign-result */
t6=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2072 in k2062 in k2044 in k2031 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 481  foreign-type-convert-result */
t2=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1987,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[101]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_1994(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_1994(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_1994(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1994(t4,C_SCHEME_FALSE);}}

/* k1992 in unquotify in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_1994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_1963(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1963,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1969,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 458  for-each */
t5=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1968 in set-real-names! in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1969,4,t0,t1,t2,t3);}
/* compiler.scm: 458  set-real-name! */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_1951(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 428  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 429  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1944 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1881(2,t3,t2);}

/* k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 431  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 432  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1937 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1884(2,t3,t2);}

/* k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 434  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1930 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1887(2,t3,t2);}

/* k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 436  make-random-name */
t3=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[97]);}

/* k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 437  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[88]))){
/* compiler.scm: 439  vector-fill! */
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[88]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 440  make-vector */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1923 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_1898(2,t3,t2);}

/* k1896 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 442  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1916 in k1896 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1901(2,t3,t2);}

/* k1899 in k1896 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 445  vector-fill! */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 446  make-vector */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1909 in k1899 in k1896 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[815] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1759compiler.scm",(void*)f_1759},
{"f_1762compiler.scm",(void*)f_1762},
{"f_1765compiler.scm",(void*)f_1765},
{"f_1772compiler.scm",(void*)f_1772},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1780compiler.scm",(void*)f_1780},
{"f_1784compiler.scm",(void*)f_1784},
{"f_1788compiler.scm",(void*)f_1788},
{"f_1792compiler.scm",(void*)f_1792},
{"f_10110compiler.scm",(void*)f_10110},
{"f_11167compiler.scm",(void*)f_11167},
{"f_11170compiler.scm",(void*)f_11170},
{"f_11173compiler.scm",(void*)f_11173},
{"f_11176compiler.scm",(void*)f_11176},
{"f_11179compiler.scm",(void*)f_11179},
{"f_10967compiler.scm",(void*)f_10967},
{"f_10973compiler.scm",(void*)f_10973},
{"f_10200compiler.scm",(void*)f_10200},
{"f_10956compiler.scm",(void*)f_10956},
{"f_10953compiler.scm",(void*)f_10953},
{"f_10866compiler.scm",(void*)f_10866},
{"f_10930compiler.scm",(void*)f_10930},
{"f_10943compiler.scm",(void*)f_10943},
{"f_10924compiler.scm",(void*)f_10924},
{"f_10914compiler.scm",(void*)f_10914},
{"f_10887compiler.scm",(void*)f_10887},
{"f_10890compiler.scm",(void*)f_10890},
{"f_10838compiler.scm",(void*)f_10838},
{"f_10841compiler.scm",(void*)f_10841},
{"f_10795compiler.scm",(void*)f_10795},
{"f_10807compiler.scm",(void*)f_10807},
{"f_10798compiler.scm",(void*)f_10798},
{"f_10801compiler.scm",(void*)f_10801},
{"f_10675compiler.scm",(void*)f_10675},
{"f_10776compiler.scm",(void*)f_10776},
{"f_10764compiler.scm",(void*)f_10764},
{"f_10703compiler.scm",(void*)f_10703},
{"f_10709compiler.scm",(void*)f_10709},
{"f_10733compiler.scm",(void*)f_10733},
{"f_10725compiler.scm",(void*)f_10725},
{"f_10691compiler.scm",(void*)f_10691},
{"f_10634compiler.scm",(void*)f_10634},
{"f_10646compiler.scm",(void*)f_10646},
{"f_10650compiler.scm",(void*)f_10650},
{"f_10638compiler.scm",(void*)f_10638},
{"f_10450compiler.scm",(void*)f_10450},
{"f_10571compiler.scm",(void*)f_10571},
{"f_10577compiler.scm",(void*)f_10577},
{"f_10602compiler.scm",(void*)f_10602},
{"f_10583compiler.scm",(void*)f_10583},
{"f_10457compiler.scm",(void*)f_10457},
{"f_10562compiler.scm",(void*)f_10562},
{"f_10460compiler.scm",(void*)f_10460},
{"f_10463compiler.scm",(void*)f_10463},
{"f_10466compiler.scm",(void*)f_10466},
{"f_10504compiler.scm",(void*)f_10504},
{"f_10530compiler.scm",(void*)f_10530},
{"f_10511compiler.scm",(void*)f_10511},
{"f_10515compiler.scm",(void*)f_10515},
{"f_10488compiler.scm",(void*)f_10488},
{"f_10394compiler.scm",(void*)f_10394},
{"f_10403compiler.scm",(void*)f_10403},
{"f_10397compiler.scm",(void*)f_10397},
{"f_10378compiler.scm",(void*)f_10378},
{"f_10351compiler.scm",(void*)f_10351},
{"f_10334compiler.scm",(void*)f_10334},
{"f_10330compiler.scm",(void*)f_10330},
{"f_10323compiler.scm",(void*)f_10323},
{"f_10306compiler.scm",(void*)f_10306},
{"f_10302compiler.scm",(void*)f_10302},
{"f_10278compiler.scm",(void*)f_10278},
{"f_10258compiler.scm",(void*)f_10258},
{"f_10113compiler.scm",(void*)f_10113},
{"f_10117compiler.scm",(void*)f_10117},
{"f_10132compiler.scm",(void*)f_10132},
{"f_10142compiler.scm",(void*)f_10142},
{"f_10147compiler.scm",(void*)f_10147},
{"f_10192compiler.scm",(void*)f_10192},
{"f_10151compiler.scm",(void*)f_10151},
{"f_10157compiler.scm",(void*)f_10157},
{"f_10167compiler.scm",(void*)f_10167},
{"f_10979compiler.scm",(void*)f_10979},
{"f_10986compiler.scm",(void*)f_10986},
{"f_11048compiler.scm",(void*)f_11048},
{"f_11038compiler.scm",(void*)f_11038},
{"f_11012compiler.scm",(void*)f_11012},
{"f_10998compiler.scm",(void*)f_10998},
{"f_11073compiler.scm",(void*)f_11073},
{"f_11089compiler.scm",(void*)f_11089},
{"f_11096compiler.scm",(void*)f_11096},
{"f_11103compiler.scm",(void*)f_11103},
{"f_11077compiler.scm",(void*)f_11077},
{"f_11087compiler.scm",(void*)f_11087},
{"f_11059compiler.scm",(void*)f_11059},
{"f_11067compiler.scm",(void*)f_11067},
{"f_11105compiler.scm",(void*)f_11105},
{"f_11118compiler.scm",(void*)f_11118},
{"f_10101compiler.scm",(void*)f_10101},
{"f_10092compiler.scm",(void*)f_10092},
{"f_10083compiler.scm",(void*)f_10083},
{"f_10074compiler.scm",(void*)f_10074},
{"f_10065compiler.scm",(void*)f_10065},
{"f_10056compiler.scm",(void*)f_10056},
{"f_10047compiler.scm",(void*)f_10047},
{"f_10038compiler.scm",(void*)f_10038},
{"f_10029compiler.scm",(void*)f_10029},
{"f_10020compiler.scm",(void*)f_10020},
{"f_10011compiler.scm",(void*)f_10011},
{"f_10002compiler.scm",(void*)f_10002},
{"f_9993compiler.scm",(void*)f_9993},
{"f_9984compiler.scm",(void*)f_9984},
{"f_9975compiler.scm",(void*)f_9975},
{"f_9966compiler.scm",(void*)f_9966},
{"f_9957compiler.scm",(void*)f_9957},
{"f_9948compiler.scm",(void*)f_9948},
{"f_9939compiler.scm",(void*)f_9939},
{"f_9930compiler.scm",(void*)f_9930},
{"f_9921compiler.scm",(void*)f_9921},
{"f_9912compiler.scm",(void*)f_9912},
{"f_9903compiler.scm",(void*)f_9903},
{"f_9894compiler.scm",(void*)f_9894},
{"f_9885compiler.scm",(void*)f_9885},
{"f_9876compiler.scm",(void*)f_9876},
{"f_9867compiler.scm",(void*)f_9867},
{"f_9858compiler.scm",(void*)f_9858},
{"f_9849compiler.scm",(void*)f_9849},
{"f_9840compiler.scm",(void*)f_9840},
{"f_9834compiler.scm",(void*)f_9834},
{"f_9828compiler.scm",(void*)f_9828},
{"f_8594compiler.scm",(void*)f_8594},
{"f_9795compiler.scm",(void*)f_9795},
{"f_9798compiler.scm",(void*)f_9798},
{"f_9801compiler.scm",(void*)f_9801},
{"f_9804compiler.scm",(void*)f_9804},
{"f_9807compiler.scm",(void*)f_9807},
{"f_9822compiler.scm",(void*)f_9822},
{"f_9820compiler.scm",(void*)f_9820},
{"f_9810compiler.scm",(void*)f_9810},
{"f_9647compiler.scm",(void*)f_9647},
{"f_9653compiler.scm",(void*)f_9653},
{"f_8958compiler.scm",(void*)f_8958},
{"f_8977compiler.scm",(void*)f_8977},
{"f_9010compiler.scm",(void*)f_9010},
{"f_9537compiler.scm",(void*)f_9537},
{"f_9533compiler.scm",(void*)f_9533},
{"f_9526compiler.scm",(void*)f_9526},
{"f_9377compiler.scm",(void*)f_9377},
{"f_9383compiler.scm",(void*)f_9383},
{"f_9453compiler.scm",(void*)f_9453},
{"f_9483compiler.scm",(void*)f_9483},
{"f_9466compiler.scm",(void*)f_9466},
{"f_9470compiler.scm",(void*)f_9470},
{"f_9392compiler.scm",(void*)f_9392},
{"f_9439compiler.scm",(void*)f_9439},
{"f_9443compiler.scm",(void*)f_9443},
{"f_9419compiler.scm",(void*)f_9419},
{"f_9415compiler.scm",(void*)f_9415},
{"f_9106compiler.scm",(void*)f_9106},
{"f_9355compiler.scm",(void*)f_9355},
{"f_9110compiler.scm",(void*)f_9110},
{"f_9353compiler.scm",(void*)f_9353},
{"f_9113compiler.scm",(void*)f_9113},
{"f_9116compiler.scm",(void*)f_9116},
{"f_9122compiler.scm",(void*)f_9122},
{"f_9128compiler.scm",(void*)f_9128},
{"f_9134compiler.scm",(void*)f_9134},
{"f_9320compiler.scm",(void*)f_9320},
{"f_9323compiler.scm",(void*)f_9323},
{"f_9137compiler.scm",(void*)f_9137},
{"f_9296compiler.scm",(void*)f_9296},
{"f_9281compiler.scm",(void*)f_9281},
{"f_9277compiler.scm",(void*)f_9277},
{"f_9211compiler.scm",(void*)f_9211},
{"f_9236compiler.scm",(void*)f_9236},
{"f_9242compiler.scm",(void*)f_9242},
{"f_9253compiler.scm",(void*)f_9253},
{"f_9240compiler.scm",(void*)f_9240},
{"f_9222compiler.scm",(void*)f_9222},
{"f_9214compiler.scm",(void*)f_9214},
{"f_9199compiler.scm",(void*)f_9199},
{"f_9207compiler.scm",(void*)f_9207},
{"f_9160compiler.scm",(void*)f_9160},
{"f_9190compiler.scm",(void*)f_9190},
{"f_9182compiler.scm",(void*)f_9182},
{"f_9178compiler.scm",(void*)f_9178},
{"f_9174compiler.scm",(void*)f_9174},
{"f_9163compiler.scm",(void*)f_9163},
{"f_9031compiler.scm",(void*)f_9031},
{"f_9034compiler.scm",(void*)f_9034},
{"f_9086compiler.scm",(void*)f_9086},
{"f_9050compiler.scm",(void*)f_9050},
{"f_9079compiler.scm",(void*)f_9079},
{"f_9071compiler.scm",(void*)f_9071},
{"f_9016compiler.scm",(void*)f_9016},
{"f_8989compiler.scm",(void*)f_8989},
{"f_8995compiler.scm",(void*)f_8995},
{"f_9659compiler.scm",(void*)f_9659},
{"f_9666compiler.scm",(void*)f_9666},
{"f_9682compiler.scm",(void*)f_9682},
{"f_8624compiler.scm",(void*)f_8624},
{"f_8643compiler.scm",(void*)f_8643},
{"f_8922compiler.scm",(void*)f_8922},
{"f_8883compiler.scm",(void*)f_8883},
{"f_9698compiler.scm",(void*)f_9698},
{"f_9736compiler.scm",(void*)f_9736},
{"f_9762compiler.scm",(void*)f_9762},
{"f_9748compiler.scm",(void*)f_9748},
{"f_9727compiler.scm",(void*)f_9727},
{"f_9696compiler.scm",(void*)f_9696},
{"f_8896compiler.scm",(void*)f_8896},
{"f_8899compiler.scm",(void*)f_8899},
{"f_8910compiler.scm",(void*)f_8910},
{"f_8847compiler.scm",(void*)f_8847},
{"f_8739compiler.scm",(void*)f_8739},
{"f_8745compiler.scm",(void*)f_8745},
{"f_8757compiler.scm",(void*)f_8757},
{"f_8760compiler.scm",(void*)f_8760},
{"f_8763compiler.scm",(void*)f_8763},
{"f_8781compiler.scm",(void*)f_8781},
{"f_8788compiler.scm",(void*)f_8788},
{"f_8766compiler.scm",(void*)f_8766},
{"f_8769compiler.scm",(void*)f_8769},
{"f_8772compiler.scm",(void*)f_8772},
{"f_8733compiler.scm",(void*)f_8733},
{"f_8723compiler.scm",(void*)f_8723},
{"f_8706compiler.scm",(void*)f_8706},
{"f_8711compiler.scm",(void*)f_8711},
{"f_8664compiler.scm",(void*)f_8664},
{"f_8681compiler.scm",(void*)f_8681},
{"f_8668compiler.scm",(void*)f_8668},
{"f_8679compiler.scm",(void*)f_8679},
{"f_8654compiler.scm",(void*)f_8654},
{"f_8613compiler.scm",(void*)f_8613},
{"f_8622compiler.scm",(void*)f_8622},
{"f_8603compiler.scm",(void*)f_8603},
{"f_8608compiler.scm",(void*)f_8608},
{"f_8597compiler.scm",(void*)f_8597},
{"f_7069compiler.scm",(void*)f_7069},
{"f_7073compiler.scm",(void*)f_7073},
{"f_7823compiler.scm",(void*)f_7823},
{"f_7826compiler.scm",(void*)f_7826},
{"f_7830compiler.scm",(void*)f_7830},
{"f_7833compiler.scm",(void*)f_7833},
{"f_7846compiler.scm",(void*)f_7846},
{"f_8481compiler.scm",(void*)f_8481},
{"f_7850compiler.scm",(void*)f_7850},
{"f_8446compiler.scm",(void*)f_8446},
{"f_7857compiler.scm",(void*)f_7857},
{"f_8392compiler.scm",(void*)f_8392},
{"f_8395compiler.scm",(void*)f_8395},
{"f_8407compiler.scm",(void*)f_8407},
{"f_8401compiler.scm",(void*)f_8401},
{"f_7860compiler.scm",(void*)f_7860},
{"f_7863compiler.scm",(void*)f_7863},
{"f_8375compiler.scm",(void*)f_8375},
{"f_8367compiler.scm",(void*)f_8367},
{"f_8335compiler.scm",(void*)f_8335},
{"f_8341compiler.scm",(void*)f_8341},
{"f_7866compiler.scm",(void*)f_7866},
{"f_8297compiler.scm",(void*)f_8297},
{"f_8306compiler.scm",(void*)f_8306},
{"f_8309compiler.scm",(void*)f_8309},
{"f_7869compiler.scm",(void*)f_7869},
{"f_8198compiler.scm",(void*)f_8198},
{"f_8216compiler.scm",(void*)f_8216},
{"f_8259compiler.scm",(void*)f_8259},
{"f_8284compiler.scm",(void*)f_8284},
{"f_8280compiler.scm",(void*)f_8280},
{"f_8266compiler.scm",(void*)f_8266},
{"f_8269compiler.scm",(void*)f_8269},
{"f_8220compiler.scm",(void*)f_8220},
{"f_8226compiler.scm",(void*)f_8226},
{"f_7872compiler.scm",(void*)f_7872},
{"f_8176compiler.scm",(void*)f_8176},
{"f_8162compiler.scm",(void*)f_8162},
{"f_8169compiler.scm",(void*)f_8169},
{"f_8150compiler.scm",(void*)f_8150},
{"f_8135compiler.scm",(void*)f_8135},
{"f_7875compiler.scm",(void*)f_7875},
{"f_8047compiler.scm",(void*)f_8047},
{"f_8121compiler.scm",(void*)f_8121},
{"f_8053compiler.scm",(void*)f_8053},
{"f_8111compiler.scm",(void*)f_8111},
{"f_8103compiler.scm",(void*)f_8103},
{"f_8099compiler.scm",(void*)f_8099},
{"f_8056compiler.scm",(void*)f_8056},
{"f_8059compiler.scm",(void*)f_8059},
{"f_7878compiler.scm",(void*)f_7878},
{"f_7906compiler.scm",(void*)f_7906},
{"f_7927compiler.scm",(void*)f_7927},
{"f_7948compiler.scm",(void*)f_7948},
{"f_7954compiler.scm",(void*)f_7954},
{"f_7881compiler.scm",(void*)f_7881},
{"f_7887compiler.scm",(void*)f_7887},
{"f_7891compiler.scm",(void*)f_7891},
{"f_7836compiler.scm",(void*)f_7836},
{"f_7840compiler.scm",(void*)f_7840},
{"f_7843compiler.scm",(void*)f_7843},
{"f_7798compiler.scm",(void*)f_7798},
{"f_7808compiler.scm",(void*)f_7808},
{"f_7816compiler.scm",(void*)f_7816},
{"f_7784compiler.scm",(void*)f_7784},
{"f_7792compiler.scm",(void*)f_7792},
{"f_7663compiler.scm",(void*)f_7663},
{"f_7669compiler.scm",(void*)f_7669},
{"f_7082compiler.scm",(void*)f_7082},
{"f_7104compiler.scm",(void*)f_7104},
{"f_7625compiler.scm",(void*)f_7625},
{"f_7619compiler.scm",(void*)f_7619},
{"f_7592compiler.scm",(void*)f_7592},
{"f_7601compiler.scm",(void*)f_7601},
{"f_7586compiler.scm",(void*)f_7586},
{"f_7511compiler.scm",(void*)f_7511},
{"f_7540compiler.scm",(void*)f_7540},
{"f_7555compiler.scm",(void*)f_7555},
{"f_7559compiler.scm",(void*)f_7559},
{"f_7546compiler.scm",(void*)f_7546},
{"f_7514compiler.scm",(void*)f_7514},
{"f_7537compiler.scm",(void*)f_7537},
{"f_7517compiler.scm",(void*)f_7517},
{"f_7520compiler.scm",(void*)f_7520},
{"f_7523compiler.scm",(void*)f_7523},
{"f_7401compiler.scm",(void*)f_7401},
{"f_7493compiler.scm",(void*)f_7493},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7483compiler.scm",(void*)f_7483},
{"f_7487compiler.scm",(void*)f_7487},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7414compiler.scm",(void*)f_7414},
{"f_7468compiler.scm",(void*)f_7468},
{"f_7417compiler.scm",(void*)f_7417},
{"f_7420compiler.scm",(void*)f_7420},
{"f_7453compiler.scm",(void*)f_7453},
{"f_7423compiler.scm",(void*)f_7423},
{"f_7450compiler.scm",(void*)f_7450},
{"f_7426compiler.scm",(void*)f_7426},
{"f_7357compiler.scm",(void*)f_7357},
{"f_7376compiler.scm",(void*)f_7376},
{"f_7361compiler.scm",(void*)f_7361},
{"f_7374compiler.scm",(void*)f_7374},
{"f_7365compiler.scm",(void*)f_7365},
{"f_7290compiler.scm",(void*)f_7290},
{"f_7295compiler.scm",(void*)f_7295},
{"f_7322compiler.scm",(void*)f_7322},
{"f_7325compiler.scm",(void*)f_7325},
{"f_7328compiler.scm",(void*)f_7328},
{"f_7313compiler.scm",(void*)f_7313},
{"f_7218compiler.scm",(void*)f_7218},
{"f_7266compiler.scm",(void*)f_7266},
{"f_7229compiler.scm",(void*)f_7229},
{"f_7248compiler.scm",(void*)f_7248},
{"f_7195compiler.scm",(void*)f_7195},
{"f_7198compiler.scm",(void*)f_7198},
{"f_7159compiler.scm",(void*)f_7159},
{"f_7116compiler.scm",(void*)f_7116},
{"f_7147compiler.scm",(void*)f_7147},
{"f_7675compiler.scm",(void*)f_7675},
{"f_7688compiler.scm",(void*)f_7688},
{"f_7748compiler.scm",(void*)f_7748},
{"f_7697compiler.scm",(void*)f_7697},
{"f_7700compiler.scm",(void*)f_7700},
{"f_7703compiler.scm",(void*)f_7703},
{"f_7778compiler.scm",(void*)f_7778},
{"f_7075compiler.scm",(void*)f_7075},
{"f_7060compiler.scm",(void*)f_7060},
{"f_7051compiler.scm",(void*)f_7051},
{"f_7042compiler.scm",(void*)f_7042},
{"f_7033compiler.scm",(void*)f_7033},
{"f_7024compiler.scm",(void*)f_7024},
{"f_7015compiler.scm",(void*)f_7015},
{"f_7006compiler.scm",(void*)f_7006},
{"f_6997compiler.scm",(void*)f_6997},
{"f_6988compiler.scm",(void*)f_6988},
{"f_6979compiler.scm",(void*)f_6979},
{"f_6973compiler.scm",(void*)f_6973},
{"f_6967compiler.scm",(void*)f_6967},
{"f_6292compiler.scm",(void*)f_6292},
{"f_6939compiler.scm",(void*)f_6939},
{"f_6854compiler.scm",(void*)f_6854},
{"f_6860compiler.scm",(void*)f_6860},
{"f_6880compiler.scm",(void*)f_6880},
{"f_6898compiler.scm",(void*)f_6898},
{"f_6907compiler.scm",(void*)f_6907},
{"f_6933compiler.scm",(void*)f_6933},
{"f_6921compiler.scm",(void*)f_6921},
{"f_6874compiler.scm",(void*)f_6874},
{"f_6838compiler.scm",(void*)f_6838},
{"f_6844compiler.scm",(void*)f_6844},
{"f_6713compiler.scm",(void*)f_6713},
{"f_6717compiler.scm",(void*)f_6717},
{"f_6720compiler.scm",(void*)f_6720},
{"f_6774compiler.scm",(void*)f_6774},
{"f_6770compiler.scm",(void*)f_6770},
{"f_6766compiler.scm",(void*)f_6766},
{"f_6745compiler.scm",(void*)f_6745},
{"f_6751compiler.scm",(void*)f_6751},
{"f_6762compiler.scm",(void*)f_6762},
{"f_6755compiler.scm",(void*)f_6755},
{"f_6743compiler.scm",(void*)f_6743},
{"f_6339compiler.scm",(void*)f_6339},
{"f_6361compiler.scm",(void*)f_6361},
{"f_6627compiler.scm",(void*)f_6627},
{"f_6784compiler.scm",(void*)f_6784},
{"f_6787compiler.scm",(void*)f_6787},
{"f_6832compiler.scm",(void*)f_6832},
{"f_6828compiler.scm",(void*)f_6828},
{"f_6824compiler.scm",(void*)f_6824},
{"f_6820compiler.scm",(void*)f_6820},
{"f_6592compiler.scm",(void*)f_6592},
{"f_6618compiler.scm",(void*)f_6618},
{"f_6542compiler.scm",(void*)f_6542},
{"f_6551compiler.scm",(void*)f_6551},
{"f_6579compiler.scm",(void*)f_6579},
{"f_6575compiler.scm",(void*)f_6575},
{"f_6529compiler.scm",(void*)f_6529},
{"f_6467compiler.scm",(void*)f_6467},
{"f_6490compiler.scm",(void*)f_6490},
{"f_6504compiler.scm",(void*)f_6504},
{"f_6373compiler.scm",(void*)f_6373},
{"f_6376compiler.scm",(void*)f_6376},
{"f_6452compiler.scm",(void*)f_6452},
{"f_6448compiler.scm",(void*)f_6448},
{"f_6444compiler.scm",(void*)f_6444},
{"f_6417compiler.scm",(void*)f_6417},
{"f_6428compiler.scm",(void*)f_6428},
{"f_6432compiler.scm",(void*)f_6432},
{"f_6411compiler.scm",(void*)f_6411},
{"f_6377compiler.scm",(void*)f_6377},
{"f_6388compiler.scm",(void*)f_6388},
{"f_6295compiler.scm",(void*)f_6295},
{"f_6299compiler.scm",(void*)f_6299},
{"f_6322compiler.scm",(void*)f_6322},
{"f_6333compiler.scm",(void*)f_6333},
{"f_6316compiler.scm",(void*)f_6316},
{"f_6202compiler.scm",(void*)f_6202},
{"f_6234compiler.scm",(void*)f_6234},
{"f_6253compiler.scm",(void*)f_6253},
{"f_6276compiler.scm",(void*)f_6276},
{"f_6259compiler.scm",(void*)f_6259},
{"f_6205compiler.scm",(void*)f_6205},
{"f_6211compiler.scm",(void*)f_6211},
{"f_6221compiler.scm",(void*)f_6221},
{"f_6121compiler.scm",(void*)f_6121},
{"f_6125compiler.scm",(void*)f_6125},
{"f_6128compiler.scm",(void*)f_6128},
{"f_6131compiler.scm",(void*)f_6131},
{"f_6147compiler.scm",(void*)f_6147},
{"f_6134compiler.scm",(void*)f_6134},
{"f_6137compiler.scm",(void*)f_6137},
{"f_6140compiler.scm",(void*)f_6140},
{"f_6084compiler.scm",(void*)f_6084},
{"f_6107compiler.scm",(void*)f_6107},
{"f_6094compiler.scm",(void*)f_6094},
{"f_6097compiler.scm",(void*)f_6097},
{"f_6100compiler.scm",(void*)f_6100},
{"f_6047compiler.scm",(void*)f_6047},
{"f_6070compiler.scm",(void*)f_6070},
{"f_6057compiler.scm",(void*)f_6057},
{"f_6060compiler.scm",(void*)f_6060},
{"f_6063compiler.scm",(void*)f_6063},
{"f_6002compiler.scm",(void*)f_6002},
{"f_6009compiler.scm",(void*)f_6009},
{"f_6015compiler.scm",(void*)f_6015},
{"f_5957compiler.scm",(void*)f_5957},
{"f_5964compiler.scm",(void*)f_5964},
{"f_5970compiler.scm",(void*)f_5970},
{"f_5803compiler.scm",(void*)f_5803},
{"f_5951compiler.scm",(void*)f_5951},
{"f_5807compiler.scm",(void*)f_5807},
{"f_5810compiler.scm",(void*)f_5810},
{"f_5813compiler.scm",(void*)f_5813},
{"f_5816compiler.scm",(void*)f_5816},
{"f_5819compiler.scm",(void*)f_5819},
{"f_5945compiler.scm",(void*)f_5945},
{"f_5829compiler.scm",(void*)f_5829},
{"f_5920compiler.scm",(void*)f_5920},
{"f_5928compiler.scm",(void*)f_5928},
{"f_5832compiler.scm",(void*)f_5832},
{"f_5872compiler.scm",(void*)f_5872},
{"f_5875compiler.scm",(void*)f_5875},
{"f_5894compiler.scm",(void*)f_5894},
{"f_5890compiler.scm",(void*)f_5890},
{"f_5886compiler.scm",(void*)f_5886},
{"f_5865compiler.scm",(void*)f_5865},
{"f_5855compiler.scm",(void*)f_5855},
{"f_5843compiler.scm",(void*)f_5843},
{"f_5794compiler.scm",(void*)f_5794},
{"f_5785compiler.scm",(void*)f_5785},
{"f_5776compiler.scm",(void*)f_5776},
{"f_5767compiler.scm",(void*)f_5767},
{"f_5758compiler.scm",(void*)f_5758},
{"f_5749compiler.scm",(void*)f_5749},
{"f_5740compiler.scm",(void*)f_5740},
{"f_5731compiler.scm",(void*)f_5731},
{"f_5722compiler.scm",(void*)f_5722},
{"f_5713compiler.scm",(void*)f_5713},
{"f_5704compiler.scm",(void*)f_5704},
{"f_5695compiler.scm",(void*)f_5695},
{"f_5686compiler.scm",(void*)f_5686},
{"f_5677compiler.scm",(void*)f_5677},
{"f_5668compiler.scm",(void*)f_5668},
{"f_5659compiler.scm",(void*)f_5659},
{"f_5653compiler.scm",(void*)f_5653},
{"f_5647compiler.scm",(void*)f_5647},
{"f_4702compiler.scm",(void*)f_4702},
{"f_4756compiler.scm",(void*)f_4756},
{"f_4760compiler.scm",(void*)f_4760},
{"f_5616compiler.scm",(void*)f_5616},
{"f_5626compiler.scm",(void*)f_5626},
{"f_5621compiler.scm",(void*)f_5621},
{"f_5588compiler.scm",(void*)f_5588},
{"f_5594compiler.scm",(void*)f_5594},
{"f_5570compiler.scm",(void*)f_5570},
{"f_5574compiler.scm",(void*)f_5574},
{"f_5542compiler.scm",(void*)f_5542},
{"f_5549compiler.scm",(void*)f_5549},
{"f_5525compiler.scm",(void*)f_5525},
{"f_5451compiler.scm",(void*)f_5451},
{"f_5455compiler.scm",(void*)f_5455},
{"f_5438compiler.scm",(void*)f_5438},
{"f_5430compiler.scm",(void*)f_5430},
{"f_5434compiler.scm",(void*)f_5434},
{"f_5275compiler.scm",(void*)f_5275},
{"f_5385compiler.scm",(void*)f_5385},
{"f_5374compiler.scm",(void*)f_5374},
{"f_5378compiler.scm",(void*)f_5378},
{"f_5345compiler.scm",(void*)f_5345},
{"f_5320compiler.scm",(void*)f_5320},
{"f_5295compiler.scm",(void*)f_5295},
{"f_5262compiler.scm",(void*)f_5262},
{"f_5214compiler.scm",(void*)f_5214},
{"f_5223compiler.scm",(void*)f_5223},
{"f_5221compiler.scm",(void*)f_5221},
{"f_5124compiler.scm",(void*)f_5124},
{"f_5102compiler.scm",(void*)f_5102},
{"f_5106compiler.scm",(void*)f_5106},
{"f_5075compiler.scm",(void*)f_5075},
{"f_5079compiler.scm",(void*)f_5079},
{"f_5061compiler.scm",(void*)f_5061},
{"f_5065compiler.scm",(void*)f_5065},
{"f_5040compiler.scm",(void*)f_5040},
{"f_5026compiler.scm",(void*)f_5026},
{"f_4943compiler.scm",(void*)f_4943},
{"f_4926compiler.scm",(void*)f_4926},
{"f_4930compiler.scm",(void*)f_4930},
{"f_4897compiler.scm",(void*)f_4897},
{"f_4872compiler.scm",(void*)f_4872},
{"f_4825compiler.scm",(void*)f_4825},
{"f_4855compiler.scm",(void*)f_4855},
{"f_4831compiler.scm",(void*)f_4831},
{"f_4834compiler.scm",(void*)f_4834},
{"f_4841compiler.scm",(void*)f_4841},
{"f_4837compiler.scm",(void*)f_4837},
{"f_4775compiler.scm",(void*)f_4775},
{"f_4778compiler.scm",(void*)f_4778},
{"f_4812compiler.scm",(void*)f_4812},
{"f_4806compiler.scm",(void*)f_4806},
{"f_4787compiler.scm",(void*)f_4787},
{"f_4796compiler.scm",(void*)f_4796},
{"f_4804compiler.scm",(void*)f_4804},
{"f_4790compiler.scm",(void*)f_4790},
{"f_4794compiler.scm",(void*)f_4794},
{"f_4766compiler.scm",(void*)f_4766},
{"f_4705compiler.scm",(void*)f_4705},
{"f_4728compiler.scm",(void*)f_4728},
{"f_4718compiler.scm",(void*)f_4718},
{"f_1948compiler.scm",(void*)f_1948},
{"f_4697compiler.scm",(void*)f_4697},
{"f_4660compiler.scm",(void*)f_4660},
{"f_4663compiler.scm",(void*)f_4663},
{"f_4678compiler.scm",(void*)f_4678},
{"f_4687compiler.scm",(void*)f_4687},
{"f_4691compiler.scm",(void*)f_4691},
{"f_4674compiler.scm",(void*)f_4674},
{"f_4647compiler.scm",(void*)f_4647},
{"f_4653compiler.scm",(void*)f_4653},
{"f_2120compiler.scm",(void*)f_2120},
{"f_2157compiler.scm",(void*)f_2157},
{"f_4508compiler.scm",(void*)f_4508},
{"f_4623compiler.scm",(void*)f_4623},
{"f_4523compiler.scm",(void*)f_4523},
{"f_4610compiler.scm",(void*)f_4610},
{"f_4532compiler.scm",(void*)f_4532},
{"f_4535compiler.scm",(void*)f_4535},
{"f_4544compiler.scm",(void*)f_4544},
{"f_4566compiler.scm",(void*)f_4566},
{"f_4559compiler.scm",(void*)f_4559},
{"f_4511compiler.scm",(void*)f_4511},
{"f_4514compiler.scm",(void*)f_4514},
{"f_2184compiler.scm",(void*)f_2184},
{"f_2190compiler.scm",(void*)f_2190},
{"f_4490compiler.scm",(void*)f_4490},
{"f_2193compiler.scm",(void*)f_2193},
{"f_2200compiler.scm",(void*)f_2200},
{"f_2209compiler.scm",(void*)f_2209},
{"f_2218compiler.scm",(void*)f_2218},
{"f_2345compiler.scm",(void*)f_2345},
{"f_4410compiler.scm",(void*)f_4410},
{"f_4416compiler.scm",(void*)f_4416},
{"f_4321compiler.scm",(void*)f_4321},
{"f_4381compiler.scm",(void*)f_4381},
{"f_4281compiler.scm",(void*)f_4281},
{"f_4285compiler.scm",(void*)f_4285},
{"f_4291compiler.scm",(void*)f_4291},
{"f_4305compiler.scm",(void*)f_4305},
{"f_4294compiler.scm",(void*)f_4294},
{"f_3917compiler.scm",(void*)f_3917},
{"f_4265compiler.scm",(void*)f_4265},
{"f_3939compiler.scm",(void*)f_3939},
{"f_4230compiler.scm",(void*)f_4230},
{"f_3942compiler.scm",(void*)f_3942},
{"f_3953compiler.scm",(void*)f_3953},
{"f_4180compiler.scm",(void*)f_4180},
{"f_4224compiler.scm",(void*)f_4224},
{"f_4220compiler.scm",(void*)f_4220},
{"f_4216compiler.scm",(void*)f_4216},
{"f_4204compiler.scm",(void*)f_4204},
{"f_3973compiler.scm",(void*)f_3973},
{"f_4052compiler.scm",(void*)f_4052},
{"f_4029compiler.scm",(void*)f_4029},
{"f_4024compiler.scm",(void*)f_4024},
{"f_3987compiler.scm",(void*)f_3987},
{"f_3977compiler.scm",(void*)f_3977},
{"f_3961compiler.scm",(void*)f_3961},
{"f_3949compiler.scm",(void*)f_3949},
{"f_3907compiler.scm",(void*)f_3907},
{"f_3884compiler.scm",(void*)f_3884},
{"f_3882compiler.scm",(void*)f_3882},
{"f_3811compiler.scm",(void*)f_3811},
{"f_3829compiler.scm",(void*)f_3829},
{"f_3851compiler.scm",(void*)f_3851},
{"f_3857compiler.scm",(void*)f_3857},
{"f_3835compiler.scm",(void*)f_3835},
{"f_3842compiler.scm",(void*)f_3842},
{"f_3817compiler.scm",(void*)f_3817},
{"f_3823compiler.scm",(void*)f_3823},
{"f_3809compiler.scm",(void*)f_3809},
{"f_3747compiler.scm",(void*)f_3747},
{"f_3758compiler.scm",(void*)f_3758},
{"f_3768compiler.scm",(void*)f_3768},
{"f_3771compiler.scm",(void*)f_3771},
{"f_3775compiler.scm",(void*)f_3775},
{"f_3761compiler.scm",(void*)f_3761},
{"f_3686compiler.scm",(void*)f_3686},
{"f_3690compiler.scm",(void*)f_3690},
{"f_3728compiler.scm",(void*)f_3728},
{"f_3694compiler.scm",(void*)f_3694},
{"f_3708compiler.scm",(void*)f_3708},
{"f_3706compiler.scm",(void*)f_3706},
{"f_3668compiler.scm",(void*)f_3668},
{"f_3676compiler.scm",(void*)f_3676},
{"f_3541compiler.scm",(void*)f_3541},
{"f_3544compiler.scm",(void*)f_3544},
{"f_3550compiler.scm",(void*)f_3550},
{"f_3629compiler.scm",(void*)f_3629},
{"f_3606compiler.scm",(void*)f_3606},
{"f_3581compiler.scm",(void*)f_3581},
{"f_3589compiler.scm",(void*)f_3589},
{"f_3577compiler.scm",(void*)f_3577},
{"f_3573compiler.scm",(void*)f_3573},
{"f_3565compiler.scm",(void*)f_3565},
{"f_3466compiler.scm",(void*)f_3466},
{"f_3475compiler.scm",(void*)f_3475},
{"f_3514compiler.scm",(void*)f_3514},
{"f_3506compiler.scm",(void*)f_3506},
{"f_3478compiler.scm",(void*)f_3478},
{"f_3498compiler.scm",(void*)f_3498},
{"f_3490compiler.scm",(void*)f_3490},
{"f_3446compiler.scm",(void*)f_3446},
{"f_3392compiler.scm",(void*)f_3392},
{"f_3395compiler.scm",(void*)f_3395},
{"f_3398compiler.scm",(void*)f_3398},
{"f_3402compiler.scm",(void*)f_3402},
{"f_3406compiler.scm",(void*)f_3406},
{"f_3325compiler.scm",(void*)f_3325},
{"f_3337compiler.scm",(void*)f_3337},
{"f_3310compiler.scm",(void*)f_3310},
{"f_3297compiler.scm",(void*)f_3297},
{"f_3284compiler.scm",(void*)f_3284},
{"f_3271compiler.scm",(void*)f_3271},
{"f_3258compiler.scm",(void*)f_3258},
{"f_3191compiler.scm",(void*)f_3191},
{"f_3210compiler.scm",(void*)f_3210},
{"f_3237compiler.scm",(void*)f_3237},
{"f_3241compiler.scm",(void*)f_3241},
{"f_3230compiler.scm",(void*)f_3230},
{"f_3204compiler.scm",(void*)f_3204},
{"f_3178compiler.scm",(void*)f_3178},
{"f_3163compiler.scm",(void*)f_3163},
{"f_3136compiler.scm",(void*)f_3136},
{"f_3140compiler.scm",(void*)f_3140},
{"f_3115compiler.scm",(void*)f_3115},
{"f_3086compiler.scm",(void*)f_3086},
{"f_3090compiler.scm",(void*)f_3090},
{"f_3057compiler.scm",(void*)f_3057},
{"f_3061compiler.scm",(void*)f_3061},
{"f_2883compiler.scm",(void*)f_2883},
{"f_2892compiler.scm",(void*)f_2892},
{"f_2895compiler.scm",(void*)f_2895},
{"f_3003compiler.scm",(void*)f_3003},
{"f_3032compiler.scm",(void*)f_3032},
{"f_3036compiler.scm",(void*)f_3036},
{"f_3006compiler.scm",(void*)f_3006},
{"f_3012compiler.scm",(void*)f_3012},
{"f_3025compiler.scm",(void*)f_3025},
{"f_3015compiler.scm",(void*)f_3015},
{"f_2898compiler.scm",(void*)f_2898},
{"f_2993compiler.scm",(void*)f_2993},
{"f_2901compiler.scm",(void*)f_2901},
{"f_2956compiler.scm",(void*)f_2956},
{"f_2987compiler.scm",(void*)f_2987},
{"f_2979compiler.scm",(void*)f_2979},
{"f_2913compiler.scm",(void*)f_2913},
{"f_2944compiler.scm",(void*)f_2944},
{"f_2932compiler.scm",(void*)f_2932},
{"f_2845compiler.scm",(void*)f_2845},
{"f_2871compiler.scm",(void*)f_2871},
{"f_2848compiler.scm",(void*)f_2848},
{"f_2863compiler.scm",(void*)f_2863},
{"f_2861compiler.scm",(void*)f_2861},
{"f_2851compiler.scm",(void*)f_2851},
{"f_2854compiler.scm",(void*)f_2854},
{"f_2580compiler.scm",(void*)f_2580},
{"f_2795compiler.scm",(void*)f_2795},
{"f_2806compiler.scm",(void*)f_2806},
{"f_2800compiler.scm",(void*)f_2800},
{"f_2589compiler.scm",(void*)f_2589},
{"f_2594compiler.scm",(void*)f_2594},
{"f_2598compiler.scm",(void*)f_2598},
{"f_2792compiler.scm",(void*)f_2792},
{"f_2601compiler.scm",(void*)f_2601},
{"f_2784compiler.scm",(void*)f_2784},
{"f_2604compiler.scm",(void*)f_2604},
{"f_2607compiler.scm",(void*)f_2607},
{"f_2782compiler.scm",(void*)f_2782},
{"f_2775compiler.scm",(void*)f_2775},
{"f_2610compiler.scm",(void*)f_2610},
{"f_2616compiler.scm",(void*)f_2616},
{"f_2625compiler.scm",(void*)f_2625},
{"f_2645compiler.scm",(void*)f_2645},
{"f_2729compiler.scm",(void*)f_2729},
{"f_2725compiler.scm",(void*)f_2725},
{"f_2721compiler.scm",(void*)f_2721},
{"f_2678compiler.scm",(void*)f_2678},
{"f_2685compiler.scm",(void*)f_2685},
{"f_2635compiler.scm",(void*)f_2635},
{"f_2506compiler.scm",(void*)f_2506},
{"f_2512compiler.scm",(void*)f_2512},
{"f_2515compiler.scm",(void*)f_2515},
{"f_2568compiler.scm",(void*)f_2568},
{"f_2518compiler.scm",(void*)f_2518},
{"f_2521compiler.scm",(void*)f_2521},
{"f_2548compiler.scm",(void*)f_2548},
{"f_2556compiler.scm",(void*)f_2556},
{"f_2528compiler.scm",(void*)f_2528},
{"f_2542compiler.scm",(void*)f_2542},
{"f_2536compiler.scm",(void*)f_2536},
{"f_2532compiler.scm",(void*)f_2532},
{"f_2392compiler.scm",(void*)f_2392},
{"f_2402compiler.scm",(void*)f_2402},
{"f_2413compiler.scm",(void*)f_2413},
{"f_2487compiler.scm",(void*)f_2487},
{"f_2497compiler.scm",(void*)f_2497},
{"f_2478compiler.scm",(void*)f_2478},
{"f_2452compiler.scm",(void*)f_2452},
{"f_2466compiler.scm",(void*)f_2466},
{"f_2464compiler.scm",(void*)f_2464},
{"f_2440compiler.scm",(void*)f_2440},
{"f_2417compiler.scm",(void*)f_2417},
{"f_2424compiler.scm",(void*)f_2424},
{"f_2407compiler.scm",(void*)f_2407},
{"f_2386compiler.scm",(void*)f_2386},
{"f_2354compiler.scm",(void*)f_2354},
{"f_2357compiler.scm",(void*)f_2357},
{"f_2368compiler.scm",(void*)f_2368},
{"f_2362compiler.scm",(void*)f_2362},
{"f_2360compiler.scm",(void*)f_2360},
{"f_2312compiler.scm",(void*)f_2312},
{"f_2324compiler.scm",(void*)f_2324},
{"f_2328compiler.scm",(void*)f_2328},
{"f_2287compiler.scm",(void*)f_2287},
{"f_2241compiler.scm",(void*)f_2241},
{"f_2248compiler.scm",(void*)f_2248},
{"f_2252compiler.scm",(void*)f_2252},
{"f_2256compiler.scm",(void*)f_2256},
{"f_2145compiler.scm",(void*)f_2145},
{"f_2139compiler.scm",(void*)f_2139},
{"f_2029compiler.scm",(void*)f_2029},
{"f_2033compiler.scm",(void*)f_2033},
{"f_2046compiler.scm",(void*)f_2046},
{"f_2094compiler.scm",(void*)f_2094},
{"f_2104compiler.scm",(void*)f_2104},
{"f_2064compiler.scm",(void*)f_2064},
{"f_2074compiler.scm",(void*)f_2074},
{"f_1987compiler.scm",(void*)f_1987},
{"f_1994compiler.scm",(void*)f_1994},
{"f_1963compiler.scm",(void*)f_1963},
{"f_1969compiler.scm",(void*)f_1969},
{"f_1951compiler.scm",(void*)f_1951},
{"f_1877compiler.scm",(void*)f_1877},
{"f_1946compiler.scm",(void*)f_1946},
{"f_1881compiler.scm",(void*)f_1881},
{"f_1939compiler.scm",(void*)f_1939},
{"f_1884compiler.scm",(void*)f_1884},
{"f_1932compiler.scm",(void*)f_1932},
{"f_1887compiler.scm",(void*)f_1887},
{"f_1891compiler.scm",(void*)f_1891},
{"f_1895compiler.scm",(void*)f_1895},
{"f_1925compiler.scm",(void*)f_1925},
{"f_1898compiler.scm",(void*)f_1898},
{"f_1918compiler.scm",(void*)f_1918},
{"f_1901compiler.scm",(void*)f_1901},
{"f_1911compiler.scm",(void*)f_1911},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
