/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-07 10:49
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[580];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11250)
static void C_ccall f_11250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11050)
static void C_fcall f_11050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10283)
static void C_fcall f_10283(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11039)
static void C_ccall f_11039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11036)
static void C_ccall f_11036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10949)
static void C_fcall f_10949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11026)
static void C_ccall f_11026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11007)
static void C_ccall f_11007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10970)
static void C_fcall f_10970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10921)
static void C_fcall f_10921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10924)
static void C_ccall f_10924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_ccall f_10878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10890)
static void C_fcall f_10890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10881)
static void C_fcall f_10881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10758)
static void C_ccall f_10758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10859)
static void C_ccall f_10859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10847)
static void C_ccall f_10847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10786)
static void C_ccall f_10786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10792)
static void C_fcall f_10792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10816)
static void C_ccall f_10816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10808)
static void C_ccall f_10808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10729)
static void C_ccall f_10729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10721)
static void C_ccall f_10721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_fcall f_10666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10540)
static void C_ccall f_10540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10645)
static void C_ccall f_10645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10543)
static void C_ccall f_10543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10546)
static void C_ccall f_10546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10613)
static void C_ccall f_10613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10594)
static void C_fcall f_10594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10477)
static void C_ccall f_10477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10486)
static void C_fcall f_10486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10480)
static void C_fcall f_10480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10461)
static void C_ccall f_10461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10434)
static void C_ccall f_10434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10417)
static void C_ccall f_10417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10413)
static void C_ccall f_10413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10406)
static void C_ccall f_10406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10389)
static void C_ccall f_10389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10361)
static void C_ccall f_10361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10341)
static void C_ccall f_10341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10196)
static void C_fcall f_10196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10200)
static void C_ccall f_10200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10215)
static void C_ccall f_10215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10225)
static void C_ccall f_10225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10240)
static void C_fcall f_10240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11062)
static void C_fcall f_11062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11069)
static void C_ccall f_11069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11121)
static void C_ccall f_11121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11081)
static void C_ccall f_11081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11156)
static void C_fcall f_11156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11186)
static void C_ccall f_11186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11160)
static void C_ccall f_11160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11142)
static void C_fcall f_11142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11188)
static void C_fcall f_11188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11201)
static void C_ccall f_11201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10166)
static void C_ccall f_10166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10094)
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10085)
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10067)
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10040)
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9995)
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9917)
static void C_ccall f_9917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9911)
static void C_ccall f_9911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9884)
static void C_ccall f_9884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9730)
static void C_fcall f_9730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9736)
static void C_ccall f_9736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9041)
static void C_fcall f_9041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9060)
static void C_fcall f_9060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static void C_fcall f_9093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9609)
static void C_fcall f_9609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9566)
static void C_ccall f_9566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9549)
static void C_ccall f_9549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9475)
static void C_ccall f_9475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9498)
static void C_ccall f_9498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9436)
static void C_ccall f_9436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_fcall f_9217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9403)
static void C_ccall f_9403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_ccall f_9360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9273)
static void C_ccall f_9273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9257)
static void C_ccall f_9257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9133)
static void C_ccall f_9133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9099)
static void C_ccall f_9099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_fcall f_9742(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_fcall f_8707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8726)
static void C_fcall f_8726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9781)
static void C_ccall f_9781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9819)
static void C_fcall f_9819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_ccall f_9845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9831)
static void C_fcall f_9831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8822)
static void C_ccall f_8822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8828)
static void C_fcall f_8828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8840)
static void C_ccall f_8840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8843)
static void C_ccall f_8843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_fcall f_8846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8864)
static void C_fcall f_8864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static void C_ccall f_8871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8852)
static void C_ccall f_8852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8816)
static void C_fcall f_8816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_fcall f_8806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8747)
static void C_ccall f_8747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8764)
static void C_ccall f_8764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8696)
static void C_fcall f_8696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8691)
static void C_ccall f_8691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8680)
static void C_fcall f_8680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7906)
static void C_ccall f_7906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_fcall f_8529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7940)
static void C_ccall f_7940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_fcall f_8475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_fcall f_8490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_fcall f_8484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8424)
static void C_fcall f_8424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_fcall f_8380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8392)
static void C_fcall f_8392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8281)
static void C_fcall f_8281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8342)
static void C_ccall f_8342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_fcall f_8349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_fcall f_8309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_fcall f_8245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_fcall f_8233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8218)
static void C_fcall f_8218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_fcall f_8139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7961)
static void C_ccall f_7961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7989)
static void C_fcall f_7989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_fcall f_8010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8031)
static void C_fcall f_8031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_fcall f_7970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_fcall f_7926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_fcall f_7881(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7867)
static void C_fcall f_7867(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7165)
static void C_fcall f_7165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7187)
static void C_fcall f_7187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_fcall f_7623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_fcall f_7638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_fcall f_7629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_ccall f_7597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_fcall f_7503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_fcall f_7536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_fcall f_7506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_fcall f_7378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7771)
static void C_fcall f_7771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_ccall f_7831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_fcall f_7780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_fcall f_7861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7158)
static C_word C_fcall f_7158(C_word t0);
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6937)
static void C_fcall f_6937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6943)
static void C_fcall f_6943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6957)
static void C_ccall f_6957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_fcall f_6921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6796)
static void C_fcall f_6796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_ccall f_6828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_fcall f_6422(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6444)
static void C_fcall f_6444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6710)
static void C_fcall f_6710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_fcall f_6550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6587)
static void C_ccall f_6587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6456)
static void C_ccall f_6456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_fcall f_6378(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6317)
static void C_fcall f_6317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6294)
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6208)
static void C_fcall f_6208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_fcall f_6211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static void C_fcall f_6214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_fcall f_5912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4821)
static void C_fcall f_4821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_fcall f_5189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_fcall f_4906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_fcall f_4770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_fcall f_4783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2166)
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_fcall f_4588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_fcall f_4609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_fcall f_2398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_fcall f_4346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_fcall f_4295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_fcall f_4245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static C_word C_fcall f_4094(C_word *a,C_word t0);
C_noret_decl(f_4089)
static void C_fcall f_4089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static C_word C_fcall f_4052(C_word *a,C_word t0);
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_fcall f_3646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_fcall f_3543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_fcall f_3071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_fcall f_2840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_fcall f_2684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_fcall f_2698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_fcall f_2731(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_fcall f_2493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2022)
static void C_fcall f_2022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1979)
static C_word C_fcall f_1979(C_word t0,C_word t1);
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11050)
static void C_fcall trf_11050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11050(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11050(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10283)
static void C_fcall trf_10283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10283(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10283(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10949)
static void C_fcall trf_10949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10949(t0,t1);}

C_noret_decl(trf_10970)
static void C_fcall trf_10970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10970(t0,t1);}

C_noret_decl(trf_10921)
static void C_fcall trf_10921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10921(t0,t1);}

C_noret_decl(trf_10890)
static void C_fcall trf_10890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10890(t0,t1);}

C_noret_decl(trf_10881)
static void C_fcall trf_10881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10881(t0,t1);}

C_noret_decl(trf_10792)
static void C_fcall trf_10792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10792(t0,t1);}

C_noret_decl(trf_10666)
static void C_fcall trf_10666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10666(t0,t1);}

C_noret_decl(trf_10594)
static void C_fcall trf_10594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10594(t0,t1);}

C_noret_decl(trf_10486)
static void C_fcall trf_10486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10486(t0,t1);}

C_noret_decl(trf_10480)
static void C_fcall trf_10480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10480(t0,t1);}

C_noret_decl(trf_10196)
static void C_fcall trf_10196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10196(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10196(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10230)
static void C_fcall trf_10230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10230(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10230(t0,t1,t2,t3);}

C_noret_decl(trf_10240)
static void C_fcall trf_10240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10240(t0,t1);}

C_noret_decl(trf_11062)
static void C_fcall trf_11062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11062(t0,t1,t2);}

C_noret_decl(trf_11156)
static void C_fcall trf_11156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11156(t0,t1,t2);}

C_noret_decl(trf_11142)
static void C_fcall trf_11142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11142(t0,t1,t2);}

C_noret_decl(trf_11188)
static void C_fcall trf_11188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11188(t0,t1);}

C_noret_decl(trf_9730)
static void C_fcall trf_9730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9730(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9730(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9041)
static void C_fcall trf_9041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9041(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9041(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9060)
static void C_fcall trf_9060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9060(t0,t1);}

C_noret_decl(trf_9093)
static void C_fcall trf_9093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9093(t0,t1);}

C_noret_decl(trf_9609)
static void C_fcall trf_9609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9609(t0,t1);}

C_noret_decl(trf_9217)
static void C_fcall trf_9217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9217(t0,t1);}

C_noret_decl(trf_9742)
static void C_fcall trf_9742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9742(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9742(t0,t1,t2,t3);}

C_noret_decl(trf_8707)
static void C_fcall trf_8707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8707(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8707(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8726)
static void C_fcall trf_8726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8726(t0,t1);}

C_noret_decl(trf_9819)
static void C_fcall trf_9819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9819(t0,t1);}

C_noret_decl(trf_9831)
static void C_fcall trf_9831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9831(t0,t1);}

C_noret_decl(trf_8828)
static void C_fcall trf_8828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8828(t0,t1);}

C_noret_decl(trf_8846)
static void C_fcall trf_8846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8846(t0,t1);}

C_noret_decl(trf_8864)
static void C_fcall trf_8864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8864(t0,t1);}

C_noret_decl(trf_8816)
static void C_fcall trf_8816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8816(t0,t1);}

C_noret_decl(trf_8806)
static void C_fcall trf_8806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8806(t0,t1);}

C_noret_decl(trf_8696)
static void C_fcall trf_8696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8696(t0,t1,t2);}

C_noret_decl(trf_8686)
static void C_fcall trf_8686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8686(t0,t1,t2,t3);}

C_noret_decl(trf_8680)
static void C_fcall trf_8680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8680(t0,t1,t2,t3);}

C_noret_decl(trf_8529)
static void C_fcall trf_8529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8529(t0,t1);}

C_noret_decl(trf_8475)
static void C_fcall trf_8475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8475(t0,t1);}

C_noret_decl(trf_8490)
static void C_fcall trf_8490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8490(t0,t1);}

C_noret_decl(trf_8484)
static void C_fcall trf_8484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8484(t0,t1);}

C_noret_decl(trf_8424)
static void C_fcall trf_8424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8424(t0,t1);}

C_noret_decl(trf_8380)
static void C_fcall trf_8380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8380(t0,t1);}

C_noret_decl(trf_8392)
static void C_fcall trf_8392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8392(t0,t1);}

C_noret_decl(trf_8281)
static void C_fcall trf_8281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8281(t0,t1);}

C_noret_decl(trf_8349)
static void C_fcall trf_8349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8349(t0,t1);}

C_noret_decl(trf_8309)
static void C_fcall trf_8309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8309(t0,t1);}

C_noret_decl(trf_8245)
static void C_fcall trf_8245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8245(t0,t1);}

C_noret_decl(trf_8233)
static void C_fcall trf_8233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8233(t0,t1);}

C_noret_decl(trf_8218)
static void C_fcall trf_8218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8218(t0,t1);}

C_noret_decl(trf_8139)
static void C_fcall trf_8139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8139(t0,t1);}

C_noret_decl(trf_7989)
static void C_fcall trf_7989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7989(t0,t1);}

C_noret_decl(trf_8010)
static void C_fcall trf_8010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8010(t0,t1);}

C_noret_decl(trf_8031)
static void C_fcall trf_8031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8031(t0,t1);}

C_noret_decl(trf_7970)
static void C_fcall trf_7970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7970(t0,t1);}

C_noret_decl(trf_7926)
static void C_fcall trf_7926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7926(t0,t1);}

C_noret_decl(trf_7881)
static void C_fcall trf_7881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7881(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7881(t0,t1,t2,t3);}

C_noret_decl(trf_7867)
static void C_fcall trf_7867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7867(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7867(t0,t1,t2,t3);}

C_noret_decl(trf_7746)
static void C_fcall trf_7746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7746(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7746(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7165)
static void C_fcall trf_7165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7165(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7165(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7187)
static void C_fcall trf_7187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7187(t0,t1);}

C_noret_decl(trf_7623)
static void C_fcall trf_7623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7623(t0,t1);}

C_noret_decl(trf_7638)
static void C_fcall trf_7638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7638(t0,t1);}

C_noret_decl(trf_7629)
static void C_fcall trf_7629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7629(t0,t1);}

C_noret_decl(trf_7503)
static void C_fcall trf_7503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7503(t0,t1);}

C_noret_decl(trf_7536)
static void C_fcall trf_7536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7536(t0,t1);}

C_noret_decl(trf_7506)
static void C_fcall trf_7506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7506(t0,t1);}

C_noret_decl(trf_7378)
static void C_fcall trf_7378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7378(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7378(t0,t1,t2,t3);}

C_noret_decl(trf_7758)
static void C_fcall trf_7758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7758(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7758(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7771)
static void C_fcall trf_7771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7771(t0,t1);}

C_noret_decl(trf_7780)
static void C_fcall trf_7780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7780(t0,t1);}

C_noret_decl(trf_7861)
static void C_fcall trf_7861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7861(t0,t1,t2,t3);}

C_noret_decl(trf_6937)
static void C_fcall trf_6937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6937(t0,t1,t2,t3);}

C_noret_decl(trf_6943)
static void C_fcall trf_6943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6943(t0,t1,t2,t3);}

C_noret_decl(trf_6921)
static void C_fcall trf_6921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6921(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6921(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6796)
static void C_fcall trf_6796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6796(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6796(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6422)
static void C_fcall trf_6422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6422(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6422(t0,t1,t2,t3);}

C_noret_decl(trf_6444)
static void C_fcall trf_6444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6444(t0,t1);}

C_noret_decl(trf_6710)
static void C_fcall trf_6710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6710(t0,t1);}

C_noret_decl(trf_6550)
static void C_fcall trf_6550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6550(t0,t1,t2,t3);}

C_noret_decl(trf_6378)
static void C_fcall trf_6378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6378(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6378(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6317)
static void C_fcall trf_6317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6317(t0,t1,t2);}

C_noret_decl(trf_6288)
static void C_fcall trf_6288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6288(t0,t1,t2);}

C_noret_decl(trf_6294)
static void C_fcall trf_6294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6294(t0,t1,t2);}

C_noret_decl(trf_6208)
static void C_fcall trf_6208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6208(t0,t1);}

C_noret_decl(trf_6211)
static void C_fcall trf_6211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6211(t0,t1);}

C_noret_decl(trf_6214)
static void C_fcall trf_6214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6214(t0,t1);}

C_noret_decl(trf_5912)
static void C_fcall trf_5912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5912(t0,t1);}

C_noret_decl(trf_4821)
static void C_fcall trf_4821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4821(t0,t1);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5495(t0,t1);}

C_noret_decl(trf_5189)
static void C_fcall trf_5189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5189(t0,t1);}

C_noret_decl(trf_4906)
static void C_fcall trf_4906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4906(t0,t1);}

C_noret_decl(trf_4770)
static void C_fcall trf_4770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4770(t0,t1,t2,t3);}

C_noret_decl(trf_4783)
static void C_fcall trf_4783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4783(t0,t1);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4712(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2166)
static void C_fcall trf_2166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2166(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2166(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4588)
static void C_fcall trf_4588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4588(t0,t1);}

C_noret_decl(trf_4609)
static void C_fcall trf_4609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4609(t0,t1);}

C_noret_decl(trf_2398)
static void C_fcall trf_2398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2398(t0,t1);}

C_noret_decl(trf_4346)
static void C_fcall trf_4346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4346(t0,t1);}

C_noret_decl(trf_4295)
static void C_fcall trf_4295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4295(t0,t1);}

C_noret_decl(trf_4245)
static void C_fcall trf_4245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4245(t0,t1,t2,t3);}

C_noret_decl(trf_4089)
static void C_fcall trf_4089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4089(t0,t1);}

C_noret_decl(trf_3646)
static void C_fcall trf_3646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3646(t0,t1);}

C_noret_decl(trf_3543)
static void C_fcall trf_3543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3543(t0,t1);}

C_noret_decl(trf_3275)
static void C_fcall trf_3275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3275(t0,t1,t2);}

C_noret_decl(trf_3071)
static void C_fcall trf_3071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3071(t0,t1);}

C_noret_decl(trf_2840)
static void C_fcall trf_2840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2840(t0,t1);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2678(t0,t1);}

C_noret_decl(trf_2684)
static void C_fcall trf_2684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2684(t0,t1);}

C_noret_decl(trf_2698)
static void C_fcall trf_2698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2698(t0,t1);}

C_noret_decl(trf_2731)
static void C_fcall trf_2731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2731(t0,t1);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2688(t0,t1,t2);}

C_noret_decl(trf_2445)
static void C_fcall trf_2445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2445(t0,t1,t2);}

C_noret_decl(trf_2493)
static void C_fcall trf_2493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2493(t0,t1);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2148(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2057(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2022)
static void C_fcall trf_2022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2022(t0,t1);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1991(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5612)){
C_save(t1);
C_rereclaim2(5612*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,580);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],28,"\010compilerprofiled-procedures");
lf[49]=C_h_intern(&lf[49],41,"\010compilerdefault-default-target-heap-size");
lf[50]=C_h_intern(&lf[50],42,"\010compilerdefault-default-target-stack-size");
lf[51]=C_h_intern(&lf[51],21,"\010compilerverbose-mode");
lf[52]=C_h_intern(&lf[52],30,"\010compileroriginal-program-size");
lf[53]=C_h_intern(&lf[53],29,"\010compilercurrent-program-size");
lf[54]=C_h_intern(&lf[54],31,"\010compilerline-number-database-2");
lf[55]=C_h_intern(&lf[55],28,"\010compilerimmutable-constants");
lf[56]=C_h_intern(&lf[56],43,"\010compilerrest-parameters-promoted-to-vector");
lf[57]=C_h_intern(&lf[57],21,"\010compilerinline-table");
lf[58]=C_h_intern(&lf[58],26,"\010compilerinline-table-used");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstant-table");
lf[60]=C_h_intern(&lf[60],23,"\010compilerconstants-used");
lf[61]=C_h_intern(&lf[61],26,"\010compilermutable-constants");
lf[62]=C_h_intern(&lf[62],30,"\010compilerbroken-constant-nodes");
lf[63]=C_h_intern(&lf[63],37,"\010compilerinline-substitutions-enabled");
lf[64]=C_h_intern(&lf[64],24,"\010compilerdirect-call-ids");
lf[65]=C_h_intern(&lf[65],23,"\010compilerfirst-analysis");
lf[66]=C_h_intern(&lf[66],27,"\010compilerforeign-type-table");
lf[67]=C_h_intern(&lf[67],26,"\010compilerforeign-variables");
lf[68]=C_h_intern(&lf[68],29,"\010compilerforeign-lambda-stubs");
lf[69]=C_h_intern(&lf[69],22,"foreign-callback-stubs");
lf[70]=C_h_intern(&lf[70],27,"\010compilerexternal-variables");
lf[71]=C_h_intern(&lf[71],26,"\010compilerloop-lambda-names");
lf[72]=C_h_intern(&lf[72],28,"\010compilerprofile-lambda-list");
lf[73]=C_h_intern(&lf[73],29,"\010compilerprofile-lambda-index");
lf[74]=C_h_intern(&lf[74],33,"\010compilerprofile-info-vector-name");
lf[75]=C_h_intern(&lf[75],28,"\010compilerexternal-to-pointer");
lf[76]=C_h_intern(&lf[76],34,"\010compilererror-is-extended-binding");
lf[77]=C_h_intern(&lf[77],24,"\010compilerreal-name-table");
lf[78]=C_h_intern(&lf[78],29,"\010compilerlocation-pointer-map");
lf[79]=C_h_intern(&lf[79],34,"\010compilerpending-canonicalizations");
lf[80]=C_h_intern(&lf[80],29,"\010compilerdefconstant-bindings");
lf[81]=C_h_intern(&lf[81],23,"\010compilercallback-names");
lf[82]=C_h_intern(&lf[82],23,"\010compilertoplevel-scope");
lf[83]=C_h_intern(&lf[83],27,"\010compilertoplevel-lambda-id");
lf[84]=C_h_intern(&lf[84],29,"\010compilercustom-declare-alist");
lf[85]=C_h_intern(&lf[85],25,"\010compilercsc-control-file");
lf[86]=C_h_intern(&lf[86],26,"\010compilerdata-declarations");
lf[87]=C_h_intern(&lf[87],20,"\010compilerinline-list");
lf[88]=C_h_intern(&lf[88],24,"\010compilernot-inline-list");
lf[89]=C_h_intern(&lf[89],26,"\010compilerfile-requirements");
lf[90]=C_h_intern(&lf[90],28,"\010compilerpostponed-initforms");
lf[91]=C_h_intern(&lf[91],25,"\010compilerunused-variables");
lf[92]=C_h_intern(&lf[92],29,"\010compilercompiler-macro-table");
lf[93]=C_h_intern(&lf[93],32,"\010compilercompiler-macros-enabled");
lf[94]=C_h_intern(&lf[94],29,"\010compilerliteral-rewrite-hook");
lf[95]=C_h_intern(&lf[95],28,"\010compilerinitialize-compiler");
lf[96]=C_h_intern(&lf[96],12,"vector-fill!");
lf[97]=C_h_intern(&lf[97],11,"make-vector");
lf[98]=C_h_intern(&lf[98],25,"\010compilermake-random-name");
lf[99]=C_h_intern(&lf[99],12,"profile-info");
lf[100]=C_h_intern(&lf[100],32,"\010compilercanonicalize-expression");
lf[101]=C_h_intern(&lf[101],23,"\010compilerset-real-name!");
lf[102]=C_h_intern(&lf[102],8,"for-each");
lf[103]=C_h_intern(&lf[103],5,"quote");
lf[104]=C_h_intern(&lf[104],15,"\004coreinline_ref");
lf[105]=C_h_intern(&lf[105],36,"\010compilerforeign-type-convert-result");
lf[106]=C_h_intern(&lf[106],30,"\010compilerfinish-foreign-result");
lf[107]=C_h_intern(&lf[107],27,"\010compilerfinal-foreign-type");
lf[108]=C_h_intern(&lf[108],19,"\004coreinline_loc_ref");
lf[109]=C_h_intern(&lf[109],18,"\003syshash-table-ref");
lf[110]=C_h_intern(&lf[110],21,"\003sysalias-global-hook");
lf[111]=C_h_intern(&lf[111],12,"syntax-error");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[113]=C_h_intern(&lf[113],24,"\003syssyntax-error-culprit");
lf[114]=C_h_intern(&lf[114],2,"if");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],16,"\003syscheck-syntax");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[119]=C_h_intern(&lf[119],10,"\004corecheck");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[121]=C_h_intern(&lf[121],14,"\004coreimmutable");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],6,"gensym");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],6,"cadadr");
lf[126]=C_h_intern(&lf[126],14,"\004coreundefined");
lf[127]=C_h_intern(&lf[127],23,"\004corerequire-for-syntax");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[129]=C_h_intern(&lf[129],10,"lset-union");
lf[130]=C_h_intern(&lf[130],3,"eq\077");
lf[131]=C_h_intern(&lf[131],22,"\003syshash-table-update!");
lf[132]=C_h_intern(&lf[132],19,"syntax-requirements");
lf[133]=C_h_intern(&lf[133],11,"\003sysrequire");
lf[134]=C_h_intern(&lf[134],7,"\003sysmap");
lf[135]=C_h_intern(&lf[135],4,"eval");
lf[136]=C_h_intern(&lf[136],22,"\004corerequire-extension");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[138]=C_h_intern(&lf[138],22,"\003sysdo-the-right-thing");
lf[139]=C_h_intern(&lf[139],5,"begin");
lf[140]=C_h_intern(&lf[140],28,"\010compilerlookup-exports-file");
lf[141]=C_h_intern(&lf[141],7,"exports");
lf[142]=C_h_intern(&lf[142],19,"\003syshash-table-set!");
lf[143]=C_h_intern(&lf[143],12,"\003sysfor-each");
lf[144]=C_h_intern(&lf[144],25,"\003sysextension-information");
lf[145]=C_h_intern(&lf[145],25,"\010compilercompiler-warning");
lf[146]=C_h_intern(&lf[146],3,"ext");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[148]=C_h_intern(&lf[148],18,"\003sysfind-extension");
lf[149]=C_h_intern(&lf[149],31,"\003syscanonicalize-extension-path");
lf[150]=C_h_intern(&lf[150],17,"require-extension");
lf[151]=C_h_intern(&lf[151],8,"feature\077");
lf[152]=C_h_intern(&lf[152],5,"cadar");
lf[153]=C_h_intern(&lf[153],3,"let");
lf[154]=C_h_intern(&lf[154],21,"\003syscanonicalize-body");
lf[155]=C_h_intern(&lf[155],3,"map");
lf[156]=C_h_intern(&lf[156],6,"append");
lf[157]=C_h_intern(&lf[157],4,"cons");
lf[158]=C_h_intern(&lf[158],6,"unzip1");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[160]=C_h_intern(&lf[160],6,"lambda");
lf[161]=C_h_intern(&lf[161],20,"\004coreinternal-lambda");
lf[162]=C_h_intern(&lf[162],30,"\010compilerexpand-profile-lambda");
lf[163]=C_h_intern(&lf[163],37,"\010compilerprocess-lambda-documentation");
lf[164]=C_h_intern(&lf[164],6,"cddadr");
lf[165]=C_h_intern(&lf[165],5,"cdadr");
lf[166]=C_h_intern(&lf[166],5,"caadr");
lf[167]=C_h_intern(&lf[167],26,"\010compilerbuild-lambda-list");
lf[168]=C_h_intern(&lf[168],13,"\010compilerposq");
lf[169]=C_h_intern(&lf[169],30,"\010compilerdecompose-lambda-list");
lf[170]=C_h_intern(&lf[170],31,"\003sysexpand-extended-lambda-list");
lf[171]=C_h_intern(&lf[171],9,"\003syserror");
lf[172]=C_h_intern(&lf[172],25,"\003sysextended-lambda-list\077");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[174]=C_h_intern(&lf[174],17,"\004corenamed-lambda");
lf[175]=C_h_intern(&lf[175],16,"\004coreloop-lambda");
lf[176]=C_h_intern(&lf[176],4,"set!");
lf[177]=C_h_intern(&lf[177],9,"\004coreset!");
lf[178]=C_h_intern(&lf[178],18,"\004coreinline_update");
lf[179]=C_h_intern(&lf[179],27,"\010compilerforeign-type-check");
lf[180]=C_h_intern(&lf[180],38,"\010compilerforeign-type-convert-argument");
lf[181]=C_h_intern(&lf[181],22,"\004coreinline_loc_update");
lf[182]=C_h_intern(&lf[182],6,"syntax");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[184]=C_h_intern(&lf[184],8,"keyword\077");
lf[185]=C_h_intern(&lf[185],15,"undefine-macro!");
lf[186]=C_h_intern(&lf[186],3,"var");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[188]=C_h_intern(&lf[188],7,"sprintf");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[191]=C_h_intern(&lf[191],6,"macro\077");
lf[192]=C_h_intern(&lf[192],11,"lset-adjoin");
lf[193]=C_h_intern(&lf[193],17,"\010compilerget-line");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[195]=C_h_intern(&lf[195],11,"\004coreinline");
lf[196]=C_h_intern(&lf[196],20,"\004coreinline_allocate");
lf[197]=C_h_intern(&lf[197],19,"\004corecompiletimetoo");
lf[198]=C_h_intern(&lf[198],23,"\004coreelaborationtimetoo");
lf[199]=C_h_intern(&lf[199],20,"\004corecompiletimeonly");
lf[200]=C_h_intern(&lf[200],24,"\004coreelaborationtimeonly");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[202]=C_h_intern(&lf[202],32,"\010compilercanonicalize-begin-body");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[205]=C_h_intern(&lf[205],19,"\004coreforeign-lambda");
lf[206]=C_h_intern(&lf[206],30,"\010compilerexpand-foreign-lambda");
lf[207]=C_h_intern(&lf[207],28,"\004coreforeign-callback-lambda");
lf[208]=C_h_intern(&lf[208],39,"\010compilerexpand-foreign-callback-lambda");
lf[209]=C_h_intern(&lf[209],20,"\004coreforeign-lambda*");
lf[210]=C_h_intern(&lf[210],31,"\010compilerexpand-foreign-lambda*");
lf[211]=C_h_intern(&lf[211],29,"\004coreforeign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],40,"\010compilerexpand-foreign-callback-lambda*");
lf[213]=C_h_intern(&lf[213],22,"\004coreforeign-primitive");
lf[214]=C_h_intern(&lf[214],33,"\010compilerexpand-foreign-primitive");
lf[215]=C_h_intern(&lf[215],28,"\004coredefine-foreign-variable");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[217]=C_h_intern(&lf[217],14,"symbol->string");
lf[218]=C_h_intern(&lf[218],24,"\004coredefine-foreign-type");
lf[219]=C_h_intern(&lf[219],10,"\003sysvalues");
lf[220]=C_h_intern(&lf[220],5,"cons*");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[222]=C_h_intern(&lf[222],29,"\004coredefine-external-variable");
lf[223]=C_h_intern(&lf[223],9,"c-pointer");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[225]=C_h_intern(&lf[225],13,"string-append");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[227]=C_h_intern(&lf[227],5,"fifth");
lf[228]=C_h_intern(&lf[228],17,"\004corelet-location");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[230]=C_h_intern(&lf[230],10,"\003sysappend");
lf[231]=C_h_intern(&lf[231],14,"\010compilerwords");
lf[232]=C_h_intern(&lf[232],46,"\010compilerestimate-foreign-result-location-size");
lf[233]=C_h_intern(&lf[233],18,"\004coredefine-inline");
lf[234]=C_h_intern(&lf[234],34,"\010compilerextract-mutable-constants");
lf[235]=C_h_intern(&lf[235],20,"\004coredefine-constant");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[238]=C_h_intern(&lf[238],29,"\010compilercollapsable-literal\077");
lf[239]=C_h_intern(&lf[239],4,"quit");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[241]=C_h_intern(&lf[241],22,"with-exception-handler");
lf[242]=C_h_intern(&lf[242],30,"call-with-current-continuation");
lf[243]=C_h_intern(&lf[243],12,"\004coredeclare");
lf[244]=C_h_intern(&lf[244],28,"\010compilerprocess-declaration");
lf[245]=C_h_intern(&lf[245],29,"\004coreforeign-callback-wrapper");
lf[246]=C_h_intern(&lf[246],8,"split-at");
lf[247]=C_h_intern(&lf[247],1,"r");
lf[248]=C_h_intern(&lf[248],17,"\003sysmake-c-string");
lf[249]=C_h_intern(&lf[249],3,"and");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[253]=C_h_intern(&lf[253],25,"nonnull-unsigned-c-string");
lf[254]=C_h_intern(&lf[254],16,"nonnull-c-string");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[256]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[257]=C_h_intern(&lf[257],18,"unsigned-c-string*");
lf[258]=C_h_intern(&lf[258],9,"c-string*");
lf[259]=C_h_intern(&lf[259],13,"c-string-list");
lf[260]=C_h_intern(&lf[260],14,"c-string-list*");
lf[261]=C_h_intern(&lf[261],8,"c-string");
lf[262]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[263]=C_h_intern(&lf[263],17,"unsigned-c-string");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[267]=C_h_intern(&lf[267],28,"\010compilervalid-c-identifier\077");
lf[268]=C_h_intern(&lf[268],8,"location");
lf[269]=C_h_intern(&lf[269],17,"\003sysmake-locative");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[271]=C_h_intern(&lf[271],13,"\004corecallunit");
lf[272]=C_h_intern(&lf[272],14,"\004coreprimitive");
lf[273]=C_h_intern(&lf[273],37,"\010compilerupdate-line-number-database!");
lf[274]=C_h_intern(&lf[274],23,"\003sysmacroexpand-1-local");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[277]=C_h_intern(&lf[277],31,"\010compileremit-syntax-trace-info");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[279]=C_h_intern(&lf[279],4,"list");
lf[280]=C_h_intern(&lf[280],1,"t");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_h_intern(&lf[282],4,"caar");
lf[283]=C_h_intern(&lf[283],18,"\010compilerconstant\077");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[285]=C_h_intern(&lf[285],26,"\010compilerinternal-bindings");
lf[286]=C_h_intern(&lf[286],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[287]=C_h_intern(&lf[287],7,"reverse");
lf[288]=C_h_intern(&lf[288],22,"\003sysclear-trace-buffer");
lf[289]=C_h_intern(&lf[289],26,"\010compilerdebugging-chicken");
lf[290]=C_h_intern(&lf[290],12,"pretty-print");
lf[291]=C_h_intern(&lf[291],7,"newline");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[294]=C_h_intern(&lf[294],4,"uses");
lf[295]=C_h_intern(&lf[295],29,"\010compilerstring->c-identifier");
lf[296]=C_h_intern(&lf[296],18,"\010compilerstringify");
lf[297]=C_h_intern(&lf[297],17,"register-feature!");
lf[298]=C_h_intern(&lf[298],4,"unit");
lf[299]=C_h_intern(&lf[299],5,"usage");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-standard-bindings");
lf[302]=C_h_intern(&lf[302],34,"\010compilerdefault-extended-bindings");
lf[303]=C_h_intern(&lf[303],18,"usual-integrations");
lf[304]=C_h_intern(&lf[304],17,"lset-intersection");
lf[305]=C_h_intern(&lf[305],6,"fixnum");
lf[306]=C_h_intern(&lf[306],17,"fixnum-arithmetic");
lf[307]=C_h_intern(&lf[307],23,"\005matchset-error-control");
lf[308]=C_h_intern(&lf[308],12,"\000unspecified");
lf[309]=C_h_intern(&lf[309],4,"safe");
lf[310]=C_h_intern(&lf[310],18,"interrupts-enabled");
lf[311]=C_h_intern(&lf[311],18,"disable-interrupts");
lf[312]=C_h_intern(&lf[312],15,"disable-warning");
lf[313]=C_h_intern(&lf[313],26,"\010compilerdisabled-warnings");
lf[314]=C_h_intern(&lf[314],12,"safe-globals");
lf[315]=C_h_intern(&lf[315],38,"no-procedure-checks-for-usual-bindings");
lf[316]=C_h_intern(&lf[316],18,"bound-to-procedure");
lf[317]=C_h_intern(&lf[317],15,"foreign-declare");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[319]=C_h_intern(&lf[319],5,"every");
lf[320]=C_h_intern(&lf[320],7,"string\077");
lf[321]=C_h_intern(&lf[321],14,"custom-declare");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[323]=C_h_intern(&lf[323],35,"\010compilerprocess-custom-declaration");
lf[324]=C_h_intern(&lf[324],9,"c-options");
lf[325]=C_h_intern(&lf[325],31,"\010compileremit-control-file-item");
lf[326]=C_h_intern(&lf[326],12,"link-options");
lf[327]=C_h_intern(&lf[327],12,"post-process");
lf[328]=C_h_intern(&lf[328],17,"string-substitute");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[330]=C_h_intern(&lf[330],24,"pathname-strip-extension");
lf[331]=C_h_intern(&lf[331],5,"block");
lf[332]=C_h_intern(&lf[332],8,"separate");
lf[333]=C_h_intern(&lf[333],20,"keep-shadowed-macros");
lf[334]=C_h_intern(&lf[334],6,"unused");
lf[335]=C_h_intern(&lf[335],3,"not");
lf[336]=C_h_intern(&lf[336],15,"lset-difference");
lf[337]=C_h_intern(&lf[337],6,"inline");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[339]=C_h_intern(&lf[339],15,"run-time-macros");
lf[340]=C_h_intern(&lf[340],25,"\003sysenable-runtime-macros");
lf[341]=C_h_intern(&lf[341],12,"block-global");
lf[342]=C_h_intern(&lf[342],4,"hide");
lf[343]=C_h_intern(&lf[343],6,"export");
lf[344]=C_h_intern(&lf[344],12,"emit-exports");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[346]=C_h_intern(&lf[346],30,"emit-external-prototypes-first");
lf[347]=C_h_intern(&lf[347],11,"lambda-lift");
lf[348]=C_h_intern(&lf[348],12,"inline-limit");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[350]=C_h_intern(&lf[350],8,"constant");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[352]=C_h_intern(&lf[352],7,"symbol\077");
lf[353]=C_h_intern(&lf[353],6,"import");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[355]=C_h_intern(&lf[355],9,"partition");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[357]=C_h_intern(&lf[357],7,"profile");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[360]=C_h_intern(&lf[360],17,"make-foreign-stub");
lf[361]=C_h_intern(&lf[361],12,"foreign-stub");
lf[362]=C_h_intern(&lf[362],13,"foreign-stub\077");
lf[363]=C_h_intern(&lf[363],20,"foreign-stub-id-set!");
lf[364]=C_h_intern(&lf[364],14,"\003sysblock-set!");
lf[365]=C_h_intern(&lf[365],15,"foreign-stub-id");
lf[366]=C_h_intern(&lf[366],29,"foreign-stub-return-type-set!");
lf[367]=C_h_intern(&lf[367],24,"foreign-stub-return-type");
lf[368]=C_h_intern(&lf[368],22,"foreign-stub-name-set!");
lf[369]=C_h_intern(&lf[369],17,"foreign-stub-name");
lf[370]=C_h_intern(&lf[370],32,"foreign-stub-argument-types-set!");
lf[371]=C_h_intern(&lf[371],27,"foreign-stub-argument-types");
lf[372]=C_h_intern(&lf[372],32,"foreign-stub-argument-names-set!");
lf[373]=C_h_intern(&lf[373],27,"foreign-stub-argument-names");
lf[374]=C_h_intern(&lf[374],22,"foreign-stub-body-set!");
lf[375]=C_h_intern(&lf[375],17,"foreign-stub-body");
lf[376]=C_h_intern(&lf[376],21,"foreign-stub-cps-set!");
lf[377]=C_h_intern(&lf[377],16,"foreign-stub-cps");
lf[378]=C_h_intern(&lf[378],26,"foreign-stub-callback-set!");
lf[379]=C_h_intern(&lf[379],21,"foreign-stub-callback");
lf[380]=C_h_intern(&lf[380],28,"\010compilercreate-foreign-stub");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[382]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[384]=C_h_intern(&lf[384],37,"\010compilerestimate-foreign-result-size");
lf[385]=C_h_intern(&lf[385],4,"stub");
lf[386]=C_h_intern(&lf[386],1,"a");
lf[387]=C_h_intern(&lf[387],13,"list-tabulate");
lf[388]=C_h_intern(&lf[388],6,"second");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[391]=C_h_intern(&lf[391],4,"cadr");
lf[392]=C_h_intern(&lf[392],3,"car");
lf[393]=C_h_intern(&lf[393],4,"void");
lf[394]=C_h_intern(&lf[394],24,"\003sysline-number-database");
lf[395]=C_h_intern(&lf[395],31,"\010compilerperform-cps-conversion");
lf[396]=C_h_intern(&lf[396],4,"node");
lf[397]=C_h_intern(&lf[397],11,"\004corelambda");
lf[398]=C_h_intern(&lf[398],9,"\004corecall");
lf[399]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[400]=C_h_intern(&lf[400],16,"\010compilervarnode");
lf[401]=C_h_intern(&lf[401],1,"k");
lf[402]=C_h_intern(&lf[402],13,"\004corevariable");
lf[403]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[404]=C_h_intern(&lf[404],2,"f_");
lf[405]=C_h_intern(&lf[405],26,"make-foreign-callback-stub");
lf[406]=C_h_intern(&lf[406],13,"\010compilerbomb");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[408]=C_h_intern(&lf[408],15,"\004coreglobal-ref");
lf[409]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[410]=C_h_intern(&lf[410],6,"values");
lf[411]=C_h_intern(&lf[411],21,"foreign-callback-stub");
lf[412]=C_h_intern(&lf[412],22,"foreign-callback-stub\077");
lf[413]=C_h_intern(&lf[413],29,"foreign-callback-stub-id-set!");
lf[414]=C_h_intern(&lf[414],24,"foreign-callback-stub-id");
lf[415]=C_h_intern(&lf[415],31,"foreign-callback-stub-name-set!");
lf[416]=C_h_intern(&lf[416],26,"foreign-callback-stub-name");
lf[417]=C_h_intern(&lf[417],37,"foreign-callback-stub-qualifiers-set!");
lf[418]=C_h_intern(&lf[418],32,"foreign-callback-stub-qualifiers");
lf[419]=C_h_intern(&lf[419],38,"foreign-callback-stub-return-type-set!");
lf[420]=C_h_intern(&lf[420],33,"foreign-callback-stub-return-type");
lf[421]=C_h_intern(&lf[421],41,"foreign-callback-stub-argument-types-set!");
lf[422]=C_h_intern(&lf[422],36,"foreign-callback-stub-argument-types");
lf[423]=C_h_intern(&lf[423],27,"\010compileranalyze-expression");
lf[424]=C_h_intern(&lf[424],17,"\010compilercollect!");
lf[425]=C_h_intern(&lf[425],10,"references");
lf[426]=C_h_intern(&lf[426],13,"\010compilerput!");
lf[427]=C_h_intern(&lf[427],9,"undefined");
lf[428]=C_h_intern(&lf[428],7,"unknown");
lf[429]=C_h_intern(&lf[429],5,"value");
lf[430]=C_h_intern(&lf[430],12,"\010compilerget");
lf[431]=C_h_intern(&lf[431],4,"home");
lf[432]=C_h_intern(&lf[432],16,"\010compilerget-all");
lf[433]=C_h_intern(&lf[433],8,"captured");
lf[434]=C_h_intern(&lf[434],6,"global");
lf[435]=C_h_intern(&lf[435],12,"\004corerecurse");
lf[436]=C_h_intern(&lf[436],44,"\010compileroptimizable-rest-argument-operators");
lf[437]=C_h_intern(&lf[437],15,"\010compilercount!");
lf[438]=C_h_intern(&lf[438],16,"o-r/access-count");
lf[439]=C_h_intern(&lf[439],14,"rest-parameter");
lf[440]=C_h_intern(&lf[440],16,"standard-binding");
lf[441]=C_h_intern(&lf[441],10,"call-sites");
lf[442]=C_h_intern(&lf[442],18,"\004coredirect_lambda");
lf[443]=C_h_intern(&lf[443],6,"simple");
lf[444]=C_h_intern(&lf[444],28,"\010compilersimple-lambda-node\077");
lf[445]=C_h_intern(&lf[445],6,"vector");
lf[446]=C_h_intern(&lf[446],12,"contained-in");
lf[447]=C_h_intern(&lf[447],8,"contains");
lf[448]=C_h_intern(&lf[448],8,"assigned");
lf[449]=C_h_intern(&lf[449],16,"assigned-locally");
lf[450]=C_h_intern(&lf[450],15,"potential-value");
lf[451]=C_h_intern(&lf[451],5,"redef");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[454]=C_h_intern(&lf[454],16,"extended-binding");
lf[455]=C_h_intern(&lf[455],9,"\004coreproc");
lf[456]=C_h_intern(&lf[456],3,"any");
lf[457]=C_h_intern(&lf[457],9,"replacing");
lf[458]=C_h_intern(&lf[458],10,"replacable");
lf[459]=C_h_intern(&lf[459],9,"removable");
lf[460]=C_h_intern(&lf[460],37,"\010compilerexpression-has-side-effects\077");
lf[461]=C_h_intern(&lf[461],21,"has-unused-parameters");
lf[462]=C_h_intern(&lf[462],13,"explicit-rest");
lf[463]=C_h_intern(&lf[463],11,"collapsable");
lf[464]=C_h_intern(&lf[464],12,"contractable");
lf[465]=C_h_intern(&lf[465],9,"inlinable");
lf[466]=C_h_intern(&lf[466],28,"\010compilerscan-free-variables");
lf[467]=C_h_intern(&lf[467],5,"boxed");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[470]=C_h_intern(&lf[470],23,"\003syshash-table-for-each");
lf[471]=C_h_intern(&lf[471],18,"\010compilerdebugging");
lf[472]=C_h_intern(&lf[472],1,"p");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[475]=C_h_intern(&lf[475],37,"\010compilerinitialize-analysis-database");
lf[476]=C_h_intern(&lf[476],35,"\010compilerperform-closure-conversion");
lf[477]=C_h_intern(&lf[477],12,"customizable");
lf[478]=C_h_intern(&lf[478],20,"node-parameters-set!");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[480]=C_h_intern(&lf[480],28,"\010compilersource-info->string");
lf[481]=C_h_intern(&lf[481],8,"toplevel");
lf[482]=C_h_intern(&lf[482],18,"captured-variables");
lf[483]=C_h_intern(&lf[483],12,"closure-size");
lf[484]=C_h_intern(&lf[484],8,"\004coreref");
lf[485]=C_h_intern(&lf[485],10,"\004coreunbox");
lf[486]=C_h_intern(&lf[486],8,"\004corebox");
lf[487]=C_h_intern(&lf[487],12,"\004coreclosure");
lf[488]=C_h_intern(&lf[488],14,"\010compilerqnode");
lf[489]=C_h_intern(&lf[489],20,"\003sysmake-lambda-info");
lf[490]=C_h_intern(&lf[490],1,"\077");
lf[491]=C_h_intern(&lf[491],8,"->string");
lf[492]=C_h_intern(&lf[492],18,"\010compilerreal-name");
lf[493]=C_h_intern(&lf[493],10,"fold-right");
lf[494]=C_h_intern(&lf[494],10,"boxed-rest");
lf[495]=C_h_intern(&lf[495],6,"filter");
lf[496]=C_h_intern(&lf[496],16,"\004coreupdatebox_i");
lf[497]=C_h_intern(&lf[497],14,"\004coreupdatebox");
lf[498]=C_h_intern(&lf[498],13,"\004coreupdate_i");
lf[499]=C_h_intern(&lf[499],11,"\004coreupdate");
lf[500]=C_h_intern(&lf[500],19,"\010compilerimmediate\077");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[502]=C_h_intern(&lf[502],11,"\004coreswitch");
lf[503]=C_h_intern(&lf[503],9,"\004corecond");
lf[504]=C_h_intern(&lf[504],16,"\004coredirect_call");
lf[505]=C_h_intern(&lf[505],11,"\004corereturn");
lf[506]=C_h_intern(&lf[506],1,"o");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[508]=C_h_intern(&lf[508],16,"\003sysmake-promise");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[512]=C_h_intern(&lf[512],19,"make-lambda-literal");
lf[513]=C_h_intern(&lf[513],14,"lambda-literal");
lf[514]=C_h_intern(&lf[514],15,"lambda-literal\077");
lf[515]=C_h_intern(&lf[515],22,"lambda-literal-id-set!");
lf[516]=C_h_intern(&lf[516],17,"lambda-literal-id");
lf[517]=C_h_intern(&lf[517],28,"lambda-literal-external-set!");
lf[518]=C_h_intern(&lf[518],23,"lambda-literal-external");
lf[519]=C_h_intern(&lf[519],29,"lambda-literal-arguments-set!");
lf[520]=C_h_intern(&lf[520],24,"lambda-literal-arguments");
lf[521]=C_h_intern(&lf[521],34,"lambda-literal-argument-count-set!");
lf[522]=C_h_intern(&lf[522],29,"lambda-literal-argument-count");
lf[523]=C_h_intern(&lf[523],33,"lambda-literal-rest-argument-set!");
lf[524]=C_h_intern(&lf[524],28,"lambda-literal-rest-argument");
lf[525]=C_h_intern(&lf[525],31,"lambda-literal-temporaries-set!");
lf[526]=C_h_intern(&lf[526],26,"lambda-literal-temporaries");
lf[527]=C_h_intern(&lf[527],37,"lambda-literal-callee-signatures-set!");
lf[528]=C_h_intern(&lf[528],32,"lambda-literal-callee-signatures");
lf[529]=C_h_intern(&lf[529],29,"lambda-literal-allocated-set!");
lf[530]=C_h_intern(&lf[530],24,"lambda-literal-allocated");
lf[531]=C_h_intern(&lf[531],35,"lambda-literal-directly-called-set!");
lf[532]=C_h_intern(&lf[532],30,"lambda-literal-directly-called");
lf[533]=C_h_intern(&lf[533],32,"lambda-literal-closure-size-set!");
lf[534]=C_h_intern(&lf[534],27,"lambda-literal-closure-size");
lf[535]=C_h_intern(&lf[535],27,"lambda-literal-looping-set!");
lf[536]=C_h_intern(&lf[536],22,"lambda-literal-looping");
lf[537]=C_h_intern(&lf[537],32,"lambda-literal-customizable-set!");
lf[538]=C_h_intern(&lf[538],27,"lambda-literal-customizable");
lf[539]=C_h_intern(&lf[539],38,"lambda-literal-rest-argument-mode-set!");
lf[540]=C_h_intern(&lf[540],33,"lambda-literal-rest-argument-mode");
lf[541]=C_h_intern(&lf[541],24,"lambda-literal-body-set!");
lf[542]=C_h_intern(&lf[542],19,"lambda-literal-body");
lf[543]=C_h_intern(&lf[543],26,"lambda-literal-direct-set!");
lf[544]=C_h_intern(&lf[544],21,"lambda-literal-direct");
lf[545]=C_h_intern(&lf[545],36,"\010compilerprepare-for-code-generation");
lf[546]=C_h_intern(&lf[546],14,"\004coreimmediate");
lf[547]=C_h_intern(&lf[547],3,"fix");
lf[548]=C_h_intern(&lf[548],4,"bool");
lf[549]=C_h_intern(&lf[549],4,"char");
lf[550]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[551]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[553]=C_h_intern(&lf[553],36,"\010compilermake-block-variable-literal");
lf[554]=C_h_intern(&lf[554],36,"\010compilerblock-variable-literal-name");
lf[555]=C_h_intern(&lf[555],32,"\010compilerblock-variable-literal\077");
lf[556]=C_h_intern(&lf[556],10,"list-index");
lf[557]=C_h_intern(&lf[557],11,"\004coreglobal");
lf[558]=C_h_intern(&lf[558],10,"\004corelocal");
lf[559]=C_h_intern(&lf[559],12,"\004coreliteral");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[562]=C_h_intern(&lf[562],4,"none");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[565]=C_h_intern(&lf[565],7,"butlast");
lf[566]=C_h_intern(&lf[566],9,"\004corebind");
lf[567]=C_h_intern(&lf[567],13,"\004coresetlocal");
lf[568]=C_h_intern(&lf[568],16,"\004coresetglobal_i");
lf[569]=C_h_intern(&lf[569],14,"\004coresetglobal");
lf[570]=C_h_intern(&lf[570],1,"=");
lf[571]=C_h_intern(&lf[571],4,"type");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[574]=C_h_intern(&lf[574],20,"\010compilerbig-fixnum\077");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[579]=C_h_intern(&lf[579],14,"make-parameter");
C_register_lf2(lf,580,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1774 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1777 in k1774 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1780 in k1777 in k1774 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 317  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_set_block_item(lf[48],0,C_SCHEME_FALSE);
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t43=C_mutate((C_word*)lf[50]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_SCHEME_FALSE);
t46=C_set_block_item(lf[53],0,C_fix(0));
t47=C_set_block_item(lf[54],0,C_SCHEME_FALSE);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_END_OF_LIST);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_FALSE);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_END_OF_LIST);
t56=C_set_block_item(lf[63],0,C_SCHEME_FALSE);
t57=C_set_block_item(lf[64],0,C_SCHEME_END_OF_LIST);
t58=C_set_block_item(lf[65],0,C_SCHEME_TRUE);
t59=C_set_block_item(lf[66],0,C_SCHEME_FALSE);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_SCHEME_END_OF_LIST);
t66=C_set_block_item(lf[73],0,C_fix(0));
t67=C_set_block_item(lf[74],0,C_SCHEME_FALSE);
t68=C_set_block_item(lf[75],0,C_SCHEME_END_OF_LIST);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_FALSE);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_END_OF_LIST);
t75=C_set_block_item(lf[82],0,C_SCHEME_TRUE);
t76=C_set_block_item(lf[83],0,C_SCHEME_FALSE);
t77=C_set_block_item(lf[84],0,C_SCHEME_END_OF_LIST);
t78=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_END_OF_LIST);
t82=C_set_block_item(lf[89],0,C_SCHEME_FALSE);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_END_OF_LIST);
t85=C_set_block_item(lf[92],0,C_SCHEME_FALSE);
t86=C_set_block_item(lf[93],0,C_SCHEME_TRUE);
t87=C_set_block_item(lf[94],0,C_SCHEME_FALSE);
t88=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1905,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1976,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4767,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5730,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5736,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5742,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5751,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5760,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5769,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5778,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5787,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5796,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5805,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5814,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5823,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5832,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5841,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5850,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5859,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5868,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5877,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5886,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6040,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6085,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6130,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6167,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6204,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6285,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6375,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[405]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7050,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7056,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7062,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7071,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7080,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7089,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7098,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7107,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7116,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7134,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7143,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7152,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[476]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8677,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9911,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9917,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9923,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9932,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9941,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9950,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9959,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9968,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9977,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9986,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9995,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10004,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10013,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10022,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10031,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10040,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10049,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10058,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10067,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10076,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10085,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10094,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10103,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10112,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10121,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10130,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10139,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10148,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10157,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10166,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10175,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10184,tmp=(C_word)a,a+=2,tmp));
t163=C_mutate((C_word*)lf[545]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10193,tmp=(C_word)a,a+=2,tmp));
t164=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t164+1)))(2,t164,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10193,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11188,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11142,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11156,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11062,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10230,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10196,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10283,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11050,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11250,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2323 debugging */
t37=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[472],lf[578]);}

/* k11248 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2324 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10283(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11251 in k11248 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2325 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[577],((C_word*)((C_word*)t0)[2])[1]);}

/* k11254 in k11251 in k11248 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2326 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[576],((C_word*)((C_word*)t0)[2])[1]);}

/* k11257 in k11254 in k11251 in k11248 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2327 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11260 in k11257 in k11254 in k11251 in k11248 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2328 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11050,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11056,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a11055 in mapwalk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11056,3,t0,t1,t2);}
/* compiler.scm: 2281 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10283(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10283(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10283,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[126]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[455]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[402]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2115 walk-var */
t16=((C_word*)t0)[16];
f_10196(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[408]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2118 walk-global */
t17=((C_word*)t0)[15];
f_10230(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[504]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10341,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2122 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_11050(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[196]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10361,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2126 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_11050(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[104]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10385,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10389,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2129 estimate-foreign-result-size */
t22=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[108]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10413,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10417,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2133 estimate-foreign-result-size */
t23=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[487]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10434,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2138 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11050(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[486]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10461,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2142 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[497]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10477,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2146 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11050(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[397]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[442]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[442]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10533,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2166 decompose-lambda-list */
t36=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[153]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[486],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10717,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2223 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[176]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10758,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2229 posq */
t30=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[398]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2253 lset-adjoin */
t31=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[570]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[435]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10921,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10921(t32,t31);}
else{
t30=t29;
f_10921(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10949,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11036,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2264 big-fixnum? */
t33=C_retrieve(lf[574]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10949(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11039,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2278 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_11050(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k11037 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11039,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k11034 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10949(t2,(C_word)C_i_not(t1));}

/* k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10949,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2265 immediate-literal */
f_11188(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[305],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10970,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10997,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2268 big-fixnum? */
t5=C_retrieve(lf[574]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10970(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11007,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2274 literal */
t4=((C_word*)t0)[2];
f_11062(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2275 immediate? */
t3=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k11011 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11013,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2275 immediate-literal */
f_11188(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11026,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2276 literal */
t3=((C_word*)t0)[2];
f_11062(t3,t2,((C_word*)t0)[3]);}}

/* k11024 in k11011 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11026,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* k11005 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11007,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* k10995 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10970(t2,(C_word)C_i_not(t1));}

/* k10968 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10970,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2269 compiler-warning */
t4=C_retrieve(lf[145]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[571],lf[572],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2273 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[573],((C_word*)t0)[4]);}}

/* k10971 in k10968 in k10947 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2272 immediate-literal */
f_11188(((C_word*)t0)[2],t2);}

/* k10919 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10921,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10924,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2260 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11050(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10922 in k10919 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10924,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10876 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10878,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10890,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10890(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10890(t6,C_SCHEME_FALSE);}}

/* k10888 in k10876 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10881(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10881(t2,C_SCHEME_UNDEFINED);}}

/* k10879 in k10876 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10881,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2256 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11050(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10882 in k10879 in k10876 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10884,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10758,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10774,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2231 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10283(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10847,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10847(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10847(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10847(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10859,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2237 get */
t8=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[440]);}}}}}

/* k10857 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10847(2,t2,t1);}
else{
/* compiler.scm: 2238 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454]);}}

/* k10845 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10847,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[103]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2240 immediate? */
t8=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10786(2,t6,C_SCHEME_FALSE);}}

/* k10784 in k10845 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10786,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10792(t6,t5);}
else{
t4=t3;
f_10792(t4,C_SCHEME_UNDEFINED);}}

/* k10790 in k10784 in k10845 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10792,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[568]:lf[569]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10816,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2246 blockvar-literal */
t4=((C_word*)t0)[4];
f_11156(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2247 literal */
t4=((C_word*)t0)[2];
f_11062(t4,t3,((C_word*)t0)[3]);}}

/* k10814 in k10790 in k10784 in k10845 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10816,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10808,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2249 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10283(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10806 in k10814 in k10790 in k10784 in k10845 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10808,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10772 in k10756 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[567],((C_word*)t0)[2],t2));}

/* k10715 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10721,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2224 append */
t5=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10727 in k10715 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10733,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2224 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10731 in k10727 in k10715 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2224 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10283(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10719 in k10715 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10721,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[566],((C_word*)t0)[2],t2));}

/* a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10533,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10654,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2172 get */
t8=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[425]);}
else{
t7=t6;
f_10540(2,t7,C_SCHEME_FALSE);}}

/* k10652 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10660,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2173 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}

/* k10658 in k10652 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10660,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10540(2,t2,lf[279]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2174 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[494]);}}

/* k10683 in k10658 in k10652 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10666(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10666(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10664 in k10658 in k10652 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10540(2,t2,lf[562]);}
else{
/* compiler.scm: 2175 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[439]);}}

/* k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10543,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10645,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[562],t1);
if(C_truep(t5)){
/* compiler.scm: 2179 butlast */
t6=C_retrieve(lf[565]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10645(2,t6,((C_word*)t0)[7]);}}

/* k10643 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2176 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10283(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10546,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[562]);
if(C_truep(t3)){
/* compiler.scm: 2184 debugging */
t4=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[506],lf[563],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[445]);
if(C_truep(t4)){
/* compiler.scm: 2185 debugging */
t5=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[506],lf[564],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10546(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2187 bomb */
t4=C_retrieve(lf[406]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[561],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10549(2,t4,C_SCHEME_UNDEFINED);}}

/* k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[64])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10587,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2199 get */
t7=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[483]);}

/* k10585 in k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10587,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10594(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10613,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2203 debugging */
t7=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[506],lf[560],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10594(t6,C_SCHEME_FALSE);}}}

/* k10611 in k10585 in k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10594(t2,C_SCHEME_TRUE);}

/* k10592 in k10585 in k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10594,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10598(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2205 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[477]);}}

/* k10596 in k10592 in k10585 in k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2189 make-lambda-literal */
t2=C_retrieve(lf[512]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10569 in k10547 in k10544 in k10541 in k10538 in a10532 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[396],lf[455],t9,C_SCHEME_END_OF_LIST));}

/* k10475 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10480,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10486,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[402],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10486(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10486(t6,C_SCHEME_FALSE);}}

/* k10484 in k10475 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10480(t4,lf[496]);}
else{
t2=((C_word*)t0)[3];
f_10480(t2,((C_word*)t0)[2]);}}

/* k10478 in k10475 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10480,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10459 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10461,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[486],((C_word*)t0)[2],t2));}

/* k10432 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10434,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t1));}

/* k10415 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2133 words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10411 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10413,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10406,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2134 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11050(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10404 in k10411 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10406,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10387 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2129 words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10383 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10385,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10359 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10361,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10339 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10341,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10196,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10200,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2083 posq */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10198 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10200,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[558],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2084 keyword? */
t3=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10213 in k10198 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10215,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10225,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2084 literal */
t3=((C_word*)t0)[5];
f_11062(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2085 walk-global */
t2=((C_word*)t0)[3];
f_10230(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10223 in k10213 in k10198 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10225,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10230,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10234(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10234(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10234(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10234(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10275,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2092 get */
t9=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[440]);}}}}}

/* k10273 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10234(2,t2,t1);}
else{
/* compiler.scm: 2093 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454]);}}

/* k10232 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10234,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10240(t6,t5);}
else{
t4=t3;
f_10240(t4,C_SCHEME_UNDEFINED);}}

/* k10238 in k10232 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10240,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2099 blockvar-literal */
t3=((C_word*)t0)[3];
f_11156(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2100 literal */
t3=((C_word*)t0)[2];
f_11062(t3,t2,((C_word*)t0)[5]);}}

/* k10248 in k10238 in k10232 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10250,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11062,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2284 immediate? */
t4=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11067 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11069,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2284 immediate-literal */
f_11188(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11081,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11095,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2287 list-index */
t4=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_11081(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11121,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2293 append */
t5=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11131,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2295 posq */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11129 in k11067 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2296 new-literal */
t2=((C_word*)t0)[3];
f_11142(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11119 in k11067 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11121,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11094 in k11067 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11095,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11079 in k11067 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2289 new-literal */
t2=((C_word*)t0)[3];
f_11142(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11156,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11160,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2304 list-index */
t5=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11171 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11172,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11179,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2306 block-variable-literal? */
t4=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11177 in a11171 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2307 block-variable-literal-name */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11184 in k11177 in a11171 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11158 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11160,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2309 make-block-variable-literal */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11168 in k11158 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2309 new-literal */
t2=((C_word*)t0)[3];
f_11142(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11142,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11150,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2300 append */
t6=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11148 in new-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11188(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11188,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[126],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11201(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11201(2,t6,(C_word)C_a_i_list(&a,2,lf[548],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11201(2,t6,(C_word)C_a_i_list(&a,2,lf[549],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11201(2,t6,lf[550]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11201(2,t6,lf[551]);}
else{
/* compiler.scm: 2320 bomb */
t6=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[552]);}}}}}}}

/* k11199 in immediate-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11201,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[546],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10184,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10175,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10166,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10157,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10148,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10139,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10130,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10121,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10112,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10103,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10094,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10085,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10076,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10067,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10058,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10049,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10040,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10031,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10022,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10013,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10004,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9995,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9986,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9977,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9968,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9959,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9950,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9941,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9932,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9923,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2053 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9917,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[513]));}

/* make-lambda-literal in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9911,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[513],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8677,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8680,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8686,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8696,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8707,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9742,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9041,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9730,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9878,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2041 debugging */
t22=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[472],lf[511]);}

/* k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2042 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8707(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2043 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[510],((C_word*)((C_word*)t0)[2])[1]);}

/* k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2044 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[509]);}

/* k9885 in k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2045 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9041(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9888 in k9885 in k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9893,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9893(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9903,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9905,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2047 ##sys#make-promise */
t6=*((C_word*)lf[508]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9904 in k9888 in k9885 in k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9905,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[64])));}

/* k9901 in k9888 in k9885 in k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2047 debugging */
t2=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[506],lf[507],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9891 in k9888 in k9885 in k9882 in k9879 in k9876 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9730,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9736,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9735 in maptransform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9736,3,t0,t1,t2);}
/* compiler.scm: 2013 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9041(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9041,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_9060(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t13)){
t14=t12;
f_9060(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[455]);
t15=t12;
f_9060(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[408])));}}}

/* k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9060,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[402]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9072,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1888 ref-var */
f_9742(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[114]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9093(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[398]);
if(C_truep(t5)){
t6=t4;
f_9093(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t6)){
t7=t4;
f_9093(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
if(C_truep(t7)){
t8=t4;
f_9093(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[271]);
if(C_truep(t8)){
t9=t4;
f_9093(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[104]);
if(C_truep(t9)){
t10=t4;
f_9093(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[178]);
if(C_truep(t10)){
t11=t4;
f_9093(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t11)){
t12=t4;
f_9093(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t12)){
t13=t4;
f_9093(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[504]);
if(C_truep(t13)){
t14=t4;
f_9093(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[435]);
if(C_truep(t14)){
t15=t4;
f_9093(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[505]);
if(C_truep(t15)){
t16=t4;
f_9093(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[108]);
t17=t4;
f_9093(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[181])));}}}}}}}}}}}}}}}

/* k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9093,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9099,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1896 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9730(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[153]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1900 test */
t5=((C_word*)t0)[4];
f_8680(t5,t4,t3,lf[467]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[397]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[442]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1916 decompose-lambda-list */
t7=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[176]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9460,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[103],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1976 immediate? */
t13=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9460(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[272]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[396],lf[455],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9609,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9616,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9620,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 2007 ##sys#make-lambda-info */
t16=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9609(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 2010 bomb */
t7=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[501]);}}}}}}

/* k9618 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2007 qnode */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9614 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9609(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9607 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9609,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t2));}

/* k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9460,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1978 posq */
t4=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1980 test */
t3=((C_word*)t0)[3];
f_8680(t3,t2,((C_word*)t0)[2],lf[467]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1992 test */
t3=((C_word*)t0)[3];
f_8680(t3,t2,((C_word*)t0)[2],lf[467]);}}

/* k9534 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9536,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1996 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9566,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2000 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9041(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9564 in k9534 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9566,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[176],((C_word*)t0)[2],t2));}

/* k9547 in k9534 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1997 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9041(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9551 in k9547 in k9534 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9553,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9473 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9475,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1984 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1990 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9520 in k9473 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9526,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1991 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9041(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9524 in k9520 in k9473 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9526,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9500 in k9473 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9502,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[484],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9498,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1985 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9041(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9496 in k9500 in k9473 in k9464 in k9458 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9498,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9189,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1919 filter */
t7=C_retrieve(lf[495]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9437 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9438,3,t0,t1,t2);}
/* compiler.scm: 1919 test */
t3=((C_word*)t0)[2];
f_8680(t3,t1,t2,lf[467]);}

/* k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[123]),t1);}

/* k9434 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1920 map */
t2=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1921 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[124]);}

/* k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9199,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[481]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1923 test */
t4=((C_word*)t0)[2];
f_8680(t4,t3,t2,lf[482]);}

/* k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9205,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1924 test */
t4=((C_word*)t0)[2];
f_8680(t4,t3,((C_word*)t0)[17],lf[483]);}

/* k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9211,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9217(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9217(t4,C_SCHEME_FALSE);}}

/* k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9217,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1930 test */
t4=((C_word*)t0)[2];
f_8680(t4,t3,((C_word*)t0)[6],lf[467]);}
else{
t3=t2;
f_9220(2,t3,C_SCHEME_FALSE);}}

/* k9401 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9403,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1931 test */
t3=((C_word*)t0)[2];
f_8680(t3,t2,((C_word*)t0)[6],lf[439]);}
else{
t2=((C_word*)t0)[4];
f_9220(2,t2,C_SCHEME_FALSE);}}

/* k9404 in k9401 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1932 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[494],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9220(2,t2,C_SCHEME_FALSE);}}

/* k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9220,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9379,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9378 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9379,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9362 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1942 build-lambda-list */
t4=C_retrieve(lf[167]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1951 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9041(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9305,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9319,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1956 unzip1 */
t5=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9297(2,t3,t1);}}

/* k9317 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9323,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9325,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9324 in k9317 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9325,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9336,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1957 varnode */
t5=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9334 in a9324 in k9317 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9336,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[486],C_SCHEME_END_OF_LIST,t2));}

/* k9321 in k9317 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1953 fold-right */
t2=C_retrieve(lf[493]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9304 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9305,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[396],lf[153],t5,t6));}

/* k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9297,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9243,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9281 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9282,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1960 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9288 in a9281 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1960 ref-var */
f_9742(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9246,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9257,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9261,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9265,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9273,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1968 real-name */
t7=C_retrieve(lf[492]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9246(2,t3,t1);}}

/* k9271 in k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9273,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[490]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1968 ->string */
t5=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9263 in k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1967 ##sys#make-lambda-info */
t2=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9259 in k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1966 qnode */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9255 in k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9257,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1963 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9244 in k9241 in k9295 in k9292 in k9358 in k9218 in k9215 in k9209 in k9203 in k9197 in k9194 in k9191 in a9188 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t2));}

/* k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1901 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9115 in k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9117,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9133,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1905 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_9041(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1912 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9730(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9167 in k9115 in k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t1));}

/* k9131 in k9115 in k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9133,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1908 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9160 in k9131 in k9115 in k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[486],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9154,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1909 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9041(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9152 in k9160 in k9131 in k9115 in k9112 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9154,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t4));}

/* k9097 in k9091 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9099,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9070 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1889 test */
t3=((C_word*)t0)[3];
f_8680(t3,t2,((C_word*)t0)[2],lf[467]);}

/* k9076 in k9070 in k9058 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9078,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[485],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9742(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9742,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9749,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2017 posq */
t9=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9747 in ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9765,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2020 varnode */
t5=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9763 in k9747 in ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9765,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[484],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8707,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8726(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[402]);
if(C_truep(t13)){
t14=t12;
f_8726(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t14)){
t15=t12;
f_8726(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[455]);
if(C_truep(t15)){
t16=t12;
f_8726(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[272]);
t17=t12;
f_8726(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[408])));}}}}}

/* k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8726,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[153]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8737,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8747,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1825 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[398]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[402],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8789,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8806,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8816,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8930,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1841 test */
t19=((C_word*)t0)[3];
f_8680(t19,t18,t16,lf[428]);}
else{
t15=t14;
f_8816(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8806(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[397]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[442]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1865 decompose-lambda-list */
t8=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9005,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a9004 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9005,3,t0,t1,t2);}
/* compiler.scm: 1875 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8707(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8966,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[481]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9781,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9781(3,t14,t10,t6);}

/* walk in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9781,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[402]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9810,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2032 lset-adjoin */
t12=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[130]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[103]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9819,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9819(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[126]);
if(C_truep(t12)){
t13=t11;
f_9819(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[272]);
if(C_truep(t13)){
t14=t11;
f_9819(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[455]);
if(C_truep(t14)){
t15=t11;
f_9819(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[104]);
t16=t11;
f_9819(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[408])));}}}}}}

/* k9817 in walk in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9819,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9831,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9845,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2036 lset-adjoin */
t6=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[130]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9831(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9843 in k9817 in walk in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9831(t3,t2);}

/* k9829 in k9817 in walk in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2037 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9781(3,t3,((C_word*)t0)[2],t2);}

/* k9808 in walk in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9777 in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9779,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8979,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1871 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[483],t3);}

/* k8977 in k9777 in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1872 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[482],((C_word*)t0)[2]);}

/* k8980 in k8977 in k9777 in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8982,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1873 append */
t4=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8991 in k8980 in k8977 in k9777 in a8965 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1873 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8707(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8928 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8822(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1841 test */
t2=((C_word*)t0)[3];
f_8680(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[429]);}}

/* k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8828(t4,(C_word)C_eqp(lf[397],t3));}
else{
t3=t2;
f_8828(t3,C_SCHEME_FALSE);}}

/* k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8828,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1846 test */
t6=((C_word*)t0)[2];
f_8680(t6,t5,((C_word*)t0)[6],lf[425]);}
else{
t2=((C_word*)t0)[8];
f_8816(t2,C_SCHEME_END_OF_LIST);}}

/* k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8843,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1847 test */
t3=((C_word*)t0)[2];
f_8680(t3,t2,((C_word*)t0)[7],lf[441]);}

/* k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8846(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8846(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8846(t3,C_SCHEME_FALSE);}}

/* k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8846,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8864(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8864(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8864(t4,C_SCHEME_FALSE);}}

/* k8862 in k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8864,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1855 source-info->string */
t3=C_retrieve(lf[480]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8849(2,t2,C_SCHEME_UNDEFINED);}}

/* k8869 in k8862 in k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1853 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[479],t1);}

/* k8847 in k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1856 register-direct-call! */
t3=((C_word*)t0)[2];
f_8696(t3,t2,((C_word*)t0)[6]);}

/* k8850 in k8847 in k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1857 register-customizable! */
t3=((C_word*)t0)[3];
f_8686(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8855(2,t3,C_SCHEME_UNDEFINED);}}

/* k8853 in k8850 in k8847 in k8844 in k8841 in k8838 in k8826 in k8820 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8855,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8816(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8814 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8816,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8806(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8804 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8806,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1834 node-parameters-set! */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8787 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8793 in k8787 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8794,3,t0,t1,t2);}
/* compiler.scm: 1862 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8707(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8746 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8747,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8763 in a8746 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8764,3,t0,t1,t2);}
/* compiler.scm: 1826 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8707(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8749 in a8746 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8762,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1827 append */
t4=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8760 in k8749 in a8746 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1827 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8707(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8736 in k8724 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8737,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1825 split-at */
t3=C_retrieve(lf[246]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8696,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8705,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1812 lset-adjoin */
t6=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[130]+1),C_retrieve(lf[64]),t2);}

/* k8703 in register-direct-call! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[64]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8686,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8691,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1807 lset-adjoin */
t5=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[130]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8689 in register-customizable! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1808 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[477],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8680,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1804 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7156,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1425 make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7156,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7158,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7861,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7758,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7165,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7746,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7867,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7881,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7906,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1595 initialize-analysis-database */
t18=C_retrieve(lf[475]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1598 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[474]);}

/* k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=C_set_block_item(lf[53],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1600 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7165(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1603 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[473]);}

/* k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1604 ##sys#hash-table-for-each */
t4=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7929,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7933,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8564,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8563 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8564,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[428]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[433]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[450]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[441]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[449]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[434]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[429]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[438]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[439]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7933,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[65]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8529(t10,(C_word)C_eqp(lf[397],t9));}
else{
t7=t6;
f_8529(t7,C_SCHEME_FALSE);}}

/* k8527 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1650 set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7940(2,t2,C_SCHEME_UNDEFINED);}}

/* k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[91]));
t5=t3;
f_8475(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8475(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8475(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8475(t4,C_SCHEME_FALSE);}}

/* k8473 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8475,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1659 compiler-warning */
t3=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[186],lf[469],((C_word*)t0)[3]);}
else{
t3=t2;
f_8478(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7943(2,t2,C_SCHEME_UNDEFINED);}}

/* k8476 in k8473 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8490,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8490(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8490(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8490(t5,C_SCHEME_FALSE);}}}

/* k8488 in k8476 in k8473 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[61]));
t3=((C_word*)t0)[2];
f_8484(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8484(t2,C_SCHEME_FALSE);}}

/* k8482 in k8476 in k8473 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1663 compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[186],lf[468],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7943(2,t2,C_SCHEME_UNDEFINED);}}

/* k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1667 quick-put! */
f_7867(t2,((C_word*)t0)[8],lf[467],C_SCHEME_TRUE);}
else{
t4=t2;
f_7946(2,t4,C_SCHEME_UNDEFINED);}}

/* k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[397],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8418(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8450,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8458,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1676 scan-free-variables */
t13=C_retrieve(lf[466]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8418(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7949(2,t3,C_SCHEME_UNDEFINED);}}

/* k8456 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1676 every */
t2=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8449 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8450,3,t0,t1,t2);}
/* compiler.scm: 1676 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[434]);}

/* k8416 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8418,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8424,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8424(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8424(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7949(2,t2,C_SCHEME_UNDEFINED);}}

/* k8422 in k8416 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1678 quick-put! */
f_7867(((C_word*)t0)[3],((C_word*)t0)[2],lf[464],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1679 quick-put! */
f_7867(((C_word*)t0)[3],((C_word*)t0)[2],lf[465],C_SCHEME_TRUE);}}

/* k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8380(t6,(C_word)C_eqp(lf[103],t5));}
else{
t4=t3;
f_8380(t4,C_SCHEME_FALSE);}}

/* k8378 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1687 collapsable-literal? */
t6=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7952(2,t2,C_SCHEME_UNDEFINED);}}

/* k8387 in k8378 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8392(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8392(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8390 in k8387 in k8378 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1689 quick-put! */
f_7867(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7952(2,t2,C_SCHEME_UNDEFINED);}}

/* k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8281,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[397],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8281(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8281(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7955(2,t3,C_SCHEME_UNDEFINED);}}

/* k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8281,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1703 decompose-lambda-list */
t6=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7955(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7955(2,t2,C_SCHEME_UNDEFINED);}}

/* a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8299,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8303(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8342,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8341 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8342,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8349,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8367,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1709 get */
t5=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[425]);}

/* k8365 in a8341 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8367,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8349(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1710 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}}

/* k8361 in k8365 in a8341 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8349(t2,(C_word)C_i_not(t1));}

/* k8347 in a8341 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8349,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1711 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[334],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8350 in k8347 in a8341 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8301 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8309,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[81]));
t4=t2;
f_8309(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8309(t3,C_SCHEME_FALSE);}}

/* k8307 in k8301 in a8298 in k8279 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1717 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[461],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1720 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[462],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7958,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8218,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8218(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[402],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8245,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8245(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8259,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1728 get */
t15=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[434]);}}
else{
t6=t5;
f_8233(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8218(t5,C_SCHEME_FALSE);}}}

/* k8257 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8245(t2,(C_word)C_i_not(t1));}

/* k8243 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1729 expression-has-side-effects? */
t3=C_retrieve(lf[460]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8233(t2,C_SCHEME_FALSE);}}

/* k8250 in k8243 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8233(t2,(C_word)C_i_not(t1));}

/* k8231 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8218(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8216 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1731 quick-put! */
f_7867(((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7958(2,t2,C_SCHEME_UNDEFINED);}}

/* k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[402],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1743 get */
t11=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[425]);}
else{
t7=t2;
f_7961(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7961(2,t4,C_SCHEME_UNDEFINED);}}

/* k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1744 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[428]);}

/* k8202 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8136(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1744 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[429]);}}

/* k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8139,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8139(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8194,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1745 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[433]);}}

/* k8192 in k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8194,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8139(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8139(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1749 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}}
else{
t4=((C_word*)t0)[6];
f_8139(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8139(t2,C_SCHEME_FALSE);}}}

/* k8184 in k8192 in k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8186,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8139(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8139(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1750 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[434]);}}}

/* k8180 in k8184 in k8192 in k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8139(t2,(C_word)C_i_not(t1));}

/* k8137 in k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8139,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1751 quick-put! */
f_7867(t2,((C_word*)t0)[2],lf[458],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7961(2,t2,C_SCHEME_UNDEFINED);}}

/* k8140 in k8137 in k8134 in k8128 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1752 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}

/* k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7964,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7989(t6,(C_word)C_eqp(lf[397],t5));}
else{
t4=t3;
f_7989(t4,C_SCHEME_FALSE);}}

/* k7987 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7989,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7964(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8010,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_8010(t11,(C_word)C_eqp(lf[398],t10));}
else{
t10=t8;
f_8010(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_8010(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7964(2,t2,C_SCHEME_UNDEFINED);}}

/* k8008 in k7987 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[402],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[402],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_8031(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_8031(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_8031(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7964(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7964(2,t2,C_SCHEME_UNDEFINED);}}

/* k8029 in k8008 in k7987 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8031,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8037,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1772 quick-put! */
f_7867(t4,((C_word*)t0)[2],lf[458],t3);}
else{
t2=((C_word*)t0)[5];
f_7964(2,t2,C_SCHEME_UNDEFINED);}}

/* k8035 in k8029 in k8008 in k7987 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1773 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}

/* k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7970,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7970(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7970(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7970(t3,C_SCHEME_FALSE);}}

/* k7968 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7970,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1783 lset-adjoin */
t3=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[130]+1),C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7972 in k7968 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7944 in k7941 in k7938 in k7931 in a7928 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
/* compiler.scm: 1784 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[439],lf[445]);}

/* k7917 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1790 lset-difference */
t3=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[130]+1),C_retrieve(lf[56]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7921 in k7917 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7923,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[52]))){
t4=t3;
f_7926(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[53]));
t5=t3;
f_7926(t5,t4);}}

/* k7924 in k7921 in k7917 in k7914 in k7911 in k7907 in k7904 in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7881(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7881,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7891,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1590 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[447]);}}

/* k7889 in contains? in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7891,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1592 any */
t3=C_retrieve(lf[456]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7898 in k7889 in contains? in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7899,3,t0,t1,t2);}
/* compiler.scm: 1592 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7881(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7867(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7867,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7875,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1585 alist-cons */
t7=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7873 in quick-put! in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7746,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7752,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7751 in walkeach in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7752,3,t0,t1,t2);}
/* compiler.scm: 1559 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7165(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7165,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7158(C_fix(1));
t13=(C_word)C_eqp(t11,lf[103]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7187(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
t16=t14;
f_7187(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[455])));}}

/* k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[402]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7199,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1441 ref */
t5=((C_word*)t0)[8];
f_7861(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[408]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7242,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1449 ref */
t6=((C_word*)t0)[8];
f_7861(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[435]));
if(C_truep(t5)){
t6=f_7158(C_fix(1));
/* compiler.scm: 1455 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7746(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[398]);
if(C_truep(t6)){
t7=f_7158(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[402],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7301,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1462 collect! */
t16=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[441],t15);}
else{
t12=t9;
f_7278(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[153]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1476 append */
t9=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[160]);
if(C_truep(t8)){
t9=f_7158(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7440,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1489 decompose-lambda-list */
t12=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[397]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[442]));
if(C_truep(t10)){
t11=f_7158(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7484,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1502 decompose-lambda-list */
t14=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[176]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[65]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7669,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1533 get */
t17=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[440]);}
else{
t15=t14;
f_7594(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[272]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[195]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7708,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1552 ##sys#hash-table-ref */
t17=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[77]),t14);}
else{
t17=t16;
f_7708(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7708(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7708(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1556 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7746(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7706 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1553 set-real-name! */
t2=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7702(2,t2,C_SCHEME_UNDEFINED);}}

/* k7700 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1554 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7746(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7673 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7675,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1534 compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[451],lf[452],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1535 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[454]);}}

/* k7682 in k7673 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1536 compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[451],lf[453],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7669(2,t2,C_SCHEME_UNDEFINED);}}

/* k7667 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1537 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[450],((C_word*)t0)[2]);}

/* k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7623(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7623(t5,(C_word)C_i_not(t4));}}

/* k7621 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7623,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7158(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7638(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7638(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7638(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7629(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7597(2,t2,C_SCHEME_UNDEFINED);}}

/* k7636 in k7621 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1543 lset-adjoin */
t3=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[130]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7629(t2,C_SCHEME_UNDEFINED);}}

/* k7640 in k7636 in k7621 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7629(t3,t2);}

/* k7627 in k7621 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1544 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}

/* k7595 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1545 append */
t4=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7618 in k7595 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1545 assign */
t2=((C_word*)t0)[6];
f_7758(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7598 in k7595 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[82]))){
t3=t2;
f_7603(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1546 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[449],C_SCHEME_TRUE);}}

/* k7601 in k7598 in k7595 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1547 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448],C_SCHEME_TRUE);}

/* k7604 in k7601 in k7598 in k7595 in k7592 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1548 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7165(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7484,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[53]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7491,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7576,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1508 collect! */
t9=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],t5);}
else{
t8=t7;
f_7491(2,t8,C_SCHEME_UNDEFINED);}}

/* k7574 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1509 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[446],((C_word*)t0)[2]);}

/* k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7565 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7566,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7570,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1512 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[431],((C_word*)t0)[2]);}

/* k7568 in a7565 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1513 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[428],C_SCHEME_TRUE);}

/* k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[56]));
t4=(C_truep(t3)?lf[445]:lf[279]);
/* compiler.scm: 1516 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[439],t4);}
else{
t3=t2;
f_7497(2,t3,C_SCHEME_UNDEFINED);}}

/* k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1520 simple-lambda-node? */
t4=C_retrieve(lf[444]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7549 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1520 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[443],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7500(2,t2,C_SCHEME_UNDEFINED);}}

/* k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7500,2,t0,t1);}
t2=C_retrieve(lf[82]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[83]))){
t4=t3;
f_7503(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[83]+1,((C_word*)t0)[5]);
t5=t3;
f_7503(t5,t4);}}

/* k7501 in k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7503,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[83]),((C_word*)t0)[5]);
t5=t3;
f_7536(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7536(t4,C_SCHEME_FALSE);}}

/* k7534 in k7501 in k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7506(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7506(t2,C_SCHEME_UNDEFINED);}}

/* k7504 in k7501 in k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7506,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1525 append */
t5=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7531 in k7504 in k7501 in k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1525 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7165(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7507 in k7504 in k7501 in k7498 in k7495 in k7492 in k7489 in a7483 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[53]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7439 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7440,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7458 in a7439 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7459,3,t0,t1,t2);}
/* compiler.scm: 1493 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[428],C_SCHEME_TRUE);}

/* k7442 in a7439 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7444,2,t0,t1);}
t2=C_retrieve(lf[82]);
t3=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1497 append */
t7=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7455 in k7442 in a7439 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1497 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7165(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7446 in k7442 in a7439 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7378(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7378(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7378,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1479 append */
t6=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1482 put! */
t7=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[431],((C_word*)t0)[8]);}}

/* k7403 in loop in k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1483 assign */
t3=((C_word*)t0)[4];
f_7758(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7406 in k7403 in loop in k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1484 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7165(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7409 in k7406 in k7403 in loop in k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1485 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7378(t4,((C_word*)t0)[2],t2,t3);}

/* k7394 in loop in k7371 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1479 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7165(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7299 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1464 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[440]);}

/* k7347 in k7299 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7349,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[436])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7278(2,t3,C_SCHEME_UNDEFINED);}}

/* a7311 in k7347 in k7299 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7312,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[402],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7331,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1470 get */
t10=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[439]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7329 in a7311 in k7347 in k7299 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1470 count! */
t2=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[438]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7276 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1472 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7165(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7279 in k7276 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1473 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7746(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7240 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7158(C_fix(1));
/* compiler.scm: 1451 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}

/* k7197 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7158(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1444 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[433],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1445 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[434]);}}}

/* k7228 in k7197 in k7185 in walk in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1445 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}}

/* assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7758,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[126],t7);
if(C_truep(t8)){
/* compiler.scm: 1563 put! */
t9=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[427],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7771,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[402],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7771(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7771(t13,C_SCHEME_FALSE);}}}

/* k7769 in assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7771,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7780(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7780(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1568 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[350]);}}}}

/* k7829 in k7769 in assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7780(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7778 in k7769 in assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1571 get-all */
t3=C_retrieve(lf[432]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[428],lf[429]);}
else{
/* compiler.scm: 1579 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}}

/* k7781 in k7778 in k7769 in assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1572 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[431]);}

/* k7784 in k7781 in k7778 in k7769 in assign in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[428],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[429],((C_word*)t0)[7]))){
/* compiler.scm: 1575 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1577 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[429],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1578 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}}}}

/* ref in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7861,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1582 collect! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[425],t3);}

/* grow in k7154 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_7158(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[53]),t1);
t3=C_mutate((C_word*)lf[53]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7143,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7134,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1414 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7125,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7116,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1414 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7107,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7098,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1414 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7089,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7080,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1414 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7071,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7062,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1414 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7056,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[411]));}

/* make-foreign-callback-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7050,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[411],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6375,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6796,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6921,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6937,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1409 walk */
t21=((C_word*)t6)[1];
f_6422(t21,t1,t2,*((C_word*)lf[410]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7022,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[409]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[196]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[104]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[178]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[108]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[181]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1407 every */
t8=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6937(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6937,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6943(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6943,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6957,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1390 reverse */
t5=*((C_word*)lf[287]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1391 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7022(3,t6,t4,t5);}}

/* k6961 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1392 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6943(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1394 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[386]);}}

/* k6979 in k6961 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1395 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6422(t4,((C_word*)t0)[2],t2,t3);}

/* a6989 in k6979 in k6961 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6990,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7004,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7016,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1400 varnode */
t7=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k7014 in a6989 in k6979 in k6961 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1399 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6943(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7002 in a6989 in k6979 in k6961 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7004,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t2));}

/* k6955 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1390 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6921,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6927,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1383 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6937(t7,t1,t4,t6);}

/* a6926 in walk-inline-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6927,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[396],t3,t4,t2);
/* compiler.scm: 1386 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6796,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6800,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1359 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[401]);}

/* k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1360 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6803,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[404]);}

/* k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6853,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1364 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6851 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1364 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6826,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6828,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1365 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6937(t6,t4,((C_word*)t0)[2],t5);}

/* a6827 in k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6828,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1368 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6422(t4,t1,((C_word*)t0)[2],t3);}

/* a6833 in a6827 in k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6834,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6838,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1370 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6843 in a6833 in a6827 in k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1370 cons* */
t2=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6836 in a6833 in a6827 in k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[398],((C_word*)t0)[2],t1));}

/* k6824 in k6847 in k6855 in k6801 in k6798 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6826,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6422(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6422,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[402]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6444(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t14)){
t15=t13;
f_6444(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t15)){
t16=t13;
f_6444(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[272]);
t17=t13;
f_6444(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[408])));}}}}

/* k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6444,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1316 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1317 gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[401]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[153]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6550(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[160]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[404]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[176]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1339 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[280]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[245]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6675,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[404]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6710(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[196]);
if(C_truep(t9)){
t10=t8;
f_6710(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t10)){
t11=t8;
f_6710(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[178]);
if(C_truep(t11)){
t12=t8;
f_6710(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t13=t8;
f_6710(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[181])));}}}}}}}}}}}

/* k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6710,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1353 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6921(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1354 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6796(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[271]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6867,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1373 gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[401]);}
else{
/* compiler.scm: 1356 bomb */
t4=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[407]);}}}}

/* k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1374 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6868 in k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6870,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[404]);}

/* k6913 in k6868 in k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6911,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1378 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6909 in k6913 in k6868 in k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1378 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6905 in k6913 in k6868 in k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6907,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1380 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6901 in k6905 in k6913 in k6868 in k6865 in k6708 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6903,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[271],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t4));}

/* k6673 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6675,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[405]),t1,((C_word*)t0)[2]);}

/* k6699 in k6673 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[69]));
t3=C_mutate((C_word*)lf[69]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1350 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6378(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6623 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6634,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1340 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6422(t4,((C_word*)t0)[2],t2,t3);}

/* a6633 in k6623 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6634,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[396],lf[176],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6658,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6662,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1344 varnode */
t10=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6660 in a6633 in k6623 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1344 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6656 in a6633 in k6623 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t2));}

/* k6610 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1338 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6378(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6550,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1332 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6422(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6573,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1333 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6422(t6,t1,t4,t5);}}

/* a6572 in loop in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6573,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6587,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1337 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6550(t8,t5,t6,t7);}

/* k6585 in a6572 in loop in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6587,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t2));}

/* k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1318 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[404]);}

/* k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6531,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1323 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6529 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1323 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6525 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1324 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6422(t7,t4,t5,t6);}

/* a6499 in k6525 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6500,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1328 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6422(t5,t3,t4,((C_word*)t0)[2]);}

/* k6509 in a6499 in k6525 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6515,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1329 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6422(t4,t2,t3,((C_word*)t0)[2]);}

/* k6513 in k6509 in a6499 in k6525 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[114],C_SCHEME_END_OF_LIST,t2));}

/* k6492 in k6525 in k6533 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[153],((C_word*)t0)[2],t2));}

/* k1 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6471,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1319 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6469 in k1 in k6457 in k6454 in k6442 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[398],lf[403],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6378(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6378,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6382,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1304 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[401]);}

/* k6380 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6382,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1307 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6422(t7,t4,t5,t6);}

/* a6404 in k6380 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6405,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1309 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6414 in a6404 in k6380 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[398],lf[399],t2));}

/* k6397 in k6380 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[4],t2);
/* compiler.scm: 1305 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6285,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6288,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6317,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1296 walk */
t10=((C_word*)t7)[1];
f_6317(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6317,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1291 ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[394]),t5);}
else{
/* compiler.scm: 1295 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6288(t5,t1,t2);}}}

/* k6334 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6342(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1293 alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6357 in k6334 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1293 ##sys#hash-table-set! */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[394]),((C_word*)t0)[2],t1);}

/* k6340 in k6334 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1294 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6288(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6288,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6294(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6294,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6304,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1285 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6317(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6302 in loop in mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1286 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6294(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6208(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6208(t5,C_SCHEME_FALSE);}}

/* k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6208,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6211,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6211(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6211(t3,lf[393]);}}

/* k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6211,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6214(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6214(t4,(C_word)C_i_cadr(t3));}}

/* k6212 in k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6214,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6217,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[391]+1),t4);}

/* k6228 in k6212 in k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6215 in k6212 in k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6218 in k6215 in k6212 in k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6223,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6221 in k6218 in k6215 in k6212 in k6209 in k6206 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1275 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6167,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6190,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[391]+1),t9);}

/* k6188 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6175 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6178 in k6175 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6181 in k6178 in k6175 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1266 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6130,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6140,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6153,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[391]+1),t9);}

/* k6151 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6138 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6141 in k6138 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6144 in k6141 in k6138 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1258 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6085,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6092,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1245 symbol->string */
t6=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6092(2,t6,t4);}
else{
/* compiler.scm: 1247 quit */
t6=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[390],t4);}}}

/* k6090 in ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6098,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[388]+1),t5);}

/* k6096 in k6090 in ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1250 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6040,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1236 symbol->string */
t6=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6047(2,t6,t4);}
else{
/* compiler.scm: 1238 quit */
t6=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[389],t4);}}}

/* k6045 in ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6053,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[388]+1),t5);}

/* k6051 in k6045 in ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1241 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5886,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5890,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6034,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1209 list-tabulate */
t12=C_retrieve(lf[387]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a6033 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6034,3,t0,t1,t2);}
/* compiler.scm: 1209 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[386]);}

/* k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1210 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[385]);}

/* k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1211 gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1212 estimate-foreign-result-size */
t3=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1213 set-real-name! */
t3=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1215 make-foreign-stub */
t3=C_retrieve(lf[360]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[272],((C_word*)t0)[2]);
t7=t5;
f_5912(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5912(t6,(C_word)C_a_i_list(&a,2,lf[195],((C_word*)t0)[2]));}}

/* k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5912,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6003,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1221 map */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a6002 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6003,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6011,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1221 foreign-type-convert-argument */
t5=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k6009 in a6002 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1221 foreign-type-check */
t2=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5926,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[381]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5938,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[382],t1);
/* compiler.scm: 1226 append */
t8=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1227 final-foreign-type */
t7=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5953 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1228 words */
t3=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5956 in k5953 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[383],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[196],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5969,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1231 append */
t12=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5975 in k5956 in k5953 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1231 finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5971 in k5956 in k5953 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1230 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5967 in k5956 in k5953 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5938(2,t2,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t1));}

/* k5946 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1226 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5936 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5924 in k5913 in k5910 in k6026 in k5900 in k5897 in k5894 in k5891 in k5888 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5926,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[160],t2));}

/* foreign-stub-callback in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5877,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5868,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5859,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5850,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5841,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5832,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5823,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5814,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5805,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5796,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5787,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5778,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5769,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5760,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5751,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5742,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1198 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5736,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[361]));}

/* make-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5730,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[361],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4767,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4770,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4821,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4821(t5,t1);}

/* a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4821,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4825(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1030 syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[359],((C_word*)t0)[3]);}}

/* k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word ab[105],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[294]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4840,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[297]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[298]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4890,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1042 check-decl */
f_4770(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t9=t3;
f_4831(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1052 append */
t10=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t10=t3;
f_4831(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4962,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1056 append */
t11=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t12=t3;
f_4831(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1063 lset-intersection */
t12=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[130]+1),t10,C_retrieve(lf[301]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5008,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1066 check-decl */
f_4770(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[305]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[306]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[305]);
t13=t3;
f_4831(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4831(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1072 ##match#set-error-control */
t15=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[308]);}
else{
t14=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4831(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4831(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4831(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4831(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4831(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4831(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1079 append */
t23=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[313]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5105,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1080 append */
t24=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4831(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1084 append */
t25=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1088 append */
t27=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[317]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1092 every */
t28=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[320]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[321]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5189(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5189(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5189(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[324],t28);
/* compiler.scm: 1100 emit-control-file-item */
t30=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[326],t29);
/* compiler.scm: 1102 emit-control-file-item */
t31=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1105 pathname-strip-extension */
t31=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4831(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4831(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4831(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1111 append */
t36=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[91]));}
else{
t34=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1113 check-decl */
f_4770(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[339]);
if(C_truep(t35)){
t36=C_set_block_item(lf[340],0,C_SCHEME_TRUE);
t37=t3;
f_4831(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[341]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[342]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5495,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5503,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1147 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[130]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5495(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1151 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[130]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1155 quit */
t41=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[345],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4831(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4831(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4831(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4831(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4831(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4831(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5590,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1164 lset-union */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[130]+1),C_retrieve(lf[87]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[348]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5607,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1166 check-decl */
f_4770(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[350]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1174 every */
t47=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[352]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1178 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
t46=(C_word)C_eqp(t2,lf[357]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t48=(C_word)C_i_cdr(((C_word*)t0)[4]);
t49=C_retrieve(lf[48]);
t50=(C_truep(t49)?t49:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1190 append */
t51=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t51))(4,t51,t47,t48,t50);}
else{
/* compiler.scm: 1192 compiler-warning */
t47=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t3,lf[182],lf[358],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k5703 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* a5680 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5681,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5686,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5691,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5690 in a5680 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5691,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[356]);}

/* k5684 in a5680 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[140]),((C_word*)t0)[2]);}

/* a5652 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5659,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1179 partition */
t4=C_retrieve(lf[355]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5658 in a5652 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5659,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1183 quit */
t3=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[354],t2);}}}

/* k5633 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1175 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1176 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[351],((C_word*)t0)[2]);}}

/* k5637 in k5633 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5605 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5614(2,t4,t2);}
else{
/* compiler.scm: 1171 quit */
t4=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[349],((C_word*)t0)[3]);}}

/* k5612 in k5605 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5588 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5514 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1152 lset-union */
t6=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[130]+1),((C_word*)t0)[2],t5);}

/* k5518 in k5514 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5501 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5495(t3,t2);}

/* k5493 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5495,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1148 lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[130]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5497 in k5493 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5340,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4831(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1118 lset-difference */
t7=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[130]+1),C_retrieve(lf[301]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4831(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1122 lset-difference */
t8=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[130]+1),C_retrieve(lf[302]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4831(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1126 lset-union */
t9=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[130]+1),C_retrieve(lf[88]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4831(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5439,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1133 lset-difference */
t10=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[130]+1),C_retrieve(lf[301]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1136 check-decl */
f_4770(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5448 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4831(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1141 ##match#set-error-control */
t6=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[308]);}
else{
/* compiler.scm: 1142 compiler-warning */
t5=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[182],lf[338],((C_word*)t0)[3]);}}}

/* k5437 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1134 lset-difference */
t4=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[130]+1),C_retrieve(lf[302]),((C_word*)t0)[2]);}

/* k5441 in k5437 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5408 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5383 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5358 in k5338 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5325 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5277 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5288,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5287 in k5277 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5288,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[328]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[329],((C_word*)t0)[2],t2);}

/* k5284 in k5277 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[327],t1);
/* compiler.scm: 1104 emit-control-file-item */
t3=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5187 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1097 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[322],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1098 process-custom-declaration */
t4=C_retrieve(lf[323]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5165 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1093 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1094 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[318],((C_word*)t0)[2]);}}

/* k5169 in k5165 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5138 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5140,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1089 append */
t5=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5142 in k5138 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5124 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1086 append */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[17]));}

/* k5128 in k5124 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5103 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5089 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[313]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k5006 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4831(2,t4,t3);}

/* k4989 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1064 lset-intersection */
t4=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[130]+1),((C_word*)t0)[2],C_retrieve(lf[302]));}

/* k4993 in k4989 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k4960 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k4935 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4896,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1044 stringify */
t5=C_retrieve(lf[296]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4918 in k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1044 string->c-identifier */
t2=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4894 in k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1045 ##sys#hash-table-set! */
t3=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[89]),lf[298],((C_word*)t0)[2]);}

/* k4897 in k4894 in k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4906,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4906(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4906(t4,C_SCHEME_FALSE);}}

/* k4904 in k4897 in k4894 in k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1047 compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[299],lf[300]);}
else{
t2=((C_word*)t0)[2];
f_4902(2,t2,C_SCHEME_UNDEFINED);}}

/* k4900 in k4897 in k4894 in k4888 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[140]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4843(2,t3,C_SCHEME_UNDEFINED);}}

/* k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1038 ##sys#hash-table-update! */
t5=C_retrieve(lf[131]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[89]),lf[294],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4831(2,t2,C_SCHEME_UNDEFINED);}}

/* a4876 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4870 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4871,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[130]+1),((C_word*)t0)[2],t2);}

/* k4850 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4861,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4860 in k4850 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1039 stringify */
t4=C_retrieve(lf[296]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4867 in a4860 in k4850 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1039 string->c-identifier */
t2=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4853 in k4850 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1040 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4857 in k4853 in k4850 in k4841 in k4838 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4831(2,t3,t2);}

/* k4829 in k4823 in a4820 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[293]);}

/* check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4770(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4770,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4783,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4783(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4793,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4793(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4793(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1025 ##sys#error */
t11=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4791 in check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4783(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4781 in check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1026 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[292],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1979,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1991,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2015,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2166,a[2]=t5,a[3]=t13,a[4]=t4,a[5]=t11,a[6]=t3,a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t17=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=t2,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[124],C_retrieve(lf[289])))){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4762,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1008 newline */
t20=*((C_word*)lf[291]+1);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=t18;
f_4725(2,t19,C_SCHEME_UNDEFINED);}}

/* k4760 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1008 pretty-print */
t2=C_retrieve(lf[290]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1009 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[288]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4726 in k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1013 reverse */
t4=*((C_word*)lf[287]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[79]));}

/* k4741 in k4726 in k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4752,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1016 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[286]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4750 in k4741 in k4726 in k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1017 append */
t3=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[285]),C_retrieve(lf[13]));}

/* k4754 in k4750 in k4741 in k4726 in k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 454  ##sys#append */
t4=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4737 in k4726 in k4723 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
/* compiler.scm: 1011 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2166(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4717 in mapwalk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4718,3,t0,t1,t2);}
/* compiler.scm: 1006 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2166,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 507  resolve-atom */
t9=((C_word*)((C_word*)t0)[8])[1];
f_2057(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 509  resolve-atom */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2057(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 511  constant? */
t7=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2203(2,t7,C_SCHEME_FALSE);}}}

/* k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 512  walk-literal */
t2=((C_word*)((C_word*)t0)[12])[1];
f_2148(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 513  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[112],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 517  get-line */
t6=C_retrieve(lf[193]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 982  constant? */
t5=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 980  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[284],((C_word*)t0)[10]);}}}}}

/* k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 983  emit-syntax-trace-info */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4688,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 987  caar */
t5=*((C_word*)lf[282]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4588(t4,C_SCHEME_FALSE);}}}

/* k4686 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4588(t2,(C_word)C_eqp(lf[160],t1));}

/* k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4588,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 990  emit-syntax-trace-info */
t5=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1002 emit-syntax-trace-info */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4673 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1003 mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4712(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4595 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 991  ##sys#check-syntax */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[160],((C_word*)t0)[9],lf[281]);}

/* k4598 in k4595 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4609(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4609(t4,C_SCHEME_FALSE);}}

/* k4607 in k4598 in k4595 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4609,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 994  map */
t3=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[279]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 995  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[280]);}}

/* k4629 in k4607 in k4598 in k4595 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[153],t4,t6);
/* compiler.scm: 996  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2166(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4622 in k4607 in k4598 in k4595 in k4586 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[153],t3);
/* compiler.scm: 994  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2166(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4574 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 984  compiler-warning */
t3=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[182],lf[278],((C_word*)t0)[4]);}

/* k4577 in k4574 in k4571 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 985  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4712(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=f_1979(((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t2,a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 519  emit-syntax-trace-info */
t4=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}

/* k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[15]))){
t3=t2;
f_2239(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[15],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 522  sprintf */
t4=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[275],((C_word*)t0)[2]);}
else{
/* compiler.scm: 523  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[276],((C_word*)t0)[15]);}}}

/* k4553 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 522  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,((C_word*)t0)[15]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 526  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[274]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[9]);}

/* k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[15],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 530  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[57]),((C_word*)t0)[8]);}
else{
t4=t3;
f_2264(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 528  update-line-number-database! */
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2255(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2253 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 529  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 532  walk */
t4=((C_word*)((C_word*)t0)[13])[1];
f_2166(t4,((C_word*)t0)[12],t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 537  ##sys#check-syntax */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[114],((C_word*)t0)[14],lf[117]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[103]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 545  ##sys#check-syntax */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[103],((C_word*)t0)[14],lf[118]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[119]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[120]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[14]);
/* compiler.scm: 551  walk */
t6=((C_word*)((C_word*)t0)[13])[1];
f_2166(t6,((C_word*)t0)[12],t5,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[121]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 554  cadadr */
t7=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[14]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[126]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2398(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[271]);
if(C_truep(t8)){
t9=t7;
f_2398(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[272]);
if(C_truep(t9)){
t10=t7;
f_2398(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[104]);
t11=t7;
f_2398(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[8],lf[108])));}}}}}}}}}

/* k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2398,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[127]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[135]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[136]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2445(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[153]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 602  ##sys#check-syntax */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[153],((C_word*)t0)[12],lf[159]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[160]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[161]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 616  ##sys#check-syntax */
t8=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[160],((C_word*)t0)[12],lf[173]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[160],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 654  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2166(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[123]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[176]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[177]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 670  ##sys#check-syntax */
t12=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[176],((C_word*)t0)[12],lf[194]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 709  unquotify */
t14=((C_word*)t0)[3];
f_2015(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[178]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 717  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2166(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[181]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 722  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2166(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[197]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[198]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 727  eval */
t19=C_retrieve(lf[135]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[199]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[200]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 731  eval */
t21=C_retrieve(lf[135]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[139]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 735  ##sys#check-syntax */
t21=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[139],((C_word*)t0)[12],lf[204]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[205]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 747  expand-foreign-lambda */
t22=C_retrieve(lf[206]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[207]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 750  expand-foreign-callback-lambda */
t23=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[209]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 753  expand-foreign-lambda* */
t24=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[211]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 756  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[212]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[213]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 759  expand-foreign-primitive */
t26=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[215]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3390(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 766  symbol->string */
t32=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[218]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3457,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 777  gensym */
t33=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 790  ##sys#hash-table-set! */
t33=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[66]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[222]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3531,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 795  symbol->string */
t31=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[228]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 810  gensym */
t34=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[233]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3733,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3751,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[235]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3876,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 849  call-with-current-continuation */
t37=*((C_word*)lf[242]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[243]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3949,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[245]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 877  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[268],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 952  ##sys#check-syntax */
t36=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[268],((C_word*)t0)[12],lf[270]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[93]))){
if(C_truep(C_retrieve(lf[92]))){
/* compiler.scm: 970  ##sys#hash-table-ref */
t36=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[92]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4475(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4475(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4473 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 972  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 977  handle-call */
t2=((C_word*)t0)[7];
f_4346(t2,((C_word*)t0)[6]);}}

/* k4479 in k4473 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 974  handle-call */
t2=((C_word*)t0)[7];
f_4346(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 975  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2166(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4384 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1979(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[78]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t7=(C_word)C_a_i_list(&a,5,lf[269],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 957  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2166(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[75]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 961  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2166(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[81])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 963  symbol->string */
t7=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t7=(C_word)C_a_i_list(&a,5,lf[269],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 965  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2166(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t4=(C_word)C_a_i_list(&a,5,lf[269],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 966  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2166(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4444 in k4384 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[223]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[104],t2));}

/* handle-call in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4346,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 941  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4712(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4348 in handle-call in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4356,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 943  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[54]),t2);}

/* k4354 in k4348 in handle-call in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 948  alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4359(2,t3,C_SCHEME_UNDEFINED);}}

/* k4368 in k4354 in k4348 in handle-call in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 945  ##sys#hash-table-set! */
t3=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[54]),((C_word*)t0)[2],t2);}

/* k4357 in k4354 in k4348 in handle-call in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3982,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4004,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4330,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 884  valid-c-identifier? */
t14=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4328 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[81]));
t3=C_mutate((C_word*)lf[81]+1,t2);
t4=((C_word*)t0)[2];
f_4004(2,t4,t3);}
else{
/* compiler.scm: 886  quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[266],((C_word*)t0)[3]);}}

/* k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4295(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4295(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4295(t11,(C_word)C_i_not(t10));}}}

/* k4293 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 891  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[265],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4007(2,t2,C_SCHEME_UNDEFINED);}}

/* k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 895  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4712(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4026,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4245,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4245(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4245,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4281,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 907  final-foreign-type */
t9=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4287 in loop in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 907  finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4283 in loop in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 906  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4279 in loop in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4269,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 909  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4245(t6,t3,t4,t5);}

/* k4267 in k4279 in loop in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4269,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 912  g302 */
t7=t6;
f_4117(2,t7,f_4094(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[252]))){
/* compiler.scm: 912  g302 */
t7=t6;
f_4117(2,t7,f_4094(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t7)){
/* compiler.scm: 912  g302 */
t8=t6;
f_4117(2,t8,f_4094(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[254]);
if(C_truep(t8)){
/* compiler.scm: 912  g302 */
t9=t6;
f_4117(2,t9,f_4094(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 912  g303 */
t9=t4;
f_4089(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[256]))){
/* compiler.scm: 912  g303 */
t9=t4;
f_4089(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t9)){
/* compiler.scm: 912  g303 */
t10=t4;
f_4089(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t10)){
/* compiler.scm: 912  g303 */
t11=t4;
f_4089(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t11)){
/* compiler.scm: 912  g303 */
t12=t4;
f_4089(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t12)){
/* compiler.scm: 912  g303 */
t13=t4;
f_4089(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[261]);
if(C_truep(t13)){
/* compiler.scm: 912  g304 */
t14=t6;
f_4117(2,t14,f_4052(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[262]))){
/* compiler.scm: 912  g304 */
t14=t6;
f_4117(2,t14,f_4052(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[263]);
/* compiler.scm: 912  g304 */
t15=t6;
f_4117(2,t15,(C_truep(t14)?f_4052(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[264]))?f_4052(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4115 in k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[153],t2);
/* compiler.scm: 910  foreign-type-convert-argument */
t4=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g302 in k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_4094(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[153],t2);
t4=(C_word)C_a_i_list(&a,2,lf[248],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g303 in k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4089,NULL,2,t0,t1);}
/* compiler.scm: 924  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[250],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g304 in k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_4052(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[153],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[248],lf[247]);
t7=(C_word)C_a_i_list(&a,3,lf[249],lf[247],t6);
t8=(C_word)C_a_i_list(&a,3,lf[153],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k4040 in k4036 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[161],((C_word*)t0)[6],t2);
/* compiler.scm: 896  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2166(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4024 in k4016 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 454  ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4012 in k4005 in k4002 in a3981 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[245],t1));}

/* a3971 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 877  split-at */
t3=C_retrieve(lf[246]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3948 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3949,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 872  process-declaration */
t4=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3945 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
/* compiler.scm: 870  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3876,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3894,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 849  with-exception-handler */
t5=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3893 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 849  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3915 in a3893 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3916r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3916r(t0,t1,t2);}}

static void C_ccall f_3916r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 849  g265 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3921 in a3915 in a3893 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3899 in a3893 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 853  collapsable-literal? */
t3=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3905 in a3899 in a3893 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[153],C_retrieve(lf[80]),((C_word*)t0)[2]);
/* compiler.scm: 855  eval */
t3=C_retrieve(lf[135]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3881 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 849  g265 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3887 in a3881 in a3875 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
/* compiler.scm: 851  quit */
t2=C_retrieve(lf[239]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[240],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3872 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3812,2,t0,t1);}
t2=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[103],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[80]));
t6=C_mutate((C_word*)lf[80]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 858  collapsable-literal? */
t8=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3821 in k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3826,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 859  ##sys#hash-table-set! */
t4=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[59]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 862  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}}

/* k3831 in k3821 in k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 863  ##sys#hash-table-set! */
t4=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[59]),((C_word*)t0)[2],t3);}

/* k3834 in k3831 in k3821 in k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 864  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[61]));}

/* k3838 in k3834 in k3831 in k3821 in k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[7],t7);
/* compiler.scm: 867  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2166(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3824 in k3821 in k3810 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[236]);}

/* a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3751,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3755,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 839  ##sys#hash-table-set! */
t5=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[57]),((C_word*)t0)[2],t2);}

/* k3753 in a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 840  unzip1 */
t4=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3791 in k3753 in a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 840  append */
t2=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3757 in k3753 in a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[58],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3773,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3772 in k3757 in k3753 in a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3773,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[103],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[177],t3,t5));}

/* k3769 in k3757 in k3753 in a3750 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
/* compiler.scm: 842  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2166(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3732 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[161],t3);
/* compiler.scm: 838  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2166(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3739 in a3732 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 837  extract-mutable-constants */
t2=C_retrieve(lf[234]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 811  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 813  set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[78]));
t4=C_mutate((C_word*)lf[78]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 816  estimate-foreign-result-location-size */
t7=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3692 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 816  words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[229],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[196],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3646(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3646(t11,C_SCHEME_END_OF_LIST);}}

/* k3644 in k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3646,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3654,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 829  fifth */
t3=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3654(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3652 in k3644 in k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 454  ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3640 in k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 830  alist-cons */
t4=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3636 in k3640 in k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 824  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3628 in k3669 in k3613 in k3607 in k3604 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3630,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t1));}

/* k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 798  make-random-name */
t9=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3543(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3579,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 799  fifth */
t5=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3577 in k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 799  symbol->string */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3569 in k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3543(t3,t2);}

/* k3541 in k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3543,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[70]));
t4=C_mutate((C_word*)lf[70]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 802  string-append */
t6=*((C_word*)lf[225]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[226],((C_word*)((C_word*)t0)[7])[1]);}

/* k3561 in k3541 in k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[223],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[67]));
t4=C_mutate((C_word*)lf[67]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 804  alist-cons */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[75]));}

/* k3553 in k3561 in k3541 in k3538 in k3529 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[75]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[224]);}

/* k3509 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[221]);}

/* k3455 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 778  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3458 in k3455 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 779  ##sys#hash-table-set! */
t4=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[66]),((C_word*)t0)[2],t3);}

/* k3461 in k3458 in k3455 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 780  cons* */
t3=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3465 in k3461 in k3458 in k3455 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 781  cons* */
t4=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3469 in k3465 in k3461 in k3458 in k3455 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[219]);
t8=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[139],t4,t8);
/* compiler.scm: 782  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2166(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3388 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3402(2,t3,t1);}
else{
/* compiler.scm: 768  symbol->string */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3400 in k3388 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[67]));
t4=C_mutate((C_word*)lf[67]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[216]);}

/* k3373 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 759  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3360 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 756  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3347 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 753  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3334 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 750  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3321 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 747  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3275,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3275(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[203]);}}

/* fold in k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3275,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 742  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2166(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3302,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 743  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2166(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3300 in fold in k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 743  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3275(t3,t2,((C_word*)t0)[2]);}

/* k3304 in k3300 in fold in k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3293 in fold in k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3267 in k3254 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 737  canonicalize-begin-body */
t2=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3241 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[201]);}

/* k3226 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 728  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3199 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3205,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 723  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3203 in k3199 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[181],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3178 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[2],t1));}

/* k3149 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 714  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4712(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3153 in k3149 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[196],t2));}

/* k3120 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 709  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4712(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3124 in k3120 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1979(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 673  get-line */
t7=C_retrieve(lf[193]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2960,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 674  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2963,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 676  ##sys#alias-global-hook */
t5=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2963(2,t4,C_SCHEME_UNDEFINED);}}

/* k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 679  lset-adjoin */
t5=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[130]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3071(t4,C_SCHEME_UNDEFINED);}}

/* k3095 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 680  lset-adjoin */
t4=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[130]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3099 in k3095 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3071(t3,t2);}

/* k3069 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3071,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 681  macro? */
t3=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3075 in k3069 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 685  sprintf */
t4=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[189],((C_word*)t0)[2]);}
else{
t4=t3;
f_3090(2,t4,lf[190]);}}
else{
t2=((C_word*)t0)[4];
f_2963(2,t2,C_SCHEME_UNDEFINED);}}

/* k3088 in k3075 in k3069 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 682  compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[186],lf[187],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3078 in k3075 in k3069 in k3066 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 686  undefine-macro! */
t2=C_retrieve(lf[185]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2963(2,t2,C_SCHEME_UNDEFINED);}}

/* k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 687  keyword? */
t4=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3056 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 688  compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[182],lf[183],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2966(2,t2,C_SCHEME_UNDEFINED);}}

/* k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[67]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 692  gensym */
t5=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[78]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 700  gensym */
t6=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[176],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k3019 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 701  foreign-type-convert-argument */
t3=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3050 in k3019 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3044,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 705  foreign-type-check */
t7=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k3042 in k3050 in k3019 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[181],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t2));}

/* k2976 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 693  foreign-type-convert-argument */
t3=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3007 in k2976 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2997,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 696  foreign-type-check */
t7=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2995 in k3007 in k2976 in k2964 in k2961 in k2958 in k2955 in k2946 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t2));}

/* k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 660  map */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[157]+1),((C_word*)t0)[7],t1);}

/* k2934 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 660  append */
t2=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2911 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 663  ##sys#canonicalize-body */
t5=C_retrieve(lf[154]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2927 in k2911 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2928,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2924 in k2911 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 662  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2166(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2914 in k2911 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2919,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 666  set-real-names! */
f_1991(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2917 in k2914 in k2911 in k2908 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2642,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2860,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 619  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2858 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 620  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2642(2,t2,C_SCHEME_UNDEFINED);}}

/* a2870 in k2858 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2871,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2864 in k2858 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
/* compiler.scm: 622  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[170]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[171]+1));}

/* k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 625  decompose-lambda-list */
t3=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2647,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[123]),t2);}

/* k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 629  map */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[157]+1),((C_word*)t0)[7],t1);}

/* k2855 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 629  append */
t2=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 630  ##sys#canonicalize-body */
t4=C_retrieve(lf[154]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2848 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2849,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 631  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 635  posq */
t5=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2840(t4,C_SCHEME_FALSE);}}

/* k2845 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2840(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2838 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 633  build-lambda-list */
t2=C_retrieve(lf[167]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[160],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 637  set-real-names! */
f_1991(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2678(t4,t2);}
else{
t4=f_1979(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2678(t6,(C_word)C_i_not(t5));}}

/* k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(lf[160],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[27]))){
t4=(C_word)C_i_not(C_retrieve(lf[48]));
t5=t2;
f_2684(t5,(C_truep(t4)?t4:(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[48]))));}
else{
t4=t2;
f_2684(t4,C_SCHEME_FALSE);}}
else{
t4=t2;
f_2684(t4,C_SCHEME_FALSE);}}}

/* k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2684,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 645  expand-profile-lambda */
t2=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,lf[139]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t3;
f_2698(t7,(C_word)C_i_pairp(t6));}
else{
t6=t3;
f_2698(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2698(t4,C_SCHEME_FALSE);}}}

/* k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2698,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 647  g171 */
t6=((C_word*)t0)[4];
f_2688(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 647  caadr */
t6=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2731(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2780 in k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 647  cdadr */
t4=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2731(t3,C_SCHEME_FALSE);}}

/* k2776 in k2780 in k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 647  cddadr */
t3=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2731(t2,C_SCHEME_FALSE);}}

/* k2772 in k2776 in k2780 in k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2731(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2731(t2,C_SCHEME_FALSE);}}

/* k2729 in k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2731,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 647  cadadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2736 in k2729 in k2696 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 647  g171 */
t3=((C_word*)t0)[3];
f_2688(t3,((C_word*)t0)[2],t1);}

/* g171 in k2682 in k2676 in k2667 in k2661 in k2658 in k2655 in k2652 in k2649 in a2646 in k2640 in k2631 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,3,t0,t1,t2);}
/* compiler.scm: 649  process-lambda-documentation */
t3=C_retrieve(lf[163]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 604  unzip1 */
t4=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2568,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[123]),t1);}

/* k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 606  map */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k2619 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 606  append */
t2=*((C_word*)lf[156]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 607  set-real-names! */
f_1991(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 608  map */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2600 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2601,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 609  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2166(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2607 in a2600 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2579 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 611  ##sys#canonicalize-body */
t6=C_retrieve(lf[154]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2594 in k2579 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2595,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2587 in k2579 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 611  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2583 in k2579 in k2572 in k2569 in k2566 in k2563 in k2557 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t1));}

/* loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2445,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[137]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 579  cadar */
t4=*((C_word*)lf[152]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2466,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2466,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2531(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 583  feature? */
t7=C_retrieve(lf[151]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2531(2,t6,C_SCHEME_FALSE);}}}

/* k2538 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2531(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 585  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[150]);}}

/* k2548 in k2538 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 584  ##sys#find-extension */
t2=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2529 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 591  ##sys#extension-information */
t4=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2493(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2493(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 587  compiler-warning */
t2=C_retrieve(lf[145]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[146],lf[147],((C_word*)t0)[2]);}}

/* k2503 in k2529 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[141],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2493(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2493(t2,C_SCHEME_FALSE);}}

/* a2518 in k2503 in k2529 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2519,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2515 in k2503 in k2529 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2493(t2,C_SCHEME_TRUE);}

/* k2491 in k2529 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2470(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 597  lookup-exports-file */
t2=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2468 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 598  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2445(t4,t2,t3);}

/* k2475 in k2468 in a2465 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[139],((C_word*)t0)[2],t1));}

/* a2459 in k2453 in loop in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
/* compiler.scm: 580  ##sys#do-the-right-thing */
t2=C_retrieve(lf[138]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2437 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 575  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2405 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[133]),t1);}

/* k2408 in k2405 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 569  ##sys#hash-table-update! */
t5=C_retrieve(lf[131]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[89]),lf[132],t3,t4);}

/* a2420 in k2408 in k2405 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2414 in k2408 in k2405 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2415,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[130]+1),t2,((C_word*)t0)[2]);}

/* k2411 in k2408 in k2405 in k2396 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[128]);}

/* k2363 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[55]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 557  gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[124]);}}

/* k2375 in k2363 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 558  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[55]));}

/* k2379 in k2375 in k2363 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2331 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* compiler.scm: 546  walk-literal */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2148(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2285 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 538  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2292 in k2285 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 539  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2296 in k2292 in k2285 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2302,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2302(2,t4,lf[115]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 542  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2166(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2300 in k2296 in k2292 in k2285 in k2262 in k2244 in k2237 in k2234 in k2228 in k2201 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[114],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2189 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 510  ##sys#alias-global-hook */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2183 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* walk-literal in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_retrieve(lf[94]))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 499  literal-rewrite-hook */
t7=C_retrieve(lf[94]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[103],t2));}}

/* a2156 in walk-literal in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2157,3,t0,t1,t2);}
/* walk21 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2166(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2061,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[60]))){
/* compiler.scm: 474  ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[59]),t2);}
else{
t7=t6;
f_2061(2,t7,C_SCHEME_FALSE);}}

/* k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 475  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2166(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 476  ##sys#hash-table-ref */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[57]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2074(2,t3,C_SCHEME_FALSE);}}}

/* k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 478  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[67]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 482  final-foreign-type */
t5=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[78]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 490  final-foreign-type */
t6=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2120 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[108],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 493  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2130 in k2120 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 492  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2090 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[104],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 485  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2100 in k2090 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 484  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2015,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[103]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2022(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2022(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2022(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2022(t4,C_SCHEME_FALSE);}}

/* k2020 in unquotify in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_1991(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1997,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 461  for-each */
t5=*((C_word*)lf[102]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1996 in set-real-names! in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1997,4,t0,t1,t2,t3);}
/* compiler.scm: 461  set-real-name! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_1979(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[54]))){
/* compiler.scm: 431  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[54]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 432  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1972 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=((C_word*)t0)[2];
f_1909(2,t3,t2);}

/* k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 434  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[57]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1965 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=((C_word*)t0)[2];
f_1912(2,t3,t2);}

/* k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 437  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[59]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1958 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[59]+1,t1);
t3=((C_word*)t0)[2];
f_1915(2,t3,t2);}

/* k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 439  make-random-name */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[99]);}

/* k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 440  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[89]))){
/* compiler.scm: 442  vector-fill! */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[89]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t5=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1951 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=((C_word*)t0)[2];
f_1926(2,t3,t2);}

/* k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 445  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 446  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1944 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1929(2,t3,t2);}

/* k1927 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
if(C_truep(C_retrieve(lf[66]))){
/* compiler.scm: 448  vector-fill! */
t2=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[66]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 449  make-vector */
t3=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1937 in k1927 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[822] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1779compiler.scm",(void*)f_1779},
{"f_1782compiler.scm",(void*)f_1782},
{"f_1785compiler.scm",(void*)f_1785},
{"f_1788compiler.scm",(void*)f_1788},
{"f_1791compiler.scm",(void*)f_1791},
{"f_1798compiler.scm",(void*)f_1798},
{"f_1802compiler.scm",(void*)f_1802},
{"f_1806compiler.scm",(void*)f_1806},
{"f_1810compiler.scm",(void*)f_1810},
{"f_1814compiler.scm",(void*)f_1814},
{"f_1818compiler.scm",(void*)f_1818},
{"f_10193compiler.scm",(void*)f_10193},
{"f_11250compiler.scm",(void*)f_11250},
{"f_11253compiler.scm",(void*)f_11253},
{"f_11256compiler.scm",(void*)f_11256},
{"f_11259compiler.scm",(void*)f_11259},
{"f_11262compiler.scm",(void*)f_11262},
{"f_11050compiler.scm",(void*)f_11050},
{"f_11056compiler.scm",(void*)f_11056},
{"f_10283compiler.scm",(void*)f_10283},
{"f_11039compiler.scm",(void*)f_11039},
{"f_11036compiler.scm",(void*)f_11036},
{"f_10949compiler.scm",(void*)f_10949},
{"f_11013compiler.scm",(void*)f_11013},
{"f_11026compiler.scm",(void*)f_11026},
{"f_11007compiler.scm",(void*)f_11007},
{"f_10997compiler.scm",(void*)f_10997},
{"f_10970compiler.scm",(void*)f_10970},
{"f_10973compiler.scm",(void*)f_10973},
{"f_10921compiler.scm",(void*)f_10921},
{"f_10924compiler.scm",(void*)f_10924},
{"f_10878compiler.scm",(void*)f_10878},
{"f_10890compiler.scm",(void*)f_10890},
{"f_10881compiler.scm",(void*)f_10881},
{"f_10884compiler.scm",(void*)f_10884},
{"f_10758compiler.scm",(void*)f_10758},
{"f_10859compiler.scm",(void*)f_10859},
{"f_10847compiler.scm",(void*)f_10847},
{"f_10786compiler.scm",(void*)f_10786},
{"f_10792compiler.scm",(void*)f_10792},
{"f_10816compiler.scm",(void*)f_10816},
{"f_10808compiler.scm",(void*)f_10808},
{"f_10774compiler.scm",(void*)f_10774},
{"f_10717compiler.scm",(void*)f_10717},
{"f_10729compiler.scm",(void*)f_10729},
{"f_10733compiler.scm",(void*)f_10733},
{"f_10721compiler.scm",(void*)f_10721},
{"f_10533compiler.scm",(void*)f_10533},
{"f_10654compiler.scm",(void*)f_10654},
{"f_10660compiler.scm",(void*)f_10660},
{"f_10685compiler.scm",(void*)f_10685},
{"f_10666compiler.scm",(void*)f_10666},
{"f_10540compiler.scm",(void*)f_10540},
{"f_10645compiler.scm",(void*)f_10645},
{"f_10543compiler.scm",(void*)f_10543},
{"f_10546compiler.scm",(void*)f_10546},
{"f_10549compiler.scm",(void*)f_10549},
{"f_10587compiler.scm",(void*)f_10587},
{"f_10613compiler.scm",(void*)f_10613},
{"f_10594compiler.scm",(void*)f_10594},
{"f_10598compiler.scm",(void*)f_10598},
{"f_10571compiler.scm",(void*)f_10571},
{"f_10477compiler.scm",(void*)f_10477},
{"f_10486compiler.scm",(void*)f_10486},
{"f_10480compiler.scm",(void*)f_10480},
{"f_10461compiler.scm",(void*)f_10461},
{"f_10434compiler.scm",(void*)f_10434},
{"f_10417compiler.scm",(void*)f_10417},
{"f_10413compiler.scm",(void*)f_10413},
{"f_10406compiler.scm",(void*)f_10406},
{"f_10389compiler.scm",(void*)f_10389},
{"f_10385compiler.scm",(void*)f_10385},
{"f_10361compiler.scm",(void*)f_10361},
{"f_10341compiler.scm",(void*)f_10341},
{"f_10196compiler.scm",(void*)f_10196},
{"f_10200compiler.scm",(void*)f_10200},
{"f_10215compiler.scm",(void*)f_10215},
{"f_10225compiler.scm",(void*)f_10225},
{"f_10230compiler.scm",(void*)f_10230},
{"f_10275compiler.scm",(void*)f_10275},
{"f_10234compiler.scm",(void*)f_10234},
{"f_10240compiler.scm",(void*)f_10240},
{"f_10250compiler.scm",(void*)f_10250},
{"f_11062compiler.scm",(void*)f_11062},
{"f_11069compiler.scm",(void*)f_11069},
{"f_11131compiler.scm",(void*)f_11131},
{"f_11121compiler.scm",(void*)f_11121},
{"f_11095compiler.scm",(void*)f_11095},
{"f_11081compiler.scm",(void*)f_11081},
{"f_11156compiler.scm",(void*)f_11156},
{"f_11172compiler.scm",(void*)f_11172},
{"f_11179compiler.scm",(void*)f_11179},
{"f_11186compiler.scm",(void*)f_11186},
{"f_11160compiler.scm",(void*)f_11160},
{"f_11170compiler.scm",(void*)f_11170},
{"f_11142compiler.scm",(void*)f_11142},
{"f_11150compiler.scm",(void*)f_11150},
{"f_11188compiler.scm",(void*)f_11188},
{"f_11201compiler.scm",(void*)f_11201},
{"f_10184compiler.scm",(void*)f_10184},
{"f_10175compiler.scm",(void*)f_10175},
{"f_10166compiler.scm",(void*)f_10166},
{"f_10157compiler.scm",(void*)f_10157},
{"f_10148compiler.scm",(void*)f_10148},
{"f_10139compiler.scm",(void*)f_10139},
{"f_10130compiler.scm",(void*)f_10130},
{"f_10121compiler.scm",(void*)f_10121},
{"f_10112compiler.scm",(void*)f_10112},
{"f_10103compiler.scm",(void*)f_10103},
{"f_10094compiler.scm",(void*)f_10094},
{"f_10085compiler.scm",(void*)f_10085},
{"f_10076compiler.scm",(void*)f_10076},
{"f_10067compiler.scm",(void*)f_10067},
{"f_10058compiler.scm",(void*)f_10058},
{"f_10049compiler.scm",(void*)f_10049},
{"f_10040compiler.scm",(void*)f_10040},
{"f_10031compiler.scm",(void*)f_10031},
{"f_10022compiler.scm",(void*)f_10022},
{"f_10013compiler.scm",(void*)f_10013},
{"f_10004compiler.scm",(void*)f_10004},
{"f_9995compiler.scm",(void*)f_9995},
{"f_9986compiler.scm",(void*)f_9986},
{"f_9977compiler.scm",(void*)f_9977},
{"f_9968compiler.scm",(void*)f_9968},
{"f_9959compiler.scm",(void*)f_9959},
{"f_9950compiler.scm",(void*)f_9950},
{"f_9941compiler.scm",(void*)f_9941},
{"f_9932compiler.scm",(void*)f_9932},
{"f_9923compiler.scm",(void*)f_9923},
{"f_9917compiler.scm",(void*)f_9917},
{"f_9911compiler.scm",(void*)f_9911},
{"f_8677compiler.scm",(void*)f_8677},
{"f_9878compiler.scm",(void*)f_9878},
{"f_9881compiler.scm",(void*)f_9881},
{"f_9884compiler.scm",(void*)f_9884},
{"f_9887compiler.scm",(void*)f_9887},
{"f_9890compiler.scm",(void*)f_9890},
{"f_9905compiler.scm",(void*)f_9905},
{"f_9903compiler.scm",(void*)f_9903},
{"f_9893compiler.scm",(void*)f_9893},
{"f_9730compiler.scm",(void*)f_9730},
{"f_9736compiler.scm",(void*)f_9736},
{"f_9041compiler.scm",(void*)f_9041},
{"f_9060compiler.scm",(void*)f_9060},
{"f_9093compiler.scm",(void*)f_9093},
{"f_9620compiler.scm",(void*)f_9620},
{"f_9616compiler.scm",(void*)f_9616},
{"f_9609compiler.scm",(void*)f_9609},
{"f_9460compiler.scm",(void*)f_9460},
{"f_9466compiler.scm",(void*)f_9466},
{"f_9536compiler.scm",(void*)f_9536},
{"f_9566compiler.scm",(void*)f_9566},
{"f_9549compiler.scm",(void*)f_9549},
{"f_9553compiler.scm",(void*)f_9553},
{"f_9475compiler.scm",(void*)f_9475},
{"f_9522compiler.scm",(void*)f_9522},
{"f_9526compiler.scm",(void*)f_9526},
{"f_9502compiler.scm",(void*)f_9502},
{"f_9498compiler.scm",(void*)f_9498},
{"f_9189compiler.scm",(void*)f_9189},
{"f_9438compiler.scm",(void*)f_9438},
{"f_9193compiler.scm",(void*)f_9193},
{"f_9436compiler.scm",(void*)f_9436},
{"f_9196compiler.scm",(void*)f_9196},
{"f_9199compiler.scm",(void*)f_9199},
{"f_9205compiler.scm",(void*)f_9205},
{"f_9211compiler.scm",(void*)f_9211},
{"f_9217compiler.scm",(void*)f_9217},
{"f_9403compiler.scm",(void*)f_9403},
{"f_9406compiler.scm",(void*)f_9406},
{"f_9220compiler.scm",(void*)f_9220},
{"f_9379compiler.scm",(void*)f_9379},
{"f_9364compiler.scm",(void*)f_9364},
{"f_9360compiler.scm",(void*)f_9360},
{"f_9294compiler.scm",(void*)f_9294},
{"f_9319compiler.scm",(void*)f_9319},
{"f_9325compiler.scm",(void*)f_9325},
{"f_9336compiler.scm",(void*)f_9336},
{"f_9323compiler.scm",(void*)f_9323},
{"f_9305compiler.scm",(void*)f_9305},
{"f_9297compiler.scm",(void*)f_9297},
{"f_9282compiler.scm",(void*)f_9282},
{"f_9290compiler.scm",(void*)f_9290},
{"f_9243compiler.scm",(void*)f_9243},
{"f_9273compiler.scm",(void*)f_9273},
{"f_9265compiler.scm",(void*)f_9265},
{"f_9261compiler.scm",(void*)f_9261},
{"f_9257compiler.scm",(void*)f_9257},
{"f_9246compiler.scm",(void*)f_9246},
{"f_9114compiler.scm",(void*)f_9114},
{"f_9117compiler.scm",(void*)f_9117},
{"f_9169compiler.scm",(void*)f_9169},
{"f_9133compiler.scm",(void*)f_9133},
{"f_9162compiler.scm",(void*)f_9162},
{"f_9154compiler.scm",(void*)f_9154},
{"f_9099compiler.scm",(void*)f_9099},
{"f_9072compiler.scm",(void*)f_9072},
{"f_9078compiler.scm",(void*)f_9078},
{"f_9742compiler.scm",(void*)f_9742},
{"f_9749compiler.scm",(void*)f_9749},
{"f_9765compiler.scm",(void*)f_9765},
{"f_8707compiler.scm",(void*)f_8707},
{"f_8726compiler.scm",(void*)f_8726},
{"f_9005compiler.scm",(void*)f_9005},
{"f_8966compiler.scm",(void*)f_8966},
{"f_9781compiler.scm",(void*)f_9781},
{"f_9819compiler.scm",(void*)f_9819},
{"f_9845compiler.scm",(void*)f_9845},
{"f_9831compiler.scm",(void*)f_9831},
{"f_9810compiler.scm",(void*)f_9810},
{"f_9779compiler.scm",(void*)f_9779},
{"f_8979compiler.scm",(void*)f_8979},
{"f_8982compiler.scm",(void*)f_8982},
{"f_8993compiler.scm",(void*)f_8993},
{"f_8930compiler.scm",(void*)f_8930},
{"f_8822compiler.scm",(void*)f_8822},
{"f_8828compiler.scm",(void*)f_8828},
{"f_8840compiler.scm",(void*)f_8840},
{"f_8843compiler.scm",(void*)f_8843},
{"f_8846compiler.scm",(void*)f_8846},
{"f_8864compiler.scm",(void*)f_8864},
{"f_8871compiler.scm",(void*)f_8871},
{"f_8849compiler.scm",(void*)f_8849},
{"f_8852compiler.scm",(void*)f_8852},
{"f_8855compiler.scm",(void*)f_8855},
{"f_8816compiler.scm",(void*)f_8816},
{"f_8806compiler.scm",(void*)f_8806},
{"f_8789compiler.scm",(void*)f_8789},
{"f_8794compiler.scm",(void*)f_8794},
{"f_8747compiler.scm",(void*)f_8747},
{"f_8764compiler.scm",(void*)f_8764},
{"f_8751compiler.scm",(void*)f_8751},
{"f_8762compiler.scm",(void*)f_8762},
{"f_8737compiler.scm",(void*)f_8737},
{"f_8696compiler.scm",(void*)f_8696},
{"f_8705compiler.scm",(void*)f_8705},
{"f_8686compiler.scm",(void*)f_8686},
{"f_8691compiler.scm",(void*)f_8691},
{"f_8680compiler.scm",(void*)f_8680},
{"f_7152compiler.scm",(void*)f_7152},
{"f_7156compiler.scm",(void*)f_7156},
{"f_7906compiler.scm",(void*)f_7906},
{"f_7909compiler.scm",(void*)f_7909},
{"f_7913compiler.scm",(void*)f_7913},
{"f_7916compiler.scm",(void*)f_7916},
{"f_7929compiler.scm",(void*)f_7929},
{"f_8564compiler.scm",(void*)f_8564},
{"f_7933compiler.scm",(void*)f_7933},
{"f_8529compiler.scm",(void*)f_8529},
{"f_7940compiler.scm",(void*)f_7940},
{"f_8475compiler.scm",(void*)f_8475},
{"f_8478compiler.scm",(void*)f_8478},
{"f_8490compiler.scm",(void*)f_8490},
{"f_8484compiler.scm",(void*)f_8484},
{"f_7943compiler.scm",(void*)f_7943},
{"f_7946compiler.scm",(void*)f_7946},
{"f_8458compiler.scm",(void*)f_8458},
{"f_8450compiler.scm",(void*)f_8450},
{"f_8418compiler.scm",(void*)f_8418},
{"f_8424compiler.scm",(void*)f_8424},
{"f_7949compiler.scm",(void*)f_7949},
{"f_8380compiler.scm",(void*)f_8380},
{"f_8389compiler.scm",(void*)f_8389},
{"f_8392compiler.scm",(void*)f_8392},
{"f_7952compiler.scm",(void*)f_7952},
{"f_8281compiler.scm",(void*)f_8281},
{"f_8299compiler.scm",(void*)f_8299},
{"f_8342compiler.scm",(void*)f_8342},
{"f_8367compiler.scm",(void*)f_8367},
{"f_8363compiler.scm",(void*)f_8363},
{"f_8349compiler.scm",(void*)f_8349},
{"f_8352compiler.scm",(void*)f_8352},
{"f_8303compiler.scm",(void*)f_8303},
{"f_8309compiler.scm",(void*)f_8309},
{"f_7955compiler.scm",(void*)f_7955},
{"f_8259compiler.scm",(void*)f_8259},
{"f_8245compiler.scm",(void*)f_8245},
{"f_8252compiler.scm",(void*)f_8252},
{"f_8233compiler.scm",(void*)f_8233},
{"f_8218compiler.scm",(void*)f_8218},
{"f_7958compiler.scm",(void*)f_7958},
{"f_8130compiler.scm",(void*)f_8130},
{"f_8204compiler.scm",(void*)f_8204},
{"f_8136compiler.scm",(void*)f_8136},
{"f_8194compiler.scm",(void*)f_8194},
{"f_8186compiler.scm",(void*)f_8186},
{"f_8182compiler.scm",(void*)f_8182},
{"f_8139compiler.scm",(void*)f_8139},
{"f_8142compiler.scm",(void*)f_8142},
{"f_7961compiler.scm",(void*)f_7961},
{"f_7989compiler.scm",(void*)f_7989},
{"f_8010compiler.scm",(void*)f_8010},
{"f_8031compiler.scm",(void*)f_8031},
{"f_8037compiler.scm",(void*)f_8037},
{"f_7964compiler.scm",(void*)f_7964},
{"f_7970compiler.scm",(void*)f_7970},
{"f_7974compiler.scm",(void*)f_7974},
{"f_7919compiler.scm",(void*)f_7919},
{"f_7923compiler.scm",(void*)f_7923},
{"f_7926compiler.scm",(void*)f_7926},
{"f_7881compiler.scm",(void*)f_7881},
{"f_7891compiler.scm",(void*)f_7891},
{"f_7899compiler.scm",(void*)f_7899},
{"f_7867compiler.scm",(void*)f_7867},
{"f_7875compiler.scm",(void*)f_7875},
{"f_7746compiler.scm",(void*)f_7746},
{"f_7752compiler.scm",(void*)f_7752},
{"f_7165compiler.scm",(void*)f_7165},
{"f_7187compiler.scm",(void*)f_7187},
{"f_7708compiler.scm",(void*)f_7708},
{"f_7702compiler.scm",(void*)f_7702},
{"f_7675compiler.scm",(void*)f_7675},
{"f_7684compiler.scm",(void*)f_7684},
{"f_7669compiler.scm",(void*)f_7669},
{"f_7594compiler.scm",(void*)f_7594},
{"f_7623compiler.scm",(void*)f_7623},
{"f_7638compiler.scm",(void*)f_7638},
{"f_7642compiler.scm",(void*)f_7642},
{"f_7629compiler.scm",(void*)f_7629},
{"f_7597compiler.scm",(void*)f_7597},
{"f_7620compiler.scm",(void*)f_7620},
{"f_7600compiler.scm",(void*)f_7600},
{"f_7603compiler.scm",(void*)f_7603},
{"f_7606compiler.scm",(void*)f_7606},
{"f_7484compiler.scm",(void*)f_7484},
{"f_7576compiler.scm",(void*)f_7576},
{"f_7491compiler.scm",(void*)f_7491},
{"f_7566compiler.scm",(void*)f_7566},
{"f_7570compiler.scm",(void*)f_7570},
{"f_7494compiler.scm",(void*)f_7494},
{"f_7497compiler.scm",(void*)f_7497},
{"f_7551compiler.scm",(void*)f_7551},
{"f_7500compiler.scm",(void*)f_7500},
{"f_7503compiler.scm",(void*)f_7503},
{"f_7536compiler.scm",(void*)f_7536},
{"f_7506compiler.scm",(void*)f_7506},
{"f_7533compiler.scm",(void*)f_7533},
{"f_7509compiler.scm",(void*)f_7509},
{"f_7440compiler.scm",(void*)f_7440},
{"f_7459compiler.scm",(void*)f_7459},
{"f_7444compiler.scm",(void*)f_7444},
{"f_7457compiler.scm",(void*)f_7457},
{"f_7448compiler.scm",(void*)f_7448},
{"f_7373compiler.scm",(void*)f_7373},
{"f_7378compiler.scm",(void*)f_7378},
{"f_7405compiler.scm",(void*)f_7405},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7396compiler.scm",(void*)f_7396},
{"f_7301compiler.scm",(void*)f_7301},
{"f_7349compiler.scm",(void*)f_7349},
{"f_7312compiler.scm",(void*)f_7312},
{"f_7331compiler.scm",(void*)f_7331},
{"f_7278compiler.scm",(void*)f_7278},
{"f_7281compiler.scm",(void*)f_7281},
{"f_7242compiler.scm",(void*)f_7242},
{"f_7199compiler.scm",(void*)f_7199},
{"f_7230compiler.scm",(void*)f_7230},
{"f_7758compiler.scm",(void*)f_7758},
{"f_7771compiler.scm",(void*)f_7771},
{"f_7831compiler.scm",(void*)f_7831},
{"f_7780compiler.scm",(void*)f_7780},
{"f_7783compiler.scm",(void*)f_7783},
{"f_7786compiler.scm",(void*)f_7786},
{"f_7861compiler.scm",(void*)f_7861},
{"f_7158compiler.scm",(void*)f_7158},
{"f_7143compiler.scm",(void*)f_7143},
{"f_7134compiler.scm",(void*)f_7134},
{"f_7125compiler.scm",(void*)f_7125},
{"f_7116compiler.scm",(void*)f_7116},
{"f_7107compiler.scm",(void*)f_7107},
{"f_7098compiler.scm",(void*)f_7098},
{"f_7089compiler.scm",(void*)f_7089},
{"f_7080compiler.scm",(void*)f_7080},
{"f_7071compiler.scm",(void*)f_7071},
{"f_7062compiler.scm",(void*)f_7062},
{"f_7056compiler.scm",(void*)f_7056},
{"f_7050compiler.scm",(void*)f_7050},
{"f_6375compiler.scm",(void*)f_6375},
{"f_7022compiler.scm",(void*)f_7022},
{"f_6937compiler.scm",(void*)f_6937},
{"f_6943compiler.scm",(void*)f_6943},
{"f_6963compiler.scm",(void*)f_6963},
{"f_6981compiler.scm",(void*)f_6981},
{"f_6990compiler.scm",(void*)f_6990},
{"f_7016compiler.scm",(void*)f_7016},
{"f_7004compiler.scm",(void*)f_7004},
{"f_6957compiler.scm",(void*)f_6957},
{"f_6921compiler.scm",(void*)f_6921},
{"f_6927compiler.scm",(void*)f_6927},
{"f_6796compiler.scm",(void*)f_6796},
{"f_6800compiler.scm",(void*)f_6800},
{"f_6803compiler.scm",(void*)f_6803},
{"f_6857compiler.scm",(void*)f_6857},
{"f_6853compiler.scm",(void*)f_6853},
{"f_6849compiler.scm",(void*)f_6849},
{"f_6828compiler.scm",(void*)f_6828},
{"f_6834compiler.scm",(void*)f_6834},
{"f_6845compiler.scm",(void*)f_6845},
{"f_6838compiler.scm",(void*)f_6838},
{"f_6826compiler.scm",(void*)f_6826},
{"f_6422compiler.scm",(void*)f_6422},
{"f_6444compiler.scm",(void*)f_6444},
{"f_6710compiler.scm",(void*)f_6710},
{"f_6867compiler.scm",(void*)f_6867},
{"f_6870compiler.scm",(void*)f_6870},
{"f_6915compiler.scm",(void*)f_6915},
{"f_6911compiler.scm",(void*)f_6911},
{"f_6907compiler.scm",(void*)f_6907},
{"f_6903compiler.scm",(void*)f_6903},
{"f_6675compiler.scm",(void*)f_6675},
{"f_6701compiler.scm",(void*)f_6701},
{"f_6625compiler.scm",(void*)f_6625},
{"f_6634compiler.scm",(void*)f_6634},
{"f_6662compiler.scm",(void*)f_6662},
{"f_6658compiler.scm",(void*)f_6658},
{"f_6612compiler.scm",(void*)f_6612},
{"f_6550compiler.scm",(void*)f_6550},
{"f_6573compiler.scm",(void*)f_6573},
{"f_6587compiler.scm",(void*)f_6587},
{"f_6456compiler.scm",(void*)f_6456},
{"f_6459compiler.scm",(void*)f_6459},
{"f_6535compiler.scm",(void*)f_6535},
{"f_6531compiler.scm",(void*)f_6531},
{"f_6527compiler.scm",(void*)f_6527},
{"f_6500compiler.scm",(void*)f_6500},
{"f_6511compiler.scm",(void*)f_6511},
{"f_6515compiler.scm",(void*)f_6515},
{"f_6494compiler.scm",(void*)f_6494},
{"f_6460compiler.scm",(void*)f_6460},
{"f_6471compiler.scm",(void*)f_6471},
{"f_6378compiler.scm",(void*)f_6378},
{"f_6382compiler.scm",(void*)f_6382},
{"f_6405compiler.scm",(void*)f_6405},
{"f_6416compiler.scm",(void*)f_6416},
{"f_6399compiler.scm",(void*)f_6399},
{"f_6285compiler.scm",(void*)f_6285},
{"f_6317compiler.scm",(void*)f_6317},
{"f_6336compiler.scm",(void*)f_6336},
{"f_6359compiler.scm",(void*)f_6359},
{"f_6342compiler.scm",(void*)f_6342},
{"f_6288compiler.scm",(void*)f_6288},
{"f_6294compiler.scm",(void*)f_6294},
{"f_6304compiler.scm",(void*)f_6304},
{"f_6204compiler.scm",(void*)f_6204},
{"f_6208compiler.scm",(void*)f_6208},
{"f_6211compiler.scm",(void*)f_6211},
{"f_6214compiler.scm",(void*)f_6214},
{"f_6230compiler.scm",(void*)f_6230},
{"f_6217compiler.scm",(void*)f_6217},
{"f_6220compiler.scm",(void*)f_6220},
{"f_6223compiler.scm",(void*)f_6223},
{"f_6167compiler.scm",(void*)f_6167},
{"f_6190compiler.scm",(void*)f_6190},
{"f_6177compiler.scm",(void*)f_6177},
{"f_6180compiler.scm",(void*)f_6180},
{"f_6183compiler.scm",(void*)f_6183},
{"f_6130compiler.scm",(void*)f_6130},
{"f_6153compiler.scm",(void*)f_6153},
{"f_6140compiler.scm",(void*)f_6140},
{"f_6143compiler.scm",(void*)f_6143},
{"f_6146compiler.scm",(void*)f_6146},
{"f_6085compiler.scm",(void*)f_6085},
{"f_6092compiler.scm",(void*)f_6092},
{"f_6098compiler.scm",(void*)f_6098},
{"f_6040compiler.scm",(void*)f_6040},
{"f_6047compiler.scm",(void*)f_6047},
{"f_6053compiler.scm",(void*)f_6053},
{"f_5886compiler.scm",(void*)f_5886},
{"f_6034compiler.scm",(void*)f_6034},
{"f_5890compiler.scm",(void*)f_5890},
{"f_5893compiler.scm",(void*)f_5893},
{"f_5896compiler.scm",(void*)f_5896},
{"f_5899compiler.scm",(void*)f_5899},
{"f_5902compiler.scm",(void*)f_5902},
{"f_6028compiler.scm",(void*)f_6028},
{"f_5912compiler.scm",(void*)f_5912},
{"f_6003compiler.scm",(void*)f_6003},
{"f_6011compiler.scm",(void*)f_6011},
{"f_5915compiler.scm",(void*)f_5915},
{"f_5955compiler.scm",(void*)f_5955},
{"f_5958compiler.scm",(void*)f_5958},
{"f_5977compiler.scm",(void*)f_5977},
{"f_5973compiler.scm",(void*)f_5973},
{"f_5969compiler.scm",(void*)f_5969},
{"f_5948compiler.scm",(void*)f_5948},
{"f_5938compiler.scm",(void*)f_5938},
{"f_5926compiler.scm",(void*)f_5926},
{"f_5877compiler.scm",(void*)f_5877},
{"f_5868compiler.scm",(void*)f_5868},
{"f_5859compiler.scm",(void*)f_5859},
{"f_5850compiler.scm",(void*)f_5850},
{"f_5841compiler.scm",(void*)f_5841},
{"f_5832compiler.scm",(void*)f_5832},
{"f_5823compiler.scm",(void*)f_5823},
{"f_5814compiler.scm",(void*)f_5814},
{"f_5805compiler.scm",(void*)f_5805},
{"f_5796compiler.scm",(void*)f_5796},
{"f_5787compiler.scm",(void*)f_5787},
{"f_5778compiler.scm",(void*)f_5778},
{"f_5769compiler.scm",(void*)f_5769},
{"f_5760compiler.scm",(void*)f_5760},
{"f_5751compiler.scm",(void*)f_5751},
{"f_5742compiler.scm",(void*)f_5742},
{"f_5736compiler.scm",(void*)f_5736},
{"f_5730compiler.scm",(void*)f_5730},
{"f_4767compiler.scm",(void*)f_4767},
{"f_4821compiler.scm",(void*)f_4821},
{"f_4825compiler.scm",(void*)f_4825},
{"f_5705compiler.scm",(void*)f_5705},
{"f_5681compiler.scm",(void*)f_5681},
{"f_5691compiler.scm",(void*)f_5691},
{"f_5686compiler.scm",(void*)f_5686},
{"f_5653compiler.scm",(void*)f_5653},
{"f_5659compiler.scm",(void*)f_5659},
{"f_5635compiler.scm",(void*)f_5635},
{"f_5639compiler.scm",(void*)f_5639},
{"f_5607compiler.scm",(void*)f_5607},
{"f_5614compiler.scm",(void*)f_5614},
{"f_5590compiler.scm",(void*)f_5590},
{"f_5516compiler.scm",(void*)f_5516},
{"f_5520compiler.scm",(void*)f_5520},
{"f_5503compiler.scm",(void*)f_5503},
{"f_5495compiler.scm",(void*)f_5495},
{"f_5499compiler.scm",(void*)f_5499},
{"f_5340compiler.scm",(void*)f_5340},
{"f_5450compiler.scm",(void*)f_5450},
{"f_5439compiler.scm",(void*)f_5439},
{"f_5443compiler.scm",(void*)f_5443},
{"f_5410compiler.scm",(void*)f_5410},
{"f_5385compiler.scm",(void*)f_5385},
{"f_5360compiler.scm",(void*)f_5360},
{"f_5327compiler.scm",(void*)f_5327},
{"f_5279compiler.scm",(void*)f_5279},
{"f_5288compiler.scm",(void*)f_5288},
{"f_5286compiler.scm",(void*)f_5286},
{"f_5189compiler.scm",(void*)f_5189},
{"f_5167compiler.scm",(void*)f_5167},
{"f_5171compiler.scm",(void*)f_5171},
{"f_5140compiler.scm",(void*)f_5140},
{"f_5144compiler.scm",(void*)f_5144},
{"f_5126compiler.scm",(void*)f_5126},
{"f_5130compiler.scm",(void*)f_5130},
{"f_5105compiler.scm",(void*)f_5105},
{"f_5091compiler.scm",(void*)f_5091},
{"f_5008compiler.scm",(void*)f_5008},
{"f_4991compiler.scm",(void*)f_4991},
{"f_4995compiler.scm",(void*)f_4995},
{"f_4962compiler.scm",(void*)f_4962},
{"f_4937compiler.scm",(void*)f_4937},
{"f_4890compiler.scm",(void*)f_4890},
{"f_4920compiler.scm",(void*)f_4920},
{"f_4896compiler.scm",(void*)f_4896},
{"f_4899compiler.scm",(void*)f_4899},
{"f_4906compiler.scm",(void*)f_4906},
{"f_4902compiler.scm",(void*)f_4902},
{"f_4840compiler.scm",(void*)f_4840},
{"f_4843compiler.scm",(void*)f_4843},
{"f_4877compiler.scm",(void*)f_4877},
{"f_4871compiler.scm",(void*)f_4871},
{"f_4852compiler.scm",(void*)f_4852},
{"f_4861compiler.scm",(void*)f_4861},
{"f_4869compiler.scm",(void*)f_4869},
{"f_4855compiler.scm",(void*)f_4855},
{"f_4859compiler.scm",(void*)f_4859},
{"f_4831compiler.scm",(void*)f_4831},
{"f_4770compiler.scm",(void*)f_4770},
{"f_4793compiler.scm",(void*)f_4793},
{"f_4783compiler.scm",(void*)f_4783},
{"f_1976compiler.scm",(void*)f_1976},
{"f_4762compiler.scm",(void*)f_4762},
{"f_4725compiler.scm",(void*)f_4725},
{"f_4728compiler.scm",(void*)f_4728},
{"f_4743compiler.scm",(void*)f_4743},
{"f_4752compiler.scm",(void*)f_4752},
{"f_4756compiler.scm",(void*)f_4756},
{"f_4739compiler.scm",(void*)f_4739},
{"f_4712compiler.scm",(void*)f_4712},
{"f_4718compiler.scm",(void*)f_4718},
{"f_2166compiler.scm",(void*)f_2166},
{"f_2203compiler.scm",(void*)f_2203},
{"f_4573compiler.scm",(void*)f_4573},
{"f_4688compiler.scm",(void*)f_4688},
{"f_4588compiler.scm",(void*)f_4588},
{"f_4675compiler.scm",(void*)f_4675},
{"f_4597compiler.scm",(void*)f_4597},
{"f_4600compiler.scm",(void*)f_4600},
{"f_4609compiler.scm",(void*)f_4609},
{"f_4631compiler.scm",(void*)f_4631},
{"f_4624compiler.scm",(void*)f_4624},
{"f_4576compiler.scm",(void*)f_4576},
{"f_4579compiler.scm",(void*)f_4579},
{"f_2230compiler.scm",(void*)f_2230},
{"f_2236compiler.scm",(void*)f_2236},
{"f_4555compiler.scm",(void*)f_4555},
{"f_2239compiler.scm",(void*)f_2239},
{"f_2246compiler.scm",(void*)f_2246},
{"f_2255compiler.scm",(void*)f_2255},
{"f_2264compiler.scm",(void*)f_2264},
{"f_2398compiler.scm",(void*)f_2398},
{"f_4475compiler.scm",(void*)f_4475},
{"f_4481compiler.scm",(void*)f_4481},
{"f_4386compiler.scm",(void*)f_4386},
{"f_4446compiler.scm",(void*)f_4446},
{"f_4346compiler.scm",(void*)f_4346},
{"f_4350compiler.scm",(void*)f_4350},
{"f_4356compiler.scm",(void*)f_4356},
{"f_4370compiler.scm",(void*)f_4370},
{"f_4359compiler.scm",(void*)f_4359},
{"f_3982compiler.scm",(void*)f_3982},
{"f_4330compiler.scm",(void*)f_4330},
{"f_4004compiler.scm",(void*)f_4004},
{"f_4295compiler.scm",(void*)f_4295},
{"f_4007compiler.scm",(void*)f_4007},
{"f_4018compiler.scm",(void*)f_4018},
{"f_4245compiler.scm",(void*)f_4245},
{"f_4289compiler.scm",(void*)f_4289},
{"f_4285compiler.scm",(void*)f_4285},
{"f_4281compiler.scm",(void*)f_4281},
{"f_4269compiler.scm",(void*)f_4269},
{"f_4038compiler.scm",(void*)f_4038},
{"f_4117compiler.scm",(void*)f_4117},
{"f_4094compiler.scm",(void*)f_4094},
{"f_4089compiler.scm",(void*)f_4089},
{"f_4052compiler.scm",(void*)f_4052},
{"f_4042compiler.scm",(void*)f_4042},
{"f_4026compiler.scm",(void*)f_4026},
{"f_4014compiler.scm",(void*)f_4014},
{"f_3972compiler.scm",(void*)f_3972},
{"f_3949compiler.scm",(void*)f_3949},
{"f_3947compiler.scm",(void*)f_3947},
{"f_3876compiler.scm",(void*)f_3876},
{"f_3894compiler.scm",(void*)f_3894},
{"f_3916compiler.scm",(void*)f_3916},
{"f_3922compiler.scm",(void*)f_3922},
{"f_3900compiler.scm",(void*)f_3900},
{"f_3907compiler.scm",(void*)f_3907},
{"f_3882compiler.scm",(void*)f_3882},
{"f_3888compiler.scm",(void*)f_3888},
{"f_3874compiler.scm",(void*)f_3874},
{"f_3812compiler.scm",(void*)f_3812},
{"f_3823compiler.scm",(void*)f_3823},
{"f_3833compiler.scm",(void*)f_3833},
{"f_3836compiler.scm",(void*)f_3836},
{"f_3840compiler.scm",(void*)f_3840},
{"f_3826compiler.scm",(void*)f_3826},
{"f_3751compiler.scm",(void*)f_3751},
{"f_3755compiler.scm",(void*)f_3755},
{"f_3793compiler.scm",(void*)f_3793},
{"f_3759compiler.scm",(void*)f_3759},
{"f_3773compiler.scm",(void*)f_3773},
{"f_3771compiler.scm",(void*)f_3771},
{"f_3733compiler.scm",(void*)f_3733},
{"f_3741compiler.scm",(void*)f_3741},
{"f_3606compiler.scm",(void*)f_3606},
{"f_3609compiler.scm",(void*)f_3609},
{"f_3615compiler.scm",(void*)f_3615},
{"f_3694compiler.scm",(void*)f_3694},
{"f_3671compiler.scm",(void*)f_3671},
{"f_3646compiler.scm",(void*)f_3646},
{"f_3654compiler.scm",(void*)f_3654},
{"f_3642compiler.scm",(void*)f_3642},
{"f_3638compiler.scm",(void*)f_3638},
{"f_3630compiler.scm",(void*)f_3630},
{"f_3531compiler.scm",(void*)f_3531},
{"f_3540compiler.scm",(void*)f_3540},
{"f_3579compiler.scm",(void*)f_3579},
{"f_3571compiler.scm",(void*)f_3571},
{"f_3543compiler.scm",(void*)f_3543},
{"f_3563compiler.scm",(void*)f_3563},
{"f_3555compiler.scm",(void*)f_3555},
{"f_3511compiler.scm",(void*)f_3511},
{"f_3457compiler.scm",(void*)f_3457},
{"f_3460compiler.scm",(void*)f_3460},
{"f_3463compiler.scm",(void*)f_3463},
{"f_3467compiler.scm",(void*)f_3467},
{"f_3471compiler.scm",(void*)f_3471},
{"f_3390compiler.scm",(void*)f_3390},
{"f_3402compiler.scm",(void*)f_3402},
{"f_3375compiler.scm",(void*)f_3375},
{"f_3362compiler.scm",(void*)f_3362},
{"f_3349compiler.scm",(void*)f_3349},
{"f_3336compiler.scm",(void*)f_3336},
{"f_3323compiler.scm",(void*)f_3323},
{"f_3256compiler.scm",(void*)f_3256},
{"f_3275compiler.scm",(void*)f_3275},
{"f_3302compiler.scm",(void*)f_3302},
{"f_3306compiler.scm",(void*)f_3306},
{"f_3295compiler.scm",(void*)f_3295},
{"f_3269compiler.scm",(void*)f_3269},
{"f_3243compiler.scm",(void*)f_3243},
{"f_3228compiler.scm",(void*)f_3228},
{"f_3201compiler.scm",(void*)f_3201},
{"f_3205compiler.scm",(void*)f_3205},
{"f_3180compiler.scm",(void*)f_3180},
{"f_3151compiler.scm",(void*)f_3151},
{"f_3155compiler.scm",(void*)f_3155},
{"f_3122compiler.scm",(void*)f_3122},
{"f_3126compiler.scm",(void*)f_3126},
{"f_2948compiler.scm",(void*)f_2948},
{"f_2957compiler.scm",(void*)f_2957},
{"f_2960compiler.scm",(void*)f_2960},
{"f_3068compiler.scm",(void*)f_3068},
{"f_3097compiler.scm",(void*)f_3097},
{"f_3101compiler.scm",(void*)f_3101},
{"f_3071compiler.scm",(void*)f_3071},
{"f_3077compiler.scm",(void*)f_3077},
{"f_3090compiler.scm",(void*)f_3090},
{"f_3080compiler.scm",(void*)f_3080},
{"f_2963compiler.scm",(void*)f_2963},
{"f_3058compiler.scm",(void*)f_3058},
{"f_2966compiler.scm",(void*)f_2966},
{"f_3021compiler.scm",(void*)f_3021},
{"f_3052compiler.scm",(void*)f_3052},
{"f_3044compiler.scm",(void*)f_3044},
{"f_2978compiler.scm",(void*)f_2978},
{"f_3009compiler.scm",(void*)f_3009},
{"f_2997compiler.scm",(void*)f_2997},
{"f_2910compiler.scm",(void*)f_2910},
{"f_2936compiler.scm",(void*)f_2936},
{"f_2913compiler.scm",(void*)f_2913},
{"f_2928compiler.scm",(void*)f_2928},
{"f_2926compiler.scm",(void*)f_2926},
{"f_2916compiler.scm",(void*)f_2916},
{"f_2919compiler.scm",(void*)f_2919},
{"f_2633compiler.scm",(void*)f_2633},
{"f_2860compiler.scm",(void*)f_2860},
{"f_2871compiler.scm",(void*)f_2871},
{"f_2865compiler.scm",(void*)f_2865},
{"f_2642compiler.scm",(void*)f_2642},
{"f_2647compiler.scm",(void*)f_2647},
{"f_2651compiler.scm",(void*)f_2651},
{"f_2857compiler.scm",(void*)f_2857},
{"f_2654compiler.scm",(void*)f_2654},
{"f_2849compiler.scm",(void*)f_2849},
{"f_2657compiler.scm",(void*)f_2657},
{"f_2660compiler.scm",(void*)f_2660},
{"f_2847compiler.scm",(void*)f_2847},
{"f_2840compiler.scm",(void*)f_2840},
{"f_2663compiler.scm",(void*)f_2663},
{"f_2669compiler.scm",(void*)f_2669},
{"f_2678compiler.scm",(void*)f_2678},
{"f_2684compiler.scm",(void*)f_2684},
{"f_2698compiler.scm",(void*)f_2698},
{"f_2782compiler.scm",(void*)f_2782},
{"f_2778compiler.scm",(void*)f_2778},
{"f_2774compiler.scm",(void*)f_2774},
{"f_2731compiler.scm",(void*)f_2731},
{"f_2738compiler.scm",(void*)f_2738},
{"f_2688compiler.scm",(void*)f_2688},
{"f_2559compiler.scm",(void*)f_2559},
{"f_2565compiler.scm",(void*)f_2565},
{"f_2568compiler.scm",(void*)f_2568},
{"f_2621compiler.scm",(void*)f_2621},
{"f_2571compiler.scm",(void*)f_2571},
{"f_2574compiler.scm",(void*)f_2574},
{"f_2601compiler.scm",(void*)f_2601},
{"f_2609compiler.scm",(void*)f_2609},
{"f_2581compiler.scm",(void*)f_2581},
{"f_2595compiler.scm",(void*)f_2595},
{"f_2589compiler.scm",(void*)f_2589},
{"f_2585compiler.scm",(void*)f_2585},
{"f_2445compiler.scm",(void*)f_2445},
{"f_2455compiler.scm",(void*)f_2455},
{"f_2466compiler.scm",(void*)f_2466},
{"f_2540compiler.scm",(void*)f_2540},
{"f_2550compiler.scm",(void*)f_2550},
{"f_2531compiler.scm",(void*)f_2531},
{"f_2505compiler.scm",(void*)f_2505},
{"f_2519compiler.scm",(void*)f_2519},
{"f_2517compiler.scm",(void*)f_2517},
{"f_2493compiler.scm",(void*)f_2493},
{"f_2470compiler.scm",(void*)f_2470},
{"f_2477compiler.scm",(void*)f_2477},
{"f_2460compiler.scm",(void*)f_2460},
{"f_2439compiler.scm",(void*)f_2439},
{"f_2407compiler.scm",(void*)f_2407},
{"f_2410compiler.scm",(void*)f_2410},
{"f_2421compiler.scm",(void*)f_2421},
{"f_2415compiler.scm",(void*)f_2415},
{"f_2413compiler.scm",(void*)f_2413},
{"f_2365compiler.scm",(void*)f_2365},
{"f_2377compiler.scm",(void*)f_2377},
{"f_2381compiler.scm",(void*)f_2381},
{"f_2333compiler.scm",(void*)f_2333},
{"f_2287compiler.scm",(void*)f_2287},
{"f_2294compiler.scm",(void*)f_2294},
{"f_2298compiler.scm",(void*)f_2298},
{"f_2302compiler.scm",(void*)f_2302},
{"f_2191compiler.scm",(void*)f_2191},
{"f_2185compiler.scm",(void*)f_2185},
{"f_2148compiler.scm",(void*)f_2148},
{"f_2157compiler.scm",(void*)f_2157},
{"f_2057compiler.scm",(void*)f_2057},
{"f_2061compiler.scm",(void*)f_2061},
{"f_2074compiler.scm",(void*)f_2074},
{"f_2122compiler.scm",(void*)f_2122},
{"f_2132compiler.scm",(void*)f_2132},
{"f_2092compiler.scm",(void*)f_2092},
{"f_2102compiler.scm",(void*)f_2102},
{"f_2015compiler.scm",(void*)f_2015},
{"f_2022compiler.scm",(void*)f_2022},
{"f_1991compiler.scm",(void*)f_1991},
{"f_1997compiler.scm",(void*)f_1997},
{"f_1979compiler.scm",(void*)f_1979},
{"f_1905compiler.scm",(void*)f_1905},
{"f_1974compiler.scm",(void*)f_1974},
{"f_1909compiler.scm",(void*)f_1909},
{"f_1967compiler.scm",(void*)f_1967},
{"f_1912compiler.scm",(void*)f_1912},
{"f_1960compiler.scm",(void*)f_1960},
{"f_1915compiler.scm",(void*)f_1915},
{"f_1919compiler.scm",(void*)f_1919},
{"f_1923compiler.scm",(void*)f_1923},
{"f_1953compiler.scm",(void*)f_1953},
{"f_1926compiler.scm",(void*)f_1926},
{"f_1946compiler.scm",(void*)f_1946},
{"f_1929compiler.scm",(void*)f_1929},
{"f_1939compiler.scm",(void*)f_1939},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
