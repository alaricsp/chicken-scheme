/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-26 22:11
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   compiled 2008-07-02 on debian (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[580];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10202)
static void C_ccall f_10202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_ccall f_11265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11268)
static void C_ccall f_11268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11271)
static void C_ccall f_11271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_fcall f_11059(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10292)
static void C_fcall f_10292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11045)
static void C_ccall f_11045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10958)
static void C_fcall f_10958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_fcall f_10979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10982)
static void C_ccall f_10982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_fcall f_10930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_ccall f_10933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_fcall f_10899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10890)
static void C_fcall f_10890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10893)
static void C_ccall f_10893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10868)
static void C_ccall f_10868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_fcall f_10801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10825)
static void C_ccall f_10825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10817)
static void C_ccall f_10817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10742)
static void C_ccall f_10742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10730)
static void C_ccall f_10730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10542)
static void C_ccall f_10542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10663)
static void C_ccall f_10663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10675)
static void C_fcall f_10675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10552)
static void C_ccall f_10552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10555)
static void C_ccall f_10555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10558)
static void C_ccall f_10558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10596)
static void C_ccall f_10596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10603)
static void C_fcall f_10603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10607)
static void C_ccall f_10607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10486)
static void C_ccall f_10486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_fcall f_10495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10489)
static void C_fcall f_10489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10470)
static void C_ccall f_10470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10443)
static void C_ccall f_10443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10415)
static void C_ccall f_10415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10370)
static void C_ccall f_10370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10350)
static void C_ccall f_10350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10205)
static void C_fcall f_10205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10209)
static void C_ccall f_10209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10239)
static void C_fcall f_10239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10284)
static void C_ccall f_10284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_fcall f_10249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10259)
static void C_ccall f_10259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11071)
static void C_fcall f_11071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11078)
static void C_ccall f_11078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11104)
static void C_ccall f_11104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11090)
static void C_ccall f_11090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_fcall f_11165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11188)
static void C_ccall f_11188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11195)
static void C_ccall f_11195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11169)
static void C_ccall f_11169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11151)
static void C_fcall f_11151(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11159)
static void C_ccall f_11159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11197)
static void C_fcall f_11197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11210)
static void C_ccall f_11210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10166)
static void C_ccall f_10166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10094)
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10085)
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10067)
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10040)
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9995)
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9914)
static void C_ccall f_9914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9912)
static void C_ccall f_9912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9902)
static void C_ccall f_9902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9739)
static void C_fcall f_9739(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9050)
static void C_fcall f_9050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9069)
static void C_fcall f_9069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9102)
static void C_fcall f_9102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9629)
static void C_ccall f_9629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9618)
static void C_fcall f_9618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9475)
static void C_ccall f_9475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9558)
static void C_ccall f_9558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9562)
static void C_ccall f_9562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9484)
static void C_ccall f_9484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9535)
static void C_ccall f_9535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_ccall f_9511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9447)
static void C_ccall f_9447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9445)
static void C_ccall f_9445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_fcall f_9226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_ccall f_9415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9229)
static void C_ccall f_9229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9369)
static void C_ccall f_9369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9303)
static void C_ccall f_9303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9291)
static void C_ccall f_9291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9266)
static void C_ccall f_9266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9108)
static void C_ccall f_9108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9081)
static void C_ccall f_9081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9087)
static void C_ccall f_9087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_fcall f_9751(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9758)
static void C_ccall f_9758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_fcall f_8716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8735)
static void C_fcall f_8735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8975)
static void C_ccall f_8975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9828)
static void C_fcall f_9828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9840)
static void C_fcall f_9840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9819)
static void C_ccall f_9819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8831)
static void C_ccall f_8831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_fcall f_8837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8852)
static void C_ccall f_8852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_fcall f_8855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8873)
static void C_fcall f_8873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8861)
static void C_ccall f_8861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_fcall f_8825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_fcall f_8815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_ccall f_8798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_fcall f_8705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8695)
static void C_fcall f_8695(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8689)
static void C_fcall f_8689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7918)
static void C_ccall f_7918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_fcall f_8538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_fcall f_8484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8499)
static void C_fcall f_8499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_fcall f_8493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8467)
static void C_ccall f_8467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_fcall f_8433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_fcall f_8389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_fcall f_8401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7961)
static void C_ccall f_7961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8290)
static void C_fcall f_8290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_fcall f_8358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_fcall f_8318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_fcall f_8254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_fcall f_8242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_fcall f_8227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_fcall f_8148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7998)
static void C_fcall f_7998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8019)
static void C_fcall f_8019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8040)
static void C_fcall f_8040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7979)
static void C_fcall f_7979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_fcall f_7935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_fcall f_7890(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7876)
static void C_fcall f_7876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7761)
static void C_ccall f_7761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7174)
static void C_fcall f_7174(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7196)
static void C_fcall f_7196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_fcall f_7632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7647)
static void C_fcall f_7647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_fcall f_7638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7512)
static void C_fcall f_7512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_fcall f_7545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_fcall f_7515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_ccall f_7466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_fcall f_7387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7767)
static void C_fcall f_7767(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7780)
static void C_fcall f_7780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_fcall f_7789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_fcall f_7870(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7167)
static C_word C_fcall f_7167(C_word t0);
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6946)
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6952)
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_fcall f_6930(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6805)
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_fcall f_6431(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6453)
static void C_fcall f_6453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_fcall f_6719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6326)
static void C_fcall f_6326(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_fcall f_6297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6303)
static void C_fcall f_6303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6217)
static void C_fcall f_6217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_fcall f_6220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static void C_fcall f_6223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6155)
static void C_ccall f_6155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_fcall f_5921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5978)
static void C_ccall f_5978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_fcall f_5198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_fcall f_4915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_fcall f_4779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_fcall f_4792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_fcall f_4721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2166)
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_fcall f_4618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_fcall f_2407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_fcall f_4355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_fcall f_4304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static C_word C_fcall f_4103(C_word *a,C_word t0);
C_noret_decl(f_4098)
static void C_fcall f_4098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static C_word C_fcall f_4061(C_word *a,C_word t0);
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_fcall f_3655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_fcall f_3552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_fcall f_3284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_fcall f_3080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_fcall f_2849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_fcall f_2687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_fcall f_2693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_fcall f_2707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_fcall f_2740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_fcall f_2697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_fcall f_2502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2022)
static void C_fcall f_2022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1979)
static C_word C_fcall f_1979(C_word t0,C_word t1);
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11059)
static void C_fcall trf_11059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11059(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11059(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10292)
static void C_fcall trf_10292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10292(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10292(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10958)
static void C_fcall trf_10958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10958(t0,t1);}

C_noret_decl(trf_10979)
static void C_fcall trf_10979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10979(t0,t1);}

C_noret_decl(trf_10930)
static void C_fcall trf_10930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10930(t0,t1);}

C_noret_decl(trf_10899)
static void C_fcall trf_10899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10899(t0,t1);}

C_noret_decl(trf_10890)
static void C_fcall trf_10890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10890(t0,t1);}

C_noret_decl(trf_10801)
static void C_fcall trf_10801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10801(t0,t1);}

C_noret_decl(trf_10675)
static void C_fcall trf_10675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10675(t0,t1);}

C_noret_decl(trf_10603)
static void C_fcall trf_10603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10603(t0,t1);}

C_noret_decl(trf_10495)
static void C_fcall trf_10495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10495(t0,t1);}

C_noret_decl(trf_10489)
static void C_fcall trf_10489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10489(t0,t1);}

C_noret_decl(trf_10205)
static void C_fcall trf_10205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10239)
static void C_fcall trf_10239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10239(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10239(t0,t1,t2,t3);}

C_noret_decl(trf_10249)
static void C_fcall trf_10249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10249(t0,t1);}

C_noret_decl(trf_11071)
static void C_fcall trf_11071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11071(t0,t1,t2);}

C_noret_decl(trf_11165)
static void C_fcall trf_11165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11165(t0,t1,t2);}

C_noret_decl(trf_11151)
static void C_fcall trf_11151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11151(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11151(t0,t1,t2);}

C_noret_decl(trf_11197)
static void C_fcall trf_11197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11197(t0,t1);}

C_noret_decl(trf_9739)
static void C_fcall trf_9739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9739(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9739(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9050)
static void C_fcall trf_9050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9050(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9050(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9069)
static void C_fcall trf_9069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9069(t0,t1);}

C_noret_decl(trf_9102)
static void C_fcall trf_9102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9102(t0,t1);}

C_noret_decl(trf_9618)
static void C_fcall trf_9618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9618(t0,t1);}

C_noret_decl(trf_9226)
static void C_fcall trf_9226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9226(t0,t1);}

C_noret_decl(trf_9751)
static void C_fcall trf_9751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9751(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9751(t0,t1,t2,t3);}

C_noret_decl(trf_8716)
static void C_fcall trf_8716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8716(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8716(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8735)
static void C_fcall trf_8735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8735(t0,t1);}

C_noret_decl(trf_9828)
static void C_fcall trf_9828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9828(t0,t1);}

C_noret_decl(trf_9840)
static void C_fcall trf_9840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9840(t0,t1);}

C_noret_decl(trf_8837)
static void C_fcall trf_8837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8837(t0,t1);}

C_noret_decl(trf_8855)
static void C_fcall trf_8855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8855(t0,t1);}

C_noret_decl(trf_8873)
static void C_fcall trf_8873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8873(t0,t1);}

C_noret_decl(trf_8825)
static void C_fcall trf_8825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8825(t0,t1);}

C_noret_decl(trf_8815)
static void C_fcall trf_8815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8815(t0,t1);}

C_noret_decl(trf_8705)
static void C_fcall trf_8705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8705(t0,t1,t2);}

C_noret_decl(trf_8695)
static void C_fcall trf_8695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8695(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8695(t0,t1,t2,t3);}

C_noret_decl(trf_8689)
static void C_fcall trf_8689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8689(t0,t1,t2,t3);}

C_noret_decl(trf_8538)
static void C_fcall trf_8538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8538(t0,t1);}

C_noret_decl(trf_8484)
static void C_fcall trf_8484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8484(t0,t1);}

C_noret_decl(trf_8499)
static void C_fcall trf_8499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8499(t0,t1);}

C_noret_decl(trf_8493)
static void C_fcall trf_8493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8493(t0,t1);}

C_noret_decl(trf_8433)
static void C_fcall trf_8433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8433(t0,t1);}

C_noret_decl(trf_8389)
static void C_fcall trf_8389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8389(t0,t1);}

C_noret_decl(trf_8401)
static void C_fcall trf_8401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8401(t0,t1);}

C_noret_decl(trf_8290)
static void C_fcall trf_8290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8290(t0,t1);}

C_noret_decl(trf_8358)
static void C_fcall trf_8358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8358(t0,t1);}

C_noret_decl(trf_8318)
static void C_fcall trf_8318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8318(t0,t1);}

C_noret_decl(trf_8254)
static void C_fcall trf_8254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8254(t0,t1);}

C_noret_decl(trf_8242)
static void C_fcall trf_8242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8242(t0,t1);}

C_noret_decl(trf_8227)
static void C_fcall trf_8227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8227(t0,t1);}

C_noret_decl(trf_8148)
static void C_fcall trf_8148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8148(t0,t1);}

C_noret_decl(trf_7998)
static void C_fcall trf_7998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7998(t0,t1);}

C_noret_decl(trf_8019)
static void C_fcall trf_8019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8019(t0,t1);}

C_noret_decl(trf_8040)
static void C_fcall trf_8040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8040(t0,t1);}

C_noret_decl(trf_7979)
static void C_fcall trf_7979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7979(t0,t1);}

C_noret_decl(trf_7935)
static void C_fcall trf_7935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7935(t0,t1);}

C_noret_decl(trf_7890)
static void C_fcall trf_7890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7890(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7890(t0,t1,t2,t3);}

C_noret_decl(trf_7876)
static void C_fcall trf_7876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7876(t0,t1,t2,t3);}

C_noret_decl(trf_7755)
static void C_fcall trf_7755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7755(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7755(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7174)
static void C_fcall trf_7174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7174(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7174(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7196)
static void C_fcall trf_7196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7196(t0,t1);}

C_noret_decl(trf_7632)
static void C_fcall trf_7632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7632(t0,t1);}

C_noret_decl(trf_7647)
static void C_fcall trf_7647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7647(t0,t1);}

C_noret_decl(trf_7638)
static void C_fcall trf_7638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7638(t0,t1);}

C_noret_decl(trf_7512)
static void C_fcall trf_7512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7512(t0,t1);}

C_noret_decl(trf_7545)
static void C_fcall trf_7545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7545(t0,t1);}

C_noret_decl(trf_7515)
static void C_fcall trf_7515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7515(t0,t1);}

C_noret_decl(trf_7387)
static void C_fcall trf_7387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7387(t0,t1,t2,t3);}

C_noret_decl(trf_7767)
static void C_fcall trf_7767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7767(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7767(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7780)
static void C_fcall trf_7780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7780(t0,t1);}

C_noret_decl(trf_7789)
static void C_fcall trf_7789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7789(t0,t1);}

C_noret_decl(trf_7870)
static void C_fcall trf_7870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7870(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7870(t0,t1,t2,t3);}

C_noret_decl(trf_6946)
static void C_fcall trf_6946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6946(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6946(t0,t1,t2,t3);}

C_noret_decl(trf_6952)
static void C_fcall trf_6952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6952(t0,t1,t2,t3);}

C_noret_decl(trf_6930)
static void C_fcall trf_6930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6930(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6930(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6805)
static void C_fcall trf_6805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6805(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6805(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6431)
static void C_fcall trf_6431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6431(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6431(t0,t1,t2,t3);}

C_noret_decl(trf_6453)
static void C_fcall trf_6453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6453(t0,t1);}

C_noret_decl(trf_6719)
static void C_fcall trf_6719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6719(t0,t1);}

C_noret_decl(trf_6559)
static void C_fcall trf_6559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6559(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6559(t0,t1,t2,t3);}

C_noret_decl(trf_6387)
static void C_fcall trf_6387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6387(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6387(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6326)
static void C_fcall trf_6326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6326(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6326(t0,t1,t2);}

C_noret_decl(trf_6297)
static void C_fcall trf_6297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6297(t0,t1,t2);}

C_noret_decl(trf_6303)
static void C_fcall trf_6303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6303(t0,t1,t2);}

C_noret_decl(trf_6217)
static void C_fcall trf_6217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6217(t0,t1);}

C_noret_decl(trf_6220)
static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6220(t0,t1);}

C_noret_decl(trf_6223)
static void C_fcall trf_6223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6223(t0,t1);}

C_noret_decl(trf_5921)
static void C_fcall trf_5921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5921(t0,t1);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4830(t0,t1);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5504(t0,t1);}

C_noret_decl(trf_5198)
static void C_fcall trf_5198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5198(t0,t1);}

C_noret_decl(trf_4915)
static void C_fcall trf_4915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4915(t0,t1);}

C_noret_decl(trf_4779)
static void C_fcall trf_4779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4779(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4779(t0,t1,t2,t3);}

C_noret_decl(trf_4792)
static void C_fcall trf_4792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4792(t0,t1);}

C_noret_decl(trf_4721)
static void C_fcall trf_4721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4721(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4721(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2166)
static void C_fcall trf_2166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2166(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2166(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4597(t0,t1);}

C_noret_decl(trf_4618)
static void C_fcall trf_4618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4618(t0,t1);}

C_noret_decl(trf_2407)
static void C_fcall trf_2407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2407(t0,t1);}

C_noret_decl(trf_4355)
static void C_fcall trf_4355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4355(t0,t1);}

C_noret_decl(trf_4304)
static void C_fcall trf_4304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4304(t0,t1);}

C_noret_decl(trf_4254)
static void C_fcall trf_4254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4254(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4254(t0,t1,t2,t3);}

C_noret_decl(trf_4098)
static void C_fcall trf_4098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4098(t0,t1);}

C_noret_decl(trf_3655)
static void C_fcall trf_3655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3655(t0,t1);}

C_noret_decl(trf_3552)
static void C_fcall trf_3552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3552(t0,t1);}

C_noret_decl(trf_3284)
static void C_fcall trf_3284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3284(t0,t1,t2);}

C_noret_decl(trf_3080)
static void C_fcall trf_3080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3080(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3080(t0,t1);}

C_noret_decl(trf_2849)
static void C_fcall trf_2849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2849(t0,t1);}

C_noret_decl(trf_2687)
static void C_fcall trf_2687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2687(t0,t1);}

C_noret_decl(trf_2693)
static void C_fcall trf_2693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2693(t0,t1);}

C_noret_decl(trf_2707)
static void C_fcall trf_2707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2707(t0,t1);}

C_noret_decl(trf_2740)
static void C_fcall trf_2740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2740(t0,t1);}

C_noret_decl(trf_2697)
static void C_fcall trf_2697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2697(t0,t1,t2);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2454(t0,t1,t2);}

C_noret_decl(trf_2502)
static void C_fcall trf_2502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2502(t0,t1);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2148(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2057(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2022)
static void C_fcall trf_2022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2022(t0,t1);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1991(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5612)){
C_save(t1);
C_rereclaim2(5612*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,580);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],28,"\010compilerprofiled-procedures");
lf[49]=C_h_intern(&lf[49],41,"\010compilerdefault-default-target-heap-size");
lf[50]=C_h_intern(&lf[50],42,"\010compilerdefault-default-target-stack-size");
lf[51]=C_h_intern(&lf[51],21,"\010compilerverbose-mode");
lf[52]=C_h_intern(&lf[52],30,"\010compileroriginal-program-size");
lf[53]=C_h_intern(&lf[53],29,"\010compilercurrent-program-size");
lf[54]=C_h_intern(&lf[54],31,"\010compilerline-number-database-2");
lf[55]=C_h_intern(&lf[55],28,"\010compilerimmutable-constants");
lf[56]=C_h_intern(&lf[56],43,"\010compilerrest-parameters-promoted-to-vector");
lf[57]=C_h_intern(&lf[57],21,"\010compilerinline-table");
lf[58]=C_h_intern(&lf[58],26,"\010compilerinline-table-used");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstant-table");
lf[60]=C_h_intern(&lf[60],23,"\010compilerconstants-used");
lf[61]=C_h_intern(&lf[61],26,"\010compilermutable-constants");
lf[62]=C_h_intern(&lf[62],30,"\010compilerbroken-constant-nodes");
lf[63]=C_h_intern(&lf[63],37,"\010compilerinline-substitutions-enabled");
lf[64]=C_h_intern(&lf[64],24,"\010compilerdirect-call-ids");
lf[65]=C_h_intern(&lf[65],23,"\010compilerfirst-analysis");
lf[66]=C_h_intern(&lf[66],27,"\010compilerforeign-type-table");
lf[67]=C_h_intern(&lf[67],26,"\010compilerforeign-variables");
lf[68]=C_h_intern(&lf[68],29,"\010compilerforeign-lambda-stubs");
lf[69]=C_h_intern(&lf[69],22,"foreign-callback-stubs");
lf[70]=C_h_intern(&lf[70],27,"\010compilerexternal-variables");
lf[71]=C_h_intern(&lf[71],26,"\010compilerloop-lambda-names");
lf[72]=C_h_intern(&lf[72],28,"\010compilerprofile-lambda-list");
lf[73]=C_h_intern(&lf[73],29,"\010compilerprofile-lambda-index");
lf[74]=C_h_intern(&lf[74],33,"\010compilerprofile-info-vector-name");
lf[75]=C_h_intern(&lf[75],28,"\010compilerexternal-to-pointer");
lf[76]=C_h_intern(&lf[76],34,"\010compilererror-is-extended-binding");
lf[77]=C_h_intern(&lf[77],24,"\010compilerreal-name-table");
lf[78]=C_h_intern(&lf[78],29,"\010compilerlocation-pointer-map");
lf[79]=C_h_intern(&lf[79],34,"\010compilerpending-canonicalizations");
lf[80]=C_h_intern(&lf[80],29,"\010compilerdefconstant-bindings");
lf[81]=C_h_intern(&lf[81],23,"\010compilercallback-names");
lf[82]=C_h_intern(&lf[82],23,"\010compilertoplevel-scope");
lf[83]=C_h_intern(&lf[83],27,"\010compilertoplevel-lambda-id");
lf[84]=C_h_intern(&lf[84],29,"\010compilercustom-declare-alist");
lf[85]=C_h_intern(&lf[85],25,"\010compilercsc-control-file");
lf[86]=C_h_intern(&lf[86],26,"\010compilerdata-declarations");
lf[87]=C_h_intern(&lf[87],20,"\010compilerinline-list");
lf[88]=C_h_intern(&lf[88],24,"\010compilernot-inline-list");
lf[89]=C_h_intern(&lf[89],26,"\010compilerfile-requirements");
lf[90]=C_h_intern(&lf[90],28,"\010compilerpostponed-initforms");
lf[91]=C_h_intern(&lf[91],25,"\010compilerunused-variables");
lf[92]=C_h_intern(&lf[92],29,"\010compilercompiler-macro-table");
lf[93]=C_h_intern(&lf[93],32,"\010compilercompiler-macros-enabled");
lf[94]=C_h_intern(&lf[94],29,"\010compilerliteral-rewrite-hook");
lf[95]=C_h_intern(&lf[95],28,"\010compilerinitialize-compiler");
lf[96]=C_h_intern(&lf[96],12,"vector-fill!");
lf[97]=C_h_intern(&lf[97],11,"make-vector");
lf[98]=C_h_intern(&lf[98],25,"\010compilermake-random-name");
lf[99]=C_h_intern(&lf[99],12,"profile-info");
lf[100]=C_h_intern(&lf[100],32,"\010compilercanonicalize-expression");
lf[101]=C_h_intern(&lf[101],23,"\010compilerset-real-name!");
lf[102]=C_h_intern(&lf[102],8,"for-each");
lf[103]=C_h_intern(&lf[103],5,"quote");
lf[104]=C_h_intern(&lf[104],15,"\004coreinline_ref");
lf[105]=C_h_intern(&lf[105],36,"\010compilerforeign-type-convert-result");
lf[106]=C_h_intern(&lf[106],30,"\010compilerfinish-foreign-result");
lf[107]=C_h_intern(&lf[107],27,"\010compilerfinal-foreign-type");
lf[108]=C_h_intern(&lf[108],19,"\004coreinline_loc_ref");
lf[109]=C_h_intern(&lf[109],18,"\003syshash-table-ref");
lf[110]=C_h_intern(&lf[110],21,"\003sysalias-global-hook");
lf[111]=C_h_intern(&lf[111],8,"keyword\077");
lf[112]=C_h_intern(&lf[112],12,"syntax-error");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[114]=C_h_intern(&lf[114],24,"\003syssyntax-error-culprit");
lf[115]=C_h_intern(&lf[115],2,"if");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[117]=C_h_intern(&lf[117],16,"\003syscheck-syntax");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[120]=C_h_intern(&lf[120],10,"\004corecheck");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[122]=C_h_intern(&lf[122],14,"\004coreimmutable");
lf[123]=C_h_intern(&lf[123],10,"alist-cons");
lf[124]=C_h_intern(&lf[124],6,"gensym");
lf[125]=C_h_intern(&lf[125],1,"c");
lf[126]=C_h_intern(&lf[126],6,"cadadr");
lf[127]=C_h_intern(&lf[127],14,"\004coreundefined");
lf[128]=C_h_intern(&lf[128],23,"\004corerequire-for-syntax");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[130]=C_h_intern(&lf[130],10,"lset-union");
lf[131]=C_h_intern(&lf[131],3,"eq\077");
lf[132]=C_h_intern(&lf[132],22,"\003syshash-table-update!");
lf[133]=C_h_intern(&lf[133],19,"syntax-requirements");
lf[134]=C_h_intern(&lf[134],11,"\003sysrequire");
lf[135]=C_h_intern(&lf[135],7,"\003sysmap");
lf[136]=C_h_intern(&lf[136],4,"eval");
lf[137]=C_h_intern(&lf[137],22,"\004corerequire-extension");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[139]=C_h_intern(&lf[139],22,"\003sysdo-the-right-thing");
lf[140]=C_h_intern(&lf[140],5,"begin");
lf[141]=C_h_intern(&lf[141],28,"\010compilerlookup-exports-file");
lf[142]=C_h_intern(&lf[142],7,"exports");
lf[143]=C_h_intern(&lf[143],19,"\003syshash-table-set!");
lf[144]=C_h_intern(&lf[144],12,"\003sysfor-each");
lf[145]=C_h_intern(&lf[145],25,"\003sysextension-information");
lf[146]=C_h_intern(&lf[146],25,"\010compilercompiler-warning");
lf[147]=C_h_intern(&lf[147],3,"ext");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[149]=C_h_intern(&lf[149],18,"\003sysfind-extension");
lf[150]=C_h_intern(&lf[150],31,"\003syscanonicalize-extension-path");
lf[151]=C_h_intern(&lf[151],17,"require-extension");
lf[152]=C_h_intern(&lf[152],8,"feature\077");
lf[153]=C_h_intern(&lf[153],5,"cadar");
lf[154]=C_h_intern(&lf[154],3,"let");
lf[155]=C_h_intern(&lf[155],21,"\003syscanonicalize-body");
lf[156]=C_h_intern(&lf[156],3,"map");
lf[157]=C_h_intern(&lf[157],6,"append");
lf[158]=C_h_intern(&lf[158],4,"cons");
lf[159]=C_h_intern(&lf[159],6,"unzip1");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[161]=C_h_intern(&lf[161],6,"lambda");
lf[162]=C_h_intern(&lf[162],20,"\004coreinternal-lambda");
lf[163]=C_h_intern(&lf[163],30,"\010compilerexpand-profile-lambda");
lf[164]=C_h_intern(&lf[164],37,"\010compilerprocess-lambda-documentation");
lf[165]=C_h_intern(&lf[165],6,"cddadr");
lf[166]=C_h_intern(&lf[166],5,"cdadr");
lf[167]=C_h_intern(&lf[167],5,"caadr");
lf[168]=C_h_intern(&lf[168],26,"\010compilerbuild-lambda-list");
lf[169]=C_h_intern(&lf[169],13,"\010compilerposq");
lf[170]=C_h_intern(&lf[170],30,"\010compilerdecompose-lambda-list");
lf[171]=C_h_intern(&lf[171],31,"\003sysexpand-extended-lambda-list");
lf[172]=C_h_intern(&lf[172],9,"\003syserror");
lf[173]=C_h_intern(&lf[173],25,"\003sysextended-lambda-list\077");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[175]=C_h_intern(&lf[175],17,"\004corenamed-lambda");
lf[176]=C_h_intern(&lf[176],16,"\004coreloop-lambda");
lf[177]=C_h_intern(&lf[177],4,"set!");
lf[178]=C_h_intern(&lf[178],9,"\004coreset!");
lf[179]=C_h_intern(&lf[179],18,"\004coreinline_update");
lf[180]=C_h_intern(&lf[180],27,"\010compilerforeign-type-check");
lf[181]=C_h_intern(&lf[181],38,"\010compilerforeign-type-convert-argument");
lf[182]=C_h_intern(&lf[182],22,"\004coreinline_loc_update");
lf[183]=C_h_intern(&lf[183],6,"syntax");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[185]=C_h_intern(&lf[185],15,"undefine-macro!");
lf[186]=C_h_intern(&lf[186],3,"var");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[188]=C_h_intern(&lf[188],7,"sprintf");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[191]=C_h_intern(&lf[191],6,"macro\077");
lf[192]=C_h_intern(&lf[192],11,"lset-adjoin");
lf[193]=C_h_intern(&lf[193],17,"\010compilerget-line");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[195]=C_h_intern(&lf[195],11,"\004coreinline");
lf[196]=C_h_intern(&lf[196],20,"\004coreinline_allocate");
lf[197]=C_h_intern(&lf[197],19,"\004corecompiletimetoo");
lf[198]=C_h_intern(&lf[198],23,"\004coreelaborationtimetoo");
lf[199]=C_h_intern(&lf[199],20,"\004corecompiletimeonly");
lf[200]=C_h_intern(&lf[200],24,"\004coreelaborationtimeonly");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[202]=C_h_intern(&lf[202],32,"\010compilercanonicalize-begin-body");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[205]=C_h_intern(&lf[205],19,"\004coreforeign-lambda");
lf[206]=C_h_intern(&lf[206],30,"\010compilerexpand-foreign-lambda");
lf[207]=C_h_intern(&lf[207],28,"\004coreforeign-callback-lambda");
lf[208]=C_h_intern(&lf[208],39,"\010compilerexpand-foreign-callback-lambda");
lf[209]=C_h_intern(&lf[209],20,"\004coreforeign-lambda*");
lf[210]=C_h_intern(&lf[210],31,"\010compilerexpand-foreign-lambda*");
lf[211]=C_h_intern(&lf[211],29,"\004coreforeign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],40,"\010compilerexpand-foreign-callback-lambda*");
lf[213]=C_h_intern(&lf[213],22,"\004coreforeign-primitive");
lf[214]=C_h_intern(&lf[214],33,"\010compilerexpand-foreign-primitive");
lf[215]=C_h_intern(&lf[215],28,"\004coredefine-foreign-variable");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[217]=C_h_intern(&lf[217],14,"symbol->string");
lf[218]=C_h_intern(&lf[218],24,"\004coredefine-foreign-type");
lf[219]=C_h_intern(&lf[219],10,"\003sysvalues");
lf[220]=C_h_intern(&lf[220],5,"cons*");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[222]=C_h_intern(&lf[222],29,"\004coredefine-external-variable");
lf[223]=C_h_intern(&lf[223],9,"c-pointer");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[225]=C_h_intern(&lf[225],13,"string-append");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[227]=C_h_intern(&lf[227],5,"fifth");
lf[228]=C_h_intern(&lf[228],17,"\004corelet-location");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[230]=C_h_intern(&lf[230],10,"\003sysappend");
lf[231]=C_h_intern(&lf[231],14,"\010compilerwords");
lf[232]=C_h_intern(&lf[232],46,"\010compilerestimate-foreign-result-location-size");
lf[233]=C_h_intern(&lf[233],18,"\004coredefine-inline");
lf[234]=C_h_intern(&lf[234],34,"\010compilerextract-mutable-constants");
lf[235]=C_h_intern(&lf[235],20,"\004coredefine-constant");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[238]=C_h_intern(&lf[238],29,"\010compilercollapsable-literal\077");
lf[239]=C_h_intern(&lf[239],4,"quit");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[241]=C_h_intern(&lf[241],22,"with-exception-handler");
lf[242]=C_h_intern(&lf[242],30,"call-with-current-continuation");
lf[243]=C_h_intern(&lf[243],12,"\004coredeclare");
lf[244]=C_h_intern(&lf[244],28,"\010compilerprocess-declaration");
lf[245]=C_h_intern(&lf[245],29,"\004coreforeign-callback-wrapper");
lf[246]=C_h_intern(&lf[246],8,"split-at");
lf[247]=C_h_intern(&lf[247],1,"r");
lf[248]=C_h_intern(&lf[248],17,"\003sysmake-c-string");
lf[249]=C_h_intern(&lf[249],3,"and");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[253]=C_h_intern(&lf[253],25,"nonnull-unsigned-c-string");
lf[254]=C_h_intern(&lf[254],16,"nonnull-c-string");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[256]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[257]=C_h_intern(&lf[257],18,"unsigned-c-string*");
lf[258]=C_h_intern(&lf[258],9,"c-string*");
lf[259]=C_h_intern(&lf[259],13,"c-string-list");
lf[260]=C_h_intern(&lf[260],14,"c-string-list*");
lf[261]=C_h_intern(&lf[261],8,"c-string");
lf[262]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[263]=C_h_intern(&lf[263],17,"unsigned-c-string");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[267]=C_h_intern(&lf[267],28,"\010compilervalid-c-identifier\077");
lf[268]=C_h_intern(&lf[268],8,"location");
lf[269]=C_h_intern(&lf[269],17,"\003sysmake-locative");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[271]=C_h_intern(&lf[271],13,"\004corecallunit");
lf[272]=C_h_intern(&lf[272],14,"\004coreprimitive");
lf[273]=C_h_intern(&lf[273],37,"\010compilerupdate-line-number-database!");
lf[274]=C_h_intern(&lf[274],23,"\003sysmacroexpand-1-local");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[277]=C_h_intern(&lf[277],31,"\010compileremit-syntax-trace-info");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[279]=C_h_intern(&lf[279],4,"list");
lf[280]=C_h_intern(&lf[280],1,"t");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[282]=C_h_intern(&lf[282],4,"caar");
lf[283]=C_h_intern(&lf[283],18,"\010compilerconstant\077");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[285]=C_h_intern(&lf[285],26,"\010compilerinternal-bindings");
lf[286]=C_h_intern(&lf[286],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[287]=C_h_intern(&lf[287],7,"reverse");
lf[288]=C_h_intern(&lf[288],22,"\003sysclear-trace-buffer");
lf[289]=C_h_intern(&lf[289],26,"\010compilerdebugging-chicken");
lf[290]=C_h_intern(&lf[290],12,"pretty-print");
lf[291]=C_h_intern(&lf[291],7,"newline");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[294]=C_h_intern(&lf[294],4,"uses");
lf[295]=C_h_intern(&lf[295],29,"\010compilerstring->c-identifier");
lf[296]=C_h_intern(&lf[296],18,"\010compilerstringify");
lf[297]=C_h_intern(&lf[297],17,"register-feature!");
lf[298]=C_h_intern(&lf[298],4,"unit");
lf[299]=C_h_intern(&lf[299],5,"usage");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-standard-bindings");
lf[302]=C_h_intern(&lf[302],34,"\010compilerdefault-extended-bindings");
lf[303]=C_h_intern(&lf[303],18,"usual-integrations");
lf[304]=C_h_intern(&lf[304],17,"lset-intersection");
lf[305]=C_h_intern(&lf[305],6,"fixnum");
lf[306]=C_h_intern(&lf[306],17,"fixnum-arithmetic");
lf[307]=C_h_intern(&lf[307],23,"\005matchset-error-control");
lf[308]=C_h_intern(&lf[308],12,"\000unspecified");
lf[309]=C_h_intern(&lf[309],4,"safe");
lf[310]=C_h_intern(&lf[310],18,"interrupts-enabled");
lf[311]=C_h_intern(&lf[311],18,"disable-interrupts");
lf[312]=C_h_intern(&lf[312],15,"disable-warning");
lf[313]=C_h_intern(&lf[313],26,"\010compilerdisabled-warnings");
lf[314]=C_h_intern(&lf[314],12,"safe-globals");
lf[315]=C_h_intern(&lf[315],38,"no-procedure-checks-for-usual-bindings");
lf[316]=C_h_intern(&lf[316],18,"bound-to-procedure");
lf[317]=C_h_intern(&lf[317],15,"foreign-declare");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[319]=C_h_intern(&lf[319],5,"every");
lf[320]=C_h_intern(&lf[320],7,"string\077");
lf[321]=C_h_intern(&lf[321],14,"custom-declare");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[323]=C_h_intern(&lf[323],35,"\010compilerprocess-custom-declaration");
lf[324]=C_h_intern(&lf[324],9,"c-options");
lf[325]=C_h_intern(&lf[325],31,"\010compileremit-control-file-item");
lf[326]=C_h_intern(&lf[326],12,"link-options");
lf[327]=C_h_intern(&lf[327],12,"post-process");
lf[328]=C_h_intern(&lf[328],17,"string-substitute");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[330]=C_h_intern(&lf[330],24,"pathname-strip-extension");
lf[331]=C_h_intern(&lf[331],5,"block");
lf[332]=C_h_intern(&lf[332],8,"separate");
lf[333]=C_h_intern(&lf[333],20,"keep-shadowed-macros");
lf[334]=C_h_intern(&lf[334],6,"unused");
lf[335]=C_h_intern(&lf[335],3,"not");
lf[336]=C_h_intern(&lf[336],15,"lset-difference");
lf[337]=C_h_intern(&lf[337],6,"inline");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[339]=C_h_intern(&lf[339],15,"run-time-macros");
lf[340]=C_h_intern(&lf[340],25,"\003sysenable-runtime-macros");
lf[341]=C_h_intern(&lf[341],12,"block-global");
lf[342]=C_h_intern(&lf[342],4,"hide");
lf[343]=C_h_intern(&lf[343],6,"export");
lf[344]=C_h_intern(&lf[344],12,"emit-exports");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[346]=C_h_intern(&lf[346],30,"emit-external-prototypes-first");
lf[347]=C_h_intern(&lf[347],11,"lambda-lift");
lf[348]=C_h_intern(&lf[348],12,"inline-limit");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[350]=C_h_intern(&lf[350],8,"constant");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[352]=C_h_intern(&lf[352],7,"symbol\077");
lf[353]=C_h_intern(&lf[353],6,"import");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[355]=C_h_intern(&lf[355],9,"partition");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[357]=C_h_intern(&lf[357],7,"profile");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[360]=C_h_intern(&lf[360],17,"make-foreign-stub");
lf[361]=C_h_intern(&lf[361],12,"foreign-stub");
lf[362]=C_h_intern(&lf[362],13,"foreign-stub\077");
lf[363]=C_h_intern(&lf[363],20,"foreign-stub-id-set!");
lf[364]=C_h_intern(&lf[364],14,"\003sysblock-set!");
lf[365]=C_h_intern(&lf[365],15,"foreign-stub-id");
lf[366]=C_h_intern(&lf[366],29,"foreign-stub-return-type-set!");
lf[367]=C_h_intern(&lf[367],24,"foreign-stub-return-type");
lf[368]=C_h_intern(&lf[368],22,"foreign-stub-name-set!");
lf[369]=C_h_intern(&lf[369],17,"foreign-stub-name");
lf[370]=C_h_intern(&lf[370],32,"foreign-stub-argument-types-set!");
lf[371]=C_h_intern(&lf[371],27,"foreign-stub-argument-types");
lf[372]=C_h_intern(&lf[372],32,"foreign-stub-argument-names-set!");
lf[373]=C_h_intern(&lf[373],27,"foreign-stub-argument-names");
lf[374]=C_h_intern(&lf[374],22,"foreign-stub-body-set!");
lf[375]=C_h_intern(&lf[375],17,"foreign-stub-body");
lf[376]=C_h_intern(&lf[376],21,"foreign-stub-cps-set!");
lf[377]=C_h_intern(&lf[377],16,"foreign-stub-cps");
lf[378]=C_h_intern(&lf[378],26,"foreign-stub-callback-set!");
lf[379]=C_h_intern(&lf[379],21,"foreign-stub-callback");
lf[380]=C_h_intern(&lf[380],28,"\010compilercreate-foreign-stub");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[382]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[384]=C_h_intern(&lf[384],37,"\010compilerestimate-foreign-result-size");
lf[385]=C_h_intern(&lf[385],4,"stub");
lf[386]=C_h_intern(&lf[386],1,"a");
lf[387]=C_h_intern(&lf[387],13,"list-tabulate");
lf[388]=C_h_intern(&lf[388],6,"second");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[391]=C_h_intern(&lf[391],4,"cadr");
lf[392]=C_h_intern(&lf[392],3,"car");
lf[393]=C_h_intern(&lf[393],4,"void");
lf[394]=C_h_intern(&lf[394],24,"\003sysline-number-database");
lf[395]=C_h_intern(&lf[395],31,"\010compilerperform-cps-conversion");
lf[396]=C_h_intern(&lf[396],4,"node");
lf[397]=C_h_intern(&lf[397],11,"\004corelambda");
lf[398]=C_h_intern(&lf[398],9,"\004corecall");
lf[399]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[400]=C_h_intern(&lf[400],16,"\010compilervarnode");
lf[401]=C_h_intern(&lf[401],1,"k");
lf[402]=C_h_intern(&lf[402],13,"\004corevariable");
lf[403]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[404]=C_h_intern(&lf[404],2,"f_");
lf[405]=C_h_intern(&lf[405],26,"make-foreign-callback-stub");
lf[406]=C_h_intern(&lf[406],13,"\010compilerbomb");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[408]=C_h_intern(&lf[408],15,"\004coreglobal-ref");
lf[409]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[410]=C_h_intern(&lf[410],6,"values");
lf[411]=C_h_intern(&lf[411],21,"foreign-callback-stub");
lf[412]=C_h_intern(&lf[412],22,"foreign-callback-stub\077");
lf[413]=C_h_intern(&lf[413],29,"foreign-callback-stub-id-set!");
lf[414]=C_h_intern(&lf[414],24,"foreign-callback-stub-id");
lf[415]=C_h_intern(&lf[415],31,"foreign-callback-stub-name-set!");
lf[416]=C_h_intern(&lf[416],26,"foreign-callback-stub-name");
lf[417]=C_h_intern(&lf[417],37,"foreign-callback-stub-qualifiers-set!");
lf[418]=C_h_intern(&lf[418],32,"foreign-callback-stub-qualifiers");
lf[419]=C_h_intern(&lf[419],38,"foreign-callback-stub-return-type-set!");
lf[420]=C_h_intern(&lf[420],33,"foreign-callback-stub-return-type");
lf[421]=C_h_intern(&lf[421],41,"foreign-callback-stub-argument-types-set!");
lf[422]=C_h_intern(&lf[422],36,"foreign-callback-stub-argument-types");
lf[423]=C_h_intern(&lf[423],27,"\010compileranalyze-expression");
lf[424]=C_h_intern(&lf[424],17,"\010compilercollect!");
lf[425]=C_h_intern(&lf[425],10,"references");
lf[426]=C_h_intern(&lf[426],13,"\010compilerput!");
lf[427]=C_h_intern(&lf[427],9,"undefined");
lf[428]=C_h_intern(&lf[428],7,"unknown");
lf[429]=C_h_intern(&lf[429],5,"value");
lf[430]=C_h_intern(&lf[430],12,"\010compilerget");
lf[431]=C_h_intern(&lf[431],4,"home");
lf[432]=C_h_intern(&lf[432],16,"\010compilerget-all");
lf[433]=C_h_intern(&lf[433],8,"captured");
lf[434]=C_h_intern(&lf[434],6,"global");
lf[435]=C_h_intern(&lf[435],12,"\004corerecurse");
lf[436]=C_h_intern(&lf[436],44,"\010compileroptimizable-rest-argument-operators");
lf[437]=C_h_intern(&lf[437],15,"\010compilercount!");
lf[438]=C_h_intern(&lf[438],16,"o-r/access-count");
lf[439]=C_h_intern(&lf[439],14,"rest-parameter");
lf[440]=C_h_intern(&lf[440],16,"standard-binding");
lf[441]=C_h_intern(&lf[441],10,"call-sites");
lf[442]=C_h_intern(&lf[442],18,"\004coredirect_lambda");
lf[443]=C_h_intern(&lf[443],6,"simple");
lf[444]=C_h_intern(&lf[444],28,"\010compilersimple-lambda-node\077");
lf[445]=C_h_intern(&lf[445],6,"vector");
lf[446]=C_h_intern(&lf[446],12,"contained-in");
lf[447]=C_h_intern(&lf[447],8,"contains");
lf[448]=C_h_intern(&lf[448],8,"assigned");
lf[449]=C_h_intern(&lf[449],16,"assigned-locally");
lf[450]=C_h_intern(&lf[450],15,"potential-value");
lf[451]=C_h_intern(&lf[451],5,"redef");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[454]=C_h_intern(&lf[454],16,"extended-binding");
lf[455]=C_h_intern(&lf[455],9,"\004coreproc");
lf[456]=C_h_intern(&lf[456],3,"any");
lf[457]=C_h_intern(&lf[457],9,"replacing");
lf[458]=C_h_intern(&lf[458],10,"replacable");
lf[459]=C_h_intern(&lf[459],9,"removable");
lf[460]=C_h_intern(&lf[460],37,"\010compilerexpression-has-side-effects\077");
lf[461]=C_h_intern(&lf[461],21,"has-unused-parameters");
lf[462]=C_h_intern(&lf[462],13,"explicit-rest");
lf[463]=C_h_intern(&lf[463],11,"collapsable");
lf[464]=C_h_intern(&lf[464],12,"contractable");
lf[465]=C_h_intern(&lf[465],9,"inlinable");
lf[466]=C_h_intern(&lf[466],28,"\010compilerscan-free-variables");
lf[467]=C_h_intern(&lf[467],5,"boxed");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[470]=C_h_intern(&lf[470],23,"\003syshash-table-for-each");
lf[471]=C_h_intern(&lf[471],18,"\010compilerdebugging");
lf[472]=C_h_intern(&lf[472],1,"p");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[475]=C_h_intern(&lf[475],37,"\010compilerinitialize-analysis-database");
lf[476]=C_h_intern(&lf[476],35,"\010compilerperform-closure-conversion");
lf[477]=C_h_intern(&lf[477],12,"customizable");
lf[478]=C_h_intern(&lf[478],20,"node-parameters-set!");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[480]=C_h_intern(&lf[480],28,"\010compilersource-info->string");
lf[481]=C_h_intern(&lf[481],8,"toplevel");
lf[482]=C_h_intern(&lf[482],18,"captured-variables");
lf[483]=C_h_intern(&lf[483],12,"closure-size");
lf[484]=C_h_intern(&lf[484],8,"\004coreref");
lf[485]=C_h_intern(&lf[485],10,"\004coreunbox");
lf[486]=C_h_intern(&lf[486],8,"\004corebox");
lf[487]=C_h_intern(&lf[487],12,"\004coreclosure");
lf[488]=C_h_intern(&lf[488],14,"\010compilerqnode");
lf[489]=C_h_intern(&lf[489],20,"\003sysmake-lambda-info");
lf[490]=C_h_intern(&lf[490],1,"\077");
lf[491]=C_h_intern(&lf[491],8,"->string");
lf[492]=C_h_intern(&lf[492],18,"\010compilerreal-name");
lf[493]=C_h_intern(&lf[493],10,"fold-right");
lf[494]=C_h_intern(&lf[494],10,"boxed-rest");
lf[495]=C_h_intern(&lf[495],6,"filter");
lf[496]=C_h_intern(&lf[496],16,"\004coreupdatebox_i");
lf[497]=C_h_intern(&lf[497],14,"\004coreupdatebox");
lf[498]=C_h_intern(&lf[498],13,"\004coreupdate_i");
lf[499]=C_h_intern(&lf[499],11,"\004coreupdate");
lf[500]=C_h_intern(&lf[500],19,"\010compilerimmediate\077");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[502]=C_h_intern(&lf[502],11,"\004coreswitch");
lf[503]=C_h_intern(&lf[503],9,"\004corecond");
lf[504]=C_h_intern(&lf[504],16,"\004coredirect_call");
lf[505]=C_h_intern(&lf[505],11,"\004corereturn");
lf[506]=C_h_intern(&lf[506],1,"o");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[508]=C_h_intern(&lf[508],16,"\003sysmake-promise");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[512]=C_h_intern(&lf[512],19,"make-lambda-literal");
lf[513]=C_h_intern(&lf[513],14,"lambda-literal");
lf[514]=C_h_intern(&lf[514],15,"lambda-literal\077");
lf[515]=C_h_intern(&lf[515],22,"lambda-literal-id-set!");
lf[516]=C_h_intern(&lf[516],17,"lambda-literal-id");
lf[517]=C_h_intern(&lf[517],28,"lambda-literal-external-set!");
lf[518]=C_h_intern(&lf[518],23,"lambda-literal-external");
lf[519]=C_h_intern(&lf[519],29,"lambda-literal-arguments-set!");
lf[520]=C_h_intern(&lf[520],24,"lambda-literal-arguments");
lf[521]=C_h_intern(&lf[521],34,"lambda-literal-argument-count-set!");
lf[522]=C_h_intern(&lf[522],29,"lambda-literal-argument-count");
lf[523]=C_h_intern(&lf[523],33,"lambda-literal-rest-argument-set!");
lf[524]=C_h_intern(&lf[524],28,"lambda-literal-rest-argument");
lf[525]=C_h_intern(&lf[525],31,"lambda-literal-temporaries-set!");
lf[526]=C_h_intern(&lf[526],26,"lambda-literal-temporaries");
lf[527]=C_h_intern(&lf[527],37,"lambda-literal-callee-signatures-set!");
lf[528]=C_h_intern(&lf[528],32,"lambda-literal-callee-signatures");
lf[529]=C_h_intern(&lf[529],29,"lambda-literal-allocated-set!");
lf[530]=C_h_intern(&lf[530],24,"lambda-literal-allocated");
lf[531]=C_h_intern(&lf[531],35,"lambda-literal-directly-called-set!");
lf[532]=C_h_intern(&lf[532],30,"lambda-literal-directly-called");
lf[533]=C_h_intern(&lf[533],32,"lambda-literal-closure-size-set!");
lf[534]=C_h_intern(&lf[534],27,"lambda-literal-closure-size");
lf[535]=C_h_intern(&lf[535],27,"lambda-literal-looping-set!");
lf[536]=C_h_intern(&lf[536],22,"lambda-literal-looping");
lf[537]=C_h_intern(&lf[537],32,"lambda-literal-customizable-set!");
lf[538]=C_h_intern(&lf[538],27,"lambda-literal-customizable");
lf[539]=C_h_intern(&lf[539],38,"lambda-literal-rest-argument-mode-set!");
lf[540]=C_h_intern(&lf[540],33,"lambda-literal-rest-argument-mode");
lf[541]=C_h_intern(&lf[541],24,"lambda-literal-body-set!");
lf[542]=C_h_intern(&lf[542],19,"lambda-literal-body");
lf[543]=C_h_intern(&lf[543],26,"lambda-literal-direct-set!");
lf[544]=C_h_intern(&lf[544],21,"lambda-literal-direct");
lf[545]=C_h_intern(&lf[545],36,"\010compilerprepare-for-code-generation");
lf[546]=C_h_intern(&lf[546],14,"\004coreimmediate");
lf[547]=C_h_intern(&lf[547],3,"fix");
lf[548]=C_h_intern(&lf[548],4,"bool");
lf[549]=C_h_intern(&lf[549],4,"char");
lf[550]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[551]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[553]=C_h_intern(&lf[553],36,"\010compilermake-block-variable-literal");
lf[554]=C_h_intern(&lf[554],36,"\010compilerblock-variable-literal-name");
lf[555]=C_h_intern(&lf[555],32,"\010compilerblock-variable-literal\077");
lf[556]=C_h_intern(&lf[556],10,"list-index");
lf[557]=C_h_intern(&lf[557],11,"\004coreglobal");
lf[558]=C_h_intern(&lf[558],10,"\004corelocal");
lf[559]=C_h_intern(&lf[559],12,"\004coreliteral");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[562]=C_h_intern(&lf[562],4,"none");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[565]=C_h_intern(&lf[565],7,"butlast");
lf[566]=C_h_intern(&lf[566],9,"\004corebind");
lf[567]=C_h_intern(&lf[567],13,"\004coresetlocal");
lf[568]=C_h_intern(&lf[568],16,"\004coresetglobal_i");
lf[569]=C_h_intern(&lf[569],14,"\004coresetglobal");
lf[570]=C_h_intern(&lf[570],1,"=");
lf[571]=C_h_intern(&lf[571],4,"type");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[574]=C_h_intern(&lf[574],20,"\010compilerbig-fixnum\077");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[579]=C_h_intern(&lf[579],14,"make-parameter");
C_register_lf2(lf,580,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1774 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1777 in k1774 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1780 in k1777 in k1774 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 317  make-parameter */
t4=C_retrieve(lf[579]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_set_block_item(lf[48],0,C_SCHEME_FALSE);
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t43=C_mutate((C_word*)lf[50]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_SCHEME_FALSE);
t46=C_set_block_item(lf[53],0,C_fix(0));
t47=C_set_block_item(lf[54],0,C_SCHEME_FALSE);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_END_OF_LIST);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_FALSE);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_END_OF_LIST);
t56=C_set_block_item(lf[63],0,C_SCHEME_FALSE);
t57=C_set_block_item(lf[64],0,C_SCHEME_END_OF_LIST);
t58=C_set_block_item(lf[65],0,C_SCHEME_TRUE);
t59=C_set_block_item(lf[66],0,C_SCHEME_FALSE);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_SCHEME_END_OF_LIST);
t66=C_set_block_item(lf[73],0,C_fix(0));
t67=C_set_block_item(lf[74],0,C_SCHEME_FALSE);
t68=C_set_block_item(lf[75],0,C_SCHEME_END_OF_LIST);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_FALSE);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_END_OF_LIST);
t75=C_set_block_item(lf[82],0,C_SCHEME_TRUE);
t76=C_set_block_item(lf[83],0,C_SCHEME_FALSE);
t77=C_set_block_item(lf[84],0,C_SCHEME_END_OF_LIST);
t78=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_END_OF_LIST);
t82=C_set_block_item(lf[89],0,C_SCHEME_FALSE);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_END_OF_LIST);
t85=C_set_block_item(lf[92],0,C_SCHEME_FALSE);
t86=C_set_block_item(lf[93],0,C_SCHEME_TRUE);
t87=C_set_block_item(lf[94],0,C_SCHEME_FALSE);
t88=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1905,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1976,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4776,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5739,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5745,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5751,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5760,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5769,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5778,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5787,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5796,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5805,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5814,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5823,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5832,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5841,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5850,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5859,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5868,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5877,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5886,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5895,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6049,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6094,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6139,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6176,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6213,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6294,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6384,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[405]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7059,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7065,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7071,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7080,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7089,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7098,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7107,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7116,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7134,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7143,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7152,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7161,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[476]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8686,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9920,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9926,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9932,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9941,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9950,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9959,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9968,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9977,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9986,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9995,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10004,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10013,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10022,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10031,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10040,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10049,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10058,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10067,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10076,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10085,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10094,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10103,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10112,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10121,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10130,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10139,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10148,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10157,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10166,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10175,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10184,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10193,tmp=(C_word)a,a+=2,tmp));
t163=C_mutate((C_word*)lf[545]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10202,tmp=(C_word)a,a+=2,tmp));
t164=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t164+1)))(2,t164,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10202,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11197,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11151,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11071,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10239,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10205,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10292,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11059,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11259,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2324 debugging */
t37=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[472],lf[578]);}

/* k11257 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11262,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2325 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10292(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11260 in k11257 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2326 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[577],((C_word*)((C_word*)t0)[2])[1]);}

/* k11263 in k11260 in k11257 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2327 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[576],((C_word*)((C_word*)t0)[2])[1]);}

/* k11266 in k11263 in k11260 in k11257 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2328 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11269 in k11266 in k11263 in k11260 in k11257 in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2329 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11059(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11059,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11065,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a11064 in mapwalk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11065,3,t0,t1,t2);}
/* compiler.scm: 2282 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10292(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10292,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[127]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[455]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[402]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2116 walk-var */
t16=((C_word*)t0)[16];
f_10205(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[408]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2119 walk-global */
t17=((C_word*)t0)[15];
f_10239(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[504]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10350,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2123 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_11059(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[196]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10370,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2127 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_11059(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[104]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10394,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10398,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2130 estimate-foreign-result-size */
t22=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[108]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10422,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10426,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2134 estimate-foreign-result-size */
t23=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[487]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10443,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2139 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11059(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[486]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10470,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2143 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[497]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10486,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2147 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11059(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[397]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[442]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[442]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10542,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2167 decompose-lambda-list */
t36=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[154]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[486],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10726,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2224 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[177]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10767,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2230 posq */
t30=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[398]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10887,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2254 lset-adjoin */
t31=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[570]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[435]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10930,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10930(t32,t31);}
else{
t30=t29;
f_10930(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10958,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11045,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 big-fixnum? */
t33=C_retrieve(lf[574]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10958(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11048,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2279 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_11059(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k11046 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11048,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k11043 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10958(t2,(C_word)C_i_not(t1));}

/* k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10958,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2266 immediate-literal */
f_11197(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[305],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11006,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2269 big-fixnum? */
t5=C_retrieve(lf[574]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10979(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11016,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2275 literal */
t4=((C_word*)t0)[2];
f_11071(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2276 immediate? */
t3=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k11020 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11022,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2276 immediate-literal */
f_11197(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11035,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2277 literal */
t3=((C_word*)t0)[2];
f_11071(t3,t2,((C_word*)t0)[3]);}}

/* k11033 in k11020 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11035,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* k11014 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11016,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* k11004 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10979(t2,(C_word)C_i_not(t1));}

/* k10977 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10979,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2270 compiler-warning */
t4=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[571],lf[572],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2274 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[573],((C_word*)t0)[4]);}}

/* k10980 in k10977 in k10956 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2273 immediate-literal */
f_11197(((C_word*)t0)[2],t2);}

/* k10928 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10930,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10933,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2261 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11059(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10931 in k10928 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10933,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10885 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10887,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10899,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10899(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10899(t6,C_SCHEME_FALSE);}}

/* k10897 in k10885 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10890(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10890(t2,C_SCHEME_UNDEFINED);}}

/* k10888 in k10885 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10890,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10893,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2257 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11059(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10891 in k10888 in k10885 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10893,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10767,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10783,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2232 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10292(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10856,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10856(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10856(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10856(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10868,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2238 get */
t8=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[440]);}}}}}

/* k10866 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10856(2,t2,t1);}
else{
/* compiler.scm: 2239 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454]);}}

/* k10854 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10856,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[103]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2241 immediate? */
t8=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10795(2,t6,C_SCHEME_FALSE);}}

/* k10793 in k10854 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10795,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[127],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10801(t6,t5);}
else{
t4=t3;
f_10801(t4,C_SCHEME_UNDEFINED);}}

/* k10799 in k10793 in k10854 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10801,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[568]:lf[569]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10825,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2247 blockvar-literal */
t4=((C_word*)t0)[4];
f_11165(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2248 literal */
t4=((C_word*)t0)[2];
f_11071(t4,t3,((C_word*)t0)[3]);}}

/* k10823 in k10799 in k10793 in k10854 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10825,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10817,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2250 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10292(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10815 in k10823 in k10799 in k10793 in k10854 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10781 in k10765 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10783,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[567],((C_word*)t0)[2],t2));}

/* k10724 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10730,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2225 append */
t5=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10736 in k10724 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10742,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2225 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10740 in k10736 in k10724 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2225 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10292(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10728 in k10724 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10730,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[566],((C_word*)t0)[2],t2));}

/* a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10542,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10663,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2173 get */
t8=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[425]);}
else{
t7=t6;
f_10549(2,t7,C_SCHEME_FALSE);}}

/* k10661 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10669,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2174 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}

/* k10667 in k10661 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10669,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10549(2,t2,lf[279]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2175 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[494]);}}

/* k10692 in k10667 in k10661 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10675(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10675(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10673 in k10667 in k10661 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10549(2,t2,lf[562]);}
else{
/* compiler.scm: 2176 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[439]);}}

/* k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10552,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10654,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[562],t1);
if(C_truep(t5)){
/* compiler.scm: 2180 butlast */
t6=C_retrieve(lf[565]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10654(2,t6,((C_word*)t0)[7]);}}

/* k10652 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2177 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10292(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10555,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[562]);
if(C_truep(t3)){
/* compiler.scm: 2185 debugging */
t4=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[506],lf[563],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[445]);
if(C_truep(t4)){
/* compiler.scm: 2186 debugging */
t5=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[506],lf[564],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10555(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2188 bomb */
t4=C_retrieve(lf[406]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[561],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10558(2,t4,C_SCHEME_UNDEFINED);}}

/* k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[64])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10596,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2200 get */
t7=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[483]);}

/* k10594 in k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10596,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10603(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10622,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2204 debugging */
t7=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[506],lf[560],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10603(t6,C_SCHEME_FALSE);}}}

/* k10620 in k10594 in k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10603(t2,C_SCHEME_TRUE);}

/* k10601 in k10594 in k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10603,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10607,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10607(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2206 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[477]);}}

/* k10605 in k10601 in k10594 in k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2190 make-lambda-literal */
t2=C_retrieve(lf[512]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10578 in k10556 in k10553 in k10550 in k10547 in a10541 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[396],lf[455],t9,C_SCHEME_END_OF_LIST));}

/* k10484 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10489,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10495,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[402],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10495(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10495(t6,C_SCHEME_FALSE);}}

/* k10493 in k10484 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10489(t4,lf[496]);}
else{
t2=((C_word*)t0)[3];
f_10489(t2,((C_word*)t0)[2]);}}

/* k10487 in k10484 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10489,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10468 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10470,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[486],((C_word*)t0)[2],t2));}

/* k10441 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10443,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t1));}

/* k10424 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2134 words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10420 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10422,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10415,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2135 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11059(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10413 in k10420 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10415,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10396 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2130 words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10392 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10368 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10370,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10348 in walk in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10350,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10205,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10209,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2084 posq */
t6=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10207 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10209,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[558],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2085 keyword? */
t3=C_retrieve(lf[111]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10222 in k10207 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10224,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10234,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2085 literal */
t3=((C_word*)t0)[5];
f_11071(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2086 walk-global */
t2=((C_word*)t0)[3];
f_10239(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10232 in k10222 in k10207 in walk-var in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10234,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10239(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10239,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10243(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10243(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10243(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10243(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2093 get */
t9=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[440]);}}}}}

/* k10282 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10243(2,t2,t1);}
else{
/* compiler.scm: 2094 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[454]);}}

/* k10241 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10249(t6,t5);}
else{
t4=t3;
f_10249(t4,C_SCHEME_UNDEFINED);}}

/* k10247 in k10241 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_10249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10249,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2100 blockvar-literal */
t3=((C_word*)t0)[3];
f_11165(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2101 literal */
t3=((C_word*)t0)[2];
f_11071(t3,t2,((C_word*)t0)[5]);}}

/* k10257 in k10247 in k10241 in walk-global in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10259,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11071,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2285 immediate? */
t4=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11076 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11078,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2285 immediate-literal */
f_11197(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11090,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11104,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2288 list-index */
t4=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_11090(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11130,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2294 append */
t5=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11140,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2296 posq */
t3=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11138 in k11076 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2297 new-literal */
t2=((C_word*)t0)[3];
f_11151(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11128 in k11076 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11130,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11103 in k11076 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11104,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11088 in k11076 in literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2290 new-literal */
t2=((C_word*)t0)[3];
f_11151(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11165,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11169,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11181,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2305 list-index */
t5=C_retrieve(lf[556]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11180 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11181,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11188,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2307 block-variable-literal? */
t4=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11186 in a11180 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11188,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2308 block-variable-literal-name */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11193 in k11186 in a11180 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11167 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11169,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2310 make-block-variable-literal */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11177 in k11167 in blockvar-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2310 new-literal */
t2=((C_word*)t0)[3];
f_11151(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11151(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11151,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11159,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2301 append */
t6=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11157 in new-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_11197(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11197,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[127],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11210,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11210(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11210(2,t6,(C_word)C_a_i_list(&a,2,lf[548],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11210(2,t6,(C_word)C_a_i_list(&a,2,lf[549],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11210(2,t6,lf[550]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11210(2,t6,lf[551]);}
else{
/* compiler.scm: 2321 bomb */
t6=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[552]);}}}}}}}

/* k11208 in immediate-literal in ##compiler#prepare-for-code-generation in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_11210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11210,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[546],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10193,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10184,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10175,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10166,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10157,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10148,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10139,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10130,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10121,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10112,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10103,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10094,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10085,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10076,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10067,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10058,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10049,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10040,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10031,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10022,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10013,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10004,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9995,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9986,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9977,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9968,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9959,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9950,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9941,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[513]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9932,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[513]);
/* compiler.scm: 2054 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9926,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[513]));}

/* make-lambda-literal in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9920,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[513],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8686,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8689,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8695,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8705,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8716,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9751,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9050,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9739,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9887,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2042 debugging */
t22=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[472],lf[511]);}

/* k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2043 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8716(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2044 debugging */
t3=C_retrieve(lf[471]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[506],lf[510],((C_word*)((C_word*)t0)[2])[1]);}

/* k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2045 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[509]);}

/* k9894 in k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2046 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9050(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9897 in k9894 in k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9902,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9902(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9912,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9914,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2048 ##sys#make-promise */
t6=*((C_word*)lf[508]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9913 in k9897 in k9894 in k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9914,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[64])));}

/* k9910 in k9897 in k9894 in k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2048 debugging */
t2=C_retrieve(lf[471]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[506],lf[507],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9900 in k9897 in k9894 in k9891 in k9888 in k9885 in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9739(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9739,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9745,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9744 in maptransform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9745,3,t0,t1,t2);}
/* compiler.scm: 2014 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9050(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9050,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_9069(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[127]);
if(C_truep(t13)){
t14=t12;
f_9069(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[455]);
t15=t12;
f_9069(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[408])));}}}

/* k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9069,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[402]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9081,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1889 ref-var */
f_9751(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[115]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9102(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[398]);
if(C_truep(t5)){
t6=t4;
f_9102(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t6)){
t7=t4;
f_9102(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
if(C_truep(t7)){
t8=t4;
f_9102(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[271]);
if(C_truep(t8)){
t9=t4;
f_9102(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[104]);
if(C_truep(t9)){
t10=t4;
f_9102(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[179]);
if(C_truep(t10)){
t11=t4;
f_9102(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t11)){
t12=t4;
f_9102(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t12)){
t13=t4;
f_9102(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[504]);
if(C_truep(t13)){
t14=t4;
f_9102(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[435]);
if(C_truep(t14)){
t15=t4;
f_9102(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[505]);
if(C_truep(t15)){
t16=t4;
f_9102(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[108]);
t17=t4;
f_9102(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[182])));}}}}}}}}}}}}}}}

/* k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9102,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9108,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1897 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9739(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[154]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1901 test */
t5=((C_word*)t0)[4];
f_8689(t5,t4,t3,lf[467]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[397]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[442]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1917 decompose-lambda-list */
t7=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[177]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9469,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[103],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1977 immediate? */
t13=C_retrieve(lf[500]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9469(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[272]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[396],lf[455],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9618,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9625,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9629,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 2008 ##sys#make-lambda-info */
t16=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9618(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 2011 bomb */
t7=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[501]);}}}}}}

/* k9627 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2008 qnode */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9623 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9625,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9618(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9616 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9618,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t2));}

/* k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9469,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[127],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1979 posq */
t4=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9475,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9484,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 test */
t3=((C_word*)t0)[3];
f_8689(t3,t2,((C_word*)t0)[2],lf[467]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1993 test */
t3=((C_word*)t0)[3];
f_8689(t3,t2,((C_word*)t0)[2],lf[467]);}}

/* k9543 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9545,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1997 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9575,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2001 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9050(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9573 in k9543 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9575,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[177],((C_word*)t0)[2],t2));}

/* k9556 in k9543 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9562,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1998 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9050(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9560 in k9556 in k9543 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9562,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9482 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9484,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1985 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1991 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9529 in k9482 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9535,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1992 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9050(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9533 in k9529 in k9482 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9535,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9509 in k9482 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9511,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[484],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9507,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1986 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9050(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9505 in k9509 in k9482 in k9473 in k9467 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9507,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9198,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1920 filter */
t7=C_retrieve(lf[495]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9446 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9447,3,t0,t1,t2);}
/* compiler.scm: 1920 test */
t3=((C_word*)t0)[2];
f_8689(t3,t1,t2,lf[467]);}

/* k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9445,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[124]),t1);}

/* k9443 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1921 map */
t2=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[158]+1),((C_word*)t0)[2],t1);}

/* k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1922 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[125]);}

/* k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9208,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[481]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1924 test */
t4=((C_word*)t0)[2];
f_8689(t4,t3,t2,lf[482]);}

/* k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9214,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1925 test */
t4=((C_word*)t0)[2];
f_8689(t4,t3,((C_word*)t0)[17],lf[483]);}

/* k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9220,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9226(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9226(t4,C_SCHEME_FALSE);}}

/* k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9226,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9229,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1931 test */
t4=((C_word*)t0)[2];
f_8689(t4,t3,((C_word*)t0)[6],lf[467]);}
else{
t3=t2;
f_9229(2,t3,C_SCHEME_FALSE);}}

/* k9410 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9412,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1932 test */
t3=((C_word*)t0)[2];
f_8689(t3,t2,((C_word*)t0)[6],lf[439]);}
else{
t2=((C_word*)t0)[4];
f_9229(2,t2,C_SCHEME_FALSE);}}

/* k9413 in k9410 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1933 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[494],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9229(2,t2,C_SCHEME_FALSE);}}

/* k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9229,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9369,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9373,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9387 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9388,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9371 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1943 build-lambda-list */
t4=C_retrieve(lf[168]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9303,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1952 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9050(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9306,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9314,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9328,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1957 unzip1 */
t5=C_retrieve(lf[159]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9306(2,t3,t1);}}

/* k9326 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9332,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9334,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9333 in k9326 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9345,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1958 varnode */
t5=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9343 in a9333 in k9326 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[486],C_SCHEME_END_OF_LIST,t2));}

/* k9330 in k9326 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1954 fold-right */
t2=C_retrieve(lf[493]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9313 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9314,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[396],lf[154],t5,t6));}

/* k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9306,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9290 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9291,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1961 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9297 in a9290 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1961 ref-var */
f_9751(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9266,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9270,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9274,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9282,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1969 real-name */
t7=C_retrieve(lf[492]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9255(2,t3,t1);}}

/* k9280 in k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9282,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[490]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1969 ->string */
t5=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9272 in k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1968 ##sys#make-lambda-info */
t2=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9268 in k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1967 qnode */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9264 in k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9266,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1964 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9253 in k9250 in k9304 in k9301 in k9367 in k9227 in k9224 in k9218 in k9212 in k9206 in k9203 in k9200 in a9197 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[487],((C_word*)t0)[2],t2));}

/* k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1902 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9124 in k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9126,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9142,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1906 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_9050(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1913 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9739(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9176 in k9124 in k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9178,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t1));}

/* k9140 in k9124 in k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9142,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1909 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9169 in k9140 in k9124 in k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[486],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1910 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9050(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9161 in k9169 in k9140 in k9124 in k9121 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t4));}

/* k9106 in k9100 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9108,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9079 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9087,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1890 test */
t3=((C_word*)t0)[3];
f_8689(t3,t2,((C_word*)t0)[2],lf[467]);}

/* k9085 in k9079 in k9067 in transform in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9087,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[485],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9751(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9751,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9758,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2018 posq */
t9=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9756 in ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9758,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9774,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2021 varnode */
t5=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9772 in k9756 in ref-var in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[484],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8716,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8735(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[402]);
if(C_truep(t13)){
t14=t12;
f_8735(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[127]);
if(C_truep(t14)){
t15=t12;
f_8735(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[455]);
if(C_truep(t15)){
t16=t12;
f_8735(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[272]);
t17=t12;
f_8735(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[408])));}}}}}

/* k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8735,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[154]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8756,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1826 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[398]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[402],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8815,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8825,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8939,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1842 test */
t19=((C_word*)t0)[3];
f_8689(t19,t18,t16,lf[428]);}
else{
t15=t14;
f_8825(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8815(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[397]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[442]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1866 decompose-lambda-list */
t8=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9014,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a9013 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9014,3,t0,t1,t2);}
/* compiler.scm: 1876 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8716(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8975,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[481]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9790,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9790(3,t14,t10,t6);}

/* walk in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9790,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[402]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9819,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2033 lset-adjoin */
t12=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[131]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[103]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9828(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[127]);
if(C_truep(t12)){
t13=t11;
f_9828(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[272]);
if(C_truep(t13)){
t14=t11;
f_9828(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[455]);
if(C_truep(t14)){
t15=t11;
f_9828(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[104]);
t16=t11;
f_9828(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[408])));}}}}}}

/* k9826 in walk in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9828,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9840,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9854,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2037 lset-adjoin */
t6=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[131]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9840(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9852 in k9826 in walk in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9840(t3,t2);}

/* k9838 in k9826 in walk in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_9840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2038 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9790(3,t3,((C_word*)t0)[2],t2);}

/* k9817 in walk in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9786 in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9788,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8988,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1872 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[483],t3);}

/* k8986 in k9786 in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1873 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[482],((C_word*)t0)[2]);}

/* k8989 in k8986 in k9786 in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9002,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1874 append */
t4=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9000 in k8989 in k8986 in k9786 in a8974 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_9002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1874 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8716(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8937 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8831(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1842 test */
t2=((C_word*)t0)[3];
f_8689(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[429]);}}

/* k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8837(t4,(C_word)C_eqp(lf[397],t3));}
else{
t3=t2;
f_8837(t3,C_SCHEME_FALSE);}}

/* k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8837,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1847 test */
t6=((C_word*)t0)[2];
f_8689(t6,t5,((C_word*)t0)[6],lf[425]);}
else{
t2=((C_word*)t0)[8];
f_8825(t2,C_SCHEME_END_OF_LIST);}}

/* k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8852,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1848 test */
t3=((C_word*)t0)[2];
f_8689(t3,t2,((C_word*)t0)[7],lf[441]);}

/* k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8855(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8855(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8855(t3,C_SCHEME_FALSE);}}

/* k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8855,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8858,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8873,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8873(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8873(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8873(t4,C_SCHEME_FALSE);}}

/* k8871 in k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8873,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8880,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1856 source-info->string */
t3=C_retrieve(lf[480]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8858(2,t2,C_SCHEME_UNDEFINED);}}

/* k8878 in k8871 in k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1854 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[479],t1);}

/* k8856 in k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1857 register-direct-call! */
t3=((C_word*)t0)[2];
f_8705(t3,t2,((C_word*)t0)[6]);}

/* k8859 in k8856 in k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1858 register-customizable! */
t3=((C_word*)t0)[3];
f_8695(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8864(2,t3,C_SCHEME_UNDEFINED);}}

/* k8862 in k8859 in k8856 in k8853 in k8850 in k8847 in k8835 in k8829 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8864,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8825(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8823 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8825,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8815(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8813 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8815,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1835 node-parameters-set! */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8796 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8803,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8802 in k8796 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8803,3,t0,t1,t2);}
/* compiler.scm: 1863 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8716(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8755 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8756,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8772 in a8755 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8773,3,t0,t1,t2);}
/* compiler.scm: 1827 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8716(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8758 in a8755 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1828 append */
t4=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8769 in k8758 in a8755 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1828 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8716(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8745 in k8733 in gather in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8746,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1826 split-at */
t3=C_retrieve(lf[246]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8705,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1813 lset-adjoin */
t6=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[131]+1),C_retrieve(lf[64]),t2);}

/* k8712 in register-direct-call! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[64]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8695(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8695,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8700,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1808 lset-adjoin */
t5=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[131]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8698 in register-customizable! in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1809 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[477],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8689(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8689,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1805 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7165,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1426 make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7165,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7167,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7174,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7755,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7876,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7890,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7915,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1596 initialize-analysis-database */
t18=C_retrieve(lf[475]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1599 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[474]);}

/* k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7918,2,t0,t1);}
t2=C_set_block_item(lf[53],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1601 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7174(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1604 debugging */
t3=C_retrieve(lf[471]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[472],lf[473]);}

/* k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1605 ##sys#hash-table-for-each */
t4=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7938,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7942,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8573,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8572 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8573,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[428]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[433]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[450]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[441]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[449]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[434]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[429]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[438]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[439]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7942,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[65]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8538(t10,(C_word)C_eqp(lf[397],t9));}
else{
t7=t6;
f_8538(t7,C_SCHEME_FALSE);}}

/* k8536 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1651 set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7949(2,t2,C_SCHEME_UNDEFINED);}}

/* k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[91]));
t5=t3;
f_8484(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8484(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8484(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8484(t4,C_SCHEME_FALSE);}}

/* k8482 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8484,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1660 compiler-warning */
t3=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[186],lf[469],((C_word*)t0)[3]);}
else{
t3=t2;
f_8487(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7952(2,t2,C_SCHEME_UNDEFINED);}}

/* k8485 in k8482 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8499,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8499(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8499(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8499(t5,C_SCHEME_FALSE);}}}

/* k8497 in k8485 in k8482 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[61]));
t3=((C_word*)t0)[2];
f_8493(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8493(t2,C_SCHEME_FALSE);}}

/* k8491 in k8485 in k8482 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1664 compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[186],lf[468],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7952(2,t2,C_SCHEME_UNDEFINED);}}

/* k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1668 quick-put! */
f_7876(t2,((C_word*)t0)[8],lf[467],C_SCHEME_TRUE);}
else{
t4=t2;
f_7955(2,t4,C_SCHEME_UNDEFINED);}}

/* k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[397],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8427(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8459,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8467,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1677 scan-free-variables */
t13=C_retrieve(lf[466]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8427(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7958(2,t3,C_SCHEME_UNDEFINED);}}

/* k8465 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1677 every */
t2=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8458 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8459,3,t0,t1,t2);}
/* compiler.scm: 1677 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[434]);}

/* k8425 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8427,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8433(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8433(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7958(2,t2,C_SCHEME_UNDEFINED);}}

/* k8431 in k8425 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1679 quick-put! */
f_7876(((C_word*)t0)[3],((C_word*)t0)[2],lf[464],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1680 quick-put! */
f_7876(((C_word*)t0)[3],((C_word*)t0)[2],lf[465],C_SCHEME_TRUE);}}

/* k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8389(t6,(C_word)C_eqp(lf[103],t5));}
else{
t4=t3;
f_8389(t4,C_SCHEME_FALSE);}}

/* k8387 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8389,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1688 collapsable-literal? */
t6=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7961(2,t2,C_SCHEME_UNDEFINED);}}

/* k8396 in k8387 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8401(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8401(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8399 in k8396 in k8387 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1690 quick-put! */
f_7876(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7961(2,t2,C_SCHEME_UNDEFINED);}}

/* k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7964,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8290,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[397],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8290(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8290(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7964(2,t3,C_SCHEME_UNDEFINED);}}

/* k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8290,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1704 decompose-lambda-list */
t6=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7964(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7964(2,t2,C_SCHEME_UNDEFINED);}}

/* a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8308,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8312(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8351,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8350 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8351,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8358,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8376,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1710 get */
t5=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[425]);}

/* k8374 in a8350 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8376,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8358(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8372,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1711 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}}

/* k8370 in k8374 in a8350 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8358(t2,(C_word)C_i_not(t1));}

/* k8356 in a8350 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8358,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8361,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1712 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[334],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8359 in k8356 in a8350 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8310 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[81]));
t4=t2;
f_8318(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8318(t3,C_SCHEME_FALSE);}}

/* k8316 in k8310 in a8307 in k8288 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8318,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1718 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[461],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1721 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[462],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8227(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8242,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[402],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8254(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8268,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1729 get */
t15=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[434]);}}
else{
t6=t5;
f_8242(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8227(t5,C_SCHEME_FALSE);}}}

/* k8266 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8254(t2,(C_word)C_i_not(t1));}

/* k8252 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8254,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1730 expression-has-side-effects? */
t3=C_retrieve(lf[460]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8242(t2,C_SCHEME_FALSE);}}

/* k8259 in k8252 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8242(t2,(C_word)C_i_not(t1));}

/* k8240 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8227(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8225 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1732 quick-put! */
f_7876(((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7967(2,t2,C_SCHEME_UNDEFINED);}}

/* k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[402],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8139,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1744 get */
t11=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[425]);}
else{
t7=t2;
f_7970(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7970(2,t4,C_SCHEME_UNDEFINED);}}

/* k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1745 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[428]);}

/* k8211 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8145(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1745 get */
t2=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[429]);}}

/* k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8148(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1746 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[433]);}}

/* k8201 in k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8203,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8148(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8148(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1750 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[448]);}}
else{
t4=((C_word*)t0)[6];
f_8148(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8148(t2,C_SCHEME_FALSE);}}}

/* k8193 in k8201 in k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8195,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8148(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8148(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1751 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[434]);}}}

/* k8189 in k8193 in k8201 in k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8148(t2,(C_word)C_i_not(t1));}

/* k8146 in k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1752 quick-put! */
f_7876(t2,((C_word*)t0)[2],lf[458],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7970(2,t2,C_SCHEME_UNDEFINED);}}

/* k8149 in k8146 in k8143 in k8137 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1753 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}

/* k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7973,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7998(t6,(C_word)C_eqp(lf[397],t5));}
else{
t4=t3;
f_7998(t4,C_SCHEME_FALSE);}}

/* k7996 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7973(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8019,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_8019(t11,(C_word)C_eqp(lf[398],t10));}
else{
t10=t8;
f_8019(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_8019(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7973(2,t2,C_SCHEME_UNDEFINED);}}

/* k8017 in k7996 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8019,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[402],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[402],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_8040(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_8040(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_8040(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7973(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7973(2,t2,C_SCHEME_UNDEFINED);}}

/* k8038 in k8017 in k7996 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_8040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8040,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8046,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1773 quick-put! */
f_7876(t4,((C_word*)t0)[2],lf[458],t3);}
else{
t2=((C_word*)t0)[5];
f_7973(2,t2,C_SCHEME_UNDEFINED);}}

/* k8044 in k8038 in k8017 in k7996 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1774 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}

/* k7971 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7979,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7979(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7979(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7979(t3,C_SCHEME_FALSE);}}

/* k7977 in k7971 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7979,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1784 lset-adjoin */
t3=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[131]+1),C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7981 in k7977 in k7971 in k7968 in k7965 in k7962 in k7959 in k7956 in k7953 in k7950 in k7947 in k7940 in a7937 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
/* compiler.scm: 1785 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[439],lf[445]);}

/* k7926 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1791 lset-difference */
t3=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[131]+1),C_retrieve(lf[56]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7930 in k7926 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7932,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[52]))){
t4=t3;
f_7935(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[52]+1,C_retrieve(lf[53]));
t5=t3;
f_7935(t5,t4);}}

/* k7933 in k7930 in k7926 in k7923 in k7920 in k7916 in k7913 in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7890(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7890,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7900,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1591 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[447]);}}

/* k7898 in contains? in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7900,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1593 any */
t3=C_retrieve(lf[456]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7907 in k7898 in contains? in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7908,3,t0,t1,t2);}
/* compiler.scm: 1593 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7890(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7876(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7876,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7884,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1586 alist-cons */
t7=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7882 in quick-put! in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7755,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7761,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7760 in walkeach in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7761,3,t0,t1,t2);}
/* compiler.scm: 1560 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7174(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7174(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7174,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7167(C_fix(1));
t13=(C_word)C_eqp(t11,lf[103]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7196(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[127]);
t16=t14;
f_7196(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[455])));}}

/* k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7196(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7196,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[402]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1442 ref */
t5=((C_word*)t0)[8];
f_7870(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[408]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7251,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1450 ref */
t6=((C_word*)t0)[8];
f_7870(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[435]));
if(C_truep(t5)){
t6=f_7167(C_fix(1));
/* compiler.scm: 1456 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7755(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[398]);
if(C_truep(t6)){
t7=f_7167(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[402],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7310,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1463 collect! */
t16=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[441],t15);}
else{
t12=t9;
f_7287(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[154]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1477 append */
t9=*((C_word*)lf[157]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[161]);
if(C_truep(t8)){
t9=f_7167(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1490 decompose-lambda-list */
t12=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[397]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[442]));
if(C_truep(t10)){
t11=f_7167(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1503 decompose-lambda-list */
t14=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[177]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[65]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7678,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1534 get */
t17=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[440]);}
else{
t15=t14;
f_7603(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[272]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[195]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1553 ##sys#hash-table-ref */
t17=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[77]),t14);}
else{
t17=t16;
f_7717(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7717(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7717(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1557 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7755(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7715 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1554 set-real-name! */
t2=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7711(2,t2,C_SCHEME_UNDEFINED);}}

/* k7709 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1555 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7755(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7682 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7684,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1535 compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[451],lf[452],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1536 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[454]);}}

/* k7691 in k7682 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1537 compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[451],lf[453],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7678(2,t2,C_SCHEME_UNDEFINED);}}

/* k7676 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1538 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[450],((C_word*)t0)[2]);}

/* k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7632(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7632(t5,(C_word)C_i_not(t4));}}

/* k7630 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7632,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7167(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[65]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7647(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7647(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7647(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7638(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7606(2,t2,C_SCHEME_UNDEFINED);}}

/* k7645 in k7630 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7647,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1544 lset-adjoin */
t3=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[131]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7638(t2,C_SCHEME_UNDEFINED);}}

/* k7649 in k7645 in k7630 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7638(t3,t2);}

/* k7636 in k7630 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1545 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}

/* k7604 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7609,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1546 append */
t4=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7627 in k7604 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1546 assign */
t2=((C_word*)t0)[6];
f_7767(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7607 in k7604 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[82]))){
t3=t2;
f_7612(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1547 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[449],C_SCHEME_TRUE);}}

/* k7610 in k7607 in k7604 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1548 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448],C_SCHEME_TRUE);}

/* k7613 in k7610 in k7607 in k7604 in k7601 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1549 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7174(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7493,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[53]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7500,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7585,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1509 collect! */
t9=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],t5);}
else{
t8=t7;
f_7500(2,t8,C_SCHEME_UNDEFINED);}}

/* k7583 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1510 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[446],((C_word*)t0)[2]);}

/* k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7574 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7575,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7579,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1513 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[431],((C_word*)t0)[2]);}

/* k7577 in a7574 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1514 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[428],C_SCHEME_TRUE);}

/* k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[56]));
t4=(C_truep(t3)?lf[445]:lf[279]);
/* compiler.scm: 1517 put! */
t5=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[439],t4);}
else{
t3=t2;
f_7506(2,t3,C_SCHEME_UNDEFINED);}}

/* k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1521 simple-lambda-node? */
t4=C_retrieve(lf[444]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7558 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1521 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[443],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7509(2,t2,C_SCHEME_UNDEFINED);}}

/* k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
t2=C_retrieve(lf[82]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[83]))){
t4=t3;
f_7512(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[83]+1,((C_word*)t0)[5]);
t5=t3;
f_7512(t5,t4);}}

/* k7510 in k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7512,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7545,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[83]),((C_word*)t0)[5]);
t5=t3;
f_7545(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7545(t4,C_SCHEME_FALSE);}}

/* k7543 in k7510 in k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7515(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7515(t2,C_SCHEME_UNDEFINED);}}

/* k7513 in k7510 in k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1526 append */
t5=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7540 in k7513 in k7510 in k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1526 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7174(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7516 in k7513 in k7510 in k7507 in k7504 in k7501 in k7498 in a7492 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[53]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7448 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7449,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7467 in a7448 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7468,3,t0,t1,t2);}
/* compiler.scm: 1494 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[428],C_SCHEME_TRUE);}

/* k7451 in a7448 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7453,2,t0,t1);}
t2=C_retrieve(lf[82]);
t3=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1498 append */
t7=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7464 in k7451 in a7448 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1498 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7174(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7455 in k7451 in a7448 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7382,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7387,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7387(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7387,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1480 append */
t6=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1483 put! */
t7=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[431],((C_word*)t0)[8]);}}

/* k7412 in loop in k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7417,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1484 assign */
t3=((C_word*)t0)[4];
f_7767(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7415 in k7412 in loop in k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7420,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1485 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7174(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7418 in k7415 in k7412 in loop in k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1486 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7387(t4,((C_word*)t0)[2],t2,t3);}

/* k7403 in loop in k7380 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1480 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7174(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7308 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1465 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[440]);}

/* k7356 in k7308 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7358,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[436])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7321,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7287(2,t3,C_SCHEME_UNDEFINED);}}

/* a7320 in k7356 in k7308 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7321,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[402],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7340,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1471 get */
t10=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[439]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7338 in a7320 in k7356 in k7308 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1471 count! */
t2=C_retrieve(lf[437]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[438]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7285 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1473 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7174(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7288 in k7285 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1474 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7755(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7249 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7167(C_fix(1));
/* compiler.scm: 1452 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}

/* k7206 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7167(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1445 put! */
t3=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[433],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7239,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1446 get */
t4=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[434]);}}}

/* k7237 in k7206 in k7194 in walk in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1446 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[434],C_SCHEME_TRUE);}}

/* assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7767(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7767,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[127],t7);
if(C_truep(t8)){
/* compiler.scm: 1564 put! */
t9=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[427],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7780,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[402],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7780(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7780(t13,C_SCHEME_FALSE);}}}

/* k7778 in assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7789(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7789(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7840,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1569 get */
t6=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[350]);}}}}

/* k7838 in k7778 in assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7789(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7787 in k7778 in assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1572 get-all */
t3=C_retrieve(lf[432]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[428],lf[429]);}
else{
/* compiler.scm: 1580 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}}

/* k7790 in k7787 in k7778 in assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1573 get */
t3=C_retrieve(lf[430]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[431]);}

/* k7793 in k7790 in k7787 in k7778 in assign in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[428],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[429],((C_word*)t0)[7]))){
/* compiler.scm: 1576 put! */
t2=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1578 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[429],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1579 put! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],C_SCHEME_TRUE);}}}}

/* ref in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_7870(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7870,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1583 collect! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[425],t3);}

/* grow in k7163 in ##compiler#analyze-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_7167(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[53]),t1);
t3=C_mutate((C_word*)lf[53]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7152,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7143,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1415 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7134,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7125,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1415 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7116,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7107,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1415 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7098,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7089,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1415 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7080,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[411]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7071,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[411]);
/* compiler.scm: 1415 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7065,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[411]));}

/* make-foreign-callback-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7059,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[411],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6384,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6387,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6431,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6930,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6946,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7031,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1410 walk */
t21=((C_word*)t6)[1];
f_6431(t21,t1,t2,*((C_word*)lf[410]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7031,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[409]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[196]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[104]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[179]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[108]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[182]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1408 every */
t8=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6946,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6952(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6952,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6966,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1391 reverse */
t5=*((C_word*)lf[287]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1392 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7031(3,t6,t4,t5);}}

/* k6970 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1393 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6952(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1395 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[386]);}}

/* k6988 in k6970 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1396 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6431(t4,((C_word*)t0)[2],t2,t3);}

/* a6998 in k6988 in k6970 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6999,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7013,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7025,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1401 varnode */
t7=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k7023 in a6998 in k6988 in k6970 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1400 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6952(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7011 in a6998 in k6988 in k6970 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t2));}

/* k6964 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1391 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6930(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6930,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6936,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1384 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6946(t7,t1,t4,t6);}

/* a6935 in walk-inline-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6936,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[396],t3,t4,t2);
/* compiler.scm: 1387 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6805,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6809,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1360 gensym */
t7=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[401]);}

/* k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1361 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6812,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[404]);}

/* k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6862,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1365 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6860 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1365 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6835,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1366 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6946(t6,t4,((C_word*)t0)[2],t5);}

/* a6836 in k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6837,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6843,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1369 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6431(t4,t1,((C_word*)t0)[2],t3);}

/* a6842 in a6836 in k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6843,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6847,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1371 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6852 in a6842 in a6836 in k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1371 cons* */
t2=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6845 in a6842 in a6836 in k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[396],lf[398],((C_word*)t0)[2],t1));}

/* k6833 in k6856 in k6864 in k6810 in k6807 in walk-call in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6835,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6431(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6431,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[402]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6453(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t14)){
t15=t13;
f_6453(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[127]);
if(C_truep(t15)){
t16=t13;
f_6453(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[272]);
t17=t13;
f_6453(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[408])));}}}}

/* k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6453,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1317 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[115]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6465,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1318 gensym */
t4=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[401]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[154]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6559,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6559(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[161]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6621,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[404]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6634,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1340 gensym */
t7=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[280]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[245]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[404]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6719(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[196]);
if(C_truep(t9)){
t10=t8;
f_6719(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t10)){
t11=t8;
f_6719(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[179]);
if(C_truep(t11)){
t12=t8;
f_6719(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t13=t8;
f_6719(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[182])));}}}}}}}}}}}

/* k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6719,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1354 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6930(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1355 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6805(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[271]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6876,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1374 gensym */
t8=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[401]);}
else{
/* compiler.scm: 1357 bomb */
t4=C_retrieve(lf[406]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[407]);}}}}

/* k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1375 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6877 in k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[404]);}

/* k6922 in k6877 in k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6920,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1379 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6918 in k6922 in k6877 in k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1379 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6914 in k6922 in k6877 in k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1381 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6910 in k6914 in k6922 in k6877 in k6874 in k6717 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[271],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t4));}

/* k6682 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6684,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[405]),t1,((C_word*)t0)[2]);}

/* k6708 in k6682 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[69]));
t3=C_mutate((C_word*)lf[69]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1351 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6387(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6632 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1341 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6431(t4,((C_word*)t0)[2],t2,t3);}

/* a6642 in k6632 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6643,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[396],lf[177],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6667,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6671,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1345 varnode */
t10=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6669 in a6642 in k6632 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1345 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6665 in a6642 in k6632 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6667,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t2));}

/* k6619 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1339 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6387(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6559(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6559,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1333 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6431(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1334 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6431(t6,t1,t4,t5);}}

/* a6581 in loop in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6582,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6596,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1338 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6559(t8,t5,t6,t7);}

/* k6594 in a6581 in loop in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6596,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t2));}

/* k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1319 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}

/* k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[404]);}

/* k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6544,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6540,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1324 varnode */
t6=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6538 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1324 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6534 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6536,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1325 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6431(t7,t4,t5,t6);}

/* a6508 in k6534 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6509,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1329 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6431(t5,t3,t4,((C_word*)t0)[2]);}

/* k6518 in a6508 in k6534 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1330 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6431(t4,t2,t3,((C_word*)t0)[2]);}

/* k6522 in k6518 in a6508 in k6534 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[115],C_SCHEME_END_OF_LIST,t2));}

/* k6501 in k6534 in k6542 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[154],((C_word*)t0)[2],t2));}

/* k1 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6480,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1320 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6478 in k1 in k6466 in k6463 in k6451 in walk in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[398],lf[403],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6387,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1305 gensym */
t7=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[401]);}

/* k6389 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1308 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6431(t7,t4,t5,t6);}

/* a6413 in k6389 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6414,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6425,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1310 varnode */
t4=C_retrieve(lf[400]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6423 in a6413 in k6389 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[396],lf[398],lf[399],t2));}

/* k6406 in k6389 in cps-lambda in ##compiler#perform-cps-conversion in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[396],lf[397],((C_word*)t0)[4],t2);
/* compiler.scm: 1306 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6294,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6326,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1297 walk */
t10=((C_word*)t7)[1];
f_6326(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6326,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1292 ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[394]),t5);}
else{
/* compiler.scm: 1296 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6297(t5,t1,t2);}}}

/* k6343 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6351(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1294 alist-cons */
t5=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6366 in k6343 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1294 ##sys#hash-table-set! */
t2=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[394]),((C_word*)t0)[2],t1);}

/* k6349 in k6343 in walk in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1295 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6297(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6297,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6303(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6303(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6303,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6313,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1286 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6326(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6311 in loop in mapupdate in ##compiler#update-line-number-database! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1287 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6303(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6213,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6217,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6217(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6217(t5,C_SCHEME_FALSE);}}

/* k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6217,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6220(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6220(t3,lf[393]);}}

/* k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6220,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6223(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6223(t4,(C_word)C_i_cadr(t3));}}

/* k6221 in k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_6223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6223,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6226,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[391]+1),t4);}

/* k6237 in k6221 in k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6224 in k6221 in k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6229,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6227 in k6224 in k6221 in k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6230 in k6227 in k6224 in k6221 in k6218 in k6215 in ##compiler#expand-foreign-primitive in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1276 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6176,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6186,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6199,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[391]+1),t9);}

/* k6197 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6184 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6187 in k6184 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6190 in k6187 in k6184 in ##compiler#expand-foreign-callback-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1267 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6139,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6149,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6162,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[391]+1),t9);}

/* k6160 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[225]+1),t1);}

/* k6147 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[392]+1),((C_word*)t0)[2]);}

/* k6150 in k6147 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6155,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6153 in k6150 in k6147 in ##compiler#expand-foreign-lambda* in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1259 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6094,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6101,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1246 symbol->string */
t6=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6101(2,t6,t4);}
else{
/* compiler.scm: 1248 quit */
t6=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[390],t4);}}}

/* k6099 in ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6107,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[388]+1),t5);}

/* k6105 in k6099 in ##compiler#expand-foreign-callback-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1251 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1237 symbol->string */
t6=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6056(2,t6,t4);}
else{
/* compiler.scm: 1239 quit */
t6=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[389],t4);}}}

/* k6054 in ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6062,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[388]+1),t5);}

/* k6060 in k6054 in ##compiler#expand-foreign-lambda in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1242 create-foreign-stub */
t2=C_retrieve(lf[380]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5895,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5899,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6043,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1210 list-tabulate */
t12=C_retrieve(lf[387]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a6042 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6043,3,t0,t1,t2);}
/* compiler.scm: 1210 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[386]);}

/* k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1211 gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[385]);}

/* k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1212 gensym */
t3=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1213 estimate-foreign-result-size */
t3=C_retrieve(lf[384]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1214 set-real-name! */
t3=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6037,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1216 make-foreign-stub */
t3=C_retrieve(lf[360]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[272],((C_word*)t0)[2]);
t7=t5;
f_5921(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5921(t6,(C_word)C_a_i_list(&a,2,lf[195],((C_word*)t0)[2]));}}

/* k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5921,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6012,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1222 map */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a6011 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6012,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6020,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1222 foreign-type-convert-argument */
t5=C_retrieve(lf[181]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k6018 in a6011 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1222 foreign-type-check */
t2=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[381]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[382],t1);
/* compiler.scm: 1227 append */
t8=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5964,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1228 final-foreign-type */
t7=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5962 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1229 words */
t3=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5965 in k5962 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[383],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[196],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5978,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1232 append */
t12=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5984 in k5965 in k5962 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1232 finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5980 in k5965 in k5962 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1231 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5976 in k5965 in k5962 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5978,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5947(2,t2,(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[2],t1));}

/* k5955 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1227 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5945 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5933 in k5922 in k5919 in k6035 in k5909 in k5906 in k5903 in k5900 in k5897 in ##compiler#create-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5935,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[161],t2));}

/* foreign-stub-callback in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5886,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5877,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5868,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5859,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5850,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5841,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5832,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5823,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5814,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5805,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5796,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5787,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5778,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5769,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5760,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5751,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[361]);
/* compiler.scm: 1199 ##sys#block-set! */
t5=*((C_word*)lf[364]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5745,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[361]));}

/* make-foreign-stub in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5739,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[361],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4776,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4779,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4830(t5,t1);}

/* a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4830,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4834(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1031 syntax-error */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[359],((C_word*)t0)[3]);}}

/* k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word ab[105],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[294]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4849,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[297]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[298]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1043 check-decl */
f_4779(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t9=t3;
f_4840(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1053 append */
t10=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t10=t3;
f_4840(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4971,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1057 append */
t11=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t12=t3;
f_4840(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5000,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1064 lset-intersection */
t12=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[131]+1),t10,C_retrieve(lf[301]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5017,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1067 check-decl */
f_4779(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[305]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[306]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[305]);
t13=t3;
f_4840(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4840(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1073 ##match#set-error-control */
t15=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[308]);}
else{
t14=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4840(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4840(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4840(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4840(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4840(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4840(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1080 append */
t23=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[313]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5114,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1081 append */
t24=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4840(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5135,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1085 append */
t25=*((C_word*)lf[157]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1089 append */
t27=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[317]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1093 every */
t28=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[320]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[321]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5198(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5198(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5198(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[324],t28);
/* compiler.scm: 1101 emit-control-file-item */
t30=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[326],t29);
/* compiler.scm: 1103 emit-control-file-item */
t31=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5288,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1106 pathname-strip-extension */
t31=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4840(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4840(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4840(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5336,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1112 append */
t36=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[91]));}
else{
t34=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1114 check-decl */
f_4779(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[339]);
if(C_truep(t35)){
t36=C_set_block_item(lf[340],0,C_SCHEME_TRUE);
t37=t3;
f_4840(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[341]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[342]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5512,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1148 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[131]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5504(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1152 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[131]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1156 quit */
t41=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[345],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4840(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4840(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4840(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4840(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4840(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4840(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1165 lset-union */
t46=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[131]+1),C_retrieve(lf[87]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[348]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5616,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1167 check-decl */
f_4779(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[350]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1175 every */
t47=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[352]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5662,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5690,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1179 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
t46=(C_word)C_eqp(t2,lf[357]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5714,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t48=(C_word)C_i_cdr(((C_word*)t0)[4]);
t49=C_retrieve(lf[48]);
t50=(C_truep(t49)?t49:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1191 append */
t51=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t51))(4,t51,t47,t48,t50);}
else{
/* compiler.scm: 1193 compiler-warning */
t47=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t3,lf[183],lf[358],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k5712 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* a5689 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5690,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5695,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5700,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5699 in a5689 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5700,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[356]);}

/* k5693 in a5689 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[141]),((C_word*)t0)[2]);}

/* a5661 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1180 partition */
t4=C_retrieve(lf[355]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5667 in a5661 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5668,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1184 quit */
t3=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[354],t2);}}}

/* k5642 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5644,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1176 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1177 quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[351],((C_word*)t0)[2]);}}

/* k5646 in k5642 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5614 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5616,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5623(2,t4,t2);}
else{
/* compiler.scm: 1172 quit */
t4=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[349],((C_word*)t0)[3]);}}

/* k5621 in k5614 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5597 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5523 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1153 lset-union */
t6=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[131]+1),((C_word*)t0)[2],t5);}

/* k5527 in k5523 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5510 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5504(t3,t2);}

/* k5502 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1149 lset-union */
t3=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[131]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5506 in k5502 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4840(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1119 lset-difference */
t7=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[131]+1),C_retrieve(lf[301]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4840(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1123 lset-difference */
t8=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[131]+1),C_retrieve(lf[302]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4840(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1127 lset-union */
t9=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[131]+1),C_retrieve(lf[88]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4840(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5448,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1134 lset-difference */
t10=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[131]+1),C_retrieve(lf[301]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1137 check-decl */
f_4779(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5457 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4840(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1142 ##match#set-error-control */
t6=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[308]);}
else{
/* compiler.scm: 1143 compiler-warning */
t5=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[183],lf[338],((C_word*)t0)[3]);}}}

/* k5446 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1135 lset-difference */
t4=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[131]+1),C_retrieve(lf[302]),((C_word*)t0)[2]);}

/* k5450 in k5446 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5417 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5392 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5367 in k5347 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5334 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5286 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5295,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5297,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5296 in k5286 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5297,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[328]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[329],((C_word*)t0)[2],t2);}

/* k5293 in k5286 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5295,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[327],t1);
/* compiler.scm: 1105 emit-control-file-item */
t3=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5196 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_5198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1098 syntax-error */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[322],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1099 process-custom-declaration */
t4=C_retrieve(lf[323]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5174 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5176,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1094 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1095 syntax-error */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[318],((C_word*)t0)[2]);}}

/* k5178 in k5174 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5147 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1090 append */
t5=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5151 in k5147 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5133 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5135,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1087 append */
t4=*((C_word*)lf[157]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[17]));}

/* k5137 in k5133 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5112 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5098 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[313]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k5015 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4840(2,t4,t3);}

/* k4998 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1065 lset-intersection */
t4=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[131]+1),((C_word*)t0)[2],C_retrieve(lf[302]));}

/* k5002 in k4998 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k4969 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k4944 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4899,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4905,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4929,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1045 stringify */
t5=C_retrieve(lf[296]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4927 in k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1045 string->c-identifier */
t2=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4903 in k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1046 ##sys#hash-table-set! */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[89]),lf[298],((C_word*)t0)[2]);}

/* k4906 in k4903 in k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4915,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4915(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4915(t4,C_SCHEME_FALSE);}}

/* k4913 in k4906 in k4903 in k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1048 compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[299],lf[300]);}
else{
t2=((C_word*)t0)[2];
f_4911(2,t2,C_SCHEME_UNDEFINED);}}

/* k4909 in k4906 in k4903 in k4897 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[141]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4852(2,t3,C_SCHEME_UNDEFINED);}}

/* k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1039 ##sys#hash-table-update! */
t5=C_retrieve(lf[132]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[89]),lf[294],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4840(2,t2,C_SCHEME_UNDEFINED);}}

/* a4885 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4879 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4880,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[131]+1),((C_word*)t0)[2],t2);}

/* k4859 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4870,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4869 in k4859 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4870,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1040 stringify */
t4=C_retrieve(lf[296]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4876 in a4869 in k4859 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1040 string->c-identifier */
t2=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4862 in k4859 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1041 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4866 in k4862 in k4859 in k4850 in k4847 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4840(2,t3,t2);}

/* k4838 in k4832 in a4829 in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[293]);}

/* check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4779(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4779,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4792,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4792(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4802(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4802(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1026 ##sys#error */
t11=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4800 in check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4792(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4790 in check-decl in ##compiler#process-declaration in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1027 syntax-error */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[292],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1979,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1991,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2015,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2166,a[2]=t5,a[3]=t13,a[4]=t4,a[5]=t11,a[6]=t3,a[7]=t7,a[8]=t9,tmp=(C_word)a,a+=9,tmp));
t17=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4721,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=t2,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[125],C_retrieve(lf[289])))){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4771,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1009 newline */
t20=*((C_word*)lf[291]+1);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=t18;
f_4734(2,t19,C_SCHEME_UNDEFINED);}}

/* k4769 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1009 pretty-print */
t2=C_retrieve(lf[290]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1010 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[288]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4735 in k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1014 reverse */
t4=*((C_word*)lf[287]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[79]));}

/* k4750 in k4735 in k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4761,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1017 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[286]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4759 in k4750 in k4735 in k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1018 append */
t3=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[285]),C_retrieve(lf[13]));}

/* k4763 in k4759 in k4750 in k4735 in k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4765,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 454  ##sys#append */
t4=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4746 in k4735 in k4732 in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
/* compiler.scm: 1012 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2166(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4721,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4726 in mapwalk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4727,3,t0,t1,t2);}
/* compiler.scm: 1007 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2166,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 504  keyword? */
t7=C_retrieve(lf[111]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 512  constant? */
t7=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2212(2,t7,C_SCHEME_FALSE);}}}

/* k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 513  walk-literal */
t2=((C_word*)((C_word*)t0)[12])[1];
f_2148(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 514  syntax-error */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[113],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 518  get-line */
t6=C_retrieve(lf[193]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 983  constant? */
t5=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 981  syntax-error */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[284],((C_word*)t0)[10]);}}}}}

/* k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 984  emit-syntax-trace-info */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 988  caar */
t5=*((C_word*)lf[282]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4597(t4,C_SCHEME_FALSE);}}}

/* k4695 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4597(t2,(C_word)C_eqp(lf[161],t1));}

/* k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4597,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 991  emit-syntax-trace-info */
t5=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1003 emit-syntax-trace-info */
t3=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4682 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1004 mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4721(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4604 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 992  ##sys#check-syntax */
t3=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[161],((C_word*)t0)[9],lf[281]);}

/* k4607 in k4604 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4618(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4618(t4,C_SCHEME_FALSE);}}

/* k4616 in k4607 in k4604 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4618,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 995  map */
t3=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[279]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 996  gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[280]);}}

/* k4638 in k4616 in k4607 in k4604 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[154],t4,t6);
/* compiler.scm: 997  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2166(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4631 in k4616 in k4607 in k4604 in k4595 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[154],t3);
/* compiler.scm: 995  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2166(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4583 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 985  compiler-warning */
t3=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[183],lf[278],((C_word*)t0)[4]);}

/* k4586 in k4583 in k4580 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 986  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4721(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=f_1979(((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2245,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t2,a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 520  emit-syntax-trace-info */
t4=C_retrieve(lf[277]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}

/* k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[15]))){
t3=t2;
f_2248(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[15],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 523  sprintf */
t4=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[275],((C_word*)t0)[2]);}
else{
/* compiler.scm: 524  syntax-error */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[276],((C_word*)t0)[15]);}}}

/* k4562 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 523  syntax-error */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,((C_word*)t0)[15]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 527  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[274]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[9]);}

/* k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[15],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 531  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[57]),((C_word*)t0)[8]);}
else{
t4=t3;
f_2273(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 529  update-line-number-database! */
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2264(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2262 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 530  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 533  walk */
t4=((C_word*)((C_word*)t0)[13])[1];
f_2166(t4,((C_word*)t0)[12],t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[115]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 538  ##sys#check-syntax */
t4=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[115],((C_word*)t0)[14],lf[118]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[103]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 546  ##sys#check-syntax */
t5=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[103],((C_word*)t0)[14],lf[119]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[120]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[121]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[14]);
/* compiler.scm: 552  walk */
t6=((C_word*)((C_word*)t0)[13])[1];
f_2166(t6,((C_word*)t0)[12],t5,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[122]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 555  cadadr */
t7=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[14]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[127]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2407(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[271]);
if(C_truep(t8)){
t9=t7;
f_2407(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[272]);
if(C_truep(t9)){
t10=t7;
f_2407(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[104]);
t11=t7;
f_2407(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[8],lf[108])));}}}}}}}}}

/* k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2407,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[128]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[136]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[137]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2454(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[154]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 603  ##sys#check-syntax */
t6=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[154],((C_word*)t0)[12],lf[160]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[161]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[162]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 617  ##sys#check-syntax */
t8=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[161],((C_word*)t0)[12],lf[174]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[161],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 655  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2166(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[176]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[124]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[178]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 671  ##sys#check-syntax */
t12=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[177],((C_word*)t0)[12],lf[194]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 710  unquotify */
t14=((C_word*)t0)[3];
f_2015(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3160,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[179]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 718  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2166(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[182]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 723  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2166(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[197]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[198]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 728  eval */
t19=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[199]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[200]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 732  eval */
t21=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[140]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 736  ##sys#check-syntax */
t21=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[140],((C_word*)t0)[12],lf[204]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[205]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 748  expand-foreign-lambda */
t22=C_retrieve(lf[206]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[207]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 751  expand-foreign-callback-lambda */
t23=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[209]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 754  expand-foreign-lambda* */
t24=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[211]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 757  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[212]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[213]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 760  expand-foreign-primitive */
t26=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[215]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3399(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 767  symbol->string */
t32=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[218]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3466,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 778  gensym */
t33=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 791  ##sys#hash-table-set! */
t33=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[66]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[222]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3540,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 796  symbol->string */
t31=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[228]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 811  gensym */
t34=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[233]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3742,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3760,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[235]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3883,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 850  call-with-current-continuation */
t37=*((C_word*)lf[242]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[243]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3958,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[245]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 878  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[268],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 953  ##sys#check-syntax */
t36=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[268],((C_word*)t0)[12],lf[270]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[93]))){
if(C_truep(C_retrieve(lf[92]))){
/* compiler.scm: 971  ##sys#hash-table-ref */
t36=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[92]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4484(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4484(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4482 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 973  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 978  handle-call */
t2=((C_word*)t0)[7];
f_4355(t2,((C_word*)t0)[6]);}}

/* k4488 in k4482 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 975  handle-call */
t2=((C_word*)t0)[7];
f_4355(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 976  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2166(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4393 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1979(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[78]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t7=(C_word)C_a_i_list(&a,5,lf[269],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 958  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2166(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[75]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 962  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2166(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[81])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 964  symbol->string */
t7=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t7=(C_word)C_a_i_list(&a,5,lf[269],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 966  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2166(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[103],lf[268]);
t4=(C_word)C_a_i_list(&a,5,lf[269],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 967  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2166(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4453 in k4393 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[223]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[104],t2));}

/* handle-call in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4355,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 942  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4721(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4357 in handle-call in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4365,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 944  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[54]),t2);}

/* k4363 in k4357 in handle-call in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 949  alist-cons */
t5=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4368(2,t3,C_SCHEME_UNDEFINED);}}

/* k4377 in k4363 in k4357 in handle-call in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 946  ##sys#hash-table-set! */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[54]),((C_word*)t0)[2],t2);}

/* k4366 in k4363 in k4357 in handle-call in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3991,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4013,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4339,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 885  valid-c-identifier? */
t14=C_retrieve(lf[267]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4337 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4339,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[81]));
t3=C_mutate((C_word*)lf[81]+1,t2);
t4=((C_word*)t0)[2];
f_4013(2,t4,t3);}
else{
/* compiler.scm: 887  quit */
t2=C_retrieve(lf[239]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[266],((C_word*)t0)[3]);}}

/* k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4304(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4304(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4304(t11,(C_word)C_i_not(t10));}}}

/* k4302 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 892  syntax-error */
t2=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[265],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4016(2,t2,C_SCHEME_UNDEFINED);}}

/* k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 896  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4721(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4254,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4254(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4254,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4294,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 908  final-foreign-type */
t9=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4296 in loop in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 908  finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4292 in loop in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 907  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4288 in loop in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 910  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4254(t6,t3,t4,t5);}

/* k4276 in k4288 in loop in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 913  g302 */
t7=t6;
f_4126(2,t7,f_4103(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[252]))){
/* compiler.scm: 913  g302 */
t7=t6;
f_4126(2,t7,f_4103(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t7)){
/* compiler.scm: 913  g302 */
t8=t6;
f_4126(2,t8,f_4103(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[254]);
if(C_truep(t8)){
/* compiler.scm: 913  g302 */
t9=t6;
f_4126(2,t9,f_4103(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 913  g303 */
t9=t4;
f_4098(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[256]))){
/* compiler.scm: 913  g303 */
t9=t4;
f_4098(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t9)){
/* compiler.scm: 913  g303 */
t10=t4;
f_4098(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t10)){
/* compiler.scm: 913  g303 */
t11=t4;
f_4098(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t11)){
/* compiler.scm: 913  g303 */
t12=t4;
f_4098(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t12)){
/* compiler.scm: 913  g303 */
t13=t4;
f_4098(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[261]);
if(C_truep(t13)){
/* compiler.scm: 913  g304 */
t14=t6;
f_4126(2,t14,f_4061(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[262]))){
/* compiler.scm: 913  g304 */
t14=t6;
f_4126(2,t14,f_4061(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[263]);
/* compiler.scm: 913  g304 */
t15=t6;
f_4126(2,t15,(C_truep(t14)?f_4061(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[264]))?f_4061(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4124 in k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[154],t2);
/* compiler.scm: 911  foreign-type-convert-argument */
t4=C_retrieve(lf[181]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g302 in k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_4103(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[154],t2);
t4=(C_word)C_a_i_list(&a,2,lf[248],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g303 in k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_4098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4098,NULL,2,t0,t1);}
/* compiler.scm: 925  syntax-error */
t2=C_retrieve(lf[112]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[250],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g304 in k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_4061(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[154],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[248],lf[247]);
t7=(C_word)C_a_i_list(&a,3,lf[249],lf[247],t6);
t8=(C_word)C_a_i_list(&a,3,lf[154],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k4049 in k4045 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[162],((C_word*)t0)[6],t2);
/* compiler.scm: 897  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2166(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4033 in k4025 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 454  ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4021 in k4014 in k4011 in a3990 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[245],t1));}

/* a3980 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 878  split-at */
t3=C_retrieve(lf[246]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3957 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3958,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 873  process-declaration */
t4=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3954 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
/* compiler.scm: 871  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3891,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3903,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 850  with-exception-handler */
t5=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3902 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 850  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3924 in a3902 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3925r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3925r(t0,t1,t2);}}

static void C_ccall f_3925r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 850  g265 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3930 in a3924 in a3902 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3908 in a3902 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 854  collapsable-literal? */
t3=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3914 in a3908 in a3902 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[154],C_retrieve(lf[80]),((C_word*)t0)[2]);
/* compiler.scm: 856  eval */
t3=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3890 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3891,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 850  g265 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3896 in a3890 in a3884 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
/* compiler.scm: 852  quit */
t2=C_retrieve(lf[239]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[240],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3881 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[103],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[80]));
t6=C_mutate((C_word*)lf[80]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 859  collapsable-literal? */
t8=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3830 in k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 860  ##sys#hash-table-set! */
t4=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[59]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 863  gensym */
t3=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}}

/* k3840 in k3830 in k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 864  ##sys#hash-table-set! */
t4=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[59]),((C_word*)t0)[2],t3);}

/* k3843 in k3840 in k3830 in k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 865  alist-cons */
t3=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[61]));}

/* k3847 in k3843 in k3840 in k3830 in k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[7],t7);
/* compiler.scm: 868  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2166(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3833 in k3830 in k3819 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[236]);}

/* a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3760,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3764,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 840  ##sys#hash-table-set! */
t5=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[57]),((C_word*)t0)[2],t2);}

/* k3762 in a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 841  unzip1 */
t4=C_retrieve(lf[159]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3800 in k3762 in a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 841  append */
t2=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3766 in k3762 in a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3768,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[58],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3782,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3781 in k3766 in k3762 in a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3782,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[103],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[178],t3,t5));}

/* k3778 in k3766 in k3762 in a3759 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3780,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
/* compiler.scm: 843  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2166(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3741 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[162],t3);
/* compiler.scm: 839  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2166(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3748 in a3741 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 838  extract-mutable-constants */
t2=C_retrieve(lf[234]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 812  gensym */
t3=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 814  set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[78]));
t4=C_mutate((C_word*)lf[78]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 817  estimate-foreign-result-location-size */
t7=C_retrieve(lf[232]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3701 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 817  words */
t2=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[229],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[196],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3639,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3655(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3655(t11,C_SCHEME_END_OF_LIST);}}

/* k3653 in k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3655,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3663,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 830  fifth */
t3=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3663(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3661 in k3653 in k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 454  ##sys#append */
t3=*((C_word*)lf[230]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3649 in k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 831  alist-cons */
t4=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3645 in k3649 in k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 825  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3637 in k3678 in k3622 in k3616 in k3613 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[2],t1));}

/* k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 799  make-random-name */
t9=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3552(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3580,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 800  fifth */
t5=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3586 in k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 800  symbol->string */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3578 in k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3552(t3,t2);}

/* k3550 in k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3552,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[70]));
t4=C_mutate((C_word*)lf[70]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 803  string-append */
t6=*((C_word*)lf[225]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[226],((C_word*)((C_word*)t0)[7])[1]);}

/* k3570 in k3550 in k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3572,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[223],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[67]));
t4=C_mutate((C_word*)lf[67]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 805  alist-cons */
t6=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[75]));}

/* k3562 in k3570 in k3550 in k3547 in k3538 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[75]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[224]);}

/* k3518 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[221]);}

/* k3464 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 779  gensym */
t3=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3467 in k3464 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 780  ##sys#hash-table-set! */
t4=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[66]),((C_word*)t0)[2],t3);}

/* k3470 in k3467 in k3464 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 781  cons* */
t3=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3474 in k3470 in k3467 in k3464 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 782  cons* */
t4=C_retrieve(lf[220]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3478 in k3474 in k3470 in k3467 in k3464 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[219]);
t8=(C_word)C_a_i_list(&a,3,lf[178],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[140],t4,t8);
/* compiler.scm: 783  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2166(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3397 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3411(2,t3,t1);}
else{
/* compiler.scm: 769  symbol->string */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3409 in k3397 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[67]));
t4=C_mutate((C_word*)lf[67]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[216]);}

/* k3382 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 760  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3369 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 757  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3356 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 754  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3343 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 751  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3330 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 748  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3284,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3284(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[203]);}}

/* fold in k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3284,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 743  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2166(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 744  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2166(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3309 in fold in k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3315,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 744  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3284(t3,t2,((C_word*)t0)[2]);}

/* k3313 in k3309 in fold in k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3302 in fold in k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3276 in k3263 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 738  canonicalize-begin-body */
t2=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3250 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[201]);}

/* k3235 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 729  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3208 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 724  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3212 in k3208 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[182],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3187 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[179],((C_word*)t0)[2],t1));}

/* k3158 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 715  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4721(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3162 in k3158 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[196],t2));}

/* k3129 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 710  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4721(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3133 in k3129 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1979(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 674  get-line */
t7=C_retrieve(lf[193]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2969,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 675  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2972,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 677  ##sys#alias-global-hook */
t5=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2972(2,t4,C_SCHEME_UNDEFINED);}}

/* k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 680  lset-adjoin */
t5=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[131]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3080(t4,C_SCHEME_UNDEFINED);}}

/* k3104 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 681  lset-adjoin */
t4=C_retrieve(lf[192]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[131]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3108 in k3104 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3080(t3,t2);}

/* k3078 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_3080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3080,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 682  macro? */
t3=C_retrieve(lf[191]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3084 in k3078 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 686  sprintf */
t4=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[189],((C_word*)t0)[2]);}
else{
t4=t3;
f_3099(2,t4,lf[190]);}}
else{
t2=((C_word*)t0)[4];
f_2972(2,t2,C_SCHEME_UNDEFINED);}}

/* k3097 in k3084 in k3078 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 683  compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[186],lf[187],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3087 in k3084 in k3078 in k3075 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 687  undefine-macro! */
t2=C_retrieve(lf[185]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2972(2,t2,C_SCHEME_UNDEFINED);}}

/* k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 688  keyword? */
t4=C_retrieve(lf[111]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3065 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 689  compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[183],lf[184],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2975(2,t2,C_SCHEME_UNDEFINED);}}

/* k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[67]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 693  gensym */
t5=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[78]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 701  gensym */
t6=C_retrieve(lf[124]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k3028 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 702  foreign-type-convert-argument */
t3=C_retrieve(lf[181]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3059 in k3028 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3053,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 706  foreign-type-check */
t7=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k3051 in k3059 in k3028 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[182],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[2],t2));}

/* k2985 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 694  foreign-type-convert-argument */
t3=C_retrieve(lf[181]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3016 in k2985 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3018,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 697  foreign-type-check */
t7=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k3004 in k3016 in k2985 in k2973 in k2970 in k2967 in k2964 in k2955 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[179],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[2],t2));}

/* k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 661  map */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[158]+1),((C_word*)t0)[7],t1);}

/* k2943 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 661  append */
t2=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2920 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 664  ##sys#canonicalize-body */
t5=C_retrieve(lf[155]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2936 in k2920 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2937,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2933 in k2920 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 663  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2166(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2923 in k2920 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2928,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 667  set-real-names! */
f_1991(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2926 in k2923 in k2920 in k2917 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[161],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2651,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 620  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2867 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 621  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2651(2,t2,C_SCHEME_UNDEFINED);}}

/* a2879 in k2867 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2880,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2873 in k2867 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
/* compiler.scm: 623  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[171]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[172]+1));}

/* k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 626  decompose-lambda-list */
t3=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2656,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[124]),t2);}

/* k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 630  map */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[158]+1),((C_word*)t0)[7],t1);}

/* k2864 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 630  append */
t2=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 631  ##sys#canonicalize-body */
t4=C_retrieve(lf[155]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2857 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2858,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 632  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2166(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 636  posq */
t5=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2849(t4,C_SCHEME_FALSE);}}

/* k2854 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2849(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2847 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 634  build-lambda-list */
t2=C_retrieve(lf[168]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[161],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 638  set-real-names! */
f_1991(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2687(t4,t2);}
else{
t4=f_1979(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2687(t6,(C_word)C_i_not(t5));}}

/* k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2687,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(lf[161],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[27]))){
t4=(C_word)C_i_not(C_retrieve(lf[48]));
t5=t2;
f_2693(t5,(C_truep(t4)?t4:(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[48]))));}
else{
t4=t2;
f_2693(t4,C_SCHEME_FALSE);}}
else{
t4=t2;
f_2693(t4,C_SCHEME_FALSE);}}}

/* k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2693,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 646  expand-profile-lambda */
t2=C_retrieve(lf[163]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,lf[140]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t3;
f_2707(t7,(C_word)C_i_pairp(t6));}
else{
t6=t3;
f_2707(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2707(t4,C_SCHEME_FALSE);}}}

/* k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2707,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 648  g171 */
t6=((C_word*)t0)[4];
f_2697(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  caadr */
t6=*((C_word*)lf[167]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2740(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2789 in k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  cdadr */
t4=*((C_word*)lf[166]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2740(t3,C_SCHEME_FALSE);}}

/* k2785 in k2789 in k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  cddadr */
t3=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2740(t2,C_SCHEME_FALSE);}}

/* k2781 in k2785 in k2789 in k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2740(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2740(t2,C_SCHEME_FALSE);}}

/* k2738 in k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 648  cadadr */
t3=*((C_word*)lf[126]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2745 in k2738 in k2705 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 648  g171 */
t3=((C_word*)t0)[3];
f_2697(t3,((C_word*)t0)[2],t1);}

/* g171 in k2691 in k2685 in k2676 in k2670 in k2667 in k2664 in k2661 in k2658 in a2655 in k2649 in k2640 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2697,NULL,3,t0,t1,t2);}
/* compiler.scm: 650  process-lambda-documentation */
t3=C_retrieve(lf[164]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 605  unzip1 */
t4=C_retrieve(lf[159]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2577,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[124]),t1);}

/* k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 607  map */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[158]+1),((C_word*)t0)[2],t1);}

/* k2628 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 607  append */
t2=*((C_word*)lf[157]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 608  set-real-names! */
f_1991(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 609  map */
t4=*((C_word*)lf[156]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2609 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2610,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 610  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2166(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2616 in a2609 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2588 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2594,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 612  ##sys#canonicalize-body */
t6=C_retrieve(lf[155]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2603 in k2588 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2596 in k2588 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 612  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2592 in k2588 in k2581 in k2578 in k2575 in k2572 in k2566 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[154],((C_word*)t0)[2],t1));}

/* loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[138]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 580  cadar */
t4=*((C_word*)lf[153]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2475,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2475,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2540(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 584  feature? */
t7=C_retrieve(lf[152]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2540(2,t6,C_SCHEME_FALSE);}}}

/* k2547 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2540(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 586  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[151]);}}

/* k2557 in k2547 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 585  ##sys#find-extension */
t2=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2538 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 592  ##sys#extension-information */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2502(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2502(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 588  compiler-warning */
t2=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[147],lf[148],((C_word*)t0)[2]);}}

/* k2512 in k2538 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[142],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2502(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2502(t2,C_SCHEME_FALSE);}}

/* a2527 in k2512 in k2538 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2528,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[143]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2524 in k2512 in k2538 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2502(t2,C_SCHEME_TRUE);}

/* k2500 in k2538 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2479(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 598  lookup-exports-file */
t2=C_retrieve(lf[141]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2477 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 599  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2454(t4,t2,t3);}

/* k2484 in k2477 in a2474 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[140],((C_word*)t0)[2],t1));}

/* a2468 in k2462 in loop in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
/* compiler.scm: 581  ##sys#do-the-right-thing */
t2=C_retrieve(lf[139]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2446 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 576  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2166(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2414 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[134]),t1);}

/* k2417 in k2414 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 570  ##sys#hash-table-update! */
t5=C_retrieve(lf[132]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[89]),lf[133],t3,t4);}

/* a2429 in k2417 in k2414 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2423 in k2417 in k2414 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2424,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[130]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[131]+1),t2,((C_word*)t0)[2]);}

/* k2420 in k2417 in k2414 in k2405 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}

/* k2372 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[55]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 558  gensym */
t4=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[125]);}}

/* k2384 in k2372 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 559  alist-cons */
t3=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[55]));}

/* k2388 in k2384 in k2372 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2340 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* compiler.scm: 547  walk-literal */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2148(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2294 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 539  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2301 in k2294 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 540  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2166(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2305 in k2301 in k2294 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2311(2,t4,lf[116]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 543  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2166(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2309 in k2305 in k2301 in k2294 in k2271 in k2253 in k2246 in k2243 in k2237 in k2210 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[115],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2177 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 504  walk-literal */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2148(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 508  resolve-atom */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2057(t5,t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 510  resolve-atom */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2057(t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k2198 in k2177 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 511  ##sys#alias-global-hook */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2192 in k2177 in walk in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* walk-literal in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_retrieve(lf[94]))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 499  literal-rewrite-hook */
t7=C_retrieve(lf[94]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[103],t2));}}

/* a2156 in walk-literal in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2157,3,t0,t1,t2);}
/* walk21 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2166(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2057(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2061,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[60]))){
/* compiler.scm: 474  ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[59]),t2);}
else{
t7=t6;
f_2061(2,t7,C_SCHEME_FALSE);}}

/* k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 475  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2166(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 476  ##sys#hash-table-ref */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[57]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2074(2,t3,C_SCHEME_FALSE);}}}

/* k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 478  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2166(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[67]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 482  final-foreign-type */
t5=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[78]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 490  final-foreign-type */
t6=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2120 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[108],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 493  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2130 in k2120 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 492  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2090 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[104],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 485  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2100 in k2090 in k2072 in k2059 in resolve-atom in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 484  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2015,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2022,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[103]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2022(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2022(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2022(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2022(t4,C_SCHEME_FALSE);}}

/* k2020 in unquotify in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_2022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_fcall f_1991(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1997,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 461  for-each */
t5=*((C_word*)lf[102]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1996 in set-real-names! in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1997,4,t0,t1,t2,t3);}
/* compiler.scm: 461  set-real-name! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static C_word C_fcall f_1979(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[54]))){
/* compiler.scm: 431  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[54]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 432  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1972 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=((C_word*)t0)[2];
f_1909(2,t3,t2);}

/* k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 434  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[57]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1965 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=((C_word*)t0)[2];
f_1912(2,t3,t2);}

/* k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 437  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[59]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1958 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[59]+1,t1);
t3=((C_word*)t0)[2];
f_1915(2,t3,t2);}

/* k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 439  make-random-name */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[99]);}

/* k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 440  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[89]))){
/* compiler.scm: 442  vector-fill! */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[89]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t5=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1951 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=((C_word*)t0)[2];
f_1926(2,t3,t2);}

/* k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 445  vector-fill! */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 446  make-vector */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1944 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1929(2,t3,t2);}

/* k1927 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
if(C_truep(C_retrieve(lf[66]))){
/* compiler.scm: 448  vector-fill! */
t2=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[66]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 449  make-vector */
t3=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1937 in k1927 in k1924 in k1921 in k1917 in k1913 in k1910 in k1907 in ##compiler#initialize-compiler in k1816 in k1812 in k1808 in k1804 in k1800 in k1796 in k1789 in k1786 in k1783 in k1780 in k1777 in k1774 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[823] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1779compiler.scm",(void*)f_1779},
{"f_1782compiler.scm",(void*)f_1782},
{"f_1785compiler.scm",(void*)f_1785},
{"f_1788compiler.scm",(void*)f_1788},
{"f_1791compiler.scm",(void*)f_1791},
{"f_1798compiler.scm",(void*)f_1798},
{"f_1802compiler.scm",(void*)f_1802},
{"f_1806compiler.scm",(void*)f_1806},
{"f_1810compiler.scm",(void*)f_1810},
{"f_1814compiler.scm",(void*)f_1814},
{"f_1818compiler.scm",(void*)f_1818},
{"f_10202compiler.scm",(void*)f_10202},
{"f_11259compiler.scm",(void*)f_11259},
{"f_11262compiler.scm",(void*)f_11262},
{"f_11265compiler.scm",(void*)f_11265},
{"f_11268compiler.scm",(void*)f_11268},
{"f_11271compiler.scm",(void*)f_11271},
{"f_11059compiler.scm",(void*)f_11059},
{"f_11065compiler.scm",(void*)f_11065},
{"f_10292compiler.scm",(void*)f_10292},
{"f_11048compiler.scm",(void*)f_11048},
{"f_11045compiler.scm",(void*)f_11045},
{"f_10958compiler.scm",(void*)f_10958},
{"f_11022compiler.scm",(void*)f_11022},
{"f_11035compiler.scm",(void*)f_11035},
{"f_11016compiler.scm",(void*)f_11016},
{"f_11006compiler.scm",(void*)f_11006},
{"f_10979compiler.scm",(void*)f_10979},
{"f_10982compiler.scm",(void*)f_10982},
{"f_10930compiler.scm",(void*)f_10930},
{"f_10933compiler.scm",(void*)f_10933},
{"f_10887compiler.scm",(void*)f_10887},
{"f_10899compiler.scm",(void*)f_10899},
{"f_10890compiler.scm",(void*)f_10890},
{"f_10893compiler.scm",(void*)f_10893},
{"f_10767compiler.scm",(void*)f_10767},
{"f_10868compiler.scm",(void*)f_10868},
{"f_10856compiler.scm",(void*)f_10856},
{"f_10795compiler.scm",(void*)f_10795},
{"f_10801compiler.scm",(void*)f_10801},
{"f_10825compiler.scm",(void*)f_10825},
{"f_10817compiler.scm",(void*)f_10817},
{"f_10783compiler.scm",(void*)f_10783},
{"f_10726compiler.scm",(void*)f_10726},
{"f_10738compiler.scm",(void*)f_10738},
{"f_10742compiler.scm",(void*)f_10742},
{"f_10730compiler.scm",(void*)f_10730},
{"f_10542compiler.scm",(void*)f_10542},
{"f_10663compiler.scm",(void*)f_10663},
{"f_10669compiler.scm",(void*)f_10669},
{"f_10694compiler.scm",(void*)f_10694},
{"f_10675compiler.scm",(void*)f_10675},
{"f_10549compiler.scm",(void*)f_10549},
{"f_10654compiler.scm",(void*)f_10654},
{"f_10552compiler.scm",(void*)f_10552},
{"f_10555compiler.scm",(void*)f_10555},
{"f_10558compiler.scm",(void*)f_10558},
{"f_10596compiler.scm",(void*)f_10596},
{"f_10622compiler.scm",(void*)f_10622},
{"f_10603compiler.scm",(void*)f_10603},
{"f_10607compiler.scm",(void*)f_10607},
{"f_10580compiler.scm",(void*)f_10580},
{"f_10486compiler.scm",(void*)f_10486},
{"f_10495compiler.scm",(void*)f_10495},
{"f_10489compiler.scm",(void*)f_10489},
{"f_10470compiler.scm",(void*)f_10470},
{"f_10443compiler.scm",(void*)f_10443},
{"f_10426compiler.scm",(void*)f_10426},
{"f_10422compiler.scm",(void*)f_10422},
{"f_10415compiler.scm",(void*)f_10415},
{"f_10398compiler.scm",(void*)f_10398},
{"f_10394compiler.scm",(void*)f_10394},
{"f_10370compiler.scm",(void*)f_10370},
{"f_10350compiler.scm",(void*)f_10350},
{"f_10205compiler.scm",(void*)f_10205},
{"f_10209compiler.scm",(void*)f_10209},
{"f_10224compiler.scm",(void*)f_10224},
{"f_10234compiler.scm",(void*)f_10234},
{"f_10239compiler.scm",(void*)f_10239},
{"f_10284compiler.scm",(void*)f_10284},
{"f_10243compiler.scm",(void*)f_10243},
{"f_10249compiler.scm",(void*)f_10249},
{"f_10259compiler.scm",(void*)f_10259},
{"f_11071compiler.scm",(void*)f_11071},
{"f_11078compiler.scm",(void*)f_11078},
{"f_11140compiler.scm",(void*)f_11140},
{"f_11130compiler.scm",(void*)f_11130},
{"f_11104compiler.scm",(void*)f_11104},
{"f_11090compiler.scm",(void*)f_11090},
{"f_11165compiler.scm",(void*)f_11165},
{"f_11181compiler.scm",(void*)f_11181},
{"f_11188compiler.scm",(void*)f_11188},
{"f_11195compiler.scm",(void*)f_11195},
{"f_11169compiler.scm",(void*)f_11169},
{"f_11179compiler.scm",(void*)f_11179},
{"f_11151compiler.scm",(void*)f_11151},
{"f_11159compiler.scm",(void*)f_11159},
{"f_11197compiler.scm",(void*)f_11197},
{"f_11210compiler.scm",(void*)f_11210},
{"f_10193compiler.scm",(void*)f_10193},
{"f_10184compiler.scm",(void*)f_10184},
{"f_10175compiler.scm",(void*)f_10175},
{"f_10166compiler.scm",(void*)f_10166},
{"f_10157compiler.scm",(void*)f_10157},
{"f_10148compiler.scm",(void*)f_10148},
{"f_10139compiler.scm",(void*)f_10139},
{"f_10130compiler.scm",(void*)f_10130},
{"f_10121compiler.scm",(void*)f_10121},
{"f_10112compiler.scm",(void*)f_10112},
{"f_10103compiler.scm",(void*)f_10103},
{"f_10094compiler.scm",(void*)f_10094},
{"f_10085compiler.scm",(void*)f_10085},
{"f_10076compiler.scm",(void*)f_10076},
{"f_10067compiler.scm",(void*)f_10067},
{"f_10058compiler.scm",(void*)f_10058},
{"f_10049compiler.scm",(void*)f_10049},
{"f_10040compiler.scm",(void*)f_10040},
{"f_10031compiler.scm",(void*)f_10031},
{"f_10022compiler.scm",(void*)f_10022},
{"f_10013compiler.scm",(void*)f_10013},
{"f_10004compiler.scm",(void*)f_10004},
{"f_9995compiler.scm",(void*)f_9995},
{"f_9986compiler.scm",(void*)f_9986},
{"f_9977compiler.scm",(void*)f_9977},
{"f_9968compiler.scm",(void*)f_9968},
{"f_9959compiler.scm",(void*)f_9959},
{"f_9950compiler.scm",(void*)f_9950},
{"f_9941compiler.scm",(void*)f_9941},
{"f_9932compiler.scm",(void*)f_9932},
{"f_9926compiler.scm",(void*)f_9926},
{"f_9920compiler.scm",(void*)f_9920},
{"f_8686compiler.scm",(void*)f_8686},
{"f_9887compiler.scm",(void*)f_9887},
{"f_9890compiler.scm",(void*)f_9890},
{"f_9893compiler.scm",(void*)f_9893},
{"f_9896compiler.scm",(void*)f_9896},
{"f_9899compiler.scm",(void*)f_9899},
{"f_9914compiler.scm",(void*)f_9914},
{"f_9912compiler.scm",(void*)f_9912},
{"f_9902compiler.scm",(void*)f_9902},
{"f_9739compiler.scm",(void*)f_9739},
{"f_9745compiler.scm",(void*)f_9745},
{"f_9050compiler.scm",(void*)f_9050},
{"f_9069compiler.scm",(void*)f_9069},
{"f_9102compiler.scm",(void*)f_9102},
{"f_9629compiler.scm",(void*)f_9629},
{"f_9625compiler.scm",(void*)f_9625},
{"f_9618compiler.scm",(void*)f_9618},
{"f_9469compiler.scm",(void*)f_9469},
{"f_9475compiler.scm",(void*)f_9475},
{"f_9545compiler.scm",(void*)f_9545},
{"f_9575compiler.scm",(void*)f_9575},
{"f_9558compiler.scm",(void*)f_9558},
{"f_9562compiler.scm",(void*)f_9562},
{"f_9484compiler.scm",(void*)f_9484},
{"f_9531compiler.scm",(void*)f_9531},
{"f_9535compiler.scm",(void*)f_9535},
{"f_9511compiler.scm",(void*)f_9511},
{"f_9507compiler.scm",(void*)f_9507},
{"f_9198compiler.scm",(void*)f_9198},
{"f_9447compiler.scm",(void*)f_9447},
{"f_9202compiler.scm",(void*)f_9202},
{"f_9445compiler.scm",(void*)f_9445},
{"f_9205compiler.scm",(void*)f_9205},
{"f_9208compiler.scm",(void*)f_9208},
{"f_9214compiler.scm",(void*)f_9214},
{"f_9220compiler.scm",(void*)f_9220},
{"f_9226compiler.scm",(void*)f_9226},
{"f_9412compiler.scm",(void*)f_9412},
{"f_9415compiler.scm",(void*)f_9415},
{"f_9229compiler.scm",(void*)f_9229},
{"f_9388compiler.scm",(void*)f_9388},
{"f_9373compiler.scm",(void*)f_9373},
{"f_9369compiler.scm",(void*)f_9369},
{"f_9303compiler.scm",(void*)f_9303},
{"f_9328compiler.scm",(void*)f_9328},
{"f_9334compiler.scm",(void*)f_9334},
{"f_9345compiler.scm",(void*)f_9345},
{"f_9332compiler.scm",(void*)f_9332},
{"f_9314compiler.scm",(void*)f_9314},
{"f_9306compiler.scm",(void*)f_9306},
{"f_9291compiler.scm",(void*)f_9291},
{"f_9299compiler.scm",(void*)f_9299},
{"f_9252compiler.scm",(void*)f_9252},
{"f_9282compiler.scm",(void*)f_9282},
{"f_9274compiler.scm",(void*)f_9274},
{"f_9270compiler.scm",(void*)f_9270},
{"f_9266compiler.scm",(void*)f_9266},
{"f_9255compiler.scm",(void*)f_9255},
{"f_9123compiler.scm",(void*)f_9123},
{"f_9126compiler.scm",(void*)f_9126},
{"f_9178compiler.scm",(void*)f_9178},
{"f_9142compiler.scm",(void*)f_9142},
{"f_9171compiler.scm",(void*)f_9171},
{"f_9163compiler.scm",(void*)f_9163},
{"f_9108compiler.scm",(void*)f_9108},
{"f_9081compiler.scm",(void*)f_9081},
{"f_9087compiler.scm",(void*)f_9087},
{"f_9751compiler.scm",(void*)f_9751},
{"f_9758compiler.scm",(void*)f_9758},
{"f_9774compiler.scm",(void*)f_9774},
{"f_8716compiler.scm",(void*)f_8716},
{"f_8735compiler.scm",(void*)f_8735},
{"f_9014compiler.scm",(void*)f_9014},
{"f_8975compiler.scm",(void*)f_8975},
{"f_9790compiler.scm",(void*)f_9790},
{"f_9828compiler.scm",(void*)f_9828},
{"f_9854compiler.scm",(void*)f_9854},
{"f_9840compiler.scm",(void*)f_9840},
{"f_9819compiler.scm",(void*)f_9819},
{"f_9788compiler.scm",(void*)f_9788},
{"f_8988compiler.scm",(void*)f_8988},
{"f_8991compiler.scm",(void*)f_8991},
{"f_9002compiler.scm",(void*)f_9002},
{"f_8939compiler.scm",(void*)f_8939},
{"f_8831compiler.scm",(void*)f_8831},
{"f_8837compiler.scm",(void*)f_8837},
{"f_8849compiler.scm",(void*)f_8849},
{"f_8852compiler.scm",(void*)f_8852},
{"f_8855compiler.scm",(void*)f_8855},
{"f_8873compiler.scm",(void*)f_8873},
{"f_8880compiler.scm",(void*)f_8880},
{"f_8858compiler.scm",(void*)f_8858},
{"f_8861compiler.scm",(void*)f_8861},
{"f_8864compiler.scm",(void*)f_8864},
{"f_8825compiler.scm",(void*)f_8825},
{"f_8815compiler.scm",(void*)f_8815},
{"f_8798compiler.scm",(void*)f_8798},
{"f_8803compiler.scm",(void*)f_8803},
{"f_8756compiler.scm",(void*)f_8756},
{"f_8773compiler.scm",(void*)f_8773},
{"f_8760compiler.scm",(void*)f_8760},
{"f_8771compiler.scm",(void*)f_8771},
{"f_8746compiler.scm",(void*)f_8746},
{"f_8705compiler.scm",(void*)f_8705},
{"f_8714compiler.scm",(void*)f_8714},
{"f_8695compiler.scm",(void*)f_8695},
{"f_8700compiler.scm",(void*)f_8700},
{"f_8689compiler.scm",(void*)f_8689},
{"f_7161compiler.scm",(void*)f_7161},
{"f_7165compiler.scm",(void*)f_7165},
{"f_7915compiler.scm",(void*)f_7915},
{"f_7918compiler.scm",(void*)f_7918},
{"f_7922compiler.scm",(void*)f_7922},
{"f_7925compiler.scm",(void*)f_7925},
{"f_7938compiler.scm",(void*)f_7938},
{"f_8573compiler.scm",(void*)f_8573},
{"f_7942compiler.scm",(void*)f_7942},
{"f_8538compiler.scm",(void*)f_8538},
{"f_7949compiler.scm",(void*)f_7949},
{"f_8484compiler.scm",(void*)f_8484},
{"f_8487compiler.scm",(void*)f_8487},
{"f_8499compiler.scm",(void*)f_8499},
{"f_8493compiler.scm",(void*)f_8493},
{"f_7952compiler.scm",(void*)f_7952},
{"f_7955compiler.scm",(void*)f_7955},
{"f_8467compiler.scm",(void*)f_8467},
{"f_8459compiler.scm",(void*)f_8459},
{"f_8427compiler.scm",(void*)f_8427},
{"f_8433compiler.scm",(void*)f_8433},
{"f_7958compiler.scm",(void*)f_7958},
{"f_8389compiler.scm",(void*)f_8389},
{"f_8398compiler.scm",(void*)f_8398},
{"f_8401compiler.scm",(void*)f_8401},
{"f_7961compiler.scm",(void*)f_7961},
{"f_8290compiler.scm",(void*)f_8290},
{"f_8308compiler.scm",(void*)f_8308},
{"f_8351compiler.scm",(void*)f_8351},
{"f_8376compiler.scm",(void*)f_8376},
{"f_8372compiler.scm",(void*)f_8372},
{"f_8358compiler.scm",(void*)f_8358},
{"f_8361compiler.scm",(void*)f_8361},
{"f_8312compiler.scm",(void*)f_8312},
{"f_8318compiler.scm",(void*)f_8318},
{"f_7964compiler.scm",(void*)f_7964},
{"f_8268compiler.scm",(void*)f_8268},
{"f_8254compiler.scm",(void*)f_8254},
{"f_8261compiler.scm",(void*)f_8261},
{"f_8242compiler.scm",(void*)f_8242},
{"f_8227compiler.scm",(void*)f_8227},
{"f_7967compiler.scm",(void*)f_7967},
{"f_8139compiler.scm",(void*)f_8139},
{"f_8213compiler.scm",(void*)f_8213},
{"f_8145compiler.scm",(void*)f_8145},
{"f_8203compiler.scm",(void*)f_8203},
{"f_8195compiler.scm",(void*)f_8195},
{"f_8191compiler.scm",(void*)f_8191},
{"f_8148compiler.scm",(void*)f_8148},
{"f_8151compiler.scm",(void*)f_8151},
{"f_7970compiler.scm",(void*)f_7970},
{"f_7998compiler.scm",(void*)f_7998},
{"f_8019compiler.scm",(void*)f_8019},
{"f_8040compiler.scm",(void*)f_8040},
{"f_8046compiler.scm",(void*)f_8046},
{"f_7973compiler.scm",(void*)f_7973},
{"f_7979compiler.scm",(void*)f_7979},
{"f_7983compiler.scm",(void*)f_7983},
{"f_7928compiler.scm",(void*)f_7928},
{"f_7932compiler.scm",(void*)f_7932},
{"f_7935compiler.scm",(void*)f_7935},
{"f_7890compiler.scm",(void*)f_7890},
{"f_7900compiler.scm",(void*)f_7900},
{"f_7908compiler.scm",(void*)f_7908},
{"f_7876compiler.scm",(void*)f_7876},
{"f_7884compiler.scm",(void*)f_7884},
{"f_7755compiler.scm",(void*)f_7755},
{"f_7761compiler.scm",(void*)f_7761},
{"f_7174compiler.scm",(void*)f_7174},
{"f_7196compiler.scm",(void*)f_7196},
{"f_7717compiler.scm",(void*)f_7717},
{"f_7711compiler.scm",(void*)f_7711},
{"f_7684compiler.scm",(void*)f_7684},
{"f_7693compiler.scm",(void*)f_7693},
{"f_7678compiler.scm",(void*)f_7678},
{"f_7603compiler.scm",(void*)f_7603},
{"f_7632compiler.scm",(void*)f_7632},
{"f_7647compiler.scm",(void*)f_7647},
{"f_7651compiler.scm",(void*)f_7651},
{"f_7638compiler.scm",(void*)f_7638},
{"f_7606compiler.scm",(void*)f_7606},
{"f_7629compiler.scm",(void*)f_7629},
{"f_7609compiler.scm",(void*)f_7609},
{"f_7612compiler.scm",(void*)f_7612},
{"f_7615compiler.scm",(void*)f_7615},
{"f_7493compiler.scm",(void*)f_7493},
{"f_7585compiler.scm",(void*)f_7585},
{"f_7500compiler.scm",(void*)f_7500},
{"f_7575compiler.scm",(void*)f_7575},
{"f_7579compiler.scm",(void*)f_7579},
{"f_7503compiler.scm",(void*)f_7503},
{"f_7506compiler.scm",(void*)f_7506},
{"f_7560compiler.scm",(void*)f_7560},
{"f_7509compiler.scm",(void*)f_7509},
{"f_7512compiler.scm",(void*)f_7512},
{"f_7545compiler.scm",(void*)f_7545},
{"f_7515compiler.scm",(void*)f_7515},
{"f_7542compiler.scm",(void*)f_7542},
{"f_7518compiler.scm",(void*)f_7518},
{"f_7449compiler.scm",(void*)f_7449},
{"f_7468compiler.scm",(void*)f_7468},
{"f_7453compiler.scm",(void*)f_7453},
{"f_7466compiler.scm",(void*)f_7466},
{"f_7457compiler.scm",(void*)f_7457},
{"f_7382compiler.scm",(void*)f_7382},
{"f_7387compiler.scm",(void*)f_7387},
{"f_7414compiler.scm",(void*)f_7414},
{"f_7417compiler.scm",(void*)f_7417},
{"f_7420compiler.scm",(void*)f_7420},
{"f_7405compiler.scm",(void*)f_7405},
{"f_7310compiler.scm",(void*)f_7310},
{"f_7358compiler.scm",(void*)f_7358},
{"f_7321compiler.scm",(void*)f_7321},
{"f_7340compiler.scm",(void*)f_7340},
{"f_7287compiler.scm",(void*)f_7287},
{"f_7290compiler.scm",(void*)f_7290},
{"f_7251compiler.scm",(void*)f_7251},
{"f_7208compiler.scm",(void*)f_7208},
{"f_7239compiler.scm",(void*)f_7239},
{"f_7767compiler.scm",(void*)f_7767},
{"f_7780compiler.scm",(void*)f_7780},
{"f_7840compiler.scm",(void*)f_7840},
{"f_7789compiler.scm",(void*)f_7789},
{"f_7792compiler.scm",(void*)f_7792},
{"f_7795compiler.scm",(void*)f_7795},
{"f_7870compiler.scm",(void*)f_7870},
{"f_7167compiler.scm",(void*)f_7167},
{"f_7152compiler.scm",(void*)f_7152},
{"f_7143compiler.scm",(void*)f_7143},
{"f_7134compiler.scm",(void*)f_7134},
{"f_7125compiler.scm",(void*)f_7125},
{"f_7116compiler.scm",(void*)f_7116},
{"f_7107compiler.scm",(void*)f_7107},
{"f_7098compiler.scm",(void*)f_7098},
{"f_7089compiler.scm",(void*)f_7089},
{"f_7080compiler.scm",(void*)f_7080},
{"f_7071compiler.scm",(void*)f_7071},
{"f_7065compiler.scm",(void*)f_7065},
{"f_7059compiler.scm",(void*)f_7059},
{"f_6384compiler.scm",(void*)f_6384},
{"f_7031compiler.scm",(void*)f_7031},
{"f_6946compiler.scm",(void*)f_6946},
{"f_6952compiler.scm",(void*)f_6952},
{"f_6972compiler.scm",(void*)f_6972},
{"f_6990compiler.scm",(void*)f_6990},
{"f_6999compiler.scm",(void*)f_6999},
{"f_7025compiler.scm",(void*)f_7025},
{"f_7013compiler.scm",(void*)f_7013},
{"f_6966compiler.scm",(void*)f_6966},
{"f_6930compiler.scm",(void*)f_6930},
{"f_6936compiler.scm",(void*)f_6936},
{"f_6805compiler.scm",(void*)f_6805},
{"f_6809compiler.scm",(void*)f_6809},
{"f_6812compiler.scm",(void*)f_6812},
{"f_6866compiler.scm",(void*)f_6866},
{"f_6862compiler.scm",(void*)f_6862},
{"f_6858compiler.scm",(void*)f_6858},
{"f_6837compiler.scm",(void*)f_6837},
{"f_6843compiler.scm",(void*)f_6843},
{"f_6854compiler.scm",(void*)f_6854},
{"f_6847compiler.scm",(void*)f_6847},
{"f_6835compiler.scm",(void*)f_6835},
{"f_6431compiler.scm",(void*)f_6431},
{"f_6453compiler.scm",(void*)f_6453},
{"f_6719compiler.scm",(void*)f_6719},
{"f_6876compiler.scm",(void*)f_6876},
{"f_6879compiler.scm",(void*)f_6879},
{"f_6924compiler.scm",(void*)f_6924},
{"f_6920compiler.scm",(void*)f_6920},
{"f_6916compiler.scm",(void*)f_6916},
{"f_6912compiler.scm",(void*)f_6912},
{"f_6684compiler.scm",(void*)f_6684},
{"f_6710compiler.scm",(void*)f_6710},
{"f_6634compiler.scm",(void*)f_6634},
{"f_6643compiler.scm",(void*)f_6643},
{"f_6671compiler.scm",(void*)f_6671},
{"f_6667compiler.scm",(void*)f_6667},
{"f_6621compiler.scm",(void*)f_6621},
{"f_6559compiler.scm",(void*)f_6559},
{"f_6582compiler.scm",(void*)f_6582},
{"f_6596compiler.scm",(void*)f_6596},
{"f_6465compiler.scm",(void*)f_6465},
{"f_6468compiler.scm",(void*)f_6468},
{"f_6544compiler.scm",(void*)f_6544},
{"f_6540compiler.scm",(void*)f_6540},
{"f_6536compiler.scm",(void*)f_6536},
{"f_6509compiler.scm",(void*)f_6509},
{"f_6520compiler.scm",(void*)f_6520},
{"f_6524compiler.scm",(void*)f_6524},
{"f_6503compiler.scm",(void*)f_6503},
{"f_6469compiler.scm",(void*)f_6469},
{"f_6480compiler.scm",(void*)f_6480},
{"f_6387compiler.scm",(void*)f_6387},
{"f_6391compiler.scm",(void*)f_6391},
{"f_6414compiler.scm",(void*)f_6414},
{"f_6425compiler.scm",(void*)f_6425},
{"f_6408compiler.scm",(void*)f_6408},
{"f_6294compiler.scm",(void*)f_6294},
{"f_6326compiler.scm",(void*)f_6326},
{"f_6345compiler.scm",(void*)f_6345},
{"f_6368compiler.scm",(void*)f_6368},
{"f_6351compiler.scm",(void*)f_6351},
{"f_6297compiler.scm",(void*)f_6297},
{"f_6303compiler.scm",(void*)f_6303},
{"f_6313compiler.scm",(void*)f_6313},
{"f_6213compiler.scm",(void*)f_6213},
{"f_6217compiler.scm",(void*)f_6217},
{"f_6220compiler.scm",(void*)f_6220},
{"f_6223compiler.scm",(void*)f_6223},
{"f_6239compiler.scm",(void*)f_6239},
{"f_6226compiler.scm",(void*)f_6226},
{"f_6229compiler.scm",(void*)f_6229},
{"f_6232compiler.scm",(void*)f_6232},
{"f_6176compiler.scm",(void*)f_6176},
{"f_6199compiler.scm",(void*)f_6199},
{"f_6186compiler.scm",(void*)f_6186},
{"f_6189compiler.scm",(void*)f_6189},
{"f_6192compiler.scm",(void*)f_6192},
{"f_6139compiler.scm",(void*)f_6139},
{"f_6162compiler.scm",(void*)f_6162},
{"f_6149compiler.scm",(void*)f_6149},
{"f_6152compiler.scm",(void*)f_6152},
{"f_6155compiler.scm",(void*)f_6155},
{"f_6094compiler.scm",(void*)f_6094},
{"f_6101compiler.scm",(void*)f_6101},
{"f_6107compiler.scm",(void*)f_6107},
{"f_6049compiler.scm",(void*)f_6049},
{"f_6056compiler.scm",(void*)f_6056},
{"f_6062compiler.scm",(void*)f_6062},
{"f_5895compiler.scm",(void*)f_5895},
{"f_6043compiler.scm",(void*)f_6043},
{"f_5899compiler.scm",(void*)f_5899},
{"f_5902compiler.scm",(void*)f_5902},
{"f_5905compiler.scm",(void*)f_5905},
{"f_5908compiler.scm",(void*)f_5908},
{"f_5911compiler.scm",(void*)f_5911},
{"f_6037compiler.scm",(void*)f_6037},
{"f_5921compiler.scm",(void*)f_5921},
{"f_6012compiler.scm",(void*)f_6012},
{"f_6020compiler.scm",(void*)f_6020},
{"f_5924compiler.scm",(void*)f_5924},
{"f_5964compiler.scm",(void*)f_5964},
{"f_5967compiler.scm",(void*)f_5967},
{"f_5986compiler.scm",(void*)f_5986},
{"f_5982compiler.scm",(void*)f_5982},
{"f_5978compiler.scm",(void*)f_5978},
{"f_5957compiler.scm",(void*)f_5957},
{"f_5947compiler.scm",(void*)f_5947},
{"f_5935compiler.scm",(void*)f_5935},
{"f_5886compiler.scm",(void*)f_5886},
{"f_5877compiler.scm",(void*)f_5877},
{"f_5868compiler.scm",(void*)f_5868},
{"f_5859compiler.scm",(void*)f_5859},
{"f_5850compiler.scm",(void*)f_5850},
{"f_5841compiler.scm",(void*)f_5841},
{"f_5832compiler.scm",(void*)f_5832},
{"f_5823compiler.scm",(void*)f_5823},
{"f_5814compiler.scm",(void*)f_5814},
{"f_5805compiler.scm",(void*)f_5805},
{"f_5796compiler.scm",(void*)f_5796},
{"f_5787compiler.scm",(void*)f_5787},
{"f_5778compiler.scm",(void*)f_5778},
{"f_5769compiler.scm",(void*)f_5769},
{"f_5760compiler.scm",(void*)f_5760},
{"f_5751compiler.scm",(void*)f_5751},
{"f_5745compiler.scm",(void*)f_5745},
{"f_5739compiler.scm",(void*)f_5739},
{"f_4776compiler.scm",(void*)f_4776},
{"f_4830compiler.scm",(void*)f_4830},
{"f_4834compiler.scm",(void*)f_4834},
{"f_5714compiler.scm",(void*)f_5714},
{"f_5690compiler.scm",(void*)f_5690},
{"f_5700compiler.scm",(void*)f_5700},
{"f_5695compiler.scm",(void*)f_5695},
{"f_5662compiler.scm",(void*)f_5662},
{"f_5668compiler.scm",(void*)f_5668},
{"f_5644compiler.scm",(void*)f_5644},
{"f_5648compiler.scm",(void*)f_5648},
{"f_5616compiler.scm",(void*)f_5616},
{"f_5623compiler.scm",(void*)f_5623},
{"f_5599compiler.scm",(void*)f_5599},
{"f_5525compiler.scm",(void*)f_5525},
{"f_5529compiler.scm",(void*)f_5529},
{"f_5512compiler.scm",(void*)f_5512},
{"f_5504compiler.scm",(void*)f_5504},
{"f_5508compiler.scm",(void*)f_5508},
{"f_5349compiler.scm",(void*)f_5349},
{"f_5459compiler.scm",(void*)f_5459},
{"f_5448compiler.scm",(void*)f_5448},
{"f_5452compiler.scm",(void*)f_5452},
{"f_5419compiler.scm",(void*)f_5419},
{"f_5394compiler.scm",(void*)f_5394},
{"f_5369compiler.scm",(void*)f_5369},
{"f_5336compiler.scm",(void*)f_5336},
{"f_5288compiler.scm",(void*)f_5288},
{"f_5297compiler.scm",(void*)f_5297},
{"f_5295compiler.scm",(void*)f_5295},
{"f_5198compiler.scm",(void*)f_5198},
{"f_5176compiler.scm",(void*)f_5176},
{"f_5180compiler.scm",(void*)f_5180},
{"f_5149compiler.scm",(void*)f_5149},
{"f_5153compiler.scm",(void*)f_5153},
{"f_5135compiler.scm",(void*)f_5135},
{"f_5139compiler.scm",(void*)f_5139},
{"f_5114compiler.scm",(void*)f_5114},
{"f_5100compiler.scm",(void*)f_5100},
{"f_5017compiler.scm",(void*)f_5017},
{"f_5000compiler.scm",(void*)f_5000},
{"f_5004compiler.scm",(void*)f_5004},
{"f_4971compiler.scm",(void*)f_4971},
{"f_4946compiler.scm",(void*)f_4946},
{"f_4899compiler.scm",(void*)f_4899},
{"f_4929compiler.scm",(void*)f_4929},
{"f_4905compiler.scm",(void*)f_4905},
{"f_4908compiler.scm",(void*)f_4908},
{"f_4915compiler.scm",(void*)f_4915},
{"f_4911compiler.scm",(void*)f_4911},
{"f_4849compiler.scm",(void*)f_4849},
{"f_4852compiler.scm",(void*)f_4852},
{"f_4886compiler.scm",(void*)f_4886},
{"f_4880compiler.scm",(void*)f_4880},
{"f_4861compiler.scm",(void*)f_4861},
{"f_4870compiler.scm",(void*)f_4870},
{"f_4878compiler.scm",(void*)f_4878},
{"f_4864compiler.scm",(void*)f_4864},
{"f_4868compiler.scm",(void*)f_4868},
{"f_4840compiler.scm",(void*)f_4840},
{"f_4779compiler.scm",(void*)f_4779},
{"f_4802compiler.scm",(void*)f_4802},
{"f_4792compiler.scm",(void*)f_4792},
{"f_1976compiler.scm",(void*)f_1976},
{"f_4771compiler.scm",(void*)f_4771},
{"f_4734compiler.scm",(void*)f_4734},
{"f_4737compiler.scm",(void*)f_4737},
{"f_4752compiler.scm",(void*)f_4752},
{"f_4761compiler.scm",(void*)f_4761},
{"f_4765compiler.scm",(void*)f_4765},
{"f_4748compiler.scm",(void*)f_4748},
{"f_4721compiler.scm",(void*)f_4721},
{"f_4727compiler.scm",(void*)f_4727},
{"f_2166compiler.scm",(void*)f_2166},
{"f_2212compiler.scm",(void*)f_2212},
{"f_4582compiler.scm",(void*)f_4582},
{"f_4697compiler.scm",(void*)f_4697},
{"f_4597compiler.scm",(void*)f_4597},
{"f_4684compiler.scm",(void*)f_4684},
{"f_4606compiler.scm",(void*)f_4606},
{"f_4609compiler.scm",(void*)f_4609},
{"f_4618compiler.scm",(void*)f_4618},
{"f_4640compiler.scm",(void*)f_4640},
{"f_4633compiler.scm",(void*)f_4633},
{"f_4585compiler.scm",(void*)f_4585},
{"f_4588compiler.scm",(void*)f_4588},
{"f_2239compiler.scm",(void*)f_2239},
{"f_2245compiler.scm",(void*)f_2245},
{"f_4564compiler.scm",(void*)f_4564},
{"f_2248compiler.scm",(void*)f_2248},
{"f_2255compiler.scm",(void*)f_2255},
{"f_2264compiler.scm",(void*)f_2264},
{"f_2273compiler.scm",(void*)f_2273},
{"f_2407compiler.scm",(void*)f_2407},
{"f_4484compiler.scm",(void*)f_4484},
{"f_4490compiler.scm",(void*)f_4490},
{"f_4395compiler.scm",(void*)f_4395},
{"f_4455compiler.scm",(void*)f_4455},
{"f_4355compiler.scm",(void*)f_4355},
{"f_4359compiler.scm",(void*)f_4359},
{"f_4365compiler.scm",(void*)f_4365},
{"f_4379compiler.scm",(void*)f_4379},
{"f_4368compiler.scm",(void*)f_4368},
{"f_3991compiler.scm",(void*)f_3991},
{"f_4339compiler.scm",(void*)f_4339},
{"f_4013compiler.scm",(void*)f_4013},
{"f_4304compiler.scm",(void*)f_4304},
{"f_4016compiler.scm",(void*)f_4016},
{"f_4027compiler.scm",(void*)f_4027},
{"f_4254compiler.scm",(void*)f_4254},
{"f_4298compiler.scm",(void*)f_4298},
{"f_4294compiler.scm",(void*)f_4294},
{"f_4290compiler.scm",(void*)f_4290},
{"f_4278compiler.scm",(void*)f_4278},
{"f_4047compiler.scm",(void*)f_4047},
{"f_4126compiler.scm",(void*)f_4126},
{"f_4103compiler.scm",(void*)f_4103},
{"f_4098compiler.scm",(void*)f_4098},
{"f_4061compiler.scm",(void*)f_4061},
{"f_4051compiler.scm",(void*)f_4051},
{"f_4035compiler.scm",(void*)f_4035},
{"f_4023compiler.scm",(void*)f_4023},
{"f_3981compiler.scm",(void*)f_3981},
{"f_3958compiler.scm",(void*)f_3958},
{"f_3956compiler.scm",(void*)f_3956},
{"f_3885compiler.scm",(void*)f_3885},
{"f_3903compiler.scm",(void*)f_3903},
{"f_3925compiler.scm",(void*)f_3925},
{"f_3931compiler.scm",(void*)f_3931},
{"f_3909compiler.scm",(void*)f_3909},
{"f_3916compiler.scm",(void*)f_3916},
{"f_3891compiler.scm",(void*)f_3891},
{"f_3897compiler.scm",(void*)f_3897},
{"f_3883compiler.scm",(void*)f_3883},
{"f_3821compiler.scm",(void*)f_3821},
{"f_3832compiler.scm",(void*)f_3832},
{"f_3842compiler.scm",(void*)f_3842},
{"f_3845compiler.scm",(void*)f_3845},
{"f_3849compiler.scm",(void*)f_3849},
{"f_3835compiler.scm",(void*)f_3835},
{"f_3760compiler.scm",(void*)f_3760},
{"f_3764compiler.scm",(void*)f_3764},
{"f_3802compiler.scm",(void*)f_3802},
{"f_3768compiler.scm",(void*)f_3768},
{"f_3782compiler.scm",(void*)f_3782},
{"f_3780compiler.scm",(void*)f_3780},
{"f_3742compiler.scm",(void*)f_3742},
{"f_3750compiler.scm",(void*)f_3750},
{"f_3615compiler.scm",(void*)f_3615},
{"f_3618compiler.scm",(void*)f_3618},
{"f_3624compiler.scm",(void*)f_3624},
{"f_3703compiler.scm",(void*)f_3703},
{"f_3680compiler.scm",(void*)f_3680},
{"f_3655compiler.scm",(void*)f_3655},
{"f_3663compiler.scm",(void*)f_3663},
{"f_3651compiler.scm",(void*)f_3651},
{"f_3647compiler.scm",(void*)f_3647},
{"f_3639compiler.scm",(void*)f_3639},
{"f_3540compiler.scm",(void*)f_3540},
{"f_3549compiler.scm",(void*)f_3549},
{"f_3588compiler.scm",(void*)f_3588},
{"f_3580compiler.scm",(void*)f_3580},
{"f_3552compiler.scm",(void*)f_3552},
{"f_3572compiler.scm",(void*)f_3572},
{"f_3564compiler.scm",(void*)f_3564},
{"f_3520compiler.scm",(void*)f_3520},
{"f_3466compiler.scm",(void*)f_3466},
{"f_3469compiler.scm",(void*)f_3469},
{"f_3472compiler.scm",(void*)f_3472},
{"f_3476compiler.scm",(void*)f_3476},
{"f_3480compiler.scm",(void*)f_3480},
{"f_3399compiler.scm",(void*)f_3399},
{"f_3411compiler.scm",(void*)f_3411},
{"f_3384compiler.scm",(void*)f_3384},
{"f_3371compiler.scm",(void*)f_3371},
{"f_3358compiler.scm",(void*)f_3358},
{"f_3345compiler.scm",(void*)f_3345},
{"f_3332compiler.scm",(void*)f_3332},
{"f_3265compiler.scm",(void*)f_3265},
{"f_3284compiler.scm",(void*)f_3284},
{"f_3311compiler.scm",(void*)f_3311},
{"f_3315compiler.scm",(void*)f_3315},
{"f_3304compiler.scm",(void*)f_3304},
{"f_3278compiler.scm",(void*)f_3278},
{"f_3252compiler.scm",(void*)f_3252},
{"f_3237compiler.scm",(void*)f_3237},
{"f_3210compiler.scm",(void*)f_3210},
{"f_3214compiler.scm",(void*)f_3214},
{"f_3189compiler.scm",(void*)f_3189},
{"f_3160compiler.scm",(void*)f_3160},
{"f_3164compiler.scm",(void*)f_3164},
{"f_3131compiler.scm",(void*)f_3131},
{"f_3135compiler.scm",(void*)f_3135},
{"f_2957compiler.scm",(void*)f_2957},
{"f_2966compiler.scm",(void*)f_2966},
{"f_2969compiler.scm",(void*)f_2969},
{"f_3077compiler.scm",(void*)f_3077},
{"f_3106compiler.scm",(void*)f_3106},
{"f_3110compiler.scm",(void*)f_3110},
{"f_3080compiler.scm",(void*)f_3080},
{"f_3086compiler.scm",(void*)f_3086},
{"f_3099compiler.scm",(void*)f_3099},
{"f_3089compiler.scm",(void*)f_3089},
{"f_2972compiler.scm",(void*)f_2972},
{"f_3067compiler.scm",(void*)f_3067},
{"f_2975compiler.scm",(void*)f_2975},
{"f_3030compiler.scm",(void*)f_3030},
{"f_3061compiler.scm",(void*)f_3061},
{"f_3053compiler.scm",(void*)f_3053},
{"f_2987compiler.scm",(void*)f_2987},
{"f_3018compiler.scm",(void*)f_3018},
{"f_3006compiler.scm",(void*)f_3006},
{"f_2919compiler.scm",(void*)f_2919},
{"f_2945compiler.scm",(void*)f_2945},
{"f_2922compiler.scm",(void*)f_2922},
{"f_2937compiler.scm",(void*)f_2937},
{"f_2935compiler.scm",(void*)f_2935},
{"f_2925compiler.scm",(void*)f_2925},
{"f_2928compiler.scm",(void*)f_2928},
{"f_2642compiler.scm",(void*)f_2642},
{"f_2869compiler.scm",(void*)f_2869},
{"f_2880compiler.scm",(void*)f_2880},
{"f_2874compiler.scm",(void*)f_2874},
{"f_2651compiler.scm",(void*)f_2651},
{"f_2656compiler.scm",(void*)f_2656},
{"f_2660compiler.scm",(void*)f_2660},
{"f_2866compiler.scm",(void*)f_2866},
{"f_2663compiler.scm",(void*)f_2663},
{"f_2858compiler.scm",(void*)f_2858},
{"f_2666compiler.scm",(void*)f_2666},
{"f_2669compiler.scm",(void*)f_2669},
{"f_2856compiler.scm",(void*)f_2856},
{"f_2849compiler.scm",(void*)f_2849},
{"f_2672compiler.scm",(void*)f_2672},
{"f_2678compiler.scm",(void*)f_2678},
{"f_2687compiler.scm",(void*)f_2687},
{"f_2693compiler.scm",(void*)f_2693},
{"f_2707compiler.scm",(void*)f_2707},
{"f_2791compiler.scm",(void*)f_2791},
{"f_2787compiler.scm",(void*)f_2787},
{"f_2783compiler.scm",(void*)f_2783},
{"f_2740compiler.scm",(void*)f_2740},
{"f_2747compiler.scm",(void*)f_2747},
{"f_2697compiler.scm",(void*)f_2697},
{"f_2568compiler.scm",(void*)f_2568},
{"f_2574compiler.scm",(void*)f_2574},
{"f_2577compiler.scm",(void*)f_2577},
{"f_2630compiler.scm",(void*)f_2630},
{"f_2580compiler.scm",(void*)f_2580},
{"f_2583compiler.scm",(void*)f_2583},
{"f_2610compiler.scm",(void*)f_2610},
{"f_2618compiler.scm",(void*)f_2618},
{"f_2590compiler.scm",(void*)f_2590},
{"f_2604compiler.scm",(void*)f_2604},
{"f_2598compiler.scm",(void*)f_2598},
{"f_2594compiler.scm",(void*)f_2594},
{"f_2454compiler.scm",(void*)f_2454},
{"f_2464compiler.scm",(void*)f_2464},
{"f_2475compiler.scm",(void*)f_2475},
{"f_2549compiler.scm",(void*)f_2549},
{"f_2559compiler.scm",(void*)f_2559},
{"f_2540compiler.scm",(void*)f_2540},
{"f_2514compiler.scm",(void*)f_2514},
{"f_2528compiler.scm",(void*)f_2528},
{"f_2526compiler.scm",(void*)f_2526},
{"f_2502compiler.scm",(void*)f_2502},
{"f_2479compiler.scm",(void*)f_2479},
{"f_2486compiler.scm",(void*)f_2486},
{"f_2469compiler.scm",(void*)f_2469},
{"f_2448compiler.scm",(void*)f_2448},
{"f_2416compiler.scm",(void*)f_2416},
{"f_2419compiler.scm",(void*)f_2419},
{"f_2430compiler.scm",(void*)f_2430},
{"f_2424compiler.scm",(void*)f_2424},
{"f_2422compiler.scm",(void*)f_2422},
{"f_2374compiler.scm",(void*)f_2374},
{"f_2386compiler.scm",(void*)f_2386},
{"f_2390compiler.scm",(void*)f_2390},
{"f_2342compiler.scm",(void*)f_2342},
{"f_2296compiler.scm",(void*)f_2296},
{"f_2303compiler.scm",(void*)f_2303},
{"f_2307compiler.scm",(void*)f_2307},
{"f_2311compiler.scm",(void*)f_2311},
{"f_2179compiler.scm",(void*)f_2179},
{"f_2200compiler.scm",(void*)f_2200},
{"f_2194compiler.scm",(void*)f_2194},
{"f_2148compiler.scm",(void*)f_2148},
{"f_2157compiler.scm",(void*)f_2157},
{"f_2057compiler.scm",(void*)f_2057},
{"f_2061compiler.scm",(void*)f_2061},
{"f_2074compiler.scm",(void*)f_2074},
{"f_2122compiler.scm",(void*)f_2122},
{"f_2132compiler.scm",(void*)f_2132},
{"f_2092compiler.scm",(void*)f_2092},
{"f_2102compiler.scm",(void*)f_2102},
{"f_2015compiler.scm",(void*)f_2015},
{"f_2022compiler.scm",(void*)f_2022},
{"f_1991compiler.scm",(void*)f_1991},
{"f_1997compiler.scm",(void*)f_1997},
{"f_1979compiler.scm",(void*)f_1979},
{"f_1905compiler.scm",(void*)f_1905},
{"f_1974compiler.scm",(void*)f_1974},
{"f_1909compiler.scm",(void*)f_1909},
{"f_1967compiler.scm",(void*)f_1967},
{"f_1912compiler.scm",(void*)f_1912},
{"f_1960compiler.scm",(void*)f_1960},
{"f_1915compiler.scm",(void*)f_1915},
{"f_1919compiler.scm",(void*)f_1919},
{"f_1923compiler.scm",(void*)f_1923},
{"f_1953compiler.scm",(void*)f_1953},
{"f_1926compiler.scm",(void*)f_1926},
{"f_1946compiler.scm",(void*)f_1946},
{"f_1929compiler.scm",(void*)f_1929},
{"f_1939compiler.scm",(void*)f_1939},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
