/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-11 10:06
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[579];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10104)
static void C_ccall f_10104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10961)
static void C_fcall f_10961(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10967)
static void C_ccall f_10967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10194)
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10950)
static void C_ccall f_10950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10947)
static void C_ccall f_10947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10860)
static void C_fcall f_10860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10924)
static void C_ccall f_10924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10937)
static void C_ccall f_10937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10918)
static void C_ccall f_10918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10908)
static void C_ccall f_10908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10881)
static void C_fcall f_10881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10832)
static void C_fcall f_10832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10835)
static void C_ccall f_10835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_fcall f_10801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10792)
static void C_fcall f_10792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10770)
static void C_ccall f_10770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10758)
static void C_ccall f_10758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10703)
static void C_fcall f_10703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10628)
static void C_ccall f_10628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10644)
static void C_ccall f_10644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10632)
static void C_ccall f_10632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10565)
static void C_ccall f_10565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10596)
static void C_ccall f_10596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_fcall f_10577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10556)
static void C_ccall f_10556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10457)
static void C_ccall f_10457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10498)
static void C_ccall f_10498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10505)
static void C_fcall f_10505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10509)
static void C_ccall f_10509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_ccall f_10388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10397)
static void C_fcall f_10397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_fcall f_10391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10328)
static void C_ccall f_10328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_ccall f_10324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_ccall f_10317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10300)
static void C_ccall f_10300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10296)
static void C_ccall f_10296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10252)
static void C_ccall f_10252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_fcall f_10107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10111)
static void C_ccall f_10111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_ccall f_10136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10141)
static void C_fcall f_10141(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10151)
static void C_fcall f_10151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10161)
static void C_ccall f_10161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10973)
static void C_fcall f_10973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10980)
static void C_ccall f_10980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11042)
static void C_ccall f_11042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11032)
static void C_ccall f_11032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10992)
static void C_ccall f_10992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11067)
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11083)
static void C_ccall f_11083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11090)
static void C_ccall f_11090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11097)
static void C_ccall f_11097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11071)
static void C_ccall f_11071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11081)
static void C_ccall f_11081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11053)
static void C_fcall f_11053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11061)
static void C_ccall f_11061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11099)
static void C_fcall f_11099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10077)
static void C_ccall f_10077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10068)
static void C_ccall f_10068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10050)
static void C_ccall f_10050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10032)
static void C_ccall f_10032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10014)
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10005)
static void C_ccall f_10005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9969)
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9960)
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9951)
static void C_ccall f_9951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9942)
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9915)
static void C_ccall f_9915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9906)
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9897)
static void C_ccall f_9897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_ccall f_9801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9816)
static void C_ccall f_9816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9641)
static void C_fcall f_9641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8952)
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8971)
static void C_fcall f_8971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_fcall f_9004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9520)
static void C_fcall f_9520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9371)
static void C_ccall f_9371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9447)
static void C_ccall f_9447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9433)
static void C_ccall f_9433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_ccall f_9100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9104)
static void C_ccall f_9104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9347)
static void C_ccall f_9347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_fcall f_9128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_ccall f_9131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9275)
static void C_ccall f_9275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9247)
static void C_ccall f_9247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9234)
static void C_ccall f_9234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9216)
static void C_ccall f_9216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9201)
static void C_ccall f_9201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9073)
static void C_ccall f_9073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9065)
static void C_ccall f_9065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8989)
static void C_ccall f_8989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_fcall f_9653(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9676)
static void C_ccall f_9676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_fcall f_8618(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8637)
static void C_fcall f_8637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8877)
static void C_ccall f_8877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9730)
static void C_fcall f_9730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9756)
static void C_ccall f_9756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_fcall f_9742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9721)
static void C_ccall f_9721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9690)
static void C_ccall f_9690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8893)
static void C_ccall f_8893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8904)
static void C_ccall f_8904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8841)
static void C_ccall f_8841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_fcall f_8739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_fcall f_8757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_fcall f_8775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8763)
static void C_ccall f_8763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8727)
static void C_fcall f_8727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8717)
static void C_fcall f_8717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8658)
static void C_ccall f_8658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_fcall f_8607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8616)
static void C_ccall f_8616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_fcall f_8597(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_fcall f_8591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_ccall f_7824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7844)
static void C_ccall f_7844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_fcall f_8440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8386)
static void C_fcall f_8386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_fcall f_8401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_fcall f_8395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_fcall f_8335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_fcall f_8291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_fcall f_8303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8192)
static void C_fcall f_8192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8260)
static void C_fcall f_8260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_ccall f_8214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8220)
static void C_fcall f_8220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_fcall f_8156(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8163)
static void C_ccall f_8163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8144)
static void C_fcall f_8144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_fcall f_8129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8105)
static void C_ccall f_8105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8097)
static void C_ccall f_8097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_fcall f_8050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_fcall f_7900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7921)
static void C_fcall f_7921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_fcall f_7942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_fcall f_7881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7837)
static void C_fcall f_7837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_fcall f_7792(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7778)
static void C_fcall f_7778(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7657)
static void C_fcall f_7657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7076)
static void C_fcall f_7076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7098)
static void C_fcall f_7098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_fcall f_7534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_fcall f_7549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_ccall f_7553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_fcall f_7540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_fcall f_7414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_fcall f_7447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_fcall f_7417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7370)
static void C_ccall f_7370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_fcall f_7289(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_fcall f_7669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7682)
static void C_fcall f_7682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_fcall f_7691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7772)
static void C_fcall f_7772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7069)
static C_word C_fcall f_7069(C_word t0);
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6848)
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6854)
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_fcall f_6832(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6707)
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_ccall f_6749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_fcall f_6333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6355)
static void C_fcall f_6355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_fcall f_6621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_fcall f_6461(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_fcall f_6289(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6293)
static void C_ccall f_6293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6228)
static void C_fcall f_6228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6205)
static void C_fcall f_6205(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6119)
static void C_fcall f_6119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_fcall f_6122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_fcall f_6125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6091)
static void C_ccall f_6091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_fcall f_5823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4750)
static void C_fcall f_4750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_fcall f_5424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_fcall f_5118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_fcall f_4835(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_fcall f_4699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_fcall f_4641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2114)
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_fcall f_4517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_fcall f_4538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_fcall f_4275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_fcall f_4224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_fcall f_4174(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static C_word C_fcall f_4023(C_word *a,C_word t0);
C_noret_decl(f_4018)
static void C_fcall f_4018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static C_word C_fcall f_3981(C_word *a,C_word t0);
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_fcall f_3575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_fcall f_3000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_fcall f_2769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_fcall f_2619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_fcall f_2672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_fcall f_2629(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_fcall f_2434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_fcall f_1988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_fcall f_1957(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1945)
static C_word C_fcall f_1945(C_word t0,C_word t1);
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10961)
static void C_fcall trf_10961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10961(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10961(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10194)
static void C_fcall trf_10194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10194(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10194(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10860)
static void C_fcall trf_10860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10860(t0,t1);}

C_noret_decl(trf_10881)
static void C_fcall trf_10881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10881(t0,t1);}

C_noret_decl(trf_10832)
static void C_fcall trf_10832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10832(t0,t1);}

C_noret_decl(trf_10801)
static void C_fcall trf_10801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10801(t0,t1);}

C_noret_decl(trf_10792)
static void C_fcall trf_10792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10792(t0,t1);}

C_noret_decl(trf_10703)
static void C_fcall trf_10703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10703(t0,t1);}

C_noret_decl(trf_10577)
static void C_fcall trf_10577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10577(t0,t1);}

C_noret_decl(trf_10505)
static void C_fcall trf_10505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10505(t0,t1);}

C_noret_decl(trf_10397)
static void C_fcall trf_10397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10397(t0,t1);}

C_noret_decl(trf_10391)
static void C_fcall trf_10391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10391(t0,t1);}

C_noret_decl(trf_10107)
static void C_fcall trf_10107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10107(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10107(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10141)
static void C_fcall trf_10141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10141(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10141(t0,t1,t2,t3);}

C_noret_decl(trf_10151)
static void C_fcall trf_10151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10151(t0,t1);}

C_noret_decl(trf_10973)
static void C_fcall trf_10973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10973(t0,t1,t2);}

C_noret_decl(trf_11067)
static void C_fcall trf_11067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11067(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11067(t0,t1,t2);}

C_noret_decl(trf_11053)
static void C_fcall trf_11053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11053(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11053(t0,t1,t2);}

C_noret_decl(trf_11099)
static void C_fcall trf_11099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11099(t0,t1);}

C_noret_decl(trf_9641)
static void C_fcall trf_9641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9641(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9641(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8952)
static void C_fcall trf_8952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8952(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8952(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8971)
static void C_fcall trf_8971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8971(t0,t1);}

C_noret_decl(trf_9004)
static void C_fcall trf_9004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9004(t0,t1);}

C_noret_decl(trf_9520)
static void C_fcall trf_9520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9520(t0,t1);}

C_noret_decl(trf_9128)
static void C_fcall trf_9128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9128(t0,t1);}

C_noret_decl(trf_9653)
static void C_fcall trf_9653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9653(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9653(t0,t1,t2,t3);}

C_noret_decl(trf_8618)
static void C_fcall trf_8618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8618(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8618(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8637)
static void C_fcall trf_8637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8637(t0,t1);}

C_noret_decl(trf_9730)
static void C_fcall trf_9730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9730(t0,t1);}

C_noret_decl(trf_9742)
static void C_fcall trf_9742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9742(t0,t1);}

C_noret_decl(trf_8739)
static void C_fcall trf_8739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8739(t0,t1);}

C_noret_decl(trf_8757)
static void C_fcall trf_8757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8757(t0,t1);}

C_noret_decl(trf_8775)
static void C_fcall trf_8775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8775(t0,t1);}

C_noret_decl(trf_8727)
static void C_fcall trf_8727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8727(t0,t1);}

C_noret_decl(trf_8717)
static void C_fcall trf_8717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8717(t0,t1);}

C_noret_decl(trf_8607)
static void C_fcall trf_8607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8607(t0,t1,t2);}

C_noret_decl(trf_8597)
static void C_fcall trf_8597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8597(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8597(t0,t1,t2,t3);}

C_noret_decl(trf_8591)
static void C_fcall trf_8591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8591(t0,t1,t2,t3);}

C_noret_decl(trf_8440)
static void C_fcall trf_8440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8440(t0,t1);}

C_noret_decl(trf_8386)
static void C_fcall trf_8386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8386(t0,t1);}

C_noret_decl(trf_8401)
static void C_fcall trf_8401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8401(t0,t1);}

C_noret_decl(trf_8395)
static void C_fcall trf_8395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8395(t0,t1);}

C_noret_decl(trf_8335)
static void C_fcall trf_8335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8335(t0,t1);}

C_noret_decl(trf_8291)
static void C_fcall trf_8291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8291(t0,t1);}

C_noret_decl(trf_8303)
static void C_fcall trf_8303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8303(t0,t1);}

C_noret_decl(trf_8192)
static void C_fcall trf_8192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8192(t0,t1);}

C_noret_decl(trf_8260)
static void C_fcall trf_8260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8260(t0,t1);}

C_noret_decl(trf_8220)
static void C_fcall trf_8220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8220(t0,t1);}

C_noret_decl(trf_8156)
static void C_fcall trf_8156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8156(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8156(t0,t1);}

C_noret_decl(trf_8144)
static void C_fcall trf_8144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8144(t0,t1);}

C_noret_decl(trf_8129)
static void C_fcall trf_8129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8129(t0,t1);}

C_noret_decl(trf_8050)
static void C_fcall trf_8050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8050(t0,t1);}

C_noret_decl(trf_7900)
static void C_fcall trf_7900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7900(t0,t1);}

C_noret_decl(trf_7921)
static void C_fcall trf_7921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7921(t0,t1);}

C_noret_decl(trf_7942)
static void C_fcall trf_7942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7942(t0,t1);}

C_noret_decl(trf_7881)
static void C_fcall trf_7881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7881(t0,t1);}

C_noret_decl(trf_7837)
static void C_fcall trf_7837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7837(t0,t1);}

C_noret_decl(trf_7792)
static void C_fcall trf_7792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7792(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7792(t0,t1,t2,t3);}

C_noret_decl(trf_7778)
static void C_fcall trf_7778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7778(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7778(t0,t1,t2,t3);}

C_noret_decl(trf_7657)
static void C_fcall trf_7657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7657(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7657(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7076)
static void C_fcall trf_7076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7076(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7076(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7098)
static void C_fcall trf_7098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7098(t0,t1);}

C_noret_decl(trf_7534)
static void C_fcall trf_7534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7534(t0,t1);}

C_noret_decl(trf_7549)
static void C_fcall trf_7549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7549(t0,t1);}

C_noret_decl(trf_7540)
static void C_fcall trf_7540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7540(t0,t1);}

C_noret_decl(trf_7414)
static void C_fcall trf_7414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7414(t0,t1);}

C_noret_decl(trf_7447)
static void C_fcall trf_7447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7447(t0,t1);}

C_noret_decl(trf_7417)
static void C_fcall trf_7417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7417(t0,t1);}

C_noret_decl(trf_7289)
static void C_fcall trf_7289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7289(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7289(t0,t1,t2,t3);}

C_noret_decl(trf_7669)
static void C_fcall trf_7669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7669(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7669(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7682)
static void C_fcall trf_7682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7682(t0,t1);}

C_noret_decl(trf_7691)
static void C_fcall trf_7691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7691(t0,t1);}

C_noret_decl(trf_7772)
static void C_fcall trf_7772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7772(t0,t1,t2,t3);}

C_noret_decl(trf_6848)
static void C_fcall trf_6848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6848(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6848(t0,t1,t2,t3);}

C_noret_decl(trf_6854)
static void C_fcall trf_6854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6854(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6854(t0,t1,t2,t3);}

C_noret_decl(trf_6832)
static void C_fcall trf_6832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6832(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6832(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6707)
static void C_fcall trf_6707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6707(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6707(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6333)
static void C_fcall trf_6333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6333(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6333(t0,t1,t2,t3);}

C_noret_decl(trf_6355)
static void C_fcall trf_6355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6355(t0,t1);}

C_noret_decl(trf_6621)
static void C_fcall trf_6621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6621(t0,t1);}

C_noret_decl(trf_6461)
static void C_fcall trf_6461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6461(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6461(t0,t1,t2,t3);}

C_noret_decl(trf_6289)
static void C_fcall trf_6289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6289(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6289(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6228)
static void C_fcall trf_6228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6228(t0,t1,t2);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6199(t0,t1,t2);}

C_noret_decl(trf_6205)
static void C_fcall trf_6205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6205(t0,t1,t2);}

C_noret_decl(trf_6119)
static void C_fcall trf_6119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6119(t0,t1);}

C_noret_decl(trf_6122)
static void C_fcall trf_6122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6122(t0,t1);}

C_noret_decl(trf_6125)
static void C_fcall trf_6125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6125(t0,t1);}

C_noret_decl(trf_5823)
static void C_fcall trf_5823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5823(t0,t1);}

C_noret_decl(trf_4750)
static void C_fcall trf_4750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4750(t0,t1);}

C_noret_decl(trf_5424)
static void C_fcall trf_5424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5424(t0,t1);}

C_noret_decl(trf_5118)
static void C_fcall trf_5118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5118(t0,t1);}

C_noret_decl(trf_4835)
static void C_fcall trf_4835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4835(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4835(t0,t1);}

C_noret_decl(trf_4699)
static void C_fcall trf_4699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4699(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4699(t0,t1,t2,t3);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4712(t0,t1);}

C_noret_decl(trf_4641)
static void C_fcall trf_4641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4641(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4641(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2114)
static void C_fcall trf_2114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2114(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2114(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4517)
static void C_fcall trf_4517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4517(t0,t1);}

C_noret_decl(trf_4538)
static void C_fcall trf_4538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4538(t0,t1);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2339(t0,t1);}

C_noret_decl(trf_4275)
static void C_fcall trf_4275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4275(t0,t1);}

C_noret_decl(trf_4224)
static void C_fcall trf_4224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4224(t0,t1);}

C_noret_decl(trf_4174)
static void C_fcall trf_4174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4174(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4174(t0,t1,t2,t3);}

C_noret_decl(trf_4018)
static void C_fcall trf_4018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4018(t0,t1);}

C_noret_decl(trf_3575)
static void C_fcall trf_3575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3575(t0,t1);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3472(t0,t1);}

C_noret_decl(trf_3204)
static void C_fcall trf_3204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3204(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3204(t0,t1,t2);}

C_noret_decl(trf_3000)
static void C_fcall trf_3000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3000(t0,t1);}

C_noret_decl(trf_2769)
static void C_fcall trf_2769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2769(t0,t1);}

C_noret_decl(trf_2619)
static void C_fcall trf_2619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2619(t0,t1);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2639(t0,t1);}

C_noret_decl(trf_2672)
static void C_fcall trf_2672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2672(t0,t1);}

C_noret_decl(trf_2629)
static void C_fcall trf_2629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2629(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2629(t0,t1,t2);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2386(t0,t1,t2);}

C_noret_decl(trf_2434)
static void C_fcall trf_2434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2434(t0,t1);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2023(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1988)
static void C_fcall trf_1988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1988(t0,t1);}

C_noret_decl(trf_1957)
static void C_fcall trf_1957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1957(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1957(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5602)){
C_save(t1);
C_rereclaim2(5602*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,579);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],28,"\010compilerinitialize-compiler");
lf[94]=C_h_intern(&lf[94],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],11,"make-vector");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],25,"\010compilermake-random-name");
lf[99]=C_h_intern(&lf[99],12,"profile-info");
lf[100]=C_h_intern(&lf[100],32,"\010compilercanonicalize-expression");
lf[101]=C_h_intern(&lf[101],23,"\010compilerset-real-name!");
lf[102]=C_h_intern(&lf[102],8,"for-each");
lf[103]=C_h_intern(&lf[103],5,"quote");
lf[104]=C_h_intern(&lf[104],15,"\004coreinline_ref");
lf[105]=C_h_intern(&lf[105],36,"\010compilerforeign-type-convert-result");
lf[106]=C_h_intern(&lf[106],30,"\010compilerfinish-foreign-result");
lf[107]=C_h_intern(&lf[107],27,"\010compilerfinal-foreign-type");
lf[108]=C_h_intern(&lf[108],19,"\004coreinline_loc_ref");
lf[109]=C_h_intern(&lf[109],18,"\003syshash-table-ref");
lf[110]=C_h_intern(&lf[110],21,"\003sysalias-global-hook");
lf[111]=C_h_intern(&lf[111],12,"syntax-error");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[113]=C_h_intern(&lf[113],24,"\003syssyntax-error-culprit");
lf[114]=C_h_intern(&lf[114],2,"if");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],16,"\003syscheck-syntax");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[119]=C_h_intern(&lf[119],10,"\004corecheck");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[121]=C_h_intern(&lf[121],14,"\004coreimmutable");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],6,"gensym");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],6,"cadadr");
lf[126]=C_h_intern(&lf[126],14,"\004coreundefined");
lf[127]=C_h_intern(&lf[127],23,"\004corerequire-for-syntax");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[129]=C_h_intern(&lf[129],10,"lset-union");
lf[130]=C_h_intern(&lf[130],18,"hash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[237]=C_h_intern(&lf[237],29,"\010compilercollapsable-literal\077");
lf[238]=C_h_intern(&lf[238],4,"quit");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[240]=C_h_intern(&lf[240],22,"with-exception-handler");
lf[241]=C_h_intern(&lf[241],30,"call-with-current-continuation");
lf[242]=C_h_intern(&lf[242],12,"\004coredeclare");
lf[243]=C_h_intern(&lf[243],28,"\010compilerprocess-declaration");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],8,"split-at");
lf[246]=C_h_intern(&lf[246],1,"r");
lf[247]=C_h_intern(&lf[247],17,"\003sysmake-c-string");
lf[248]=C_h_intern(&lf[248],3,"and");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[252]=C_h_intern(&lf[252],25,"nonnull-unsigned-c-string");
lf[253]=C_h_intern(&lf[253],16,"nonnull-c-string");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[256]=C_h_intern(&lf[256],18,"unsigned-c-string*");
lf[257]=C_h_intern(&lf[257],9,"c-string*");
lf[258]=C_h_intern(&lf[258],13,"c-string-list");
lf[259]=C_h_intern(&lf[259],14,"c-string-list*");
lf[260]=C_h_intern(&lf[260],8,"c-string");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[262]=C_h_intern(&lf[262],17,"unsigned-c-string");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[266]=C_h_intern(&lf[266],28,"\010compilervalid-c-identifier\077");
lf[267]=C_h_intern(&lf[267],8,"location");
lf[268]=C_h_intern(&lf[268],17,"\003sysmake-locative");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[270]=C_h_intern(&lf[270],13,"\004corecallunit");
lf[271]=C_h_intern(&lf[271],14,"\004coreprimitive");
lf[272]=C_h_intern(&lf[272],37,"\010compilerupdate-line-number-database!");
lf[273]=C_h_intern(&lf[273],23,"\003sysmacroexpand-1-local");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[276]=C_h_intern(&lf[276],31,"\010compileremit-syntax-trace-info");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[278]=C_h_intern(&lf[278],4,"list");
lf[279]=C_h_intern(&lf[279],1,"t");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[281]=C_h_intern(&lf[281],4,"caar");
lf[282]=C_h_intern(&lf[282],18,"\010compilerconstant\077");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[284]=C_h_intern(&lf[284],26,"\010compilerinternal-bindings");
lf[285]=C_h_intern(&lf[285],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[286]=C_h_intern(&lf[286],7,"reverse");
lf[287]=C_h_intern(&lf[287],22,"\003sysclear-trace-buffer");
lf[288]=C_h_intern(&lf[288],26,"\010compilerdebugging-chicken");
lf[289]=C_h_intern(&lf[289],12,"pretty-print");
lf[290]=C_h_intern(&lf[290],7,"newline");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],4,"uses");
lf[294]=C_h_intern(&lf[294],29,"\010compilerstring->c-identifier");
lf[295]=C_h_intern(&lf[295],18,"\010compilerstringify");
lf[296]=C_h_intern(&lf[296],17,"register-feature!");
lf[297]=C_h_intern(&lf[297],4,"unit");
lf[298]=C_h_intern(&lf[298],5,"usage");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[300]=C_h_intern(&lf[300],15,"hash-table-set!");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-standard-bindings");
lf[302]=C_h_intern(&lf[302],34,"\010compilerdefault-extended-bindings");
lf[303]=C_h_intern(&lf[303],18,"usual-integrations");
lf[304]=C_h_intern(&lf[304],17,"lset-intersection");
lf[305]=C_h_intern(&lf[305],6,"fixnum");
lf[306]=C_h_intern(&lf[306],17,"fixnum-arithmetic");
lf[307]=C_h_intern(&lf[307],23,"\005matchset-error-control");
lf[308]=C_h_intern(&lf[308],12,"\000unspecified");
lf[309]=C_h_intern(&lf[309],4,"safe");
lf[310]=C_h_intern(&lf[310],18,"interrupts-enabled");
lf[311]=C_h_intern(&lf[311],18,"disable-interrupts");
lf[312]=C_h_intern(&lf[312],15,"disable-warning");
lf[313]=C_h_intern(&lf[313],26,"\010compilerdisabled-warnings");
lf[314]=C_h_intern(&lf[314],12,"safe-globals");
lf[315]=C_h_intern(&lf[315],38,"no-procedure-checks-for-usual-bindings");
lf[316]=C_h_intern(&lf[316],18,"bound-to-procedure");
lf[317]=C_h_intern(&lf[317],15,"foreign-declare");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[319]=C_h_intern(&lf[319],5,"every");
lf[320]=C_h_intern(&lf[320],7,"string\077");
lf[321]=C_h_intern(&lf[321],14,"custom-declare");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[323]=C_h_intern(&lf[323],35,"\010compilerprocess-custom-declaration");
lf[324]=C_h_intern(&lf[324],9,"c-options");
lf[325]=C_h_intern(&lf[325],31,"\010compileremit-control-file-item");
lf[326]=C_h_intern(&lf[326],12,"link-options");
lf[327]=C_h_intern(&lf[327],12,"post-process");
lf[328]=C_h_intern(&lf[328],17,"string-substitute");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[330]=C_h_intern(&lf[330],24,"pathname-strip-extension");
lf[331]=C_h_intern(&lf[331],5,"block");
lf[332]=C_h_intern(&lf[332],8,"separate");
lf[333]=C_h_intern(&lf[333],20,"keep-shadowed-macros");
lf[334]=C_h_intern(&lf[334],6,"unused");
lf[335]=C_h_intern(&lf[335],3,"not");
lf[336]=C_h_intern(&lf[336],15,"lset-difference");
lf[337]=C_h_intern(&lf[337],6,"inline");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[339]=C_h_intern(&lf[339],15,"run-time-macros");
lf[340]=C_h_intern(&lf[340],25,"\003sysenable-runtime-macros");
lf[341]=C_h_intern(&lf[341],12,"block-global");
lf[342]=C_h_intern(&lf[342],4,"hide");
lf[343]=C_h_intern(&lf[343],6,"export");
lf[344]=C_h_intern(&lf[344],12,"emit-exports");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[346]=C_h_intern(&lf[346],30,"emit-external-prototypes-first");
lf[347]=C_h_intern(&lf[347],11,"lambda-lift");
lf[348]=C_h_intern(&lf[348],12,"inline-limit");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[350]=C_h_intern(&lf[350],8,"constant");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[352]=C_h_intern(&lf[352],7,"symbol\077");
lf[353]=C_h_intern(&lf[353],6,"import");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[355]=C_h_intern(&lf[355],9,"partition");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[359]=C_h_intern(&lf[359],17,"make-foreign-stub");
lf[360]=C_h_intern(&lf[360],12,"foreign-stub");
lf[361]=C_h_intern(&lf[361],13,"foreign-stub\077");
lf[362]=C_h_intern(&lf[362],20,"foreign-stub-id-set!");
lf[363]=C_h_intern(&lf[363],14,"\003sysblock-set!");
lf[364]=C_h_intern(&lf[364],15,"foreign-stub-id");
lf[365]=C_h_intern(&lf[365],29,"foreign-stub-return-type-set!");
lf[366]=C_h_intern(&lf[366],24,"foreign-stub-return-type");
lf[367]=C_h_intern(&lf[367],22,"foreign-stub-name-set!");
lf[368]=C_h_intern(&lf[368],17,"foreign-stub-name");
lf[369]=C_h_intern(&lf[369],32,"foreign-stub-argument-types-set!");
lf[370]=C_h_intern(&lf[370],27,"foreign-stub-argument-types");
lf[371]=C_h_intern(&lf[371],32,"foreign-stub-argument-names-set!");
lf[372]=C_h_intern(&lf[372],27,"foreign-stub-argument-names");
lf[373]=C_h_intern(&lf[373],22,"foreign-stub-body-set!");
lf[374]=C_h_intern(&lf[374],17,"foreign-stub-body");
lf[375]=C_h_intern(&lf[375],21,"foreign-stub-cps-set!");
lf[376]=C_h_intern(&lf[376],16,"foreign-stub-cps");
lf[377]=C_h_intern(&lf[377],26,"foreign-stub-callback-set!");
lf[378]=C_h_intern(&lf[378],21,"foreign-stub-callback");
lf[379]=C_h_intern(&lf[379],28,"\010compilercreate-foreign-stub");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[383]=C_h_intern(&lf[383],37,"\010compilerestimate-foreign-result-size");
lf[384]=C_h_intern(&lf[384],4,"stub");
lf[385]=C_h_intern(&lf[385],1,"a");
lf[386]=C_h_intern(&lf[386],13,"list-tabulate");
lf[387]=C_h_intern(&lf[387],6,"second");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[390]=C_h_intern(&lf[390],4,"cadr");
lf[391]=C_h_intern(&lf[391],3,"car");
lf[392]=C_h_intern(&lf[392],4,"void");
lf[393]=C_h_intern(&lf[393],24,"\003sysline-number-database");
lf[394]=C_h_intern(&lf[394],31,"\010compilerperform-cps-conversion");
lf[395]=C_h_intern(&lf[395],4,"node");
lf[396]=C_h_intern(&lf[396],11,"\004corelambda");
lf[397]=C_h_intern(&lf[397],9,"\004corecall");
lf[398]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[399]=C_h_intern(&lf[399],16,"\010compilervarnode");
lf[400]=C_h_intern(&lf[400],1,"k");
lf[401]=C_h_intern(&lf[401],13,"\004corevariable");
lf[402]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[403]=C_h_intern(&lf[403],2,"f_");
lf[404]=C_h_intern(&lf[404],26,"make-foreign-callback-stub");
lf[405]=C_h_intern(&lf[405],13,"\010compilerbomb");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[407]=C_h_intern(&lf[407],15,"\004coreglobal-ref");
lf[408]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[409]=C_h_intern(&lf[409],6,"values");
lf[410]=C_h_intern(&lf[410],21,"foreign-callback-stub");
lf[411]=C_h_intern(&lf[411],22,"foreign-callback-stub\077");
lf[412]=C_h_intern(&lf[412],29,"foreign-callback-stub-id-set!");
lf[413]=C_h_intern(&lf[413],24,"foreign-callback-stub-id");
lf[414]=C_h_intern(&lf[414],31,"foreign-callback-stub-name-set!");
lf[415]=C_h_intern(&lf[415],26,"foreign-callback-stub-name");
lf[416]=C_h_intern(&lf[416],37,"foreign-callback-stub-qualifiers-set!");
lf[417]=C_h_intern(&lf[417],32,"foreign-callback-stub-qualifiers");
lf[418]=C_h_intern(&lf[418],38,"foreign-callback-stub-return-type-set!");
lf[419]=C_h_intern(&lf[419],33,"foreign-callback-stub-return-type");
lf[420]=C_h_intern(&lf[420],41,"foreign-callback-stub-argument-types-set!");
lf[421]=C_h_intern(&lf[421],36,"foreign-callback-stub-argument-types");
lf[422]=C_h_intern(&lf[422],27,"\010compileranalyze-expression");
lf[423]=C_h_intern(&lf[423],17,"\010compilercollect!");
lf[424]=C_h_intern(&lf[424],10,"references");
lf[425]=C_h_intern(&lf[425],13,"\010compilerput!");
lf[426]=C_h_intern(&lf[426],9,"undefined");
lf[427]=C_h_intern(&lf[427],7,"unknown");
lf[428]=C_h_intern(&lf[428],5,"value");
lf[429]=C_h_intern(&lf[429],12,"\010compilerget");
lf[430]=C_h_intern(&lf[430],4,"home");
lf[431]=C_h_intern(&lf[431],16,"\010compilerget-all");
lf[432]=C_h_intern(&lf[432],8,"captured");
lf[433]=C_h_intern(&lf[433],6,"global");
lf[434]=C_h_intern(&lf[434],12,"\004corerecurse");
lf[435]=C_h_intern(&lf[435],44,"\010compileroptimizable-rest-argument-operators");
lf[436]=C_h_intern(&lf[436],15,"\010compilercount!");
lf[437]=C_h_intern(&lf[437],16,"o-r/access-count");
lf[438]=C_h_intern(&lf[438],14,"rest-parameter");
lf[439]=C_h_intern(&lf[439],16,"standard-binding");
lf[440]=C_h_intern(&lf[440],10,"call-sites");
lf[441]=C_h_intern(&lf[441],18,"\004coredirect_lambda");
lf[442]=C_h_intern(&lf[442],6,"simple");
lf[443]=C_h_intern(&lf[443],28,"\010compilersimple-lambda-node\077");
lf[444]=C_h_intern(&lf[444],6,"vector");
lf[445]=C_h_intern(&lf[445],12,"contained-in");
lf[446]=C_h_intern(&lf[446],8,"contains");
lf[447]=C_h_intern(&lf[447],8,"assigned");
lf[448]=C_h_intern(&lf[448],16,"assigned-locally");
lf[449]=C_h_intern(&lf[449],15,"potential-value");
lf[450]=C_h_intern(&lf[450],5,"redef");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[453]=C_h_intern(&lf[453],16,"extended-binding");
lf[454]=C_h_intern(&lf[454],9,"\004coreproc");
lf[455]=C_h_intern(&lf[455],3,"any");
lf[456]=C_h_intern(&lf[456],9,"replacing");
lf[457]=C_h_intern(&lf[457],10,"replacable");
lf[458]=C_h_intern(&lf[458],9,"removable");
lf[459]=C_h_intern(&lf[459],37,"\010compilerexpression-has-side-effects\077");
lf[460]=C_h_intern(&lf[460],21,"has-unused-parameters");
lf[461]=C_h_intern(&lf[461],13,"explicit-rest");
lf[462]=C_h_intern(&lf[462],11,"collapsable");
lf[463]=C_h_intern(&lf[463],12,"contractable");
lf[464]=C_h_intern(&lf[464],9,"inlinable");
lf[465]=C_h_intern(&lf[465],28,"\010compilerscan-free-variables");
lf[466]=C_h_intern(&lf[466],5,"boxed");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[469]=C_h_intern(&lf[469],23,"\003syshash-table-for-each");
lf[470]=C_h_intern(&lf[470],18,"\010compilerdebugging");
lf[471]=C_h_intern(&lf[471],1,"p");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[474]=C_h_intern(&lf[474],37,"\010compilerinitialize-analysis-database");
lf[475]=C_h_intern(&lf[475],35,"\010compilerperform-closure-conversion");
lf[476]=C_h_intern(&lf[476],12,"customizable");
lf[477]=C_h_intern(&lf[477],20,"node-parameters-set!");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[479]=C_h_intern(&lf[479],28,"\010compilersource-info->string");
lf[480]=C_h_intern(&lf[480],8,"toplevel");
lf[481]=C_h_intern(&lf[481],18,"captured-variables");
lf[482]=C_h_intern(&lf[482],12,"closure-size");
lf[483]=C_h_intern(&lf[483],8,"\004coreref");
lf[484]=C_h_intern(&lf[484],10,"\004coreunbox");
lf[485]=C_h_intern(&lf[485],8,"\004corebox");
lf[486]=C_h_intern(&lf[486],12,"\004coreclosure");
lf[487]=C_h_intern(&lf[487],14,"\010compilerqnode");
lf[488]=C_h_intern(&lf[488],20,"\003sysmake-lambda-info");
lf[489]=C_h_intern(&lf[489],1,"\077");
lf[490]=C_h_intern(&lf[490],8,"->string");
lf[491]=C_h_intern(&lf[491],18,"\010compilerreal-name");
lf[492]=C_h_intern(&lf[492],10,"fold-right");
lf[493]=C_h_intern(&lf[493],10,"boxed-rest");
lf[494]=C_h_intern(&lf[494],6,"filter");
lf[495]=C_h_intern(&lf[495],16,"\004coreupdatebox_i");
lf[496]=C_h_intern(&lf[496],14,"\004coreupdatebox");
lf[497]=C_h_intern(&lf[497],13,"\004coreupdate_i");
lf[498]=C_h_intern(&lf[498],11,"\004coreupdate");
lf[499]=C_h_intern(&lf[499],19,"\010compilerimmediate\077");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[501]=C_h_intern(&lf[501],11,"\004coreswitch");
lf[502]=C_h_intern(&lf[502],9,"\004corecond");
lf[503]=C_h_intern(&lf[503],16,"\004coredirect_call");
lf[504]=C_h_intern(&lf[504],11,"\004corereturn");
lf[505]=C_h_intern(&lf[505],1,"o");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[507]=C_h_intern(&lf[507],16,"\003sysmake-promise");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[511]=C_h_intern(&lf[511],19,"make-lambda-literal");
lf[512]=C_h_intern(&lf[512],14,"lambda-literal");
lf[513]=C_h_intern(&lf[513],15,"lambda-literal\077");
lf[514]=C_h_intern(&lf[514],22,"lambda-literal-id-set!");
lf[515]=C_h_intern(&lf[515],17,"lambda-literal-id");
lf[516]=C_h_intern(&lf[516],28,"lambda-literal-external-set!");
lf[517]=C_h_intern(&lf[517],23,"lambda-literal-external");
lf[518]=C_h_intern(&lf[518],29,"lambda-literal-arguments-set!");
lf[519]=C_h_intern(&lf[519],24,"lambda-literal-arguments");
lf[520]=C_h_intern(&lf[520],34,"lambda-literal-argument-count-set!");
lf[521]=C_h_intern(&lf[521],29,"lambda-literal-argument-count");
lf[522]=C_h_intern(&lf[522],33,"lambda-literal-rest-argument-set!");
lf[523]=C_h_intern(&lf[523],28,"lambda-literal-rest-argument");
lf[524]=C_h_intern(&lf[524],31,"lambda-literal-temporaries-set!");
lf[525]=C_h_intern(&lf[525],26,"lambda-literal-temporaries");
lf[526]=C_h_intern(&lf[526],37,"lambda-literal-callee-signatures-set!");
lf[527]=C_h_intern(&lf[527],32,"lambda-literal-callee-signatures");
lf[528]=C_h_intern(&lf[528],29,"lambda-literal-allocated-set!");
lf[529]=C_h_intern(&lf[529],24,"lambda-literal-allocated");
lf[530]=C_h_intern(&lf[530],35,"lambda-literal-directly-called-set!");
lf[531]=C_h_intern(&lf[531],30,"lambda-literal-directly-called");
lf[532]=C_h_intern(&lf[532],32,"lambda-literal-closure-size-set!");
lf[533]=C_h_intern(&lf[533],27,"lambda-literal-closure-size");
lf[534]=C_h_intern(&lf[534],27,"lambda-literal-looping-set!");
lf[535]=C_h_intern(&lf[535],22,"lambda-literal-looping");
lf[536]=C_h_intern(&lf[536],32,"lambda-literal-customizable-set!");
lf[537]=C_h_intern(&lf[537],27,"lambda-literal-customizable");
lf[538]=C_h_intern(&lf[538],38,"lambda-literal-rest-argument-mode-set!");
lf[539]=C_h_intern(&lf[539],33,"lambda-literal-rest-argument-mode");
lf[540]=C_h_intern(&lf[540],24,"lambda-literal-body-set!");
lf[541]=C_h_intern(&lf[541],19,"lambda-literal-body");
lf[542]=C_h_intern(&lf[542],26,"lambda-literal-direct-set!");
lf[543]=C_h_intern(&lf[543],21,"lambda-literal-direct");
lf[544]=C_h_intern(&lf[544],36,"\010compilerprepare-for-code-generation");
lf[545]=C_h_intern(&lf[545],14,"\004coreimmediate");
lf[546]=C_h_intern(&lf[546],3,"fix");
lf[547]=C_h_intern(&lf[547],4,"bool");
lf[548]=C_h_intern(&lf[548],4,"char");
lf[549]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[550]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[552]=C_h_intern(&lf[552],36,"\010compilermake-block-variable-literal");
lf[553]=C_h_intern(&lf[553],36,"\010compilerblock-variable-literal-name");
lf[554]=C_h_intern(&lf[554],32,"\010compilerblock-variable-literal\077");
lf[555]=C_h_intern(&lf[555],10,"list-index");
lf[556]=C_h_intern(&lf[556],11,"\004coreglobal");
lf[557]=C_h_intern(&lf[557],10,"\004corelocal");
lf[558]=C_h_intern(&lf[558],12,"\004coreliteral");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[561]=C_h_intern(&lf[561],4,"none");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[564]=C_h_intern(&lf[564],7,"butlast");
lf[565]=C_h_intern(&lf[565],9,"\004corebind");
lf[566]=C_h_intern(&lf[566],13,"\004coresetlocal");
lf[567]=C_h_intern(&lf[567],16,"\004coresetglobal_i");
lf[568]=C_h_intern(&lf[568],14,"\004coresetglobal");
lf[569]=C_h_intern(&lf[569],1,"=");
lf[570]=C_h_intern(&lf[570],4,"type");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[573]=C_h_intern(&lf[573],20,"\010compilerbig-fixnum\077");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[578]=C_h_intern(&lf[578],14,"make-parameter");
C_register_lf2(lf,579,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1757 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1760 in k1757 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1763 in k1760 in k1757 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 311  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[578]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1877,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1942,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4696,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[359]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5641,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5647,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5653,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5662,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5671,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5680,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5689,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5698,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5707,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5716,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5734,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5743,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5752,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5761,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5779,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5788,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5797,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5951,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5996,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6041,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6078,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6115,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6196,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[394]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6286,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6961,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6967,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6973,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6982,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6991,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7000,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7009,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7018,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7027,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7036,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7045,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7054,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7063,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[475]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8588,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[511]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9822,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9828,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9834,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9843,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9852,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9861,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9870,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9879,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9888,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9897,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9906,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9915,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9924,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9933,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9942,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9951,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9960,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9969,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9978,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9987,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9996,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10005,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10014,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10023,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10032,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10041,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10050,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10059,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10068,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10077,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10086,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10095,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10104,tmp=(C_word)a,a+=2,tmp));
t162=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t162+1)))(2,t162,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10104,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11099,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11053,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11067,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10973,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10141,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10107,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10194,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10961,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11161,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2304 debugging */
t37=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[471],lf[577]);}

/* k11159 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2305 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10194(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11162 in k11159 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2306 debugging */
t3=C_retrieve(lf[470]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[505],lf[576],((C_word*)((C_word*)t0)[2])[1]);}

/* k11165 in k11162 in k11159 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2307 debugging */
t3=C_retrieve(lf[470]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[505],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11168 in k11165 in k11162 in k11159 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2308 debugging */
t3=C_retrieve(lf[470]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[505],lf[574],((C_word*)((C_word*)t0)[2])[1]);}

/* k11171 in k11168 in k11165 in k11162 in k11159 in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2309 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10961(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10961,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10967,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a10966 in mapwalk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10967,3,t0,t1,t2);}
/* compiler.scm: 2262 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10194(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10194,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[126]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[454]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[401]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2096 walk-var */
t16=((C_word*)t0)[16];
f_10107(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[407]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2099 walk-global */
t17=((C_word*)t0)[15];
f_10141(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[503]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10252,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2103 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_10961(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10272,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2107 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_10961(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[104]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10296,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10300,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2110 estimate-foreign-result-size */
t22=C_retrieve(lf[383]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[108]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10324,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10328,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2114 estimate-foreign-result-size */
t23=C_retrieve(lf[383]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[486]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10345,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2119 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10961(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[485]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10372,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2123 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[496]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10388,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2127 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10961(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[396]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[441]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[441]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10444,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2147 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[485],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10628,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2204 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10669,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2210 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[397]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2234 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[569]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[434]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10832,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10832(t32,t31);}
else{
t30=t29;
f_10832(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10860,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10947,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2245 big-fixnum? */
t33=C_retrieve(lf[573]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10860(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10950,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2259 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_10961(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10948 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10950,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10945 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10860(t2,(C_word)C_i_not(t1));}

/* k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10860,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2246 immediate-literal */
f_11099(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[305],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10881,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10908,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2249 big-fixnum? */
t5=C_retrieve(lf[573]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10881(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10918,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2255 literal */
t4=((C_word*)t0)[2];
f_10973(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2256 immediate? */
t3=C_retrieve(lf[499]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10922 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10924,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2256 immediate-literal */
f_11099(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10937,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2257 literal */
t3=((C_word*)t0)[2];
f_10973(t3,t2,((C_word*)t0)[3]);}}

/* k10935 in k10922 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10937,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[558],t2,C_SCHEME_END_OF_LIST));}

/* k10916 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10918,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[558],t2,C_SCHEME_END_OF_LIST));}

/* k10906 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10881(t2,(C_word)C_i_not(t1));}

/* k10879 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2250 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[570],lf[571],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2254 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[572],((C_word*)t0)[4]);}}

/* k10882 in k10879 in k10858 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2253 immediate-literal */
f_11099(((C_word*)t0)[2],t2);}

/* k10830 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10832,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10835,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2241 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10961(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10833 in k10830 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10835,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10787 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10789,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10801,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10801(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10801(t6,C_SCHEME_FALSE);}}

/* k10799 in k10787 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10792(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10792(t2,C_SCHEME_UNDEFINED);}}

/* k10790 in k10787 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10792,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10795,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2237 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10961(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10793 in k10790 in k10787 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10795,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10669,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10685,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2212 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10194(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10758,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10758(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10758(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10758(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10770,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2218 get */
t8=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[439]);}}}}}

/* k10768 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10758(2,t2,t1);}
else{
/* compiler.scm: 2219 get */
t2=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[453]);}}

/* k10756 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10758,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[103]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2221 immediate? */
t8=C_retrieve(lf[499]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10697(2,t6,C_SCHEME_FALSE);}}

/* k10695 in k10756 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10697,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10703(t6,t5);}
else{
t4=t3;
f_10703(t4,C_SCHEME_UNDEFINED);}}

/* k10701 in k10695 in k10756 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10703,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[567]:lf[568]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10727,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2227 blockvar-literal */
t4=((C_word*)t0)[4];
f_11067(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2228 literal */
t4=((C_word*)t0)[2];
f_10973(t4,t3,((C_word*)t0)[3]);}}

/* k10725 in k10701 in k10695 in k10756 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10727,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10719,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2230 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10194(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10717 in k10725 in k10701 in k10695 in k10756 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10719,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10683 in k10667 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[566],((C_word*)t0)[2],t2));}

/* k10626 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10632,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2205 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10638 in k10626 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10644,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2205 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10642 in k10638 in k10626 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2205 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10194(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10630 in k10626 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10632,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[565],((C_word*)t0)[2],t2));}

/* a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10444,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10565,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2153 get */
t8=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[424]);}
else{
t7=t6;
f_10451(2,t7,C_SCHEME_FALSE);}}

/* k10563 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10571,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2154 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447]);}

/* k10569 in k10563 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10451(2,t2,lf[278]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10596,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2155 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[493]);}}

/* k10594 in k10569 in k10563 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10577(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10577(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10575 in k10569 in k10563 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10451(2,t2,lf[561]);}
else{
/* compiler.scm: 2156 get */
t2=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[438]);}}

/* k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10556,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[561],t1);
if(C_truep(t5)){
/* compiler.scm: 2160 butlast */
t6=C_retrieve(lf[564]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10556(2,t6,((C_word*)t0)[7]);}}

/* k10554 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2157 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10194(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10457,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[561]);
if(C_truep(t3)){
/* compiler.scm: 2165 debugging */
t4=C_retrieve(lf[470]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[505],lf[562],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[444]);
if(C_truep(t4)){
/* compiler.scm: 2166 debugging */
t5=C_retrieve(lf[470]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[505],lf[563],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10457(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2168 bomb */
t4=C_retrieve(lf[405]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[560],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10460(2,t4,C_SCHEME_UNDEFINED);}}

/* k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10482,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10498,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2180 get */
t7=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[482]);}

/* k10496 in k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10498,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10505(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10524,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2184 debugging */
t7=C_retrieve(lf[470]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[505],lf[559],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10505(t6,C_SCHEME_FALSE);}}}

/* k10522 in k10496 in k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10505(t2,C_SCHEME_TRUE);}

/* k10503 in k10496 in k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10505,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10509(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2186 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[476]);}}

/* k10507 in k10503 in k10496 in k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2170 make-lambda-literal */
t2=C_retrieve(lf[511]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10480 in k10458 in k10455 in k10452 in k10449 in a10443 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10482,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[395],lf[454],t9,C_SCHEME_END_OF_LIST));}

/* k10386 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10391,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10397,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[401],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10397(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10397(t6,C_SCHEME_FALSE);}}

/* k10395 in k10386 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10391(t4,lf[495]);}
else{
t2=((C_word*)t0)[3];
f_10391(t2,((C_word*)t0)[2]);}}

/* k10389 in k10386 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10391,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10370 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10372,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[485],((C_word*)t0)[2],t2));}

/* k10343 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10345,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],lf[486],((C_word*)t0)[2],t1));}

/* k10326 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2114 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10322 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10324,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10317,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2115 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_10961(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10315 in k10322 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10317,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10298 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2110 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10294 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10296,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10270 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10272,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10250 in walk in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10252,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10107,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10111,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2064 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10109 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10111,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[557],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2065 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10124 in k10109 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10126,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10136,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2065 literal */
t3=((C_word*)t0)[5];
f_10973(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2066 walk-global */
t2=((C_word*)t0)[3];
f_10141(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10134 in k10124 in k10109 in walk-var in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10136,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[558],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10141(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10141,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10145(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10145(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10145(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10145(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10186,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2073 get */
t9=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[439]);}}}}}

/* k10184 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10145(2,t2,t1);}
else{
/* compiler.scm: 2074 get */
t2=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[453]);}}

/* k10143 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10145,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10151(t6,t5);}
else{
t4=t3;
f_10151(t4,C_SCHEME_UNDEFINED);}}

/* k10149 in k10143 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10151,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10161,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2080 blockvar-literal */
t3=((C_word*)t0)[3];
f_11067(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2081 literal */
t3=((C_word*)t0)[2];
f_10973(t3,t2,((C_word*)t0)[5]);}}

/* k10159 in k10149 in k10143 in walk-global in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10161,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[556],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_10973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10973,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2265 immediate? */
t4=C_retrieve(lf[499]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10978 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10980,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2265 immediate-literal */
f_11099(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2268 list-index */
t4=C_retrieve(lf[555]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_10992(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11032,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2274 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11042,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2276 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11040 in k10978 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2277 new-literal */
t2=((C_word*)t0)[3];
f_11053(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11030 in k10978 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11032,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11005 in k10978 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11006,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10990 in k10978 in literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2270 new-literal */
t2=((C_word*)t0)[3];
f_11053(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11067,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11071,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2285 list-index */
t5=C_retrieve(lf[555]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11082 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11083,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11090,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2287 block-variable-literal? */
t4=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11088 in a11082 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11090,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2288 block-variable-literal-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11095 in k11088 in a11082 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11069 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11071,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11081,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2290 make-block-variable-literal */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11079 in k11069 in blockvar-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2290 new-literal */
t2=((C_word*)t0)[3];
f_11053(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11053,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11061,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2281 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11059 in new-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_11099(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11099,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[395],lf[126],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11112,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11112(2,t6,(C_word)C_a_i_list(&a,2,lf[546],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11112(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11112(2,t6,(C_word)C_a_i_list(&a,2,lf[548],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11112(2,t6,lf[549]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11112(2,t6,lf[550]);}
else{
/* compiler.scm: 2301 bomb */
t6=C_retrieve(lf[405]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[551]);}}}}}}}

/* k11110 in immediate-literal in ##compiler#prepare-for-code-generation in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11112,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],lf[545],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10095,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10086,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10077,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10068,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10059,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10050,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10041,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10032,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10023,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10014,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_10005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10005,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9996,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9987,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9978,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9969,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9960,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9951,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9942,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9933,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9924,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9915,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9906,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9897,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9888,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9879,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9870,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9861,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9852,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9843,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[512]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9834,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[512]);
/* compiler.scm: 2034 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9828,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[512]));}

/* make-lambda-literal in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9822,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[512],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8588,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8591,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8597,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8607,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8618,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9653,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8952,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9641,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9789,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2022 debugging */
t22=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[471],lf[510]);}

/* k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2023 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8618(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2024 debugging */
t3=C_retrieve(lf[470]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[505],lf[509],((C_word*)((C_word*)t0)[2])[1]);}

/* k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2025 debugging */
t3=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[471],lf[508]);}

/* k9796 in k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2026 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8952(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9799 in k9796 in k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9804,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9804(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9814,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9816,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2028 ##sys#make-promise */
t6=*((C_word*)lf[507]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9815 in k9799 in k9796 in k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9816,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9812 in k9799 in k9796 in k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2028 debugging */
t2=C_retrieve(lf[470]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[505],lf[506],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9802 in k9799 in k9796 in k9793 in k9790 in k9787 in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9641,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9647,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9646 in maptransform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9647,3,t0,t1,t2);}
/* compiler.scm: 1994 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8952(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8952,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8971(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t13)){
t14=t12;
f_8971(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[454]);
t15=t12;
f_8971(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[407])));}}}

/* k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[401]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8983,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1869 ref-var */
f_9653(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[114]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9004(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[397]);
if(C_truep(t5)){
t6=t4;
f_9004(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_9004(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_9004(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[270]);
if(C_truep(t8)){
t9=t4;
f_9004(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[104]);
if(C_truep(t9)){
t10=t4;
f_9004(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_9004(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[501]);
if(C_truep(t11)){
t12=t4;
f_9004(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t12)){
t13=t4;
f_9004(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t13)){
t14=t4;
f_9004(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[434]);
if(C_truep(t14)){
t15=t4;
f_9004(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[504]);
if(C_truep(t15)){
t16=t4;
f_9004(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[108]);
t17=t4;
f_9004(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9004,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1877 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9641(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9025,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1881 test */
t5=((C_word*)t0)[4];
f_8591(t5,t4,t3,lf[466]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[396]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[441]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1897 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9371,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[103],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1957 immediate? */
t13=C_retrieve(lf[499]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9371(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[395],lf[454],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9520,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9527,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9531,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1988 ##sys#make-lambda-info */
t16=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9520(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 1991 bomb */
t7=C_retrieve(lf[405]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[500]);}}}}}}

/* k9529 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1988 qnode */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9525 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9527,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9520(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9518 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9520,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[486],((C_word*)t0)[2],t2));}

/* k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9371,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1959 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9386,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1961 test */
t3=((C_word*)t0)[3];
f_8591(t3,t2,((C_word*)t0)[2],lf[466]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1973 test */
t3=((C_word*)t0)[3];
f_8591(t3,t2,((C_word*)t0)[2],lf[466]);}}

/* k9445 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9447,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[495]:lf[496]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1977 varnode */
t4=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9477,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1981 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8952(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9475 in k9445 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[175],((C_word*)t0)[2],t2));}

/* k9458 in k9445 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9464,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1978 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8952(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9462 in k9458 in k9445 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9464,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9384 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9386,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[495]:lf[496]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1965 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[497]:lf[498]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1971 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9431 in k9384 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9437,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1972 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8952(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9435 in k9431 in k9384 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9437,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9411 in k9384 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[483],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9409,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1966 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8952(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9407 in k9411 in k9384 in k9375 in k9369 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9409,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9100,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1900 filter */
t7=C_retrieve(lf[494]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9348 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9349,3,t0,t1,t2);}
/* compiler.scm: 1900 test */
t3=((C_word*)t0)[2];
f_8591(t3,t1,t2,lf[466]);}

/* k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9347,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[123]),t1);}

/* k9345 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1901 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1902 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[124]);}

/* k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[480]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1904 test */
t4=((C_word*)t0)[2];
f_8591(t4,t3,t2,lf[481]);}

/* k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9116,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1905 test */
t4=((C_word*)t0)[2];
f_8591(t4,t3,((C_word*)t0)[17],lf[482]);}

/* k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9128(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9128(t4,C_SCHEME_FALSE);}}

/* k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9128,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1911 test */
t4=((C_word*)t0)[2];
f_8591(t4,t3,((C_word*)t0)[6],lf[466]);}
else{
t3=t2;
f_9131(2,t3,C_SCHEME_FALSE);}}

/* k9312 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9314,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1912 test */
t3=((C_word*)t0)[2];
f_8591(t3,t2,((C_word*)t0)[6],lf[438]);}
else{
t2=((C_word*)t0)[4];
f_9131(2,t2,C_SCHEME_FALSE);}}

/* k9315 in k9312 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1913 put! */
t4=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[493],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9131(2,t2,C_SCHEME_FALSE);}}

/* k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9131,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9290,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9289 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9290,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9273 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1923 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9271,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1932 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8952(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9216,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9230,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1937 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9208(2,t3,t1);}}

/* k9228 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9234,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9236,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9235 in k9228 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9247,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1938 varnode */
t5=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9245 in a9235 in k9228 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9247,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[485],C_SCHEME_END_OF_LIST,t2));}

/* k9232 in k9228 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1934 fold-right */
t2=C_retrieve(lf[492]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9215 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9216,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[395],lf[152],t5,t6));}

/* k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9208,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9154,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9192 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9193,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1941 varnode */
t4=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9199 in a9192 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1941 ref-var */
f_9653(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9168,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9172,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9176,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9184,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1949 real-name */
t7=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9157(2,t3,t1);}}

/* k9182 in k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9184,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[489]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1949 ->string */
t5=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9174 in k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1948 ##sys#make-lambda-info */
t2=C_retrieve(lf[488]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9170 in k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1947 qnode */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9166 in k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9168,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1944 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9155 in k9152 in k9206 in k9203 in k9269 in k9129 in k9126 in k9120 in k9114 in k9108 in k9105 in k9102 in a9099 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9157,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[486],((C_word*)t0)[2],t2));}

/* k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1882 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9026 in k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9044,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1886 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8952(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1893 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9641(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9078 in k9026 in k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t1));}

/* k9042 in k9026 in k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1889 varnode */
t4=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9071 in k9042 in k9026 in k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9073,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[485],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9065,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1890 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8952(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9063 in k9071 in k9042 in k9026 in k9023 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9065,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t4));}

/* k9008 in k9002 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9010,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k8981 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8989,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1870 test */
t3=((C_word*)t0)[3];
f_8591(t3,t2,((C_word*)t0)[2],lf[466]);}

/* k8987 in k8981 in k8969 in transform in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8989,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[484],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9653(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9653,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9660,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1998 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9658 in ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9660,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9676,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2001 varnode */
t5=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9674 in k9658 in ref-var in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[483],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8618(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8618,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8637(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[401]);
if(C_truep(t13)){
t14=t12;
f_8637(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t14)){
t15=t12;
f_8637(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[454]);
if(C_truep(t15)){
t16=t12;
f_8637(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[271]);
t17=t12;
f_8637(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[407])));}}}}}

/* k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8637,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8648,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8658,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1806 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[397]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[401],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8717,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8727,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8841,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1822 test */
t19=((C_word*)t0)[3];
f_8591(t19,t18,t16,lf[427]);}
else{
t15=t14;
f_8727(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8717(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[396]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[441]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1846 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8916,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8915 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8916,3,t0,t1,t2);}
/* compiler.scm: 1856 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8618(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8877,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[480]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9692,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9692(3,t14,t10,t6);}

/* walk in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9692,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[401]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9721,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2013 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[103]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9730(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[126]);
if(C_truep(t12)){
t13=t11;
f_9730(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[271]);
if(C_truep(t13)){
t14=t11;
f_9730(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[454]);
if(C_truep(t14)){
t15=t11;
f_9730(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[104]);
t16=t11;
f_9730(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[407])));}}}}}}

/* k9728 in walk in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9730,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9742,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9756,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2017 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9742(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9754 in k9728 in walk in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9742(t3,t2);}

/* k9740 in k9728 in walk in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_9742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2018 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9692(3,t3,((C_word*)t0)[2],t2);}

/* k9719 in walk in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9688 in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_9690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9690,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8890,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1852 put! */
t5=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[482],t3);}

/* k8888 in k9688 in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8893,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1853 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[481],((C_word*)t0)[2]);}

/* k8891 in k8888 in k9688 in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8893,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8904,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1854 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8902 in k8891 in k8888 in k9688 in a8876 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1854 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8618(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8839 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8733(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1822 test */
t2=((C_word*)t0)[3];
f_8591(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[428]);}}

/* k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8739(t4,(C_word)C_eqp(lf[396],t3));}
else{
t3=t2;
f_8739(t3,C_SCHEME_FALSE);}}

/* k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1827 test */
t6=((C_word*)t0)[2];
f_8591(t6,t5,((C_word*)t0)[6],lf[424]);}
else{
t2=((C_word*)t0)[8];
f_8727(t2,C_SCHEME_END_OF_LIST);}}

/* k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8754,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1828 test */
t3=((C_word*)t0)[2];
f_8591(t3,t2,((C_word*)t0)[7],lf[440]);}

/* k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8757(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8757(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8757(t3,C_SCHEME_FALSE);}}

/* k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8757,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8760,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8775,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8775(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8775(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8775(t4,C_SCHEME_FALSE);}}

/* k8773 in k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8782,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1836 source-info->string */
t3=C_retrieve(lf[479]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8760(2,t2,C_SCHEME_UNDEFINED);}}

/* k8780 in k8773 in k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1834 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[478],t1);}

/* k8758 in k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1837 register-direct-call! */
t3=((C_word*)t0)[2];
f_8607(t3,t2,((C_word*)t0)[6]);}

/* k8761 in k8758 in k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1838 register-customizable! */
t3=((C_word*)t0)[3];
f_8597(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8766(2,t3,C_SCHEME_UNDEFINED);}}

/* k8764 in k8761 in k8758 in k8755 in k8752 in k8749 in k8737 in k8731 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8727(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8725 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8727,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8717(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8715 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8717,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1815 node-parameters-set! */
t3=C_retrieve(lf[477]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8698 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8704 in k8698 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8705,3,t0,t1,t2);}
/* compiler.scm: 1843 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8618(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8657 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8658,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8674 in a8657 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8675,3,t0,t1,t2);}
/* compiler.scm: 1807 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8618(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8660 in a8657 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8662,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8673,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1808 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8671 in k8660 in a8657 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1808 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8618(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8647 in k8635 in gather in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8648,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1806 split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8607,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1793 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),C_retrieve(lf[63]),t2);}

/* k8614 in register-direct-call! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8597(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8597,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8602,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1788 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8600 in register-customizable! in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1789 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[476],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8591,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1785 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7063,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7067,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1406 make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7069,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7772,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7076,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7657,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7778,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7792,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1576 initialize-analysis-database */
t18=C_retrieve(lf[474]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1579 debugging */
t3=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[471],lf[473]);}

/* k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7820,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1581 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7076(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1584 debugging */
t3=C_retrieve(lf[470]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[471],lf[472]);}

/* k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1585 ##sys#hash-table-for-each */
t4=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7840,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7844,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8475,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8474 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8475,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[424]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[432]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[449]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[440]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[447]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[426]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[433]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[428]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[437]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[438]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7844,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8440,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8440(t10,(C_word)C_eqp(lf[396],t9));}
else{
t7=t6;
f_8440(t7,C_SCHEME_FALSE);}}

/* k8438 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1631 set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7851(2,t2,C_SCHEME_UNDEFINED);}}

/* k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8386(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8386(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8386(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8386(t4,C_SCHEME_FALSE);}}

/* k8384 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8386,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1640 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[468],((C_word*)t0)[3]);}
else{
t3=t2;
f_8389(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7854(2,t2,C_SCHEME_UNDEFINED);}}

/* k8387 in k8384 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8401(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8401(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8401(t5,C_SCHEME_FALSE);}}}

/* k8399 in k8387 in k8384 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8395(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8395(t2,C_SCHEME_FALSE);}}

/* k8393 in k8387 in k8384 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1644 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[467],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7854(2,t2,C_SCHEME_UNDEFINED);}}

/* k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1648 quick-put! */
f_7778(t2,((C_word*)t0)[8],lf[466],C_SCHEME_TRUE);}
else{
t4=t2;
f_7857(2,t4,C_SCHEME_UNDEFINED);}}

/* k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[396],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8329(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8361,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8369,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1657 scan-free-variables */
t13=C_retrieve(lf[465]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8329(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7860(2,t3,C_SCHEME_UNDEFINED);}}

/* k8367 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1657 every */
t2=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8360 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8361,3,t0,t1,t2);}
/* compiler.scm: 1657 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[433]);}

/* k8327 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8329,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8335(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8335(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7860(2,t2,C_SCHEME_UNDEFINED);}}

/* k8333 in k8327 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1659 quick-put! */
f_7778(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1660 quick-put! */
f_7778(((C_word*)t0)[3],((C_word*)t0)[2],lf[464],C_SCHEME_TRUE);}}

/* k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8291,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8291(t6,(C_word)C_eqp(lf[103],t5));}
else{
t4=t3;
f_8291(t4,C_SCHEME_FALSE);}}

/* k8289 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8291,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1668 collapsable-literal? */
t6=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7863(2,t2,C_SCHEME_UNDEFINED);}}

/* k8298 in k8289 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8303(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8303(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8301 in k8298 in k8289 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1670 quick-put! */
f_7778(((C_word*)t0)[3],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7863(2,t2,C_SCHEME_UNDEFINED);}}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8192,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[396],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8192(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8192(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7866(2,t3,C_SCHEME_UNDEFINED);}}

/* k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8192,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1684 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7866(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8210,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8214(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8253,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8252 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8253,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8260,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8278,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1690 get */
t5=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[424]);}

/* k8276 in a8252 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8278,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8260(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1691 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447]);}}

/* k8272 in k8276 in a8252 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8260(t2,(C_word)C_i_not(t1));}

/* k8258 in a8252 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8260,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1692 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[334],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8261 in k8258 in a8252 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8212 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8220,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8220(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8220(t3,C_SCHEME_FALSE);}}

/* k8218 in k8212 in a8209 in k8190 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8220,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1698 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[460],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1701 put! */
t5=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8129,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8129(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8144,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[401],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8156,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8156(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8170,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1709 get */
t15=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[433]);}}
else{
t6=t5;
f_8144(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8129(t5,C_SCHEME_FALSE);}}}

/* k8168 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8156(t2,(C_word)C_i_not(t1));}

/* k8154 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8156,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8163,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1710 expression-has-side-effects? */
t3=C_retrieve(lf[459]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8144(t2,C_SCHEME_FALSE);}}

/* k8161 in k8154 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8144(t2,(C_word)C_i_not(t1));}

/* k8142 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8129(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8127 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1712 quick-put! */
f_7778(((C_word*)t0)[3],((C_word*)t0)[2],lf[458],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[401],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1724 get */
t11=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[424]);}
else{
t7=t2;
f_7872(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7872(2,t4,C_SCHEME_UNDEFINED);}}

/* k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8047,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1725 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[427]);}

/* k8113 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8047(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1725 get */
t2=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[428]);}}

/* k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8050,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8050(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8105,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1726 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[432]);}}

/* k8103 in k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8105,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8050(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8050(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1730 get */
t6=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[447]);}}
else{
t4=((C_word*)t0)[6];
f_8050(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8050(t2,C_SCHEME_FALSE);}}}

/* k8095 in k8103 in k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8097,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8050(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8050(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1731 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[433]);}}}

/* k8091 in k8095 in k8103 in k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8050(t2,(C_word)C_i_not(t1));}

/* k8048 in k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_8050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8050,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1732 quick-put! */
f_7778(t2,((C_word*)t0)[2],lf[457],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7872(2,t2,C_SCHEME_UNDEFINED);}}

/* k8051 in k8048 in k8045 in k8039 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1733 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456],C_SCHEME_TRUE);}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7900(t6,(C_word)C_eqp(lf[396],t5));}
else{
t4=t3;
f_7900(t4,C_SCHEME_FALSE);}}

/* k7898 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7900,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7875(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7921,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7921(t11,(C_word)C_eqp(lf[397],t10));}
else{
t10=t8;
f_7921(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7921(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7875(2,t2,C_SCHEME_UNDEFINED);}}

/* k7919 in k7898 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7921,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[401],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[401],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7942(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7942(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7942(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7875(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7875(2,t2,C_SCHEME_UNDEFINED);}}

/* k7940 in k7919 in k7898 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7942,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7948,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1753 quick-put! */
f_7778(t4,((C_word*)t0)[2],lf[457],t3);}
else{
t2=((C_word*)t0)[5];
f_7875(2,t2,C_SCHEME_UNDEFINED);}}

/* k7946 in k7940 in k7919 in k7898 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1754 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456],C_SCHEME_TRUE);}

/* k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7881(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7881(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7881(t3,C_SCHEME_FALSE);}}

/* k7879 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1764 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7883 in k7879 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7842 in a7839 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1765 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[438],lf[444]);}

/* k7828 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1771 lset-difference */
t3=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7832 in k7828 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7837(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7837(t5,t4);}}

/* k7835 in k7832 in k7828 in k7825 in k7822 in k7818 in k7815 in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7792(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7792,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7802,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1571 get */
t6=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[446]);}}

/* k7800 in contains? in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1573 any */
t3=C_retrieve(lf[455]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7809 in k7800 in contains? in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7810,3,t0,t1,t2);}
/* compiler.scm: 1573 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7792(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7778(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7778,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7786,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1566 alist-cons */
t7=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7784 in quick-put! in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7657,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7663,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7662 in walkeach in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7663,3,t0,t1,t2);}
/* compiler.scm: 1540 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7076(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7076,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7069(C_fix(1));
t13=(C_word)C_eqp(t11,lf[103]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7098(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
t16=t14;
f_7098(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[454])));}}

/* k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7098,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[401]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7110,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1422 ref */
t5=((C_word*)t0)[8];
f_7772(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[407]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7153,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1430 ref */
t6=((C_word*)t0)[8];
f_7772(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[270]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[434]));
if(C_truep(t5)){
t6=f_7069(C_fix(1));
/* compiler.scm: 1436 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7657(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[397]);
if(C_truep(t6)){
t7=f_7069(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[401],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7212,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1443 collect! */
t16=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[440],t15);}
else{
t12=t9;
f_7189(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7284,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1457 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7069(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7351,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1470 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[396]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[441]));
if(C_truep(t10)){
t11=f_7069(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1483 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7580,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7586,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1514 get */
t17=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[439]);}
else{
t15=t14;
f_7505(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1533 ##sys#hash-table-ref */
t17=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7619(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7619(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7619(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1537 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7657(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7617 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1534 set-real-name! */
t2=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7613(2,t2,C_SCHEME_UNDEFINED);}}

/* k7611 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1535 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7657(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7584 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7586,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1515 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[450],lf[451],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1516 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[453]);}}

/* k7593 in k7584 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1517 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[450],lf[452],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7580(2,t2,C_SCHEME_UNDEFINED);}}

/* k7578 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1518 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[449],((C_word*)t0)[2]);}

/* k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7534,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7534(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7534(t5,(C_word)C_i_not(t4));}}

/* k7532 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7534,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7069(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7549,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7549(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7549(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7549(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7540(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7508(2,t2,C_SCHEME_UNDEFINED);}}

/* k7547 in k7532 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7553,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1524 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7540(t2,C_SCHEME_UNDEFINED);}}

/* k7551 in k7547 in k7532 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7540(t3,t2);}

/* k7538 in k7532 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1525 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[433],C_SCHEME_TRUE);}

/* k7506 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1526 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7529 in k7506 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1526 assign */
t2=((C_word*)t0)[6];
f_7669(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7509 in k7506 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7514(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1527 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[448],C_SCHEME_TRUE);}}

/* k7512 in k7509 in k7506 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7517,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1528 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],C_SCHEME_TRUE);}

/* k7515 in k7512 in k7509 in k7506 in k7503 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1529 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7076(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7395,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7487,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1489 collect! */
t9=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[446],t5);}
else{
t8=t7;
f_7402(2,t8,C_SCHEME_UNDEFINED);}}

/* k7485 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1490 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[445],((C_word*)t0)[2]);}

/* k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7476 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7481,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1493 put! */
t4=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[430],((C_word*)t0)[2]);}

/* k7479 in a7476 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1494 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[427],C_SCHEME_TRUE);}

/* k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[444]:lf[278]);
/* compiler.scm: 1497 put! */
t5=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[438],t4);}
else{
t3=t2;
f_7408(2,t3,C_SCHEME_UNDEFINED);}}

/* k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7462,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1501 simple-lambda-node? */
t4=C_retrieve(lf[443]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7460 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1501 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[442],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7411(2,t2,C_SCHEME_UNDEFINED);}}

/* k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7414(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7414(t5,t4);}}

/* k7412 in k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7414,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7447(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7447(t4,C_SCHEME_FALSE);}}

/* k7445 in k7412 in k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7417(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7417(t2,C_SCHEME_UNDEFINED);}}

/* k7415 in k7412 in k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7417,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7420,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7444,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1506 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7442 in k7415 in k7412 in k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1506 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7076(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7418 in k7415 in k7412 in k7409 in k7406 in k7403 in k7400 in a7394 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7350 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7351,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7369 in a7350 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7370,3,t0,t1,t2);}
/* compiler.scm: 1474 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[427],C_SCHEME_TRUE);}

/* k7353 in a7350 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7355,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1478 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7366 in k7353 in a7350 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1478 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7076(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7357 in k7353 in a7350 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7284,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7289,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7289(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7289(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7289,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1460 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7316,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1463 put! */
t7=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[430],((C_word*)t0)[8]);}}

/* k7314 in loop in k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1464 assign */
t3=((C_word*)t0)[4];
f_7669(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7317 in k7314 in loop in k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7322,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1465 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7076(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7320 in k7317 in k7314 in loop in k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1466 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7289(t4,((C_word*)t0)[2],t2,t3);}

/* k7305 in loop in k7282 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1460 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7076(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7210 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1445 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[439]);}

/* k7258 in k7210 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7260,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[435])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7189(2,t3,C_SCHEME_UNDEFINED);}}

/* a7222 in k7258 in k7210 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7223,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[401],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7242,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1451 get */
t10=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[438]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7240 in a7222 in k7258 in k7210 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1451 count! */
t2=C_retrieve(lf[436]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7187 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1453 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7076(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7190 in k7187 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1454 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7657(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7151 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7069(C_fix(1));
/* compiler.scm: 1432 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[433],C_SCHEME_TRUE);}

/* k7108 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7069(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1425 put! */
t3=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[432],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1426 get */
t4=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[433]);}}}

/* k7139 in k7108 in k7096 in walk in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1426 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[433],C_SCHEME_TRUE);}}

/* assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7669,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[126],t7);
if(C_truep(t8)){
/* compiler.scm: 1544 put! */
t9=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[426],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7682,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[401],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7682(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7682(t13,C_SCHEME_FALSE);}}}

/* k7680 in assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7682,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7691(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7691(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1549 get */
t6=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[350]);}}}}

/* k7740 in k7680 in assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7691(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7689 in k7680 in assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7691,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1552 get-all */
t3=C_retrieve(lf[431]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[427],lf[428]);}
else{
/* compiler.scm: 1560 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],C_SCHEME_TRUE);}}

/* k7692 in k7689 in k7680 in assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1553 get */
t3=C_retrieve(lf[429]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[430]);}

/* k7695 in k7692 in k7689 in k7680 in assign in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[427],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[428],((C_word*)t0)[7]))){
/* compiler.scm: 1556 put! */
t2=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1558 put! */
t4=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[428],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1559 put! */
t4=C_retrieve(lf[425]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],C_SCHEME_TRUE);}}}}

/* ref in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_7772(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7772,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1563 collect! */
t4=C_retrieve(lf[423]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[424],t3);}

/* grow in k7065 in ##compiler#analyze-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_7069(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7054,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[410]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7045,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[410]);
/* compiler.scm: 1395 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7036,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[410]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7027,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[410]);
/* compiler.scm: 1395 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7018,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[410]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7009,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[410]);
/* compiler.scm: 1395 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7000,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[410]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6991,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[410]);
/* compiler.scm: 1395 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6982,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[410]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6973,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[410]);
/* compiler.scm: 1395 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6967,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[410]));}

/* make-foreign-callback-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6961,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[410],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6286,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6289,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6333,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6707,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6832,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6848,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6933,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1390 walk */
t21=((C_word*)t6)[1];
f_6333(t21,t1,t2,*((C_word*)lf[409]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6933,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[408]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[104]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[108]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1388 every */
t8=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6848,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6854(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6854,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6868,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1371 reverse */
t5=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1372 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6933(3,t6,t4,t5);}}

/* k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6874,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1373 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6854(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1375 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[385]);}}

/* k6890 in k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1376 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6333(t4,((C_word*)t0)[2],t2,t3);}

/* a6900 in k6890 in k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6901,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6915,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6927,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1381 varnode */
t7=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6925 in a6900 in k6890 in k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1380 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6854(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6913 in a6900 in k6890 in k6872 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t2));}

/* k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1371 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6832(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6832,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6838,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1364 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6848(t7,t1,t4,t6);}

/* a6837 in walk-inline-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6838,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[395],t3,t4,t2);
/* compiler.scm: 1367 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6707,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6711,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1340 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[400]);}

/* k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1341 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[403]);}

/* k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6764,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1345 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6762 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1345 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6760,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[396],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6737,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1346 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6848(t6,t4,((C_word*)t0)[2],t5);}

/* a6738 in k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6739,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1349 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6333(t4,t1,((C_word*)t0)[2],t3);}

/* a6744 in a6738 in k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6745,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6749,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1351 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6754 in a6744 in a6738 in k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1351 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6747 in a6744 in a6738 in k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6749,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[395],lf[397],((C_word*)t0)[2],t1));}

/* k6735 in k6758 in k6766 in k6712 in k6709 in walk-call in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6333,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[401]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6355(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t14)){
t15=t13;
f_6355(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t15)){
t16=t13;
f_6355(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[271]);
t17=t13;
f_6355(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[407])));}}}}

/* k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6355,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1297 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6367,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1298 gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[400]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6461,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6461(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[403]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6536,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1320 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[279]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[403]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6621(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6621(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t10)){
t11=t8;
f_6621(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6621(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t13=t8;
f_6621(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6621,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1334 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6832(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[397]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1335 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6707(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[270]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6778,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1354 gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[400]);}
else{
/* compiler.scm: 1337 bomb */
t4=C_retrieve(lf[405]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[406]);}}}}

/* k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1355 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6779 in k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[403]);}

/* k6824 in k6779 in k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6826,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6822,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1359 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6820 in k6824 in k6779 in k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1359 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6816 in k6824 in k6779 in k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6818,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[396],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1361 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6812 in k6816 in k6824 in k6779 in k6776 in k6619 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[270],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t4));}

/* k6584 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[404]),t1,((C_word*)t0)[2]);}

/* k6610 in k6584 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1331 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6289(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6534 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6536,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1321 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6333(t4,((C_word*)t0)[2],t2,t3);}

/* a6544 in k6534 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6545,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[395],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6569,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6573,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1325 varnode */
t10=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6571 in a6544 in k6534 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1325 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6567 in a6544 in k6534 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t2));}

/* k6521 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1319 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6289(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6461(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6461,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1313 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6333(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1314 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6333(t6,t1,t4,t5);}}

/* a6483 in loop in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6484,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6498,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1318 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6461(t8,t5,t6,t7);}

/* k6496 in a6483 in loop in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6498,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t2));}

/* k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1299 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[403]);}

/* k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6446,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6442,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1304 varnode */
t6=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6440 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1304 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6436 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[396],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1305 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6333(t7,t4,t5,t6);}

/* a6410 in k6436 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6411,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1309 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6333(t5,t3,t4,((C_word*)t0)[2]);}

/* k6420 in a6410 in k6436 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1310 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6333(t4,t2,t3,((C_word*)t0)[2]);}

/* k6424 in k6420 in a6410 in k6436 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[114],C_SCHEME_END_OF_LIST,t2));}

/* k6403 in k6436 in k6444 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6371,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6382,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1300 varnode */
t4=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6380 in k1 in k6368 in k6365 in k6353 in walk in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6382,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[397],lf[402],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6289(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6289,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6293,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1285 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[400]);}

/* k6291 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6293,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1288 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6333(t7,t4,t5,t6);}

/* a6315 in k6291 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6316,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6327,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1290 varnode */
t4=C_retrieve(lf[399]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6325 in a6315 in k6291 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[395],lf[397],lf[398],t2));}

/* k6308 in k6291 in cps-lambda in ##compiler#perform-cps-conversion in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6310,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[395],lf[396],((C_word*)t0)[4],t2);
/* compiler.scm: 1286 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6196,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6199,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6228,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1277 walk */
t10=((C_word*)t7)[1];
f_6228(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6228,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1272 ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[393]),t5);}
else{
/* compiler.scm: 1276 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6199(t5,t1,t2);}}}

/* k6245 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6247,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6253(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1274 alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6268 in k6245 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1274 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[393]),((C_word*)t0)[2],t1);}

/* k6251 in k6245 in walk in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1275 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6199(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6199,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6205(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6205(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6205,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6215,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1266 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6228(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6213 in loop in mapupdate in ##compiler#update-line-number-database! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1267 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6205(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6115,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6119,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6119(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6119(t5,C_SCHEME_FALSE);}}

/* k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6119,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6122(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6122(t3,lf[392]);}}

/* k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6122,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6125(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6125(t4,(C_word)C_i_cadr(t3));}}

/* k6123 in k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_6125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6125,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6128,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6141,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[390]+1),t4);}

/* k6139 in k6123 in k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6126 in k6123 in k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6129 in k6126 in k6123 in k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in ##compiler#expand-foreign-primitive in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1256 create-foreign-stub */
t2=C_retrieve(lf[379]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6078,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6088,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6101,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[390]+1),t9);}

/* k6099 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6086 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6091,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6089 in k6086 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6092 in k6089 in k6086 in ##compiler#expand-foreign-callback-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1247 create-foreign-stub */
t2=C_retrieve(lf[379]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6041,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6051,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6064,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[390]+1),t9);}

/* k6062 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6049 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6054,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[391]+1),((C_word*)t0)[2]);}

/* k6052 in k6049 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6057,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6055 in k6052 in k6049 in ##compiler#expand-foreign-lambda* in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1239 create-foreign-stub */
t2=C_retrieve(lf[379]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5996,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6003,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1226 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6003(2,t6,t4);}
else{
/* compiler.scm: 1228 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[389],t4);}}}

/* k6001 in ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6003,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6009,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[387]+1),t5);}

/* k6007 in k6001 in ##compiler#expand-foreign-callback-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1231 create-foreign-stub */
t2=C_retrieve(lf[379]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5951,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1217 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5958(2,t6,t4);}
else{
/* compiler.scm: 1219 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[388],t4);}}}

/* k5956 in ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5964,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[387]+1),t5);}

/* k5962 in k5956 in ##compiler#expand-foreign-lambda in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1222 create-foreign-stub */
t2=C_retrieve(lf[379]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5797,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5801,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5945,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1190 list-tabulate */
t12=C_retrieve(lf[386]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5944 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5945,3,t0,t1,t2);}
/* compiler.scm: 1190 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[385]);}

/* k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1191 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[384]);}

/* k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1192 gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1193 estimate-foreign-result-size */
t3=C_retrieve(lf[383]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1194 set-real-name! */
t3=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1196 make-foreign-stub */
t3=C_retrieve(lf[359]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5939,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[271],((C_word*)t0)[2]);
t7=t5;
f_5823(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5823(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5823,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5826,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5914,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1202 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5913 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5914,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5922,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1202 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5920 in a5913 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1202 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[380]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5849,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[381],t1);
/* compiler.scm: 1207 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1208 final-foreign-type */
t7=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5864 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1209 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5867 in k5864 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[382],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1212 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5886 in k5867 in k5864 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1212 finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5882 in k5867 in k5864 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1211 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5878 in k5867 in k5864 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5880,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5849(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5857 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1207 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5847 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5835 in k5824 in k5821 in k5937 in k5811 in k5808 in k5805 in k5802 in k5799 in ##compiler#create-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5788,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5779,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5770,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5761,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5752,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5743,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5734,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5725,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5716,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5707,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5698,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5689,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5680,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5671,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5662,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5653,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[360]);
/* compiler.scm: 1179 ##sys#block-set! */
t5=*((C_word*)lf[363]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5647,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[360]));}

/* make-foreign-stub in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5641,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[360],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4696,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4699,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4750(t5,t1);}

/* a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4750,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4754(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1015 syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[358],((C_word*)t0)[3]);}}

/* k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[293]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4769,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[296]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[297]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4819,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1027 check-decl */
f_4699(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t9=t3;
f_4760(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4866,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1037 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t10=t3;
f_4760(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4891,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1041 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[301]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[302]));
t12=t3;
f_4760(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4920,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1048 lset-intersection */
t12=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),t10,C_retrieve(lf[301]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4937,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1051 check-decl */
f_4699(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[305]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[306]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[305]);
t13=t3;
f_4760(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4760(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1057 ##match#set-error-control */
t15=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[308]);}
else{
t14=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4760(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4760(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4760(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4760(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4760(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4760(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5020,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1064 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[313]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5034,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1065 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4760(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5055,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1069 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1073 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[317]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1077 every */
t28=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[320]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[321]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5118(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5118(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5118(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[324],t28);
/* compiler.scm: 1085 emit-control-file-item */
t30=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[326],t29);
/* compiler.scm: 1087 emit-control-file-item */
t31=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1090 pathname-strip-extension */
t31=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4760(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4760(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4760(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5256,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1096 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1098 check-decl */
f_4699(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[339]);
if(C_truep(t35)){
t36=C_set_block_item(lf[340],0,C_SCHEME_TRUE);
t37=t3;
f_4760(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[341]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[342]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5424,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5432,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1132 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5424(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5445,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1136 lset-difference */
t41=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1140 quit */
t41=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[345],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4760(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4760(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4760(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4760(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4760(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4760(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1149 lset-union */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[97]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[348]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5536,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1151 check-decl */
f_4699(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[350]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5564,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1159 every */
t47=C_retrieve(lf[319]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[352]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5610,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1163 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1173 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[357],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5609 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5610,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5615,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5620,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5619 in a5609 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5620,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[356]);}

/* k5613 in a5609 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5581 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5588,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1164 partition */
t4=C_retrieve(lf[355]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5587 in a5581 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5588,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1168 quit */
t3=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[354],t2);}}}

/* k5562 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1160 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1161 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[351],((C_word*)t0)[2]);}}

/* k5566 in k5562 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5534 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5543(2,t4,t2);}
else{
/* compiler.scm: 1156 quit */
t4=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[349],((C_word*)t0)[3]);}}

/* k5541 in k5534 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5517 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5443 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1137 lset-union */
t6=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k5447 in k5443 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5430 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5424(t3,t2);}

/* k5422 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5424,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1133 lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5426 in k5422 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4760(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1103 lset-difference */
t7=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[97]+1),C_retrieve(lf[301]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4760(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1107 lset-difference */
t8=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[97]+1),C_retrieve(lf[302]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4760(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1111 lset-union */
t9=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[97]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[303]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4760(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5368,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1118 lset-difference */
t10=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[97]+1),C_retrieve(lf[301]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1121 check-decl */
f_4699(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5377 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4760(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1126 ##match#set-error-control */
t6=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[308]);}
else{
/* compiler.scm: 1127 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[338],((C_word*)t0)[3]);}}}

/* k5366 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5372,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1119 lset-difference */
t4=C_retrieve(lf[336]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[302]),((C_word*)t0)[2]);}

/* k5370 in k5366 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5337 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5312 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5287 in k5267 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5254 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5206 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5217,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5216 in k5206 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5217,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[328]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[329],((C_word*)t0)[2],t2);}

/* k5213 in k5206 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[327],t1);
/* compiler.scm: 1089 emit-control-file-item */
t3=C_retrieve(lf[325]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5116 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_5118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1082 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[322],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1083 process-custom-declaration */
t4=C_retrieve(lf[323]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5094 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1078 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1079 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[318],((C_word*)t0)[2]);}}

/* k5098 in k5094 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5067 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1074 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5071 in k5067 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5053 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1071 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[301]),C_retrieve(lf[302]),C_retrieve(lf[17]));}

/* k5057 in k5053 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5032 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k5018 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[313]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4935 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4760(2,t4,t3);}

/* k4918 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1049 lset-intersection */
t4=C_retrieve(lf[304]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[302]));}

/* k4922 in k4918 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4889 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4864 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4849,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1029 stringify */
t5=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4847 in k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1029 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4823 in k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1030 hash-table-set! */
t3=C_retrieve(lf[300]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[297],((C_word*)t0)[2]);}

/* k4826 in k4823 in k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4835(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4835(t4,C_SCHEME_FALSE);}}

/* k4833 in k4826 in k4823 in k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1032 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[298],lf[299]);}
else{
t2=((C_word*)t0)[2];
f_4831(2,t2,C_SCHEME_UNDEFINED);}}

/* k4829 in k4826 in k4823 in k4817 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4772(2,t3,C_SCHEME_UNDEFINED);}}

/* k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4772,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1023 hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[293],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4760(2,t2,C_SCHEME_UNDEFINED);}}

/* a4805 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4799 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4800,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),((C_word*)t0)[2],t2);}

/* k4779 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4790,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4789 in k4779 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4790,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4798,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1024 stringify */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4796 in a4789 in k4779 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1024 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4782 in k4779 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1025 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4786 in k4782 in k4779 in k4770 in k4767 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4760(2,t3,t2);}

/* k4758 in k4752 in a4749 in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[292]);}

/* check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4699(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4699,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4712(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4722(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4722(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1010 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4720 in check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4712(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4710 in check-decl in ##compiler#process-declaration in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1011 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[291],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1945,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1957,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1981,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2114,a[2]=t5,a[3]=t11,a[4]=t4,a[5]=t9,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4654,a[2]=t2,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[124],C_retrieve(lf[288])))){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4691,a[2]=t2,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 993  newline */
t17=*((C_word*)lf[290]+1);
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t16=t15;
f_4654(2,t16,C_SCHEME_UNDEFINED);}}

/* k4689 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 993  pretty-print */
t2=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 994  ##sys#clear-trace-buffer */
t3=C_retrieve(lf[287]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4655 in k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 998  reverse */
t4=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4670 in k4655 in k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4681,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1001 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4679 in k4670 in k4655 in k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1002 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[284]),C_retrieve(lf[13]));}

/* k4683 in k4679 in k4670 in k4655 in k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 448  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4666 in k4655 in k4652 in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 996  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2114(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4641,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4647,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4646 in mapwalk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4647,3,t0,t1,t2);}
/* compiler.scm: 991  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2114(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2114,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2133,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 496  resolve-atom */
t9=((C_word*)((C_word*)t0)[7])[1];
f_2023(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 498  resolve-atom */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2023(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 500  constant? */
t7=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2151(2,t7,C_SCHEME_FALSE);}}}

/* k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[10]));}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 501  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[112],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 505  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 967  constant? */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 965  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[283],((C_word*)t0)[10]);}}}}}

/* k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 968  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4617,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 972  caar */
t5=*((C_word*)lf[281]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4517(t4,C_SCHEME_FALSE);}}}

/* k4615 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4517(t2,(C_word)C_eqp(lf[159],t1));}

/* k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4517,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 975  emit-syntax-trace-info */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 987  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4602 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 988  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4641(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4524 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 976  ##sys#check-syntax */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[280]);}

/* k4527 in k4524 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4538(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4538(t4,C_SCHEME_FALSE);}}

/* k4536 in k4527 in k4524 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4538,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 979  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[278]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 980  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}}

/* k4558 in k4536 in k4527 in k4524 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 981  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2114(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4551 in k4536 in k4527 in k4524 in k4515 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 979  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2114(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4503 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 969  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[277],((C_word*)t0)[4]);}

/* k4506 in k4503 in k4500 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 970  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4641(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=f_1945(((C_word*)t0)[12],((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2184,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t2,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 507  emit-syntax-trace-info */
t4=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[10],C_SCHEME_FALSE);}

/* k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[14]))){
t3=t2;
f_2187(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 510  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[274],((C_word*)t0)[2]);}
else{
/* compiler.scm: 511  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[275],((C_word*)t0)[14]);}}}

/* k4482 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 510  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 514  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[8]);}

/* k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[14],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 518  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[7]);}
else{
t4=t3;
f_2212(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t1,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 516  update-line-number-database! */
t4=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2203(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2201 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 517  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2114(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[13]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 520  walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_2114(t4,((C_word*)t0)[11],t3,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 525  ##sys#check-syntax */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[114],((C_word*)t0)[13],lf[117]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[103]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 533  ##sys#check-syntax */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[103],((C_word*)t0)[13],lf[118]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[119]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[120]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* compiler.scm: 539  walk */
t6=((C_word*)((C_word*)t0)[12])[1];
f_2114(t6,((C_word*)t0)[11],t5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[121]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 542  cadadr */
t7=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[126]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2339(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[270]);
if(C_truep(t8)){
t9=t7;
f_2339(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[271]);
if(C_truep(t9)){
t10=t7;
f_2339(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[104]);
t11=t7;
f_2339(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[7],lf[108])));}}}}}}}}}

/* k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2339,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[127]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2386(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 590  ##sys#check-syntax */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 604  ##sys#check-syntax */
t8=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 639  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2114(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[123]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 655  ##sys#check-syntax */
t12=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 694  unquotify */
t14=((C_word*)t0)[3];
f_1981(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 702  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2114(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 707  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2114(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 712  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 716  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3185,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 720  ##sys#check-syntax */
t21=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 732  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 735  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 738  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 741  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 744  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3319(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 751  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3386,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 762  gensym */
t33=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 775  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3460,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 780  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 795  gensym */
t34=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3662,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3680,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 834  call-with-current-continuation */
t37=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[242]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3878,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[244]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 862  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[267],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 937  ##sys#check-syntax */
t36=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[267],((C_word*)t0)[12],lf[269]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 955  ##sys#hash-table-ref */
t36=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4404(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4404(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4402 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 957  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 962  handle-call */
t2=((C_word*)t0)[7];
f_4275(t2,((C_word*)t0)[6]);}}

/* k4408 in k4402 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 959  handle-call */
t2=((C_word*)t0)[7];
f_4275(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 960  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2114(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4313 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1945(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 942  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2114(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 946  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2114(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 948  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 950  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2114(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[103],lf[267]);
t4=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 951  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2114(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4373 in k4313 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[104],t2));}

/* handle-call in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4275,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 926  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4641(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4277 in handle-call in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4285,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 928  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4283 in k4277 in handle-call in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 933  alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4288(2,t3,C_SCHEME_UNDEFINED);}}

/* k4297 in k4283 in k4277 in handle-call in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 930  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4286 in k4283 in k4277 in handle-call in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3911,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3933,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 869  valid-c-identifier? */
t14=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4257 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3933(2,t4,t3);}
else{
/* compiler.scm: 871  quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[265],((C_word*)t0)[3]);}}

/* k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4224(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4224(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4224(t11,(C_word)C_i_not(t10));}}}

/* k4222 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 876  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[264],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3936(2,t2,C_SCHEME_UNDEFINED);}}

/* k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 880  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4641(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3955,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4174,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4174(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4174(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4174,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4214,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4218,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 892  final-foreign-type */
t9=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4216 in loop in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 892  finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4212 in loop in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 891  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4208 in loop in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 894  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4174(t6,t3,t4,t5);}

/* k4196 in k4208 in loop in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[250]))){
/* compiler.scm: 897  g293 */
t7=t6;
f_4046(2,t7,f_4023(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 897  g293 */
t7=t6;
f_4046(2,t7,f_4023(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[252]);
if(C_truep(t7)){
/* compiler.scm: 897  g293 */
t8=t6;
f_4046(2,t8,f_4023(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t8)){
/* compiler.scm: 897  g293 */
t9=t6;
f_4046(2,t9,f_4023(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 897  g294 */
t9=t4;
f_4018(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 897  g294 */
t9=t4;
f_4018(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t9)){
/* compiler.scm: 897  g294 */
t10=t4;
f_4018(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t10)){
/* compiler.scm: 897  g294 */
t11=t4;
f_4018(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t11)){
/* compiler.scm: 897  g294 */
t12=t4;
f_4018(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t12)){
/* compiler.scm: 897  g294 */
t13=t4;
f_4018(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t13)){
/* compiler.scm: 897  g295 */
t14=t6;
f_4046(2,t14,f_3981(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[261]))){
/* compiler.scm: 897  g295 */
t14=t6;
f_4046(2,t14,f_3981(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
/* compiler.scm: 897  g295 */
t15=t6;
f_4046(2,t15,(C_truep(t14)?f_3981(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[263]))?f_3981(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4044 in k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 895  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g293 in k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_4023(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g294 in k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_4018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4018,NULL,2,t0,t1);}
/* compiler.scm: 909  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g295 in k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_3981(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[246],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[247],lf[246]);
t7=(C_word)C_a_i_list(&a,3,lf[248],lf[246],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k3969 in k3965 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 881  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2114(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3953 in k3945 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 448  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3941 in k3934 in k3931 in a3910 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[244],t1));}

/* a3900 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3901,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 862  split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3877 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3878,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 857  process-declaration */
t4=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3874 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 855  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2114(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3811,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3823,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 834  with-exception-handler */
t5=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3822 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 834  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3844 in a3822 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3845r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3845r(t0,t1,t2);}}

static void C_ccall f_3845r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 834  g256 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3850 in a3844 in a3822 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3828 in a3822 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 838  collapsable-literal? */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3834 in a3828 in a3822 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 840  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3810 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 834  g256 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3816 in a3810 in a3804 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
/* compiler.scm: 836  quit */
t2=C_retrieve(lf[238]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[239],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3801 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[103],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 843  collapsable-literal? */
t8=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3750 in k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 844  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 847  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k3760 in k3750 in k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 848  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3763 in k3760 in k3750 in k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 849  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3767 in k3763 in k3760 in k3750 in k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 852  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2114(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3753 in k3750 in k3739 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3680,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3684,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 824  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3682 in a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 825  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3720 in k3682 in a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 825  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3686 in k3682 in a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3702,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3701 in k3686 in k3682 in a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3702,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[103],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3698 in k3686 in k3682 in a3679 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 827  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2114(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3661 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 823  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2114(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3668 in a3661 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 822  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 796  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 798  set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3623,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 801  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3621 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 801  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3559,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3575(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3575(t11,C_SCHEME_END_OF_LIST);}}

/* k3573 in k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3575,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3583,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 814  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3583(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3581 in k3573 in k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 448  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3569 in k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 815  alist-cons */
t4=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3565 in k3569 in k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 809  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3557 in k3598 in k3542 in k3536 in k3533 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 783  make-random-name */
t9=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3472(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3500,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 784  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3506 in k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 784  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3498 in k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3472(t3,t2);}

/* k3470 in k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 787  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3490 in k3470 in k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3492,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 789  alist-cons */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3482 in k3490 in k3470 in k3467 in k3458 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3438 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3384 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 763  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3387 in k3384 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 764  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3390 in k3387 in k3384 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 765  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3394 in k3390 in k3387 in k3384 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 766  cons* */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3398 in k3394 in k3390 in k3387 in k3384 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3400,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 767  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2114(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3317 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3331(2,t3,t1);}
else{
/* compiler.scm: 753  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3329 in k3317 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3302 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 744  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3289 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 741  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3276 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 738  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3263 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 735  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3250 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 732  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3204,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3204(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3204,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 727  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2114(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3231,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 728  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2114(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3229 in fold in k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 728  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3204(t3,t2,((C_word*)t0)[2]);}

/* k3233 in k3229 in fold in k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3222 in fold in k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3224,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3196 in k3183 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 722  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3170 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3155 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 713  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2114(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3128 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3134,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 708  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2114(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3132 in k3128 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3107 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3078 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 699  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4641(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3082 in k3078 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3049 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 694  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4641(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3053 in k3049 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1945(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 658  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 659  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2114(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 661  ##sys#alias-global-hook */
t5=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2892(2,t4,C_SCHEME_UNDEFINED);}}

/* k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 664  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3000(t4,C_SCHEME_UNDEFINED);}}

/* k3024 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 665  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3028 in k3024 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3000(t3,t2);}

/* k2998 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_3000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3000,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 666  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3004 in k2998 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 670  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3019(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2892(2,t2,C_SCHEME_UNDEFINED);}}

/* k3017 in k3004 in k2998 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 667  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3007 in k3004 in k2998 in k2995 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 671  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2892(2,t2,C_SCHEME_UNDEFINED);}}

/* k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 672  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2985 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 673  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2895(2,t2,C_SCHEME_UNDEFINED);}}

/* k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 677  gensym */
t5=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 685  gensym */
t6=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2948 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 686  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2979 in k2948 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2973,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 690  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2971 in k2979 in k2948 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2905 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 678  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2936 in k2905 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2926,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 681  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2924 in k2936 in k2905 in k2893 in k2890 in k2887 in k2884 in k2875 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 645  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2863 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 645  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2840 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 648  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2856 in k2840 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2857,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2853 in k2840 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 647  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2114(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2843 in k2840 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2848,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 651  set-real-names! */
f_1957(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2846 in k2843 in k2840 in k2837 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2583,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2789,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 607  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2787 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 608  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2583(2,t2,C_SCHEME_UNDEFINED);}}

/* a2799 in k2787 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2800,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2793 in k2787 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
/* compiler.scm: 610  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 613  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2588,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[123]),t2);}

/* k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 617  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2784 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 617  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 618  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2777 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2778,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 619  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2114(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 623  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2769(t4,C_SCHEME_FALSE);}}

/* k2774 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2769(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2767 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 621  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[159],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 625  set-real-names! */
f_1957(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2619(t4,t2);}
else{
t4=f_1945(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2619(t6,(C_word)C_i_not(t5));}}

/* k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 630  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2639(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2639(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2639(t5,C_SCHEME_FALSE);}}}}

/* k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 632  g162 */
t6=((C_word*)t0)[4];
f_2629(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2672(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2721 in k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2672(t3,C_SCHEME_FALSE);}}

/* k2717 in k2721 in k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2672(t2,C_SCHEME_FALSE);}}

/* k2713 in k2717 in k2721 in k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2672(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2672(t2,C_SCHEME_FALSE);}}

/* k2670 in k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2672,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 632  cadadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2677 in k2670 in k2637 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 632  g162 */
t3=((C_word*)t0)[3];
f_2629(t3,((C_word*)t0)[2],t1);}

/* g162 in k2617 in k2608 in k2602 in k2599 in k2596 in k2593 in k2590 in a2587 in k2581 in k2572 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2629,NULL,3,t0,t1,t2);}
/* compiler.scm: 634  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 592  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[123]),t1);}

/* k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 594  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2560 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 594  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 595  set-real-names! */
f_1957(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 596  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2541 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2542,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 597  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2114(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2548 in a2541 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2520 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 599  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2535 in k2520 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2536,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2528 in k2520 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 599  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2524 in k2520 in k2513 in k2510 in k2507 in k2504 in k2498 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2396,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 567  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2407,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2472(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 571  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2472(2,t6,C_SCHEME_FALSE);}}}

/* k2479 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2472(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 573  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2489 in k2479 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 572  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2470 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 579  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2434(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2434(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 575  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2444 in k2470 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2434(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2434(t2,C_SCHEME_FALSE);}}

/* a2459 in k2444 in k2470 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2460,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2456 in k2444 in k2470 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2434(t2,C_SCHEME_TRUE);}

/* k2432 in k2470 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2411(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 585  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2409 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 586  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2386(t4,t2,t3);}

/* k2416 in k2409 in a2406 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2400 in k2394 in loop in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
/* compiler.scm: 568  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2378 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 563  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2114(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2346 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2349 in k2346 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 557  hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2361 in k2349 in k2346 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2355 in k2349 in k2346 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2356,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2352 in k2349 in k2346 in k2337 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[128]);}

/* k2304 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 545  gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[124]);}}

/* k2316 in k2304 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 546  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2320 in k2316 in k2304 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2279 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2233 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 526  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2114(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2240 in k2233 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 527  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2114(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2244 in k2240 in k2233 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2250(2,t4,lf[115]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 530  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2114(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2248 in k2244 in k2240 in k2233 in k2210 in k2192 in k2185 in k2182 in k2176 in k2149 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[114],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2137 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 499  ##sys#alias-global-hook */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2131 in walk in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2023,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2027,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 468  ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2027(2,t7,C_SCHEME_FALSE);}}

/* k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 469  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2114(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 470  ##sys#hash-table-ref */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2040(2,t3,C_SCHEME_FALSE);}}}

/* k2038 in k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 472  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2114(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 476  final-foreign-type */
t5=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 484  final-foreign-type */
t6=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2086 in k2038 in k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[108],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 487  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2096 in k2086 in k2038 in k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 486  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2056 in k2038 in k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[104],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 479  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2066 in k2056 in k2038 in k2025 in resolve-atom in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 478  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1981,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[103]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_1988(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_1988(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_1988(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1988(t4,C_SCHEME_FALSE);}}

/* k1986 in unquotify in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_1988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_fcall f_1957(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1957,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1963,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 455  for-each */
t5=*((C_word*)lf[102]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1962 in set-real-names! in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1963,4,t0,t1,t2,t3);}
/* compiler.scm: 455  set-real-name! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static C_word C_fcall f_1945(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 427  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 428  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1938 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1881(2,t3,t2);}

/* k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 430  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 431  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1931 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1884(2,t3,t2);}

/* k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 433  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 434  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1924 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1887(2,t3,t2);}

/* k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-random-name */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[99]);}

/* k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 436  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 437  make-hash-table */
t4=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k1897 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 439  vector-fill! */
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 440  make-vector */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1917 in k1897 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1902(2,t3,t2);}

/* k1900 in k1897 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 442  vector-fill! */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1910 in k1900 in k1897 in k1893 in k1889 in k1885 in k1882 in k1879 in ##compiler#initialize-compiler in k1790 in k1786 in k1782 in k1778 in k1774 in k1770 in k1763 in k1760 in k1757 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[814] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1759compiler.scm",(void*)f_1759},
{"f_1762compiler.scm",(void*)f_1762},
{"f_1765compiler.scm",(void*)f_1765},
{"f_1772compiler.scm",(void*)f_1772},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1780compiler.scm",(void*)f_1780},
{"f_1784compiler.scm",(void*)f_1784},
{"f_1788compiler.scm",(void*)f_1788},
{"f_1792compiler.scm",(void*)f_1792},
{"f_10104compiler.scm",(void*)f_10104},
{"f_11161compiler.scm",(void*)f_11161},
{"f_11164compiler.scm",(void*)f_11164},
{"f_11167compiler.scm",(void*)f_11167},
{"f_11170compiler.scm",(void*)f_11170},
{"f_11173compiler.scm",(void*)f_11173},
{"f_10961compiler.scm",(void*)f_10961},
{"f_10967compiler.scm",(void*)f_10967},
{"f_10194compiler.scm",(void*)f_10194},
{"f_10950compiler.scm",(void*)f_10950},
{"f_10947compiler.scm",(void*)f_10947},
{"f_10860compiler.scm",(void*)f_10860},
{"f_10924compiler.scm",(void*)f_10924},
{"f_10937compiler.scm",(void*)f_10937},
{"f_10918compiler.scm",(void*)f_10918},
{"f_10908compiler.scm",(void*)f_10908},
{"f_10881compiler.scm",(void*)f_10881},
{"f_10884compiler.scm",(void*)f_10884},
{"f_10832compiler.scm",(void*)f_10832},
{"f_10835compiler.scm",(void*)f_10835},
{"f_10789compiler.scm",(void*)f_10789},
{"f_10801compiler.scm",(void*)f_10801},
{"f_10792compiler.scm",(void*)f_10792},
{"f_10795compiler.scm",(void*)f_10795},
{"f_10669compiler.scm",(void*)f_10669},
{"f_10770compiler.scm",(void*)f_10770},
{"f_10758compiler.scm",(void*)f_10758},
{"f_10697compiler.scm",(void*)f_10697},
{"f_10703compiler.scm",(void*)f_10703},
{"f_10727compiler.scm",(void*)f_10727},
{"f_10719compiler.scm",(void*)f_10719},
{"f_10685compiler.scm",(void*)f_10685},
{"f_10628compiler.scm",(void*)f_10628},
{"f_10640compiler.scm",(void*)f_10640},
{"f_10644compiler.scm",(void*)f_10644},
{"f_10632compiler.scm",(void*)f_10632},
{"f_10444compiler.scm",(void*)f_10444},
{"f_10565compiler.scm",(void*)f_10565},
{"f_10571compiler.scm",(void*)f_10571},
{"f_10596compiler.scm",(void*)f_10596},
{"f_10577compiler.scm",(void*)f_10577},
{"f_10451compiler.scm",(void*)f_10451},
{"f_10556compiler.scm",(void*)f_10556},
{"f_10454compiler.scm",(void*)f_10454},
{"f_10457compiler.scm",(void*)f_10457},
{"f_10460compiler.scm",(void*)f_10460},
{"f_10498compiler.scm",(void*)f_10498},
{"f_10524compiler.scm",(void*)f_10524},
{"f_10505compiler.scm",(void*)f_10505},
{"f_10509compiler.scm",(void*)f_10509},
{"f_10482compiler.scm",(void*)f_10482},
{"f_10388compiler.scm",(void*)f_10388},
{"f_10397compiler.scm",(void*)f_10397},
{"f_10391compiler.scm",(void*)f_10391},
{"f_10372compiler.scm",(void*)f_10372},
{"f_10345compiler.scm",(void*)f_10345},
{"f_10328compiler.scm",(void*)f_10328},
{"f_10324compiler.scm",(void*)f_10324},
{"f_10317compiler.scm",(void*)f_10317},
{"f_10300compiler.scm",(void*)f_10300},
{"f_10296compiler.scm",(void*)f_10296},
{"f_10272compiler.scm",(void*)f_10272},
{"f_10252compiler.scm",(void*)f_10252},
{"f_10107compiler.scm",(void*)f_10107},
{"f_10111compiler.scm",(void*)f_10111},
{"f_10126compiler.scm",(void*)f_10126},
{"f_10136compiler.scm",(void*)f_10136},
{"f_10141compiler.scm",(void*)f_10141},
{"f_10186compiler.scm",(void*)f_10186},
{"f_10145compiler.scm",(void*)f_10145},
{"f_10151compiler.scm",(void*)f_10151},
{"f_10161compiler.scm",(void*)f_10161},
{"f_10973compiler.scm",(void*)f_10973},
{"f_10980compiler.scm",(void*)f_10980},
{"f_11042compiler.scm",(void*)f_11042},
{"f_11032compiler.scm",(void*)f_11032},
{"f_11006compiler.scm",(void*)f_11006},
{"f_10992compiler.scm",(void*)f_10992},
{"f_11067compiler.scm",(void*)f_11067},
{"f_11083compiler.scm",(void*)f_11083},
{"f_11090compiler.scm",(void*)f_11090},
{"f_11097compiler.scm",(void*)f_11097},
{"f_11071compiler.scm",(void*)f_11071},
{"f_11081compiler.scm",(void*)f_11081},
{"f_11053compiler.scm",(void*)f_11053},
{"f_11061compiler.scm",(void*)f_11061},
{"f_11099compiler.scm",(void*)f_11099},
{"f_11112compiler.scm",(void*)f_11112},
{"f_10095compiler.scm",(void*)f_10095},
{"f_10086compiler.scm",(void*)f_10086},
{"f_10077compiler.scm",(void*)f_10077},
{"f_10068compiler.scm",(void*)f_10068},
{"f_10059compiler.scm",(void*)f_10059},
{"f_10050compiler.scm",(void*)f_10050},
{"f_10041compiler.scm",(void*)f_10041},
{"f_10032compiler.scm",(void*)f_10032},
{"f_10023compiler.scm",(void*)f_10023},
{"f_10014compiler.scm",(void*)f_10014},
{"f_10005compiler.scm",(void*)f_10005},
{"f_9996compiler.scm",(void*)f_9996},
{"f_9987compiler.scm",(void*)f_9987},
{"f_9978compiler.scm",(void*)f_9978},
{"f_9969compiler.scm",(void*)f_9969},
{"f_9960compiler.scm",(void*)f_9960},
{"f_9951compiler.scm",(void*)f_9951},
{"f_9942compiler.scm",(void*)f_9942},
{"f_9933compiler.scm",(void*)f_9933},
{"f_9924compiler.scm",(void*)f_9924},
{"f_9915compiler.scm",(void*)f_9915},
{"f_9906compiler.scm",(void*)f_9906},
{"f_9897compiler.scm",(void*)f_9897},
{"f_9888compiler.scm",(void*)f_9888},
{"f_9879compiler.scm",(void*)f_9879},
{"f_9870compiler.scm",(void*)f_9870},
{"f_9861compiler.scm",(void*)f_9861},
{"f_9852compiler.scm",(void*)f_9852},
{"f_9843compiler.scm",(void*)f_9843},
{"f_9834compiler.scm",(void*)f_9834},
{"f_9828compiler.scm",(void*)f_9828},
{"f_9822compiler.scm",(void*)f_9822},
{"f_8588compiler.scm",(void*)f_8588},
{"f_9789compiler.scm",(void*)f_9789},
{"f_9792compiler.scm",(void*)f_9792},
{"f_9795compiler.scm",(void*)f_9795},
{"f_9798compiler.scm",(void*)f_9798},
{"f_9801compiler.scm",(void*)f_9801},
{"f_9816compiler.scm",(void*)f_9816},
{"f_9814compiler.scm",(void*)f_9814},
{"f_9804compiler.scm",(void*)f_9804},
{"f_9641compiler.scm",(void*)f_9641},
{"f_9647compiler.scm",(void*)f_9647},
{"f_8952compiler.scm",(void*)f_8952},
{"f_8971compiler.scm",(void*)f_8971},
{"f_9004compiler.scm",(void*)f_9004},
{"f_9531compiler.scm",(void*)f_9531},
{"f_9527compiler.scm",(void*)f_9527},
{"f_9520compiler.scm",(void*)f_9520},
{"f_9371compiler.scm",(void*)f_9371},
{"f_9377compiler.scm",(void*)f_9377},
{"f_9447compiler.scm",(void*)f_9447},
{"f_9477compiler.scm",(void*)f_9477},
{"f_9460compiler.scm",(void*)f_9460},
{"f_9464compiler.scm",(void*)f_9464},
{"f_9386compiler.scm",(void*)f_9386},
{"f_9433compiler.scm",(void*)f_9433},
{"f_9437compiler.scm",(void*)f_9437},
{"f_9413compiler.scm",(void*)f_9413},
{"f_9409compiler.scm",(void*)f_9409},
{"f_9100compiler.scm",(void*)f_9100},
{"f_9349compiler.scm",(void*)f_9349},
{"f_9104compiler.scm",(void*)f_9104},
{"f_9347compiler.scm",(void*)f_9347},
{"f_9107compiler.scm",(void*)f_9107},
{"f_9110compiler.scm",(void*)f_9110},
{"f_9116compiler.scm",(void*)f_9116},
{"f_9122compiler.scm",(void*)f_9122},
{"f_9128compiler.scm",(void*)f_9128},
{"f_9314compiler.scm",(void*)f_9314},
{"f_9317compiler.scm",(void*)f_9317},
{"f_9131compiler.scm",(void*)f_9131},
{"f_9290compiler.scm",(void*)f_9290},
{"f_9275compiler.scm",(void*)f_9275},
{"f_9271compiler.scm",(void*)f_9271},
{"f_9205compiler.scm",(void*)f_9205},
{"f_9230compiler.scm",(void*)f_9230},
{"f_9236compiler.scm",(void*)f_9236},
{"f_9247compiler.scm",(void*)f_9247},
{"f_9234compiler.scm",(void*)f_9234},
{"f_9216compiler.scm",(void*)f_9216},
{"f_9208compiler.scm",(void*)f_9208},
{"f_9193compiler.scm",(void*)f_9193},
{"f_9201compiler.scm",(void*)f_9201},
{"f_9154compiler.scm",(void*)f_9154},
{"f_9184compiler.scm",(void*)f_9184},
{"f_9176compiler.scm",(void*)f_9176},
{"f_9172compiler.scm",(void*)f_9172},
{"f_9168compiler.scm",(void*)f_9168},
{"f_9157compiler.scm",(void*)f_9157},
{"f_9025compiler.scm",(void*)f_9025},
{"f_9028compiler.scm",(void*)f_9028},
{"f_9080compiler.scm",(void*)f_9080},
{"f_9044compiler.scm",(void*)f_9044},
{"f_9073compiler.scm",(void*)f_9073},
{"f_9065compiler.scm",(void*)f_9065},
{"f_9010compiler.scm",(void*)f_9010},
{"f_8983compiler.scm",(void*)f_8983},
{"f_8989compiler.scm",(void*)f_8989},
{"f_9653compiler.scm",(void*)f_9653},
{"f_9660compiler.scm",(void*)f_9660},
{"f_9676compiler.scm",(void*)f_9676},
{"f_8618compiler.scm",(void*)f_8618},
{"f_8637compiler.scm",(void*)f_8637},
{"f_8916compiler.scm",(void*)f_8916},
{"f_8877compiler.scm",(void*)f_8877},
{"f_9692compiler.scm",(void*)f_9692},
{"f_9730compiler.scm",(void*)f_9730},
{"f_9756compiler.scm",(void*)f_9756},
{"f_9742compiler.scm",(void*)f_9742},
{"f_9721compiler.scm",(void*)f_9721},
{"f_9690compiler.scm",(void*)f_9690},
{"f_8890compiler.scm",(void*)f_8890},
{"f_8893compiler.scm",(void*)f_8893},
{"f_8904compiler.scm",(void*)f_8904},
{"f_8841compiler.scm",(void*)f_8841},
{"f_8733compiler.scm",(void*)f_8733},
{"f_8739compiler.scm",(void*)f_8739},
{"f_8751compiler.scm",(void*)f_8751},
{"f_8754compiler.scm",(void*)f_8754},
{"f_8757compiler.scm",(void*)f_8757},
{"f_8775compiler.scm",(void*)f_8775},
{"f_8782compiler.scm",(void*)f_8782},
{"f_8760compiler.scm",(void*)f_8760},
{"f_8763compiler.scm",(void*)f_8763},
{"f_8766compiler.scm",(void*)f_8766},
{"f_8727compiler.scm",(void*)f_8727},
{"f_8717compiler.scm",(void*)f_8717},
{"f_8700compiler.scm",(void*)f_8700},
{"f_8705compiler.scm",(void*)f_8705},
{"f_8658compiler.scm",(void*)f_8658},
{"f_8675compiler.scm",(void*)f_8675},
{"f_8662compiler.scm",(void*)f_8662},
{"f_8673compiler.scm",(void*)f_8673},
{"f_8648compiler.scm",(void*)f_8648},
{"f_8607compiler.scm",(void*)f_8607},
{"f_8616compiler.scm",(void*)f_8616},
{"f_8597compiler.scm",(void*)f_8597},
{"f_8602compiler.scm",(void*)f_8602},
{"f_8591compiler.scm",(void*)f_8591},
{"f_7063compiler.scm",(void*)f_7063},
{"f_7067compiler.scm",(void*)f_7067},
{"f_7817compiler.scm",(void*)f_7817},
{"f_7820compiler.scm",(void*)f_7820},
{"f_7824compiler.scm",(void*)f_7824},
{"f_7827compiler.scm",(void*)f_7827},
{"f_7840compiler.scm",(void*)f_7840},
{"f_8475compiler.scm",(void*)f_8475},
{"f_7844compiler.scm",(void*)f_7844},
{"f_8440compiler.scm",(void*)f_8440},
{"f_7851compiler.scm",(void*)f_7851},
{"f_8386compiler.scm",(void*)f_8386},
{"f_8389compiler.scm",(void*)f_8389},
{"f_8401compiler.scm",(void*)f_8401},
{"f_8395compiler.scm",(void*)f_8395},
{"f_7854compiler.scm",(void*)f_7854},
{"f_7857compiler.scm",(void*)f_7857},
{"f_8369compiler.scm",(void*)f_8369},
{"f_8361compiler.scm",(void*)f_8361},
{"f_8329compiler.scm",(void*)f_8329},
{"f_8335compiler.scm",(void*)f_8335},
{"f_7860compiler.scm",(void*)f_7860},
{"f_8291compiler.scm",(void*)f_8291},
{"f_8300compiler.scm",(void*)f_8300},
{"f_8303compiler.scm",(void*)f_8303},
{"f_7863compiler.scm",(void*)f_7863},
{"f_8192compiler.scm",(void*)f_8192},
{"f_8210compiler.scm",(void*)f_8210},
{"f_8253compiler.scm",(void*)f_8253},
{"f_8278compiler.scm",(void*)f_8278},
{"f_8274compiler.scm",(void*)f_8274},
{"f_8260compiler.scm",(void*)f_8260},
{"f_8263compiler.scm",(void*)f_8263},
{"f_8214compiler.scm",(void*)f_8214},
{"f_8220compiler.scm",(void*)f_8220},
{"f_7866compiler.scm",(void*)f_7866},
{"f_8170compiler.scm",(void*)f_8170},
{"f_8156compiler.scm",(void*)f_8156},
{"f_8163compiler.scm",(void*)f_8163},
{"f_8144compiler.scm",(void*)f_8144},
{"f_8129compiler.scm",(void*)f_8129},
{"f_7869compiler.scm",(void*)f_7869},
{"f_8041compiler.scm",(void*)f_8041},
{"f_8115compiler.scm",(void*)f_8115},
{"f_8047compiler.scm",(void*)f_8047},
{"f_8105compiler.scm",(void*)f_8105},
{"f_8097compiler.scm",(void*)f_8097},
{"f_8093compiler.scm",(void*)f_8093},
{"f_8050compiler.scm",(void*)f_8050},
{"f_8053compiler.scm",(void*)f_8053},
{"f_7872compiler.scm",(void*)f_7872},
{"f_7900compiler.scm",(void*)f_7900},
{"f_7921compiler.scm",(void*)f_7921},
{"f_7942compiler.scm",(void*)f_7942},
{"f_7948compiler.scm",(void*)f_7948},
{"f_7875compiler.scm",(void*)f_7875},
{"f_7881compiler.scm",(void*)f_7881},
{"f_7885compiler.scm",(void*)f_7885},
{"f_7830compiler.scm",(void*)f_7830},
{"f_7834compiler.scm",(void*)f_7834},
{"f_7837compiler.scm",(void*)f_7837},
{"f_7792compiler.scm",(void*)f_7792},
{"f_7802compiler.scm",(void*)f_7802},
{"f_7810compiler.scm",(void*)f_7810},
{"f_7778compiler.scm",(void*)f_7778},
{"f_7786compiler.scm",(void*)f_7786},
{"f_7657compiler.scm",(void*)f_7657},
{"f_7663compiler.scm",(void*)f_7663},
{"f_7076compiler.scm",(void*)f_7076},
{"f_7098compiler.scm",(void*)f_7098},
{"f_7619compiler.scm",(void*)f_7619},
{"f_7613compiler.scm",(void*)f_7613},
{"f_7586compiler.scm",(void*)f_7586},
{"f_7595compiler.scm",(void*)f_7595},
{"f_7580compiler.scm",(void*)f_7580},
{"f_7505compiler.scm",(void*)f_7505},
{"f_7534compiler.scm",(void*)f_7534},
{"f_7549compiler.scm",(void*)f_7549},
{"f_7553compiler.scm",(void*)f_7553},
{"f_7540compiler.scm",(void*)f_7540},
{"f_7508compiler.scm",(void*)f_7508},
{"f_7531compiler.scm",(void*)f_7531},
{"f_7511compiler.scm",(void*)f_7511},
{"f_7514compiler.scm",(void*)f_7514},
{"f_7517compiler.scm",(void*)f_7517},
{"f_7395compiler.scm",(void*)f_7395},
{"f_7487compiler.scm",(void*)f_7487},
{"f_7402compiler.scm",(void*)f_7402},
{"f_7477compiler.scm",(void*)f_7477},
{"f_7481compiler.scm",(void*)f_7481},
{"f_7405compiler.scm",(void*)f_7405},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7462compiler.scm",(void*)f_7462},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7414compiler.scm",(void*)f_7414},
{"f_7447compiler.scm",(void*)f_7447},
{"f_7417compiler.scm",(void*)f_7417},
{"f_7444compiler.scm",(void*)f_7444},
{"f_7420compiler.scm",(void*)f_7420},
{"f_7351compiler.scm",(void*)f_7351},
{"f_7370compiler.scm",(void*)f_7370},
{"f_7355compiler.scm",(void*)f_7355},
{"f_7368compiler.scm",(void*)f_7368},
{"f_7359compiler.scm",(void*)f_7359},
{"f_7284compiler.scm",(void*)f_7284},
{"f_7289compiler.scm",(void*)f_7289},
{"f_7316compiler.scm",(void*)f_7316},
{"f_7319compiler.scm",(void*)f_7319},
{"f_7322compiler.scm",(void*)f_7322},
{"f_7307compiler.scm",(void*)f_7307},
{"f_7212compiler.scm",(void*)f_7212},
{"f_7260compiler.scm",(void*)f_7260},
{"f_7223compiler.scm",(void*)f_7223},
{"f_7242compiler.scm",(void*)f_7242},
{"f_7189compiler.scm",(void*)f_7189},
{"f_7192compiler.scm",(void*)f_7192},
{"f_7153compiler.scm",(void*)f_7153},
{"f_7110compiler.scm",(void*)f_7110},
{"f_7141compiler.scm",(void*)f_7141},
{"f_7669compiler.scm",(void*)f_7669},
{"f_7682compiler.scm",(void*)f_7682},
{"f_7742compiler.scm",(void*)f_7742},
{"f_7691compiler.scm",(void*)f_7691},
{"f_7694compiler.scm",(void*)f_7694},
{"f_7697compiler.scm",(void*)f_7697},
{"f_7772compiler.scm",(void*)f_7772},
{"f_7069compiler.scm",(void*)f_7069},
{"f_7054compiler.scm",(void*)f_7054},
{"f_7045compiler.scm",(void*)f_7045},
{"f_7036compiler.scm",(void*)f_7036},
{"f_7027compiler.scm",(void*)f_7027},
{"f_7018compiler.scm",(void*)f_7018},
{"f_7009compiler.scm",(void*)f_7009},
{"f_7000compiler.scm",(void*)f_7000},
{"f_6991compiler.scm",(void*)f_6991},
{"f_6982compiler.scm",(void*)f_6982},
{"f_6973compiler.scm",(void*)f_6973},
{"f_6967compiler.scm",(void*)f_6967},
{"f_6961compiler.scm",(void*)f_6961},
{"f_6286compiler.scm",(void*)f_6286},
{"f_6933compiler.scm",(void*)f_6933},
{"f_6848compiler.scm",(void*)f_6848},
{"f_6854compiler.scm",(void*)f_6854},
{"f_6874compiler.scm",(void*)f_6874},
{"f_6892compiler.scm",(void*)f_6892},
{"f_6901compiler.scm",(void*)f_6901},
{"f_6927compiler.scm",(void*)f_6927},
{"f_6915compiler.scm",(void*)f_6915},
{"f_6868compiler.scm",(void*)f_6868},
{"f_6832compiler.scm",(void*)f_6832},
{"f_6838compiler.scm",(void*)f_6838},
{"f_6707compiler.scm",(void*)f_6707},
{"f_6711compiler.scm",(void*)f_6711},
{"f_6714compiler.scm",(void*)f_6714},
{"f_6768compiler.scm",(void*)f_6768},
{"f_6764compiler.scm",(void*)f_6764},
{"f_6760compiler.scm",(void*)f_6760},
{"f_6739compiler.scm",(void*)f_6739},
{"f_6745compiler.scm",(void*)f_6745},
{"f_6756compiler.scm",(void*)f_6756},
{"f_6749compiler.scm",(void*)f_6749},
{"f_6737compiler.scm",(void*)f_6737},
{"f_6333compiler.scm",(void*)f_6333},
{"f_6355compiler.scm",(void*)f_6355},
{"f_6621compiler.scm",(void*)f_6621},
{"f_6778compiler.scm",(void*)f_6778},
{"f_6781compiler.scm",(void*)f_6781},
{"f_6826compiler.scm",(void*)f_6826},
{"f_6822compiler.scm",(void*)f_6822},
{"f_6818compiler.scm",(void*)f_6818},
{"f_6814compiler.scm",(void*)f_6814},
{"f_6586compiler.scm",(void*)f_6586},
{"f_6612compiler.scm",(void*)f_6612},
{"f_6536compiler.scm",(void*)f_6536},
{"f_6545compiler.scm",(void*)f_6545},
{"f_6573compiler.scm",(void*)f_6573},
{"f_6569compiler.scm",(void*)f_6569},
{"f_6523compiler.scm",(void*)f_6523},
{"f_6461compiler.scm",(void*)f_6461},
{"f_6484compiler.scm",(void*)f_6484},
{"f_6498compiler.scm",(void*)f_6498},
{"f_6367compiler.scm",(void*)f_6367},
{"f_6370compiler.scm",(void*)f_6370},
{"f_6446compiler.scm",(void*)f_6446},
{"f_6442compiler.scm",(void*)f_6442},
{"f_6438compiler.scm",(void*)f_6438},
{"f_6411compiler.scm",(void*)f_6411},
{"f_6422compiler.scm",(void*)f_6422},
{"f_6426compiler.scm",(void*)f_6426},
{"f_6405compiler.scm",(void*)f_6405},
{"f_6371compiler.scm",(void*)f_6371},
{"f_6382compiler.scm",(void*)f_6382},
{"f_6289compiler.scm",(void*)f_6289},
{"f_6293compiler.scm",(void*)f_6293},
{"f_6316compiler.scm",(void*)f_6316},
{"f_6327compiler.scm",(void*)f_6327},
{"f_6310compiler.scm",(void*)f_6310},
{"f_6196compiler.scm",(void*)f_6196},
{"f_6228compiler.scm",(void*)f_6228},
{"f_6247compiler.scm",(void*)f_6247},
{"f_6270compiler.scm",(void*)f_6270},
{"f_6253compiler.scm",(void*)f_6253},
{"f_6199compiler.scm",(void*)f_6199},
{"f_6205compiler.scm",(void*)f_6205},
{"f_6215compiler.scm",(void*)f_6215},
{"f_6115compiler.scm",(void*)f_6115},
{"f_6119compiler.scm",(void*)f_6119},
{"f_6122compiler.scm",(void*)f_6122},
{"f_6125compiler.scm",(void*)f_6125},
{"f_6141compiler.scm",(void*)f_6141},
{"f_6128compiler.scm",(void*)f_6128},
{"f_6131compiler.scm",(void*)f_6131},
{"f_6134compiler.scm",(void*)f_6134},
{"f_6078compiler.scm",(void*)f_6078},
{"f_6101compiler.scm",(void*)f_6101},
{"f_6088compiler.scm",(void*)f_6088},
{"f_6091compiler.scm",(void*)f_6091},
{"f_6094compiler.scm",(void*)f_6094},
{"f_6041compiler.scm",(void*)f_6041},
{"f_6064compiler.scm",(void*)f_6064},
{"f_6051compiler.scm",(void*)f_6051},
{"f_6054compiler.scm",(void*)f_6054},
{"f_6057compiler.scm",(void*)f_6057},
{"f_5996compiler.scm",(void*)f_5996},
{"f_6003compiler.scm",(void*)f_6003},
{"f_6009compiler.scm",(void*)f_6009},
{"f_5951compiler.scm",(void*)f_5951},
{"f_5958compiler.scm",(void*)f_5958},
{"f_5964compiler.scm",(void*)f_5964},
{"f_5797compiler.scm",(void*)f_5797},
{"f_5945compiler.scm",(void*)f_5945},
{"f_5801compiler.scm",(void*)f_5801},
{"f_5804compiler.scm",(void*)f_5804},
{"f_5807compiler.scm",(void*)f_5807},
{"f_5810compiler.scm",(void*)f_5810},
{"f_5813compiler.scm",(void*)f_5813},
{"f_5939compiler.scm",(void*)f_5939},
{"f_5823compiler.scm",(void*)f_5823},
{"f_5914compiler.scm",(void*)f_5914},
{"f_5922compiler.scm",(void*)f_5922},
{"f_5826compiler.scm",(void*)f_5826},
{"f_5866compiler.scm",(void*)f_5866},
{"f_5869compiler.scm",(void*)f_5869},
{"f_5888compiler.scm",(void*)f_5888},
{"f_5884compiler.scm",(void*)f_5884},
{"f_5880compiler.scm",(void*)f_5880},
{"f_5859compiler.scm",(void*)f_5859},
{"f_5849compiler.scm",(void*)f_5849},
{"f_5837compiler.scm",(void*)f_5837},
{"f_5788compiler.scm",(void*)f_5788},
{"f_5779compiler.scm",(void*)f_5779},
{"f_5770compiler.scm",(void*)f_5770},
{"f_5761compiler.scm",(void*)f_5761},
{"f_5752compiler.scm",(void*)f_5752},
{"f_5743compiler.scm",(void*)f_5743},
{"f_5734compiler.scm",(void*)f_5734},
{"f_5725compiler.scm",(void*)f_5725},
{"f_5716compiler.scm",(void*)f_5716},
{"f_5707compiler.scm",(void*)f_5707},
{"f_5698compiler.scm",(void*)f_5698},
{"f_5689compiler.scm",(void*)f_5689},
{"f_5680compiler.scm",(void*)f_5680},
{"f_5671compiler.scm",(void*)f_5671},
{"f_5662compiler.scm",(void*)f_5662},
{"f_5653compiler.scm",(void*)f_5653},
{"f_5647compiler.scm",(void*)f_5647},
{"f_5641compiler.scm",(void*)f_5641},
{"f_4696compiler.scm",(void*)f_4696},
{"f_4750compiler.scm",(void*)f_4750},
{"f_4754compiler.scm",(void*)f_4754},
{"f_5610compiler.scm",(void*)f_5610},
{"f_5620compiler.scm",(void*)f_5620},
{"f_5615compiler.scm",(void*)f_5615},
{"f_5582compiler.scm",(void*)f_5582},
{"f_5588compiler.scm",(void*)f_5588},
{"f_5564compiler.scm",(void*)f_5564},
{"f_5568compiler.scm",(void*)f_5568},
{"f_5536compiler.scm",(void*)f_5536},
{"f_5543compiler.scm",(void*)f_5543},
{"f_5519compiler.scm",(void*)f_5519},
{"f_5445compiler.scm",(void*)f_5445},
{"f_5449compiler.scm",(void*)f_5449},
{"f_5432compiler.scm",(void*)f_5432},
{"f_5424compiler.scm",(void*)f_5424},
{"f_5428compiler.scm",(void*)f_5428},
{"f_5269compiler.scm",(void*)f_5269},
{"f_5379compiler.scm",(void*)f_5379},
{"f_5368compiler.scm",(void*)f_5368},
{"f_5372compiler.scm",(void*)f_5372},
{"f_5339compiler.scm",(void*)f_5339},
{"f_5314compiler.scm",(void*)f_5314},
{"f_5289compiler.scm",(void*)f_5289},
{"f_5256compiler.scm",(void*)f_5256},
{"f_5208compiler.scm",(void*)f_5208},
{"f_5217compiler.scm",(void*)f_5217},
{"f_5215compiler.scm",(void*)f_5215},
{"f_5118compiler.scm",(void*)f_5118},
{"f_5096compiler.scm",(void*)f_5096},
{"f_5100compiler.scm",(void*)f_5100},
{"f_5069compiler.scm",(void*)f_5069},
{"f_5073compiler.scm",(void*)f_5073},
{"f_5055compiler.scm",(void*)f_5055},
{"f_5059compiler.scm",(void*)f_5059},
{"f_5034compiler.scm",(void*)f_5034},
{"f_5020compiler.scm",(void*)f_5020},
{"f_4937compiler.scm",(void*)f_4937},
{"f_4920compiler.scm",(void*)f_4920},
{"f_4924compiler.scm",(void*)f_4924},
{"f_4891compiler.scm",(void*)f_4891},
{"f_4866compiler.scm",(void*)f_4866},
{"f_4819compiler.scm",(void*)f_4819},
{"f_4849compiler.scm",(void*)f_4849},
{"f_4825compiler.scm",(void*)f_4825},
{"f_4828compiler.scm",(void*)f_4828},
{"f_4835compiler.scm",(void*)f_4835},
{"f_4831compiler.scm",(void*)f_4831},
{"f_4769compiler.scm",(void*)f_4769},
{"f_4772compiler.scm",(void*)f_4772},
{"f_4806compiler.scm",(void*)f_4806},
{"f_4800compiler.scm",(void*)f_4800},
{"f_4781compiler.scm",(void*)f_4781},
{"f_4790compiler.scm",(void*)f_4790},
{"f_4798compiler.scm",(void*)f_4798},
{"f_4784compiler.scm",(void*)f_4784},
{"f_4788compiler.scm",(void*)f_4788},
{"f_4760compiler.scm",(void*)f_4760},
{"f_4699compiler.scm",(void*)f_4699},
{"f_4722compiler.scm",(void*)f_4722},
{"f_4712compiler.scm",(void*)f_4712},
{"f_1942compiler.scm",(void*)f_1942},
{"f_4691compiler.scm",(void*)f_4691},
{"f_4654compiler.scm",(void*)f_4654},
{"f_4657compiler.scm",(void*)f_4657},
{"f_4672compiler.scm",(void*)f_4672},
{"f_4681compiler.scm",(void*)f_4681},
{"f_4685compiler.scm",(void*)f_4685},
{"f_4668compiler.scm",(void*)f_4668},
{"f_4641compiler.scm",(void*)f_4641},
{"f_4647compiler.scm",(void*)f_4647},
{"f_2114compiler.scm",(void*)f_2114},
{"f_2151compiler.scm",(void*)f_2151},
{"f_4502compiler.scm",(void*)f_4502},
{"f_4617compiler.scm",(void*)f_4617},
{"f_4517compiler.scm",(void*)f_4517},
{"f_4604compiler.scm",(void*)f_4604},
{"f_4526compiler.scm",(void*)f_4526},
{"f_4529compiler.scm",(void*)f_4529},
{"f_4538compiler.scm",(void*)f_4538},
{"f_4560compiler.scm",(void*)f_4560},
{"f_4553compiler.scm",(void*)f_4553},
{"f_4505compiler.scm",(void*)f_4505},
{"f_4508compiler.scm",(void*)f_4508},
{"f_2178compiler.scm",(void*)f_2178},
{"f_2184compiler.scm",(void*)f_2184},
{"f_4484compiler.scm",(void*)f_4484},
{"f_2187compiler.scm",(void*)f_2187},
{"f_2194compiler.scm",(void*)f_2194},
{"f_2203compiler.scm",(void*)f_2203},
{"f_2212compiler.scm",(void*)f_2212},
{"f_2339compiler.scm",(void*)f_2339},
{"f_4404compiler.scm",(void*)f_4404},
{"f_4410compiler.scm",(void*)f_4410},
{"f_4315compiler.scm",(void*)f_4315},
{"f_4375compiler.scm",(void*)f_4375},
{"f_4275compiler.scm",(void*)f_4275},
{"f_4279compiler.scm",(void*)f_4279},
{"f_4285compiler.scm",(void*)f_4285},
{"f_4299compiler.scm",(void*)f_4299},
{"f_4288compiler.scm",(void*)f_4288},
{"f_3911compiler.scm",(void*)f_3911},
{"f_4259compiler.scm",(void*)f_4259},
{"f_3933compiler.scm",(void*)f_3933},
{"f_4224compiler.scm",(void*)f_4224},
{"f_3936compiler.scm",(void*)f_3936},
{"f_3947compiler.scm",(void*)f_3947},
{"f_4174compiler.scm",(void*)f_4174},
{"f_4218compiler.scm",(void*)f_4218},
{"f_4214compiler.scm",(void*)f_4214},
{"f_4210compiler.scm",(void*)f_4210},
{"f_4198compiler.scm",(void*)f_4198},
{"f_3967compiler.scm",(void*)f_3967},
{"f_4046compiler.scm",(void*)f_4046},
{"f_4023compiler.scm",(void*)f_4023},
{"f_4018compiler.scm",(void*)f_4018},
{"f_3981compiler.scm",(void*)f_3981},
{"f_3971compiler.scm",(void*)f_3971},
{"f_3955compiler.scm",(void*)f_3955},
{"f_3943compiler.scm",(void*)f_3943},
{"f_3901compiler.scm",(void*)f_3901},
{"f_3878compiler.scm",(void*)f_3878},
{"f_3876compiler.scm",(void*)f_3876},
{"f_3805compiler.scm",(void*)f_3805},
{"f_3823compiler.scm",(void*)f_3823},
{"f_3845compiler.scm",(void*)f_3845},
{"f_3851compiler.scm",(void*)f_3851},
{"f_3829compiler.scm",(void*)f_3829},
{"f_3836compiler.scm",(void*)f_3836},
{"f_3811compiler.scm",(void*)f_3811},
{"f_3817compiler.scm",(void*)f_3817},
{"f_3803compiler.scm",(void*)f_3803},
{"f_3741compiler.scm",(void*)f_3741},
{"f_3752compiler.scm",(void*)f_3752},
{"f_3762compiler.scm",(void*)f_3762},
{"f_3765compiler.scm",(void*)f_3765},
{"f_3769compiler.scm",(void*)f_3769},
{"f_3755compiler.scm",(void*)f_3755},
{"f_3680compiler.scm",(void*)f_3680},
{"f_3684compiler.scm",(void*)f_3684},
{"f_3722compiler.scm",(void*)f_3722},
{"f_3688compiler.scm",(void*)f_3688},
{"f_3702compiler.scm",(void*)f_3702},
{"f_3700compiler.scm",(void*)f_3700},
{"f_3662compiler.scm",(void*)f_3662},
{"f_3670compiler.scm",(void*)f_3670},
{"f_3535compiler.scm",(void*)f_3535},
{"f_3538compiler.scm",(void*)f_3538},
{"f_3544compiler.scm",(void*)f_3544},
{"f_3623compiler.scm",(void*)f_3623},
{"f_3600compiler.scm",(void*)f_3600},
{"f_3575compiler.scm",(void*)f_3575},
{"f_3583compiler.scm",(void*)f_3583},
{"f_3571compiler.scm",(void*)f_3571},
{"f_3567compiler.scm",(void*)f_3567},
{"f_3559compiler.scm",(void*)f_3559},
{"f_3460compiler.scm",(void*)f_3460},
{"f_3469compiler.scm",(void*)f_3469},
{"f_3508compiler.scm",(void*)f_3508},
{"f_3500compiler.scm",(void*)f_3500},
{"f_3472compiler.scm",(void*)f_3472},
{"f_3492compiler.scm",(void*)f_3492},
{"f_3484compiler.scm",(void*)f_3484},
{"f_3440compiler.scm",(void*)f_3440},
{"f_3386compiler.scm",(void*)f_3386},
{"f_3389compiler.scm",(void*)f_3389},
{"f_3392compiler.scm",(void*)f_3392},
{"f_3396compiler.scm",(void*)f_3396},
{"f_3400compiler.scm",(void*)f_3400},
{"f_3319compiler.scm",(void*)f_3319},
{"f_3331compiler.scm",(void*)f_3331},
{"f_3304compiler.scm",(void*)f_3304},
{"f_3291compiler.scm",(void*)f_3291},
{"f_3278compiler.scm",(void*)f_3278},
{"f_3265compiler.scm",(void*)f_3265},
{"f_3252compiler.scm",(void*)f_3252},
{"f_3185compiler.scm",(void*)f_3185},
{"f_3204compiler.scm",(void*)f_3204},
{"f_3231compiler.scm",(void*)f_3231},
{"f_3235compiler.scm",(void*)f_3235},
{"f_3224compiler.scm",(void*)f_3224},
{"f_3198compiler.scm",(void*)f_3198},
{"f_3172compiler.scm",(void*)f_3172},
{"f_3157compiler.scm",(void*)f_3157},
{"f_3130compiler.scm",(void*)f_3130},
{"f_3134compiler.scm",(void*)f_3134},
{"f_3109compiler.scm",(void*)f_3109},
{"f_3080compiler.scm",(void*)f_3080},
{"f_3084compiler.scm",(void*)f_3084},
{"f_3051compiler.scm",(void*)f_3051},
{"f_3055compiler.scm",(void*)f_3055},
{"f_2877compiler.scm",(void*)f_2877},
{"f_2886compiler.scm",(void*)f_2886},
{"f_2889compiler.scm",(void*)f_2889},
{"f_2997compiler.scm",(void*)f_2997},
{"f_3026compiler.scm",(void*)f_3026},
{"f_3030compiler.scm",(void*)f_3030},
{"f_3000compiler.scm",(void*)f_3000},
{"f_3006compiler.scm",(void*)f_3006},
{"f_3019compiler.scm",(void*)f_3019},
{"f_3009compiler.scm",(void*)f_3009},
{"f_2892compiler.scm",(void*)f_2892},
{"f_2987compiler.scm",(void*)f_2987},
{"f_2895compiler.scm",(void*)f_2895},
{"f_2950compiler.scm",(void*)f_2950},
{"f_2981compiler.scm",(void*)f_2981},
{"f_2973compiler.scm",(void*)f_2973},
{"f_2907compiler.scm",(void*)f_2907},
{"f_2938compiler.scm",(void*)f_2938},
{"f_2926compiler.scm",(void*)f_2926},
{"f_2839compiler.scm",(void*)f_2839},
{"f_2865compiler.scm",(void*)f_2865},
{"f_2842compiler.scm",(void*)f_2842},
{"f_2857compiler.scm",(void*)f_2857},
{"f_2855compiler.scm",(void*)f_2855},
{"f_2845compiler.scm",(void*)f_2845},
{"f_2848compiler.scm",(void*)f_2848},
{"f_2574compiler.scm",(void*)f_2574},
{"f_2789compiler.scm",(void*)f_2789},
{"f_2800compiler.scm",(void*)f_2800},
{"f_2794compiler.scm",(void*)f_2794},
{"f_2583compiler.scm",(void*)f_2583},
{"f_2588compiler.scm",(void*)f_2588},
{"f_2592compiler.scm",(void*)f_2592},
{"f_2786compiler.scm",(void*)f_2786},
{"f_2595compiler.scm",(void*)f_2595},
{"f_2778compiler.scm",(void*)f_2778},
{"f_2598compiler.scm",(void*)f_2598},
{"f_2601compiler.scm",(void*)f_2601},
{"f_2776compiler.scm",(void*)f_2776},
{"f_2769compiler.scm",(void*)f_2769},
{"f_2604compiler.scm",(void*)f_2604},
{"f_2610compiler.scm",(void*)f_2610},
{"f_2619compiler.scm",(void*)f_2619},
{"f_2639compiler.scm",(void*)f_2639},
{"f_2723compiler.scm",(void*)f_2723},
{"f_2719compiler.scm",(void*)f_2719},
{"f_2715compiler.scm",(void*)f_2715},
{"f_2672compiler.scm",(void*)f_2672},
{"f_2679compiler.scm",(void*)f_2679},
{"f_2629compiler.scm",(void*)f_2629},
{"f_2500compiler.scm",(void*)f_2500},
{"f_2506compiler.scm",(void*)f_2506},
{"f_2509compiler.scm",(void*)f_2509},
{"f_2562compiler.scm",(void*)f_2562},
{"f_2512compiler.scm",(void*)f_2512},
{"f_2515compiler.scm",(void*)f_2515},
{"f_2542compiler.scm",(void*)f_2542},
{"f_2550compiler.scm",(void*)f_2550},
{"f_2522compiler.scm",(void*)f_2522},
{"f_2536compiler.scm",(void*)f_2536},
{"f_2530compiler.scm",(void*)f_2530},
{"f_2526compiler.scm",(void*)f_2526},
{"f_2386compiler.scm",(void*)f_2386},
{"f_2396compiler.scm",(void*)f_2396},
{"f_2407compiler.scm",(void*)f_2407},
{"f_2481compiler.scm",(void*)f_2481},
{"f_2491compiler.scm",(void*)f_2491},
{"f_2472compiler.scm",(void*)f_2472},
{"f_2446compiler.scm",(void*)f_2446},
{"f_2460compiler.scm",(void*)f_2460},
{"f_2458compiler.scm",(void*)f_2458},
{"f_2434compiler.scm",(void*)f_2434},
{"f_2411compiler.scm",(void*)f_2411},
{"f_2418compiler.scm",(void*)f_2418},
{"f_2401compiler.scm",(void*)f_2401},
{"f_2380compiler.scm",(void*)f_2380},
{"f_2348compiler.scm",(void*)f_2348},
{"f_2351compiler.scm",(void*)f_2351},
{"f_2362compiler.scm",(void*)f_2362},
{"f_2356compiler.scm",(void*)f_2356},
{"f_2354compiler.scm",(void*)f_2354},
{"f_2306compiler.scm",(void*)f_2306},
{"f_2318compiler.scm",(void*)f_2318},
{"f_2322compiler.scm",(void*)f_2322},
{"f_2281compiler.scm",(void*)f_2281},
{"f_2235compiler.scm",(void*)f_2235},
{"f_2242compiler.scm",(void*)f_2242},
{"f_2246compiler.scm",(void*)f_2246},
{"f_2250compiler.scm",(void*)f_2250},
{"f_2139compiler.scm",(void*)f_2139},
{"f_2133compiler.scm",(void*)f_2133},
{"f_2023compiler.scm",(void*)f_2023},
{"f_2027compiler.scm",(void*)f_2027},
{"f_2040compiler.scm",(void*)f_2040},
{"f_2088compiler.scm",(void*)f_2088},
{"f_2098compiler.scm",(void*)f_2098},
{"f_2058compiler.scm",(void*)f_2058},
{"f_2068compiler.scm",(void*)f_2068},
{"f_1981compiler.scm",(void*)f_1981},
{"f_1988compiler.scm",(void*)f_1988},
{"f_1957compiler.scm",(void*)f_1957},
{"f_1963compiler.scm",(void*)f_1963},
{"f_1945compiler.scm",(void*)f_1945},
{"f_1877compiler.scm",(void*)f_1877},
{"f_1940compiler.scm",(void*)f_1940},
{"f_1881compiler.scm",(void*)f_1881},
{"f_1933compiler.scm",(void*)f_1933},
{"f_1884compiler.scm",(void*)f_1884},
{"f_1926compiler.scm",(void*)f_1926},
{"f_1887compiler.scm",(void*)f_1887},
{"f_1891compiler.scm",(void*)f_1891},
{"f_1895compiler.scm",(void*)f_1895},
{"f_1899compiler.scm",(void*)f_1899},
{"f_1919compiler.scm",(void*)f_1919},
{"f_1902compiler.scm",(void*)f_1902},
{"f_1912compiler.scm",(void*)f_1912},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
