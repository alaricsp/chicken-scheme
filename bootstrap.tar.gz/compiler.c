/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-18 09:45
   Version 3.1.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10129	compiled 2008-03-23 on debian (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[578];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11202)
static void C_ccall f_11202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11208)
static void C_ccall f_11208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11211)
static void C_ccall f_11211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11002)
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11008)
static void C_ccall f_11008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10235)
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10991)
static void C_ccall f_10991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10988)
static void C_ccall f_10988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10901)
static void C_fcall f_10901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10978)
static void C_ccall f_10978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10949)
static void C_ccall f_10949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10922)
static void C_fcall f_10922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10873)
static void C_fcall f_10873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10876)
static void C_ccall f_10876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_fcall f_10842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_fcall f_10833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10836)
static void C_ccall f_10836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10811)
static void C_ccall f_10811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10744)
static void C_fcall f_10744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10768)
static void C_ccall f_10768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10760)
static void C_ccall f_10760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10673)
static void C_ccall f_10673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10485)
static void C_ccall f_10485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10606)
static void C_ccall f_10606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10612)
static void C_ccall f_10612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10618)
static void C_fcall f_10618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_ccall f_10492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10597)
static void C_ccall f_10597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10498)
static void C_ccall f_10498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10501)
static void C_ccall f_10501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10539)
static void C_ccall f_10539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10565)
static void C_ccall f_10565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10546)
static void C_fcall f_10546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10550)
static void C_ccall f_10550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10523)
static void C_ccall f_10523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10429)
static void C_ccall f_10429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_fcall f_10438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_fcall f_10432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10413)
static void C_ccall f_10413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10386)
static void C_ccall f_10386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10365)
static void C_ccall f_10365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10341)
static void C_ccall f_10341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10337)
static void C_ccall f_10337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10293)
static void C_ccall f_10293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10152)
static void C_ccall f_10152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10167)
static void C_ccall f_10167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_fcall f_10182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10227)
static void C_ccall f_10227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_fcall f_10192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10202)
static void C_ccall f_10202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11014)
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11083)
static void C_ccall f_11083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11073)
static void C_ccall f_11073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11047)
static void C_ccall f_11047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11108)
static void C_fcall f_11108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11124)
static void C_ccall f_11124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11138)
static void C_ccall f_11138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11122)
static void C_ccall f_11122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11094)
static void C_fcall f_11094(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_fcall f_11140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11153)
static void C_ccall f_11153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10109)
static void C_ccall f_10109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10091)
static void C_ccall f_10091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10082)
static void C_ccall f_10082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10073)
static void C_ccall f_10073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10064)
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10055)
static void C_ccall f_10055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10046)
static void C_ccall f_10046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10001)
static void C_ccall f_10001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9992)
static void C_ccall f_9992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9983)
static void C_ccall f_9983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9974)
static void C_ccall f_9974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9965)
static void C_ccall f_9965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9956)
static void C_ccall f_9956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9938)
static void C_ccall f_9938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9929)
static void C_ccall f_9929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9911)
static void C_ccall f_9911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9902)
static void C_ccall f_9902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9884)
static void C_ccall f_9884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9863)
static void C_ccall f_9863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9830)
static void C_ccall f_9830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9833)
static void C_ccall f_9833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9839)
static void C_ccall f_9839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_ccall f_9845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_fcall f_9682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9688)
static void C_ccall f_9688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8993)
static void C_fcall f_8993(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9012)
static void C_fcall f_9012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9045)
static void C_fcall f_9045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9561)
static void C_fcall f_9561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9418)
static void C_ccall f_9418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9501)
static void C_ccall f_9501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9505)
static void C_ccall f_9505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9427)
static void C_ccall f_9427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9478)
static void C_ccall f_9478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9454)
static void C_ccall f_9454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_fcall f_9169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9358)
static void C_ccall f_9358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9331)
static void C_ccall f_9331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9312)
static void C_ccall f_9312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9288)
static void C_ccall f_9288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_ccall f_9275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9257)
static void C_ccall f_9257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9234)
static void C_ccall f_9234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9195)
static void C_ccall f_9195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9209)
static void C_ccall f_9209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9066)
static void C_ccall f_9066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9069)
static void C_ccall f_9069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9051)
static void C_ccall f_9051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9694)
static void C_fcall f_9694(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9701)
static void C_ccall f_9701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9717)
static void C_ccall f_9717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8659)
static void C_fcall f_8659(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8678)
static void C_fcall f_8678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8918)
static void C_ccall f_8918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9733)
static void C_ccall f_9733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9771)
static void C_fcall f_9771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_fcall f_9783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8931)
static void C_ccall f_8931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8945)
static void C_ccall f_8945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_fcall f_8780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8792)
static void C_ccall f_8792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_fcall f_8798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8816)
static void C_fcall f_8816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8823)
static void C_ccall f_8823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_fcall f_8768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_fcall f_8758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_fcall f_8648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_fcall f_8632(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8516)
static void C_ccall f_8516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_fcall f_8481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8427)
static void C_fcall f_8427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8442)
static void C_fcall f_8442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_fcall f_8436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7895)
static void C_ccall f_7895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8410)
static void C_ccall f_8410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8370)
static void C_ccall f_8370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_fcall f_8376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_fcall f_8332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_fcall f_8344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_fcall f_8233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8301)
static void C_fcall f_8301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_fcall f_8261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_fcall f_8197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_fcall f_8185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_fcall f_8170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_ccall f_8138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_fcall f_8091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7941)
static void C_fcall f_7941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_fcall f_7962(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_fcall f_7983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_fcall f_7922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_ccall f_7926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_fcall f_7833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7819)
static void C_fcall f_7819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_fcall f_7698(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7117)
static void C_fcall f_7117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7139)
static void C_fcall f_7139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_ccall f_7546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_fcall f_7575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7590)
static void C_fcall f_7590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7581)
static void C_fcall f_7581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_fcall f_7455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_fcall f_7488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_fcall f_7458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7710)
static void C_fcall f_7710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7723)
static void C_fcall f_7723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_fcall f_7732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7110)
static C_word C_fcall f_7110(C_word t0);
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7002)
static void C_ccall f_7002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6889)
static void C_fcall f_6889(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6895)
static void C_fcall f_6895(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_fcall f_6873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6748)
static void C_fcall f_6748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_fcall f_6374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6396)
static void C_fcall f_6396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6662)
static void C_fcall f_6662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6819)
static void C_ccall f_6819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_ccall f_6653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6502)
static void C_fcall f_6502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_ccall f_6446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6269)
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_fcall f_6240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6246)
static void C_fcall f_6246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6160)
static void C_fcall f_6160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_fcall f_6163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6132)
static void C_ccall f_6132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_fcall f_5864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5757)
static void C_ccall f_5757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4791)
static void C_fcall f_4791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_fcall f_5465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_fcall f_5159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_fcall f_4876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_fcall f_4753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_fcall f_4682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_fcall f_4558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_fcall f_4579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_fcall f_2380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_fcall f_4316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_fcall f_4265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static C_word C_fcall f_4064(C_word *a,C_word t0);
C_noret_decl(f_4059)
static void C_fcall f_4059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static C_word C_fcall f_4022(C_word *a,C_word t0);
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_fcall f_3513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_fcall f_3245(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_fcall f_3041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_fcall f_2810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_fcall f_2660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_fcall f_2680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_fcall f_2713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_fcall f_2475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_fcall f_2130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2039)
static void C_fcall f_2039(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2004)
static void C_fcall f_2004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1961)
static C_word C_fcall f_1961(C_word t0,C_word t1);
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11002)
static void C_fcall trf_11002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11002(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11002(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10235)
static void C_fcall trf_10235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10235(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10235(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10901)
static void C_fcall trf_10901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10901(t0,t1);}

C_noret_decl(trf_10922)
static void C_fcall trf_10922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10922(t0,t1);}

C_noret_decl(trf_10873)
static void C_fcall trf_10873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10873(t0,t1);}

C_noret_decl(trf_10842)
static void C_fcall trf_10842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10842(t0,t1);}

C_noret_decl(trf_10833)
static void C_fcall trf_10833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10833(t0,t1);}

C_noret_decl(trf_10744)
static void C_fcall trf_10744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10744(t0,t1);}

C_noret_decl(trf_10618)
static void C_fcall trf_10618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10618(t0,t1);}

C_noret_decl(trf_10546)
static void C_fcall trf_10546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10546(t0,t1);}

C_noret_decl(trf_10438)
static void C_fcall trf_10438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10438(t0,t1);}

C_noret_decl(trf_10432)
static void C_fcall trf_10432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10432(t0,t1);}

C_noret_decl(trf_10148)
static void C_fcall trf_10148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10148(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10148(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10182)
static void C_fcall trf_10182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10182(t0,t1,t2,t3);}

C_noret_decl(trf_10192)
static void C_fcall trf_10192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10192(t0,t1);}

C_noret_decl(trf_11014)
static void C_fcall trf_11014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11014(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11014(t0,t1,t2);}

C_noret_decl(trf_11108)
static void C_fcall trf_11108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11108(t0,t1,t2);}

C_noret_decl(trf_11094)
static void C_fcall trf_11094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11094(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11094(t0,t1,t2);}

C_noret_decl(trf_11140)
static void C_fcall trf_11140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11140(t0,t1);}

C_noret_decl(trf_9682)
static void C_fcall trf_9682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9682(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9682(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8993)
static void C_fcall trf_8993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8993(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8993(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9012)
static void C_fcall trf_9012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9012(t0,t1);}

C_noret_decl(trf_9045)
static void C_fcall trf_9045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9045(t0,t1);}

C_noret_decl(trf_9561)
static void C_fcall trf_9561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9561(t0,t1);}

C_noret_decl(trf_9169)
static void C_fcall trf_9169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9169(t0,t1);}

C_noret_decl(trf_9694)
static void C_fcall trf_9694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9694(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9694(t0,t1,t2,t3);}

C_noret_decl(trf_8659)
static void C_fcall trf_8659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8659(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8659(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8678)
static void C_fcall trf_8678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8678(t0,t1);}

C_noret_decl(trf_9771)
static void C_fcall trf_9771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9771(t0,t1);}

C_noret_decl(trf_9783)
static void C_fcall trf_9783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9783(t0,t1);}

C_noret_decl(trf_8780)
static void C_fcall trf_8780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8780(t0,t1);}

C_noret_decl(trf_8798)
static void C_fcall trf_8798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8798(t0,t1);}

C_noret_decl(trf_8816)
static void C_fcall trf_8816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8816(t0,t1);}

C_noret_decl(trf_8768)
static void C_fcall trf_8768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8768(t0,t1);}

C_noret_decl(trf_8758)
static void C_fcall trf_8758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8758(t0,t1);}

C_noret_decl(trf_8648)
static void C_fcall trf_8648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8648(t0,t1,t2);}

C_noret_decl(trf_8638)
static void C_fcall trf_8638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8638(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8638(t0,t1,t2,t3);}

C_noret_decl(trf_8632)
static void C_fcall trf_8632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8632(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8632(t0,t1,t2,t3);}

C_noret_decl(trf_8481)
static void C_fcall trf_8481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8481(t0,t1);}

C_noret_decl(trf_8427)
static void C_fcall trf_8427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8427(t0,t1);}

C_noret_decl(trf_8442)
static void C_fcall trf_8442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8442(t0,t1);}

C_noret_decl(trf_8436)
static void C_fcall trf_8436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8436(t0,t1);}

C_noret_decl(trf_8376)
static void C_fcall trf_8376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8376(t0,t1);}

C_noret_decl(trf_8332)
static void C_fcall trf_8332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8332(t0,t1);}

C_noret_decl(trf_8344)
static void C_fcall trf_8344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8344(t0,t1);}

C_noret_decl(trf_8233)
static void C_fcall trf_8233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8233(t0,t1);}

C_noret_decl(trf_8301)
static void C_fcall trf_8301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8301(t0,t1);}

C_noret_decl(trf_8261)
static void C_fcall trf_8261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8261(t0,t1);}

C_noret_decl(trf_8197)
static void C_fcall trf_8197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8197(t0,t1);}

C_noret_decl(trf_8185)
static void C_fcall trf_8185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8185(t0,t1);}

C_noret_decl(trf_8170)
static void C_fcall trf_8170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8170(t0,t1);}

C_noret_decl(trf_8091)
static void C_fcall trf_8091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8091(t0,t1);}

C_noret_decl(trf_7941)
static void C_fcall trf_7941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7941(t0,t1);}

C_noret_decl(trf_7962)
static void C_fcall trf_7962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7962(t0,t1);}

C_noret_decl(trf_7983)
static void C_fcall trf_7983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7983(t0,t1);}

C_noret_decl(trf_7922)
static void C_fcall trf_7922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7922(t0,t1);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7878(t0,t1);}

C_noret_decl(trf_7833)
static void C_fcall trf_7833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7833(t0,t1,t2,t3);}

C_noret_decl(trf_7819)
static void C_fcall trf_7819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7819(t0,t1,t2,t3);}

C_noret_decl(trf_7698)
static void C_fcall trf_7698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7698(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7698(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7117)
static void C_fcall trf_7117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7117(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7117(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7139)
static void C_fcall trf_7139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7139(t0,t1);}

C_noret_decl(trf_7575)
static void C_fcall trf_7575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7575(t0,t1);}

C_noret_decl(trf_7590)
static void C_fcall trf_7590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7590(t0,t1);}

C_noret_decl(trf_7581)
static void C_fcall trf_7581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7581(t0,t1);}

C_noret_decl(trf_7455)
static void C_fcall trf_7455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7455(t0,t1);}

C_noret_decl(trf_7488)
static void C_fcall trf_7488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7488(t0,t1);}

C_noret_decl(trf_7458)
static void C_fcall trf_7458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7458(t0,t1);}

C_noret_decl(trf_7330)
static void C_fcall trf_7330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7330(t0,t1,t2,t3);}

C_noret_decl(trf_7710)
static void C_fcall trf_7710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7710(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7710(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7723)
static void C_fcall trf_7723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7723(t0,t1);}

C_noret_decl(trf_7732)
static void C_fcall trf_7732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7732(t0,t1);}

C_noret_decl(trf_7813)
static void C_fcall trf_7813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7813(t0,t1,t2,t3);}

C_noret_decl(trf_6889)
static void C_fcall trf_6889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6889(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6889(t0,t1,t2,t3);}

C_noret_decl(trf_6895)
static void C_fcall trf_6895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6895(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6895(t0,t1,t2,t3);}

C_noret_decl(trf_6873)
static void C_fcall trf_6873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6873(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6873(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6748)
static void C_fcall trf_6748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6748(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6748(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6374)
static void C_fcall trf_6374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6374(t0,t1,t2,t3);}

C_noret_decl(trf_6396)
static void C_fcall trf_6396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6396(t0,t1);}

C_noret_decl(trf_6662)
static void C_fcall trf_6662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6662(t0,t1);}

C_noret_decl(trf_6502)
static void C_fcall trf_6502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6502(t0,t1,t2,t3);}

C_noret_decl(trf_6330)
static void C_fcall trf_6330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6330(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6330(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6269)
static void C_fcall trf_6269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6269(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6269(t0,t1,t2);}

C_noret_decl(trf_6240)
static void C_fcall trf_6240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6240(t0,t1,t2);}

C_noret_decl(trf_6246)
static void C_fcall trf_6246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6246(t0,t1,t2);}

C_noret_decl(trf_6160)
static void C_fcall trf_6160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6160(t0,t1);}

C_noret_decl(trf_6163)
static void C_fcall trf_6163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6163(t0,t1);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6166(t0,t1);}

C_noret_decl(trf_5864)
static void C_fcall trf_5864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5864(t0,t1);}

C_noret_decl(trf_4791)
static void C_fcall trf_4791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4791(t0,t1);}

C_noret_decl(trf_5465)
static void C_fcall trf_5465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5465(t0,t1);}

C_noret_decl(trf_5159)
static void C_fcall trf_5159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5159(t0,t1);}

C_noret_decl(trf_4876)
static void C_fcall trf_4876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4876(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4740(t0,t1,t2,t3);}

C_noret_decl(trf_4753)
static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4753(t0,t1);}

C_noret_decl(trf_4682)
static void C_fcall trf_4682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4682(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4682(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2148(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4558)
static void C_fcall trf_4558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4558(t0,t1);}

C_noret_decl(trf_4579)
static void C_fcall trf_4579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4579(t0,t1);}

C_noret_decl(trf_2380)
static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2380(t0,t1);}

C_noret_decl(trf_4316)
static void C_fcall trf_4316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4316(t0,t1);}

C_noret_decl(trf_4265)
static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4265(t0,t1);}

C_noret_decl(trf_4215)
static void C_fcall trf_4215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4215(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4215(t0,t1,t2,t3);}

C_noret_decl(trf_4059)
static void C_fcall trf_4059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4059(t0,t1);}

C_noret_decl(trf_3616)
static void C_fcall trf_3616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3616(t0,t1);}

C_noret_decl(trf_3513)
static void C_fcall trf_3513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3513(t0,t1);}

C_noret_decl(trf_3245)
static void C_fcall trf_3245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3245(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3245(t0,t1,t2);}

C_noret_decl(trf_3041)
static void C_fcall trf_3041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3041(t0,t1);}

C_noret_decl(trf_2810)
static void C_fcall trf_2810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2810(t0,t1);}

C_noret_decl(trf_2660)
static void C_fcall trf_2660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2660(t0,t1);}

C_noret_decl(trf_2680)
static void C_fcall trf_2680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2680(t0,t1);}

C_noret_decl(trf_2713)
static void C_fcall trf_2713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2713(t0,t1);}

C_noret_decl(trf_2670)
static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2670(t0,t1,t2);}

C_noret_decl(trf_2427)
static void C_fcall trf_2427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2427(t0,t1,t2);}

C_noret_decl(trf_2475)
static void C_fcall trf_2475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2475(t0,t1);}

C_noret_decl(trf_2130)
static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2130(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2039)
static void C_fcall trf_2039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2039(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2039(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2004)
static void C_fcall trf_2004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2004(t0,t1);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1973(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5592)){
C_save(t1);
C_rereclaim2(5592*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,578);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],29,"\010compilerliteral-rewrite-hook");
lf[94]=C_h_intern(&lf[94],28,"\010compilerinitialize-compiler");
lf[95]=C_h_intern(&lf[95],12,"vector-fill!");
lf[96]=C_h_intern(&lf[96],11,"make-vector");
lf[97]=C_h_intern(&lf[97],25,"\010compilermake-random-name");
lf[98]=C_h_intern(&lf[98],12,"profile-info");
lf[99]=C_h_intern(&lf[99],32,"\010compilercanonicalize-expression");
lf[100]=C_h_intern(&lf[100],23,"\010compilerset-real-name!");
lf[101]=C_h_intern(&lf[101],8,"for-each");
lf[102]=C_h_intern(&lf[102],5,"quote");
lf[103]=C_h_intern(&lf[103],15,"\004coreinline_ref");
lf[104]=C_h_intern(&lf[104],36,"\010compilerforeign-type-convert-result");
lf[105]=C_h_intern(&lf[105],30,"\010compilerfinish-foreign-result");
lf[106]=C_h_intern(&lf[106],27,"\010compilerfinal-foreign-type");
lf[107]=C_h_intern(&lf[107],19,"\004coreinline_loc_ref");
lf[108]=C_h_intern(&lf[108],18,"\003syshash-table-ref");
lf[109]=C_h_intern(&lf[109],21,"\003sysalias-global-hook");
lf[110]=C_h_intern(&lf[110],12,"syntax-error");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[112]=C_h_intern(&lf[112],24,"\003syssyntax-error-culprit");
lf[113]=C_h_intern(&lf[113],2,"if");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],16,"\003syscheck-syntax");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_h_intern(&lf[118],10,"\004corecheck");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[120]=C_h_intern(&lf[120],14,"\004coreimmutable");
lf[121]=C_h_intern(&lf[121],10,"alist-cons");
lf[122]=C_h_intern(&lf[122],6,"gensym");
lf[123]=C_h_intern(&lf[123],1,"c");
lf[124]=C_h_intern(&lf[124],6,"cadadr");
lf[125]=C_h_intern(&lf[125],14,"\004coreundefined");
lf[126]=C_h_intern(&lf[126],23,"\004corerequire-for-syntax");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],10,"lset-union");
lf[129]=C_h_intern(&lf[129],3,"eq\077");
lf[130]=C_h_intern(&lf[130],22,"\003syshash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[237]=C_h_intern(&lf[237],29,"\010compilercollapsable-literal\077");
lf[238]=C_h_intern(&lf[238],4,"quit");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[240]=C_h_intern(&lf[240],22,"with-exception-handler");
lf[241]=C_h_intern(&lf[241],30,"call-with-current-continuation");
lf[242]=C_h_intern(&lf[242],12,"\004coredeclare");
lf[243]=C_h_intern(&lf[243],28,"\010compilerprocess-declaration");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],8,"split-at");
lf[246]=C_h_intern(&lf[246],1,"r");
lf[247]=C_h_intern(&lf[247],17,"\003sysmake-c-string");
lf[248]=C_h_intern(&lf[248],3,"and");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[252]=C_h_intern(&lf[252],25,"nonnull-unsigned-c-string");
lf[253]=C_h_intern(&lf[253],16,"nonnull-c-string");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[256]=C_h_intern(&lf[256],18,"unsigned-c-string*");
lf[257]=C_h_intern(&lf[257],9,"c-string*");
lf[258]=C_h_intern(&lf[258],13,"c-string-list");
lf[259]=C_h_intern(&lf[259],14,"c-string-list*");
lf[260]=C_h_intern(&lf[260],8,"c-string");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[262]=C_h_intern(&lf[262],17,"unsigned-c-string");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[266]=C_h_intern(&lf[266],28,"\010compilervalid-c-identifier\077");
lf[267]=C_h_intern(&lf[267],8,"location");
lf[268]=C_h_intern(&lf[268],17,"\003sysmake-locative");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[270]=C_h_intern(&lf[270],13,"\004corecallunit");
lf[271]=C_h_intern(&lf[271],14,"\004coreprimitive");
lf[272]=C_h_intern(&lf[272],37,"\010compilerupdate-line-number-database!");
lf[273]=C_h_intern(&lf[273],23,"\003sysmacroexpand-1-local");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[276]=C_h_intern(&lf[276],31,"\010compileremit-syntax-trace-info");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[278]=C_h_intern(&lf[278],4,"list");
lf[279]=C_h_intern(&lf[279],1,"t");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[281]=C_h_intern(&lf[281],4,"caar");
lf[282]=C_h_intern(&lf[282],18,"\010compilerconstant\077");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[284]=C_h_intern(&lf[284],26,"\010compilerinternal-bindings");
lf[285]=C_h_intern(&lf[285],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[286]=C_h_intern(&lf[286],7,"reverse");
lf[287]=C_h_intern(&lf[287],22,"\003sysclear-trace-buffer");
lf[288]=C_h_intern(&lf[288],26,"\010compilerdebugging-chicken");
lf[289]=C_h_intern(&lf[289],12,"pretty-print");
lf[290]=C_h_intern(&lf[290],7,"newline");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],4,"uses");
lf[294]=C_h_intern(&lf[294],29,"\010compilerstring->c-identifier");
lf[295]=C_h_intern(&lf[295],18,"\010compilerstringify");
lf[296]=C_h_intern(&lf[296],17,"register-feature!");
lf[297]=C_h_intern(&lf[297],4,"unit");
lf[298]=C_h_intern(&lf[298],5,"usage");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[300]=C_h_intern(&lf[300],34,"\010compilerdefault-standard-bindings");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-extended-bindings");
lf[302]=C_h_intern(&lf[302],18,"usual-integrations");
lf[303]=C_h_intern(&lf[303],17,"lset-intersection");
lf[304]=C_h_intern(&lf[304],6,"fixnum");
lf[305]=C_h_intern(&lf[305],17,"fixnum-arithmetic");
lf[306]=C_h_intern(&lf[306],23,"\005matchset-error-control");
lf[307]=C_h_intern(&lf[307],12,"\000unspecified");
lf[308]=C_h_intern(&lf[308],4,"safe");
lf[309]=C_h_intern(&lf[309],18,"interrupts-enabled");
lf[310]=C_h_intern(&lf[310],18,"disable-interrupts");
lf[311]=C_h_intern(&lf[311],15,"disable-warning");
lf[312]=C_h_intern(&lf[312],26,"\010compilerdisabled-warnings");
lf[313]=C_h_intern(&lf[313],12,"safe-globals");
lf[314]=C_h_intern(&lf[314],38,"no-procedure-checks-for-usual-bindings");
lf[315]=C_h_intern(&lf[315],18,"bound-to-procedure");
lf[316]=C_h_intern(&lf[316],15,"foreign-declare");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[318]=C_h_intern(&lf[318],5,"every");
lf[319]=C_h_intern(&lf[319],7,"string\077");
lf[320]=C_h_intern(&lf[320],14,"custom-declare");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[322]=C_h_intern(&lf[322],35,"\010compilerprocess-custom-declaration");
lf[323]=C_h_intern(&lf[323],9,"c-options");
lf[324]=C_h_intern(&lf[324],31,"\010compileremit-control-file-item");
lf[325]=C_h_intern(&lf[325],12,"link-options");
lf[326]=C_h_intern(&lf[326],12,"post-process");
lf[327]=C_h_intern(&lf[327],17,"string-substitute");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[329]=C_h_intern(&lf[329],24,"pathname-strip-extension");
lf[330]=C_h_intern(&lf[330],5,"block");
lf[331]=C_h_intern(&lf[331],8,"separate");
lf[332]=C_h_intern(&lf[332],20,"keep-shadowed-macros");
lf[333]=C_h_intern(&lf[333],6,"unused");
lf[334]=C_h_intern(&lf[334],3,"not");
lf[335]=C_h_intern(&lf[335],15,"lset-difference");
lf[336]=C_h_intern(&lf[336],6,"inline");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[338]=C_h_intern(&lf[338],15,"run-time-macros");
lf[339]=C_h_intern(&lf[339],25,"\003sysenable-runtime-macros");
lf[340]=C_h_intern(&lf[340],12,"block-global");
lf[341]=C_h_intern(&lf[341],4,"hide");
lf[342]=C_h_intern(&lf[342],6,"export");
lf[343]=C_h_intern(&lf[343],12,"emit-exports");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[345]=C_h_intern(&lf[345],30,"emit-external-prototypes-first");
lf[346]=C_h_intern(&lf[346],11,"lambda-lift");
lf[347]=C_h_intern(&lf[347],12,"inline-limit");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[349]=C_h_intern(&lf[349],8,"constant");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[351]=C_h_intern(&lf[351],7,"symbol\077");
lf[352]=C_h_intern(&lf[352],6,"import");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[354]=C_h_intern(&lf[354],9,"partition");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[358]=C_h_intern(&lf[358],17,"make-foreign-stub");
lf[359]=C_h_intern(&lf[359],12,"foreign-stub");
lf[360]=C_h_intern(&lf[360],13,"foreign-stub\077");
lf[361]=C_h_intern(&lf[361],20,"foreign-stub-id-set!");
lf[362]=C_h_intern(&lf[362],14,"\003sysblock-set!");
lf[363]=C_h_intern(&lf[363],15,"foreign-stub-id");
lf[364]=C_h_intern(&lf[364],29,"foreign-stub-return-type-set!");
lf[365]=C_h_intern(&lf[365],24,"foreign-stub-return-type");
lf[366]=C_h_intern(&lf[366],22,"foreign-stub-name-set!");
lf[367]=C_h_intern(&lf[367],17,"foreign-stub-name");
lf[368]=C_h_intern(&lf[368],32,"foreign-stub-argument-types-set!");
lf[369]=C_h_intern(&lf[369],27,"foreign-stub-argument-types");
lf[370]=C_h_intern(&lf[370],32,"foreign-stub-argument-names-set!");
lf[371]=C_h_intern(&lf[371],27,"foreign-stub-argument-names");
lf[372]=C_h_intern(&lf[372],22,"foreign-stub-body-set!");
lf[373]=C_h_intern(&lf[373],17,"foreign-stub-body");
lf[374]=C_h_intern(&lf[374],21,"foreign-stub-cps-set!");
lf[375]=C_h_intern(&lf[375],16,"foreign-stub-cps");
lf[376]=C_h_intern(&lf[376],26,"foreign-stub-callback-set!");
lf[377]=C_h_intern(&lf[377],21,"foreign-stub-callback");
lf[378]=C_h_intern(&lf[378],28,"\010compilercreate-foreign-stub");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[382]=C_h_intern(&lf[382],37,"\010compilerestimate-foreign-result-size");
lf[383]=C_h_intern(&lf[383],4,"stub");
lf[384]=C_h_intern(&lf[384],1,"a");
lf[385]=C_h_intern(&lf[385],13,"list-tabulate");
lf[386]=C_h_intern(&lf[386],6,"second");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[389]=C_h_intern(&lf[389],4,"cadr");
lf[390]=C_h_intern(&lf[390],3,"car");
lf[391]=C_h_intern(&lf[391],4,"void");
lf[392]=C_h_intern(&lf[392],24,"\003sysline-number-database");
lf[393]=C_h_intern(&lf[393],31,"\010compilerperform-cps-conversion");
lf[394]=C_h_intern(&lf[394],4,"node");
lf[395]=C_h_intern(&lf[395],11,"\004corelambda");
lf[396]=C_h_intern(&lf[396],9,"\004corecall");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[398]=C_h_intern(&lf[398],16,"\010compilervarnode");
lf[399]=C_h_intern(&lf[399],1,"k");
lf[400]=C_h_intern(&lf[400],13,"\004corevariable");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[402]=C_h_intern(&lf[402],2,"f_");
lf[403]=C_h_intern(&lf[403],26,"make-foreign-callback-stub");
lf[404]=C_h_intern(&lf[404],13,"\010compilerbomb");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[406]=C_h_intern(&lf[406],15,"\004coreglobal-ref");
lf[407]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[408]=C_h_intern(&lf[408],6,"values");
lf[409]=C_h_intern(&lf[409],21,"foreign-callback-stub");
lf[410]=C_h_intern(&lf[410],22,"foreign-callback-stub\077");
lf[411]=C_h_intern(&lf[411],29,"foreign-callback-stub-id-set!");
lf[412]=C_h_intern(&lf[412],24,"foreign-callback-stub-id");
lf[413]=C_h_intern(&lf[413],31,"foreign-callback-stub-name-set!");
lf[414]=C_h_intern(&lf[414],26,"foreign-callback-stub-name");
lf[415]=C_h_intern(&lf[415],37,"foreign-callback-stub-qualifiers-set!");
lf[416]=C_h_intern(&lf[416],32,"foreign-callback-stub-qualifiers");
lf[417]=C_h_intern(&lf[417],38,"foreign-callback-stub-return-type-set!");
lf[418]=C_h_intern(&lf[418],33,"foreign-callback-stub-return-type");
lf[419]=C_h_intern(&lf[419],41,"foreign-callback-stub-argument-types-set!");
lf[420]=C_h_intern(&lf[420],36,"foreign-callback-stub-argument-types");
lf[421]=C_h_intern(&lf[421],27,"\010compileranalyze-expression");
lf[422]=C_h_intern(&lf[422],17,"\010compilercollect!");
lf[423]=C_h_intern(&lf[423],10,"references");
lf[424]=C_h_intern(&lf[424],13,"\010compilerput!");
lf[425]=C_h_intern(&lf[425],9,"undefined");
lf[426]=C_h_intern(&lf[426],7,"unknown");
lf[427]=C_h_intern(&lf[427],5,"value");
lf[428]=C_h_intern(&lf[428],12,"\010compilerget");
lf[429]=C_h_intern(&lf[429],4,"home");
lf[430]=C_h_intern(&lf[430],16,"\010compilerget-all");
lf[431]=C_h_intern(&lf[431],8,"captured");
lf[432]=C_h_intern(&lf[432],6,"global");
lf[433]=C_h_intern(&lf[433],12,"\004corerecurse");
lf[434]=C_h_intern(&lf[434],44,"\010compileroptimizable-rest-argument-operators");
lf[435]=C_h_intern(&lf[435],15,"\010compilercount!");
lf[436]=C_h_intern(&lf[436],16,"o-r/access-count");
lf[437]=C_h_intern(&lf[437],14,"rest-parameter");
lf[438]=C_h_intern(&lf[438],16,"standard-binding");
lf[439]=C_h_intern(&lf[439],10,"call-sites");
lf[440]=C_h_intern(&lf[440],18,"\004coredirect_lambda");
lf[441]=C_h_intern(&lf[441],6,"simple");
lf[442]=C_h_intern(&lf[442],28,"\010compilersimple-lambda-node\077");
lf[443]=C_h_intern(&lf[443],6,"vector");
lf[444]=C_h_intern(&lf[444],12,"contained-in");
lf[445]=C_h_intern(&lf[445],8,"contains");
lf[446]=C_h_intern(&lf[446],8,"assigned");
lf[447]=C_h_intern(&lf[447],16,"assigned-locally");
lf[448]=C_h_intern(&lf[448],15,"potential-value");
lf[449]=C_h_intern(&lf[449],5,"redef");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[452]=C_h_intern(&lf[452],16,"extended-binding");
lf[453]=C_h_intern(&lf[453],9,"\004coreproc");
lf[454]=C_h_intern(&lf[454],3,"any");
lf[455]=C_h_intern(&lf[455],9,"replacing");
lf[456]=C_h_intern(&lf[456],10,"replacable");
lf[457]=C_h_intern(&lf[457],9,"removable");
lf[458]=C_h_intern(&lf[458],37,"\010compilerexpression-has-side-effects\077");
lf[459]=C_h_intern(&lf[459],21,"has-unused-parameters");
lf[460]=C_h_intern(&lf[460],13,"explicit-rest");
lf[461]=C_h_intern(&lf[461],11,"collapsable");
lf[462]=C_h_intern(&lf[462],12,"contractable");
lf[463]=C_h_intern(&lf[463],9,"inlinable");
lf[464]=C_h_intern(&lf[464],28,"\010compilerscan-free-variables");
lf[465]=C_h_intern(&lf[465],5,"boxed");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[468]=C_h_intern(&lf[468],23,"\003syshash-table-for-each");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"p");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[473]=C_h_intern(&lf[473],37,"\010compilerinitialize-analysis-database");
lf[474]=C_h_intern(&lf[474],35,"\010compilerperform-closure-conversion");
lf[475]=C_h_intern(&lf[475],12,"customizable");
lf[476]=C_h_intern(&lf[476],20,"node-parameters-set!");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[478]=C_h_intern(&lf[478],28,"\010compilersource-info->string");
lf[479]=C_h_intern(&lf[479],8,"toplevel");
lf[480]=C_h_intern(&lf[480],18,"captured-variables");
lf[481]=C_h_intern(&lf[481],12,"closure-size");
lf[482]=C_h_intern(&lf[482],8,"\004coreref");
lf[483]=C_h_intern(&lf[483],10,"\004coreunbox");
lf[484]=C_h_intern(&lf[484],8,"\004corebox");
lf[485]=C_h_intern(&lf[485],12,"\004coreclosure");
lf[486]=C_h_intern(&lf[486],14,"\010compilerqnode");
lf[487]=C_h_intern(&lf[487],20,"\003sysmake-lambda-info");
lf[488]=C_h_intern(&lf[488],1,"\077");
lf[489]=C_h_intern(&lf[489],8,"->string");
lf[490]=C_h_intern(&lf[490],18,"\010compilerreal-name");
lf[491]=C_h_intern(&lf[491],10,"fold-right");
lf[492]=C_h_intern(&lf[492],10,"boxed-rest");
lf[493]=C_h_intern(&lf[493],6,"filter");
lf[494]=C_h_intern(&lf[494],16,"\004coreupdatebox_i");
lf[495]=C_h_intern(&lf[495],14,"\004coreupdatebox");
lf[496]=C_h_intern(&lf[496],13,"\004coreupdate_i");
lf[497]=C_h_intern(&lf[497],11,"\004coreupdate");
lf[498]=C_h_intern(&lf[498],19,"\010compilerimmediate\077");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[500]=C_h_intern(&lf[500],11,"\004coreswitch");
lf[501]=C_h_intern(&lf[501],9,"\004corecond");
lf[502]=C_h_intern(&lf[502],16,"\004coredirect_call");
lf[503]=C_h_intern(&lf[503],11,"\004corereturn");
lf[504]=C_h_intern(&lf[504],1,"o");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[506]=C_h_intern(&lf[506],16,"\003sysmake-promise");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[510]=C_h_intern(&lf[510],19,"make-lambda-literal");
lf[511]=C_h_intern(&lf[511],14,"lambda-literal");
lf[512]=C_h_intern(&lf[512],15,"lambda-literal\077");
lf[513]=C_h_intern(&lf[513],22,"lambda-literal-id-set!");
lf[514]=C_h_intern(&lf[514],17,"lambda-literal-id");
lf[515]=C_h_intern(&lf[515],28,"lambda-literal-external-set!");
lf[516]=C_h_intern(&lf[516],23,"lambda-literal-external");
lf[517]=C_h_intern(&lf[517],29,"lambda-literal-arguments-set!");
lf[518]=C_h_intern(&lf[518],24,"lambda-literal-arguments");
lf[519]=C_h_intern(&lf[519],34,"lambda-literal-argument-count-set!");
lf[520]=C_h_intern(&lf[520],29,"lambda-literal-argument-count");
lf[521]=C_h_intern(&lf[521],33,"lambda-literal-rest-argument-set!");
lf[522]=C_h_intern(&lf[522],28,"lambda-literal-rest-argument");
lf[523]=C_h_intern(&lf[523],31,"lambda-literal-temporaries-set!");
lf[524]=C_h_intern(&lf[524],26,"lambda-literal-temporaries");
lf[525]=C_h_intern(&lf[525],37,"lambda-literal-callee-signatures-set!");
lf[526]=C_h_intern(&lf[526],32,"lambda-literal-callee-signatures");
lf[527]=C_h_intern(&lf[527],29,"lambda-literal-allocated-set!");
lf[528]=C_h_intern(&lf[528],24,"lambda-literal-allocated");
lf[529]=C_h_intern(&lf[529],35,"lambda-literal-directly-called-set!");
lf[530]=C_h_intern(&lf[530],30,"lambda-literal-directly-called");
lf[531]=C_h_intern(&lf[531],32,"lambda-literal-closure-size-set!");
lf[532]=C_h_intern(&lf[532],27,"lambda-literal-closure-size");
lf[533]=C_h_intern(&lf[533],27,"lambda-literal-looping-set!");
lf[534]=C_h_intern(&lf[534],22,"lambda-literal-looping");
lf[535]=C_h_intern(&lf[535],32,"lambda-literal-customizable-set!");
lf[536]=C_h_intern(&lf[536],27,"lambda-literal-customizable");
lf[537]=C_h_intern(&lf[537],38,"lambda-literal-rest-argument-mode-set!");
lf[538]=C_h_intern(&lf[538],33,"lambda-literal-rest-argument-mode");
lf[539]=C_h_intern(&lf[539],24,"lambda-literal-body-set!");
lf[540]=C_h_intern(&lf[540],19,"lambda-literal-body");
lf[541]=C_h_intern(&lf[541],26,"lambda-literal-direct-set!");
lf[542]=C_h_intern(&lf[542],21,"lambda-literal-direct");
lf[543]=C_h_intern(&lf[543],36,"\010compilerprepare-for-code-generation");
lf[544]=C_h_intern(&lf[544],14,"\004coreimmediate");
lf[545]=C_h_intern(&lf[545],3,"fix");
lf[546]=C_h_intern(&lf[546],4,"bool");
lf[547]=C_h_intern(&lf[547],4,"char");
lf[548]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[549]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[551]=C_h_intern(&lf[551],36,"\010compilermake-block-variable-literal");
lf[552]=C_h_intern(&lf[552],36,"\010compilerblock-variable-literal-name");
lf[553]=C_h_intern(&lf[553],32,"\010compilerblock-variable-literal\077");
lf[554]=C_h_intern(&lf[554],10,"list-index");
lf[555]=C_h_intern(&lf[555],11,"\004coreglobal");
lf[556]=C_h_intern(&lf[556],10,"\004corelocal");
lf[557]=C_h_intern(&lf[557],12,"\004coreliteral");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[560]=C_h_intern(&lf[560],4,"none");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[563]=C_h_intern(&lf[563],7,"butlast");
lf[564]=C_h_intern(&lf[564],9,"\004corebind");
lf[565]=C_h_intern(&lf[565],13,"\004coresetlocal");
lf[566]=C_h_intern(&lf[566],16,"\004coresetglobal_i");
lf[567]=C_h_intern(&lf[567],14,"\004coresetglobal");
lf[568]=C_h_intern(&lf[568],1,"=");
lf[569]=C_h_intern(&lf[569],4,"type");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[572]=C_h_intern(&lf[572],20,"\010compilerbig-fixnum\077");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[577]=C_h_intern(&lf[577],14,"make-parameter");
C_register_lf2(lf,578,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1766 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1769 in k1766 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1772 in k1769 in k1766 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 311  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_set_block_item(lf[93],0,C_SCHEME_FALSE);
t87=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1887,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1958,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4737,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5682,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5688,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5694,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5703,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5712,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5721,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5730,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5739,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5748,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5757,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5766,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5775,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5784,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5793,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5802,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5811,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5820,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5829,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5838,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5992,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6037,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6082,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6119,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6156,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6237,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[393]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6327,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7002,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[410]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7008,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7014,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7023,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7032,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7041,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7050,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7059,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7068,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7077,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7086,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7095,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7104,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[474]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8629,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9863,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9869,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9875,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9884,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9893,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9902,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9911,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9920,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9929,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9938,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9947,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9956,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9965,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9974,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9983,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9992,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10001,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10010,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10019,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10028,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10037,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10046,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10055,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10064,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10073,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10082,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10091,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10100,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10109,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10118,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10127,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10136,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10145,tmp=(C_word)a,a+=2,tmp));
t163=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t163+1)))(2,t163,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10145,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11140,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11094,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11108,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11014,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10182,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10148,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10235,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11002,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11202,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2314 debugging */
t37=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[470],lf[576]);}

/* k11200 in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2315 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10235(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11203 in k11200 in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2316 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11206 in k11203 in k11200 in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11211,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2317 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[574],((C_word*)((C_word*)t0)[2])[1]);}

/* k11209 in k11206 in k11203 in k11200 in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2318 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[573],((C_word*)((C_word*)t0)[2])[1]);}

/* k11212 in k11209 in k11206 in k11203 in k11200 in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2319 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11002,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11008,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a11007 in mapwalk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11008,3,t0,t1,t2);}
/* compiler.scm: 2272 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10235(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10235,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[125]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[453]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[400]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2106 walk-var */
t16=((C_word*)t0)[16];
f_10148(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[406]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2109 walk-global */
t17=((C_word*)t0)[15];
f_10182(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[502]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10293,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2113 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_11002(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10313,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2117 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_11002(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10337,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10341,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2120 estimate-foreign-result-size */
t22=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10365,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10369,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2124 estimate-foreign-result-size */
t23=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[485]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10386,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2129 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11002(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[484]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10413,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2133 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[495]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10429,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2137 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11002(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[395]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[440]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[440]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10485,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2157 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[484],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10669,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2214 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10710,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2220 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[396]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10830,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2244 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[568]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[433]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10873,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10873(t32,t31);}
else{
t30=t29;
f_10873(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10901,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10988,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2255 big-fixnum? */
t33=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10901(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10991,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2269 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_11002(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10989 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10991,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10986 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10901(t2,(C_word)C_i_not(t1));}

/* k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10901,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2256 immediate-literal */
f_11140(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[304],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10949,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2259 big-fixnum? */
t5=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10922(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10959,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 literal */
t4=((C_word*)t0)[2];
f_11014(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2266 immediate? */
t3=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10963 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10965,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2266 immediate-literal */
f_11140(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10978,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2267 literal */
t3=((C_word*)t0)[2];
f_11014(t3,t2,((C_word*)t0)[3]);}}

/* k10976 in k10963 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10978,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10957 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10959,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10947 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10922(t2,(C_word)C_i_not(t1));}

/* k10920 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10922,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2260 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[569],lf[570],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2264 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[571],((C_word*)t0)[4]);}}

/* k10923 in k10920 in k10899 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2263 immediate-literal */
f_11140(((C_word*)t0)[2],t2);}

/* k10871 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10873,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10876,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2251 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11002(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10874 in k10871 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10876,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10828 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10830,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10842,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10842(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10842(t6,C_SCHEME_FALSE);}}

/* k10840 in k10828 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10833(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10833(t2,C_SCHEME_UNDEFINED);}}

/* k10831 in k10828 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10833,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10836,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2247 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11002(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10834 in k10831 in k10828 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10836,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10710,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10726,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2222 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10235(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10799(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10799(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10799(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10811,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2228 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[438]);}}}}}

/* k10809 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10799(2,t2,t1);}
else{
/* compiler.scm: 2229 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10797 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10799,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[102]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2231 immediate? */
t8=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10738(2,t6,C_SCHEME_FALSE);}}

/* k10736 in k10797 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10738,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10744(t6,t5);}
else{
t4=t3;
f_10744(t4,C_SCHEME_UNDEFINED);}}

/* k10742 in k10736 in k10797 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10744,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[566]:lf[567]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10768,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2237 blockvar-literal */
t4=((C_word*)t0)[4];
f_11108(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2238 literal */
t4=((C_word*)t0)[2];
f_11014(t4,t3,((C_word*)t0)[3]);}}

/* k10766 in k10742 in k10736 in k10797 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10768,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10760,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2240 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10235(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10758 in k10766 in k10742 in k10736 in k10797 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10760,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10724 in k10708 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10726,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[565],((C_word*)t0)[2],t2));}

/* k10667 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10673,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2215 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10679 in k10667 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2215 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10683 in k10679 in k10667 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2215 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10235(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10671 in k10667 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[564],((C_word*)t0)[2],t2));}

/* a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10485,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10606,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2163 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[423]);}
else{
t7=t6;
f_10492(2,t7,C_SCHEME_FALSE);}}

/* k10604 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10612,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2164 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}

/* k10610 in k10604 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10612,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10492(2,t2,lf[278]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10637,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2165 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[492]);}}

/* k10635 in k10610 in k10604 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10618(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10618(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10616 in k10610 in k10604 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10492(2,t2,lf[560]);}
else{
/* compiler.scm: 2166 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437]);}}

/* k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10495,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10597,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[560],t1);
if(C_truep(t5)){
/* compiler.scm: 2170 butlast */
t6=C_retrieve(lf[563]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10597(2,t6,((C_word*)t0)[7]);}}

/* k10595 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2167 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10235(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10498,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[560]);
if(C_truep(t3)){
/* compiler.scm: 2175 debugging */
t4=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[504],lf[561],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[443]);
if(C_truep(t4)){
/* compiler.scm: 2176 debugging */
t5=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[504],lf[562],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10498(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2178 bomb */
t4=C_retrieve(lf[404]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[559],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10501(2,t4,C_SCHEME_UNDEFINED);}}

/* k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10523,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10539,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2190 get */
t7=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[481]);}

/* k10537 in k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10539,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10546(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10565,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2194 debugging */
t7=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[504],lf[558],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10546(t6,C_SCHEME_FALSE);}}}

/* k10563 in k10537 in k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10546(t2,C_SCHEME_TRUE);}

/* k10544 in k10537 in k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10546,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10550(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2196 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[475]);}}

/* k10548 in k10544 in k10537 in k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2180 make-lambda-literal */
t2=C_retrieve(lf[510]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10521 in k10499 in k10496 in k10493 in k10490 in a10484 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[394],lf[453],t9,C_SCHEME_END_OF_LIST));}

/* k10427 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10432,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10438,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10438(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10438(t6,C_SCHEME_FALSE);}}

/* k10436 in k10427 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10432(t4,lf[494]);}
else{
t2=((C_word*)t0)[3];
f_10432(t2,((C_word*)t0)[2]);}}

/* k10430 in k10427 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10432,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10411 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10413,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],((C_word*)t0)[2],t2));}

/* k10384 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t1));}

/* k10367 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2124 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10363 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10365,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10358,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2125 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11002(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10356 in k10363 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10358,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10339 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2120 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10335 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10337,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10311 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10291 in walk in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10293,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10148,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10152,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2074 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10150 in walk-var in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10152,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[556],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2075 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10165 in k10150 in walk-var in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2075 literal */
t3=((C_word*)t0)[5];
f_11014(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2076 walk-global */
t2=((C_word*)t0)[3];
f_10182(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10175 in k10165 in k10150 in walk-var in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10177,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10182(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10182,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10186(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10186(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10186(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10186(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10227,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2083 get */
t9=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[438]);}}}}}

/* k10225 in walk-global in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10186(2,t2,t1);}
else{
/* compiler.scm: 2084 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10184 in walk-global in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10186,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10192(t6,t5);}
else{
t4=t3;
f_10192(t4,C_SCHEME_UNDEFINED);}}

/* k10190 in k10184 in walk-global in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_10192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10192,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10202,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2090 blockvar-literal */
t3=((C_word*)t0)[3];
f_11108(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2091 literal */
t3=((C_word*)t0)[2];
f_11014(t3,t2,((C_word*)t0)[5]);}}

/* k10200 in k10190 in k10184 in walk-global in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[555],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11014,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2275 immediate? */
t4=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11019 in literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2275 immediate-literal */
f_11140(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11047,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2278 list-index */
t4=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_11033(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11073,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2284 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2286 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11081 in k11019 in literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2287 new-literal */
t2=((C_word*)t0)[3];
f_11094(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11071 in k11019 in literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11073,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11046 in k11019 in literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11047,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11031 in k11019 in literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2280 new-literal */
t2=((C_word*)t0)[3];
f_11094(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_11108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11108,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11112,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2295 list-index */
t5=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11123 in blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11131,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2297 block-variable-literal? */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11129 in a11123 in blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11131,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2298 block-variable-literal-name */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11136 in k11129 in a11123 in blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11110 in blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11112,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2300 make-block-variable-literal */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11120 in k11110 in blockvar-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2300 new-literal */
t2=((C_word*)t0)[3];
f_11094(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_11094(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11094,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11102,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2291 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11100 in new-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_11140(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11140,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[125],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11153(2,t6,(C_word)C_a_i_list(&a,2,lf[545],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11153(2,t6,(C_word)C_a_i_list(&a,2,lf[546],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11153(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11153(2,t6,lf[548]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11153(2,t6,lf[549]);}
else{
/* compiler.scm: 2311 bomb */
t6=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[550]);}}}}}}}

/* k11151 in immediate-literal in ##compiler#prepare-for-code-generation in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_11153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11153,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[544],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10136,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10127,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10118,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10109,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10100,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10091,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10082,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10073,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10064,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10055,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10046,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10037,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10028,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10019,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10010,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_10001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10001,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9992,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9983,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9974,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9965,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9956,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9947,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9938,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9929,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9920,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9911,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9902,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9893,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9884,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9875,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9869,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[511]));}

/* make-lambda-literal in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9863,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[511],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8629,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8632,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8638,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8648,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8659,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9694,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8993,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9682,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9830,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2032 debugging */
t22=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[470],lf[509]);}

/* k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2033 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8659(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2034 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[508],((C_word*)((C_word*)t0)[2])[1]);}

/* k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2035 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[507]);}

/* k9837 in k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9842,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2036 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8993(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9840 in k9837 in k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9845,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9845(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9857,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2038 ##sys#make-promise */
t6=*((C_word*)lf[506]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9856 in k9840 in k9837 in k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9857,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9853 in k9840 in k9837 in k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2038 debugging */
t2=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[504],lf[505],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9843 in k9840 in k9837 in k9834 in k9831 in k9828 in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9682,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9688,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9687 in maptransform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9688,3,t0,t1,t2);}
/* compiler.scm: 2004 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8993(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8993(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8993,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_9012(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t13)){
t14=t12;
f_9012(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[453]);
t15=t12;
f_9012(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[406])));}}}

/* k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9012,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9024,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1879 ref-var */
f_9694(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[113]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9045(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[396]);
if(C_truep(t5)){
t6=t4;
f_9045(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_9045(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_9045(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[270]);
if(C_truep(t8)){
t9=t4;
f_9045(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[103]);
if(C_truep(t9)){
t10=t4;
f_9045(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_9045(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[500]);
if(C_truep(t11)){
t12=t4;
f_9045(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[501]);
if(C_truep(t12)){
t13=t4;
f_9045(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t13)){
t14=t4;
f_9045(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[433]);
if(C_truep(t14)){
t15=t4;
f_9045(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t15)){
t16=t4;
f_9045(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[107]);
t17=t4;
f_9045(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9045,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9051,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1887 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9682(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9066,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1891 test */
t5=((C_word*)t0)[4];
f_8632(t5,t4,t3,lf[465]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[395]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[440]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1907 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9412,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[102],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1967 immediate? */
t13=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9412(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[394],lf[453],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9561,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9568,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9572,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1998 ##sys#make-lambda-info */
t16=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9561(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 2001 bomb */
t7=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[499]);}}}}}}

/* k9570 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1998 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9566 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9568,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9561(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9559 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9561,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9412,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1969 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9418,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1971 test */
t3=((C_word*)t0)[3];
f_8632(t3,t2,((C_word*)t0)[2],lf[465]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1983 test */
t3=((C_word*)t0)[3];
f_8632(t3,t2,((C_word*)t0)[2],lf[465]);}}

/* k9486 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9488,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1987 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9518,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1991 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8993(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9516 in k9486 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[175],((C_word*)t0)[2],t2));}

/* k9499 in k9486 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9505,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1988 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8993(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9503 in k9499 in k9486 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9505,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9425 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9427,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1975 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9472 in k9425 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9478,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1982 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8993(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9476 in k9472 in k9425 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9478,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9452 in k9425 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9454,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1976 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8993(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9448 in k9452 in k9425 in k9416 in k9410 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9141,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1910 filter */
t7=C_retrieve(lf[493]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9389 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9390,3,t0,t1,t2);}
/* compiler.scm: 1910 test */
t3=((C_word*)t0)[2];
f_8632(t3,t1,t2,lf[465]);}

/* k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9388,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[122]),t1);}

/* k9386 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1911 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1912 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[123]);}

/* k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9151,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[479]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1914 test */
t4=((C_word*)t0)[2];
f_8632(t4,t3,t2,lf[480]);}

/* k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9157,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1915 test */
t4=((C_word*)t0)[2];
f_8632(t4,t3,((C_word*)t0)[17],lf[481]);}

/* k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9169(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9169(t4,C_SCHEME_FALSE);}}

/* k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9169,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1921 test */
t4=((C_word*)t0)[2];
f_8632(t4,t3,((C_word*)t0)[6],lf[465]);}
else{
t3=t2;
f_9172(2,t3,C_SCHEME_FALSE);}}

/* k9353 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9355,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1922 test */
t3=((C_word*)t0)[2];
f_8632(t3,t2,((C_word*)t0)[6],lf[437]);}
else{
t2=((C_word*)t0)[4];
f_9172(2,t2,C_SCHEME_FALSE);}}

/* k9356 in k9353 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1923 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[492],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9172(2,t2,C_SCHEME_FALSE);}}

/* k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9172,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9312,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9316,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9331,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9330 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9331,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9314 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1933 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9312,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1942 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8993(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9257,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1947 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9249(2,t3,t1);}}

/* k9269 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9275,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9277,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9276 in k9269 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9288,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1948 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9286 in a9276 in k9269 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9288,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2));}

/* k9273 in k9269 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1944 fold-right */
t2=C_retrieve(lf[491]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9256 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9257,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[394],lf[152],t5,t6));}

/* k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9249,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9195,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9233 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9234,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1951 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9240 in a9233 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1951 ref-var */
f_9694(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9209,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9213,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9217,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9225,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1959 real-name */
t7=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9198(2,t3,t1);}}

/* k9223 in k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9225,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[488]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1959 ->string */
t5=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9215 in k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1958 ##sys#make-lambda-info */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9211 in k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1957 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9207 in k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9209,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1954 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9196 in k9193 in k9247 in k9244 in k9310 in k9170 in k9167 in k9161 in k9155 in k9149 in k9146 in k9143 in a9140 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9198,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1892 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9067 in k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9069,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9085,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1896 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8993(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1903 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9682(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9119 in k9067 in k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9121,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t1));}

/* k9083 in k9067 in k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9085,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1899 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9112 in k9083 in k9067 in k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9106,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1900 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8993(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9104 in k9112 in k9083 in k9067 in k9064 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9106,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k9049 in k9043 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9051,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9022 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9030,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1880 test */
t3=((C_word*)t0)[3];
f_8632(t3,t2,((C_word*)t0)[2],lf[465]);}

/* k9028 in k9022 in k9010 in transform in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9030,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[483],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9694(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9694,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9701,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2008 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9699 in ref-var in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9701,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9717,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2011 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9715 in k9699 in ref-var in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9717,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8659(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8659,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8678(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[400]);
if(C_truep(t13)){
t14=t12;
f_8678(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t14)){
t15=t12;
f_8678(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[453]);
if(C_truep(t15)){
t16=t12;
f_8678(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[271]);
t17=t12;
f_8678(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[406])));}}}}}

/* k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1816 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[396]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[400],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8741,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8758,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8768,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8882,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1832 test */
t19=((C_word*)t0)[3];
f_8632(t19,t18,t16,lf[426]);}
else{
t15=t14;
f_8768(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8758(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[395]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[440]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1856 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8956 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8957,3,t0,t1,t2);}
/* compiler.scm: 1866 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8659(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8918,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[479]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9733,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9733(3,t14,t10,t6);}

/* walk in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9733,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[400]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9762,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2023 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[102]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9771(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[125]);
if(C_truep(t12)){
t13=t11;
f_9771(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[271]);
if(C_truep(t13)){
t14=t11;
f_9771(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[453]);
if(C_truep(t14)){
t15=t11;
f_9771(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[103]);
t16=t11;
f_9771(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[406])));}}}}}}

/* k9769 in walk in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9771,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9797,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2027 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9783(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9795 in k9769 in walk in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9783(t3,t2);}

/* k9781 in k9769 in walk in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_9783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2028 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9733(3,t3,((C_word*)t0)[2],t2);}

/* k9760 in walk in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9729 in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_9731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9731,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8931,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1862 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[481],t3);}

/* k8929 in k9729 in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1863 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[480],((C_word*)t0)[2]);}

/* k8932 in k8929 in k9729 in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8945,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1864 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8943 in k8932 in k8929 in k9729 in a8917 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1864 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8659(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8880 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8774(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1832 test */
t2=((C_word*)t0)[3];
f_8632(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[427]);}}

/* k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8780(t4,(C_word)C_eqp(lf[395],t3));}
else{
t3=t2;
f_8780(t3,C_SCHEME_FALSE);}}

/* k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1837 test */
t6=((C_word*)t0)[2];
f_8632(t6,t5,((C_word*)t0)[6],lf[423]);}
else{
t2=((C_word*)t0)[8];
f_8768(t2,C_SCHEME_END_OF_LIST);}}

/* k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8795,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1838 test */
t3=((C_word*)t0)[2];
f_8632(t3,t2,((C_word*)t0)[7],lf[439]);}

/* k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8798(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8798(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8798(t3,C_SCHEME_FALSE);}}

/* k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8798,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8816,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8816(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8816(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8816(t4,C_SCHEME_FALSE);}}

/* k8814 in k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8816,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1846 source-info->string */
t3=C_retrieve(lf[478]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8801(2,t2,C_SCHEME_UNDEFINED);}}

/* k8821 in k8814 in k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1844 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[477],t1);}

/* k8799 in k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1847 register-direct-call! */
t3=((C_word*)t0)[2];
f_8648(t3,t2,((C_word*)t0)[6]);}

/* k8802 in k8799 in k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1848 register-customizable! */
t3=((C_word*)t0)[3];
f_8638(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8807(2,t3,C_SCHEME_UNDEFINED);}}

/* k8805 in k8802 in k8799 in k8796 in k8793 in k8790 in k8778 in k8772 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8768(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8766 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8768,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8758(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8756 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8758,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1825 node-parameters-set! */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8739 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8745 in k8739 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8746,3,t0,t1,t2);}
/* compiler.scm: 1853 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8659(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8698 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8699,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8715 in a8698 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8716,3,t0,t1,t2);}
/* compiler.scm: 1817 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8659(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8701 in a8698 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8703,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1818 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8712 in k8701 in a8698 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1818 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8659(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8688 in k8676 in gather in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8689,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1816 split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8648,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8657,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1803 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),C_retrieve(lf[63]),t2);}

/* k8655 in register-direct-call! in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8638,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8643,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1798 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8641 in register-customizable! in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1799 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[475],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8632(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8632,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1795 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7104,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7108,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1416 make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7108,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7110,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7813,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7710,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7117,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7698,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7819,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7833,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1586 initialize-analysis-database */
t18=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1589 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[472]);}

/* k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7861,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1591 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7117(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1594 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[471]);}

/* k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1595 ##sys#hash-table-for-each */
t4=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7881,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7885,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8516,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8515 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8516,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[426]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[423]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[439]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[446]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[447]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[432]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[437]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7885,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8481,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8481(t10,(C_word)C_eqp(lf[395],t9));}
else{
t7=t6;
f_8481(t7,C_SCHEME_FALSE);}}

/* k8479 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1641 set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7892(2,t2,C_SCHEME_UNDEFINED);}}

/* k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8427(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8427(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8427(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8427(t4,C_SCHEME_FALSE);}}

/* k8425 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8427,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1650 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[467],((C_word*)t0)[3]);}
else{
t3=t2;
f_8430(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7895(2,t2,C_SCHEME_UNDEFINED);}}

/* k8428 in k8425 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8442,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8442(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8442(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8442(t5,C_SCHEME_FALSE);}}}

/* k8440 in k8428 in k8425 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8436(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8436(t2,C_SCHEME_FALSE);}}

/* k8434 in k8428 in k8425 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1654 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[466],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7895(2,t2,C_SCHEME_UNDEFINED);}}

/* k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1658 quick-put! */
f_7819(t2,((C_word*)t0)[8],lf[465],C_SCHEME_TRUE);}
else{
t4=t2;
f_7898(2,t4,C_SCHEME_UNDEFINED);}}

/* k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8370(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8402,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8410,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1667 scan-free-variables */
t13=C_retrieve(lf[464]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8370(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7901(2,t3,C_SCHEME_UNDEFINED);}}

/* k8408 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1667 every */
t2=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8401 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8402,3,t0,t1,t2);}
/* compiler.scm: 1667 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[432]);}

/* k8368 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8370,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8376,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8376(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8376(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7901(2,t2,C_SCHEME_UNDEFINED);}}

/* k8374 in k8368 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1669 quick-put! */
f_7819(((C_word*)t0)[3],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1670 quick-put! */
f_7819(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}}

/* k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8332(t6,(C_word)C_eqp(lf[102],t5));}
else{
t4=t3;
f_8332(t4,C_SCHEME_FALSE);}}

/* k8330 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8332,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1678 collapsable-literal? */
t6=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7904(2,t2,C_SCHEME_UNDEFINED);}}

/* k8339 in k8330 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8344(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8344(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8342 in k8339 in k8330 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1680 quick-put! */
f_7819(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7904(2,t2,C_SCHEME_UNDEFINED);}}

/* k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8233,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8233(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8233(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7907(2,t3,C_SCHEME_UNDEFINED);}}

/* k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8233,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1694 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7907(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7907(2,t2,C_SCHEME_UNDEFINED);}}

/* a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8251,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8255(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8294,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8293 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8301,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8319,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1700 get */
t5=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[423]);}

/* k8317 in a8293 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8319,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8301(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1701 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}

/* k8313 in k8317 in a8293 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8301(t2,(C_word)C_i_not(t1));}

/* k8299 in a8293 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1702 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[333],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8302 in k8299 in a8293 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8253 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8261(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8261(t3,C_SCHEME_FALSE);}}

/* k8259 in k8253 in a8250 in k8231 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1708 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[459],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1711 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[460],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8170(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8185,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[400],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8197(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8211,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1719 get */
t15=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[432]);}}
else{
t6=t5;
f_8185(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8170(t5,C_SCHEME_FALSE);}}}

/* k8209 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8197(t2,(C_word)C_i_not(t1));}

/* k8195 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8197,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1720 expression-has-side-effects? */
t3=C_retrieve(lf[458]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8185(t2,C_SCHEME_FALSE);}}

/* k8202 in k8195 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8185(t2,(C_word)C_i_not(t1));}

/* k8183 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8170(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8168 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1722 quick-put! */
f_7819(((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7910(2,t2,C_SCHEME_UNDEFINED);}}

/* k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[400],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1734 get */
t11=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[423]);}
else{
t7=t2;
f_7913(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7913(2,t4,C_SCHEME_UNDEFINED);}}

/* k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8156,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1735 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[426]);}

/* k8154 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8088(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1735 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[427]);}}

/* k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8091(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8146,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1736 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[431]);}}

/* k8144 in k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8146,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8091(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8091(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1740 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}
else{
t4=((C_word*)t0)[6];
f_8091(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8091(t2,C_SCHEME_FALSE);}}}

/* k8136 in k8144 in k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8138,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8091(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8091(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8134,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1741 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[432]);}}}

/* k8132 in k8136 in k8144 in k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8091(t2,(C_word)C_i_not(t1));}

/* k8089 in k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_8091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8091,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8094,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1742 quick-put! */
f_7819(t2,((C_word*)t0)[2],lf[456],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7913(2,t2,C_SCHEME_UNDEFINED);}}

/* k8092 in k8089 in k8086 in k8080 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1743 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7941(t6,(C_word)C_eqp(lf[395],t5));}
else{
t4=t3;
f_7941(t4,C_SCHEME_FALSE);}}

/* k7939 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7916(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7962,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7962(t11,(C_word)C_eqp(lf[396],t10));}
else{
t10=t8;
f_7962(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7962(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7916(2,t2,C_SCHEME_UNDEFINED);}}

/* k7960 in k7939 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7962,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[400],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7983(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7983(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7983(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7916(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7916(2,t2,C_SCHEME_UNDEFINED);}}

/* k7981 in k7960 in k7939 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7983,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7989,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1763 quick-put! */
f_7819(t4,((C_word*)t0)[2],lf[456],t3);}
else{
t2=((C_word*)t0)[5];
f_7916(2,t2,C_SCHEME_UNDEFINED);}}

/* k7987 in k7981 in k7960 in k7939 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1764 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7914 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7922(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7922(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7922(t3,C_SCHEME_FALSE);}}

/* k7920 in k7914 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7922,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1774 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7924 in k7920 in k7914 in k7911 in k7908 in k7905 in k7902 in k7899 in k7896 in k7893 in k7890 in k7883 in a7880 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1775 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437],lf[443]);}

/* k7869 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1781 lset-difference */
t3=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7873 in k7869 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7878(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7878(t5,t4);}}

/* k7876 in k7873 in k7869 in k7866 in k7863 in k7859 in k7856 in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7833,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7843,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1581 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[445]);}}

/* k7841 in contains? in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7843,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1583 any */
t3=C_retrieve(lf[454]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7850 in k7841 in contains? in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7851,3,t0,t1,t2);}
/* compiler.scm: 1583 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7833(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7819(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7819,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1576 alist-cons */
t7=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7825 in quick-put! in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7698(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7698,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7704,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7703 in walkeach in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7704,3,t0,t1,t2);}
/* compiler.scm: 1550 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7117(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7117,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7110(C_fix(1));
t13=(C_word)C_eqp(t11,lf[102]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7139(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
t16=t14;
f_7139(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[453])));}}

/* k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7139,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1432 ref */
t5=((C_word*)t0)[8];
f_7813(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[406]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7194,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1440 ref */
t6=((C_word*)t0)[8];
f_7813(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[270]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[433]));
if(C_truep(t5)){
t6=f_7110(C_fix(1));
/* compiler.scm: 1446 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7698(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[396]);
if(C_truep(t6)){
t7=f_7110(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7253,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1453 collect! */
t16=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[439],t15);}
else{
t12=t9;
f_7230(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7325,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1467 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7110(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7392,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1480 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[395]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[440]));
if(C_truep(t10)){
t11=f_7110(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7436,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1493 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7546,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7621,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1524 get */
t17=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[438]);}
else{
t15=t14;
f_7546(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7660,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1543 ##sys#hash-table-ref */
t17=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7660(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7660(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7660(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1547 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7698(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7658 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1544 set-real-name! */
t2=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7654(2,t2,C_SCHEME_UNDEFINED);}}

/* k7652 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1545 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7698(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7625 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7627,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1525 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[449],lf[450],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1526 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[452]);}}

/* k7634 in k7625 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1527 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[449],lf[451],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7621(2,t2,C_SCHEME_UNDEFINED);}}

/* k7619 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1528 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[448],((C_word*)t0)[2]);}

/* k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7575(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7575(t5,(C_word)C_i_not(t4));}}

/* k7573 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7110(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7590,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7590(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7590(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7590(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7581(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7549(2,t2,C_SCHEME_UNDEFINED);}}

/* k7588 in k7573 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7590,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1534 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7581(t2,C_SCHEME_UNDEFINED);}}

/* k7592 in k7588 in k7573 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7581(t3,t2);}

/* k7579 in k7573 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1535 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7547 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7552,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7572,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1536 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7570 in k7547 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1536 assign */
t2=((C_word*)t0)[6];
f_7710(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7550 in k7547 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7555(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1537 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],C_SCHEME_TRUE);}}

/* k7553 in k7550 in k7547 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1538 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446],C_SCHEME_TRUE);}

/* k7556 in k7553 in k7550 in k7547 in k7544 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1539 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7117(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7436,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7443,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1499 collect! */
t9=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[445],t5);}
else{
t8=t7;
f_7443(2,t8,C_SCHEME_UNDEFINED);}}

/* k7526 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1500 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[444],((C_word*)t0)[2]);}

/* k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7517 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7518,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7522,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1503 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[429],((C_word*)t0)[2]);}

/* k7520 in a7517 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1504 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[426],C_SCHEME_TRUE);}

/* k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[443]:lf[278]);
/* compiler.scm: 1507 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[437],t4);}
else{
t3=t2;
f_7449(2,t3,C_SCHEME_UNDEFINED);}}

/* k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7503,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1511 simple-lambda-node? */
t4=C_retrieve(lf[442]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7501 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1511 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7452(2,t2,C_SCHEME_UNDEFINED);}}

/* k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7455(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7455(t5,t4);}}

/* k7453 in k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7455,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7488(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7488(t4,C_SCHEME_FALSE);}}

/* k7486 in k7453 in k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7458(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7458(t2,C_SCHEME_UNDEFINED);}}

/* k7456 in k7453 in k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7458,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7461,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1516 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7483 in k7456 in k7453 in k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1516 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7117(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7459 in k7456 in k7453 in k7450 in k7447 in k7444 in k7441 in a7435 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7391 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7392,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7410 in a7391 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7411,3,t0,t1,t2);}
/* compiler.scm: 1484 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[426],C_SCHEME_TRUE);}

/* k7394 in a7391 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7400,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1488 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7407 in k7394 in a7391 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1488 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7117(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7398 in k7394 in a7391 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7330(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7330(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7330,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1470 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1473 put! */
t7=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[429],((C_word*)t0)[8]);}}

/* k7355 in loop in k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1474 assign */
t3=((C_word*)t0)[4];
f_7710(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7358 in k7355 in loop in k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7363,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1475 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7117(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7361 in k7358 in k7355 in loop in k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1476 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7330(t4,((C_word*)t0)[2],t2,t3);}

/* k7346 in loop in k7323 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1470 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7117(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7251 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1455 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[438]);}

/* k7299 in k7251 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[434])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7264,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7230(2,t3,C_SCHEME_UNDEFINED);}}

/* a7263 in k7299 in k7251 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7264,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7283,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1461 get */
t10=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[437]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7281 in a7263 in k7299 in k7251 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1461 count! */
t2=C_retrieve(lf[435]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7228 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1463 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7117(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7231 in k7228 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1464 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7698(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7192 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7110(C_fix(1));
/* compiler.scm: 1442 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7149 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7151,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7110(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1435 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[431],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7182,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1436 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[432]);}}}

/* k7180 in k7149 in k7137 in walk in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1436 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}}

/* assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7710,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[125],t7);
if(C_truep(t8)){
/* compiler.scm: 1554 put! */
t9=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[425],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7723,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[400],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7723(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7723(t13,C_SCHEME_FALSE);}}}

/* k7721 in assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7723,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7732(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7732(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1559 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[349]);}}}}

/* k7781 in k7721 in assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7732(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7730 in k7721 in assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1562 get-all */
t3=C_retrieve(lf[430]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[426],lf[427]);}
else{
/* compiler.scm: 1570 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}

/* k7733 in k7730 in k7721 in assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1563 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[429]);}

/* k7736 in k7733 in k7730 in k7721 in assign in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[426],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[427],((C_word*)t0)[7]))){
/* compiler.scm: 1566 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1568 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1569 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}}}

/* ref in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7813,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1573 collect! */
t4=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[423],t3);}

/* grow in k7106 in ##compiler#analyze-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static C_word C_fcall f_7110(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7095,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7086,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7077,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7068,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7059,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7050,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7041,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7032,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7023,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7014,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7008,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[409]));}

/* make-foreign-callback-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_7002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7002,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[409],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6327,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6374,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6748,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6873,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6889,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6974,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1400 walk */
t21=((C_word*)t6)[1];
f_6374(t21,t1,t2,*((C_word*)lf[408]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6974,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[407]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[103]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[107]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1398 every */
t8=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6889(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6889,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6895(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6895(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6895,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6909,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1381 reverse */
t5=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1382 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6974(3,t6,t4,t5);}}

/* k6913 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1383 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6895(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1385 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[384]);}}

/* k6931 in k6913 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1386 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6374(t4,((C_word*)t0)[2],t2,t3);}

/* a6941 in k6931 in k6913 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6942,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6956,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6968,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1391 varnode */
t7=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6966 in a6941 in k6931 in k6913 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1390 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6895(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6954 in a6941 in k6931 in k6913 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6956,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6907 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1381 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6873,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6879,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1374 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6889(t7,t1,t4,t6);}

/* a6878 in walk-inline-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6879,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[394],t3,t4,t2);
/* compiler.scm: 1377 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6748,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6752,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1350 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1351 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1355 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6803 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1355 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6778,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1356 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6889(t6,t4,((C_word*)t0)[2],t5);}

/* a6779 in k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6780,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1359 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6374(t4,t1,((C_word*)t0)[2],t3);}

/* a6785 in a6779 in k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6786,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6790,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1361 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6795 in a6785 in a6779 in k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1361 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6788 in a6785 in a6779 in k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[396],((C_word*)t0)[2],t1));}

/* k6776 in k6799 in k6807 in k6753 in k6750 in walk-call in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6778,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6374,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[400]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6396(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t14)){
t15=t13;
f_6396(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
if(C_truep(t15)){
t16=t13;
f_6396(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[271]);
t17=t13;
f_6396(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[406])));}}}}

/* k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6396,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1307 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1308 gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[399]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6502,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6502(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[402]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1330 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[279]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[402]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6662(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6662(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[103]);
if(C_truep(t10)){
t11=t8;
f_6662(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6662(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[107]);
t13=t8;
f_6662(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6662,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1344 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6873(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1345 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6748(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[270]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6819,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1364 gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[399]);}
else{
/* compiler.scm: 1347 bomb */
t4=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[405]);}}}}

/* k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1365 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6820 in k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6822,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6865 in k6820 in k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6863,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1369 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6861 in k6865 in k6820 in k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1369 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6857 in k6865 in k6820 in k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1371 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6853 in k6857 in k6865 in k6820 in k6817 in k6660 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6855,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[270],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k6625 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6653,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[403]),t1,((C_word*)t0)[2]);}

/* k6651 in k6625 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1341 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6330(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6575 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1331 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6374(t4,((C_word*)t0)[2],t2,t3);}

/* a6585 in k6575 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6586,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[394],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6610,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6614,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1335 varnode */
t10=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6612 in a6585 in k6575 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1335 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6608 in a6585 in k6575 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6610,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6562 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1329 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6330(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6502,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1323 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6374(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1324 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6374(t6,t1,t4,t5);}}

/* a6524 in loop in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6525,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1328 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6502(t8,t5,t6,t7);}

/* k6537 in a6524 in loop in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1309 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[402]);}

/* k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6483,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1314 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6481 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1314 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6477 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1315 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6374(t7,t4,t5,t6);}

/* a6451 in k6477 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1319 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6374(t5,t3,t4,((C_word*)t0)[2]);}

/* k6461 in a6451 in k6477 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6467,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1320 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6374(t4,t2,t3,((C_word*)t0)[2]);}

/* k6465 in k6461 in a6451 in k6477 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6467,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[113],C_SCHEME_END_OF_LIST,t2));}

/* k6444 in k6477 in k6485 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6446,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6423,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1310 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6421 in k1 in k6409 in k6406 in k6394 in walk in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[401],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6330,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6334,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1295 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6332 in cps-lambda in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1298 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6374(t7,t4,t5,t6);}

/* a6356 in k6332 in cps-lambda in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6357,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1300 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6366 in a6356 in k6332 in cps-lambda in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[397],t2));}

/* k6349 in k6332 in cps-lambda in ##compiler#perform-cps-conversion in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[4],t2);
/* compiler.scm: 1296 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6237,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6240,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6269,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1287 walk */
t10=((C_word*)t7)[1];
f_6269(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6269,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1282 ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[392]),t5);}
else{
/* compiler.scm: 1286 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6240(t5,t1,t2);}}}

/* k6286 in walk in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6288,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6294(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1284 alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6309 in k6286 in walk in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1284 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[392]),((C_word*)t0)[2],t1);}

/* k6292 in k6286 in walk in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1285 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6240(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6240,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6246(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6246,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6256,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1276 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6269(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6254 in loop in mapupdate in ##compiler#update-line-number-database! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1277 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6246(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6156,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6160,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6160(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6160(t5,C_SCHEME_FALSE);}}

/* k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6163,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6163(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6163(t3,lf[391]);}}

/* k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6163(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6163,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6166(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6166(t4,(C_word)C_i_cadr(t3));}}

/* k6164 in k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_6166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6166,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6169,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[389]+1),t4);}

/* k6180 in k6164 in k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6167 in k6164 in k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6170 in k6167 in k6164 in k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6173 in k6170 in k6167 in k6164 in k6161 in k6158 in ##compiler#expand-foreign-primitive in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1266 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6119,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6129,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6142,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6140 in ##compiler#expand-foreign-callback-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6127 in ##compiler#expand-foreign-callback-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6132,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6130 in k6127 in ##compiler#expand-foreign-callback-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6133 in k6130 in k6127 in ##compiler#expand-foreign-callback-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1257 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6082,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6092,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6105,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6103 in ##compiler#expand-foreign-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6090 in ##compiler#expand-foreign-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6093 in k6090 in ##compiler#expand-foreign-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6096 in k6093 in k6090 in ##compiler#expand-foreign-lambda* in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1249 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6037,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6044,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1236 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6044(2,t6,t4);}
else{
/* compiler.scm: 1238 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[388],t4);}}}

/* k6042 in ##compiler#expand-foreign-callback-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6050,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6048 in k6042 in ##compiler#expand-foreign-callback-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1241 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5992,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5999,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1227 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5999(2,t6,t4);}
else{
/* compiler.scm: 1229 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[387],t4);}}}

/* k5997 in ##compiler#expand-foreign-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5999,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6005,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6003 in k5997 in ##compiler#expand-foreign-lambda in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1232 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5838,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5842,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5986,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1200 list-tabulate */
t12=C_retrieve(lf[385]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5985 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5986,3,t0,t1,t2);}
/* compiler.scm: 1200 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[384]);}

/* k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1201 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}

/* k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1202 gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1203 estimate-foreign-result-size */
t3=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1204 set-real-name! */
t3=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1206 make-foreign-stub */
t3=C_retrieve(lf[358]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[271],((C_word*)t0)[2]);
t7=t5;
f_5864(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5864(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_5864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5864,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5955,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1212 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5954 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5955,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5963,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1212 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5961 in a5954 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1212 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[379]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[380],t1);
/* compiler.scm: 1217 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1218 final-foreign-type */
t7=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5905 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1219 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5908 in k5905 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[381],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5921,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1222 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5927 in k5908 in k5905 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1222 finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5923 in k5908 in k5905 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1221 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5919 in k5908 in k5905 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5921,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5890(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5898 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1217 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5888 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5876 in k5865 in k5862 in k5978 in k5852 in k5849 in k5846 in k5843 in k5840 in ##compiler#create-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5829,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5820,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5811,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5802,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5793,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5784,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5775,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5766,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5757,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5748,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5739,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5730,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5721,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5712,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5703,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5694,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5688,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[359]));}

/* make-foreign-stub in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5682,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[359],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4737,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4740,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4791(t5,t1);}

/* a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4791,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4795(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1025 syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[357],((C_word*)t0)[3]);}}

/* k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[293]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[296]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[297]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4860,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1037 check-decl */
f_4740(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t9=t3;
f_4801(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4907,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1047 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t10=t3;
f_4801(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4932,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1051 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t12=t3;
f_4801(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4961,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1058 lset-intersection */
t12=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),t10,C_retrieve(lf[300]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4978,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1061 check-decl */
f_4740(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[304]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[305]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[304]);
t13=t3;
f_4801(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4801(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1067 ##match#set-error-control */
t15=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[307]);}
else{
t14=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4801(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4801(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4801(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4801(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4801(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4801(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5061,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1074 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[312]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1075 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4801(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5096,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1079 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1083 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5137,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1087 every */
t28=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[319]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5159(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5159(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5159(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[323]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[323],t28);
/* compiler.scm: 1095 emit-control-file-item */
t30=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[325]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[325],t29);
/* compiler.scm: 1097 emit-control-file-item */
t31=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1100 pathname-strip-extension */
t31=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4801(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4801(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4801(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5297,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1106 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1108 check-decl */
f_4740(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[338]);
if(C_truep(t35)){
t36=C_set_block_item(lf[339],0,C_SCHEME_TRUE);
t37=t3;
f_4801(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[340]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[341]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5465,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5473,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1142 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5465(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5486,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1146 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1150 quit */
t41=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[344],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4801(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4801(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4801(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4801(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4801(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4801(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1159 lset-union */
t46=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[129]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5577,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1161 check-decl */
f_4740(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1169 every */
t47=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[351]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[352]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5651,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1173 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1183 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[356],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5650 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5651,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5656,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5661,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5660 in a5650 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5661,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[355]);}

/* k5654 in a5650 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5622 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5629,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1174 partition */
t4=C_retrieve(lf[354]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5628 in a5622 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5629,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1178 quit */
t3=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[353],t2);}}}

/* k5603 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5605,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1170 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1171 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[350],((C_word*)t0)[2]);}}

/* k5607 in k5603 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5575 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5584(2,t4,t2);}
else{
/* compiler.scm: 1166 quit */
t4=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[348],((C_word*)t0)[3]);}}

/* k5582 in k5575 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5558 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5484 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1147 lset-union */
t6=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],t5);}

/* k5488 in k5484 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5471 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5465(t3,t2);}

/* k5463 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_5465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5465,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1143 lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5467 in k5463 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4801(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1113 lset-difference */
t7=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4801(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1117 lset-difference */
t8=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[129]+1),C_retrieve(lf[301]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4801(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5380,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1121 lset-union */
t9=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[129]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4801(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5409,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1128 lset-difference */
t10=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1131 check-decl */
f_4740(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5418 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4801(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1136 ##match#set-error-control */
t6=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[307]);}
else{
/* compiler.scm: 1137 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[337],((C_word*)t0)[3]);}}}

/* k5407 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1129 lset-difference */
t4=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[301]),((C_word*)t0)[2]);}

/* k5411 in k5407 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5378 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5353 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5328 in k5308 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5295 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5247 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5258,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5257 in k5247 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5258,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[327]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[328],((C_word*)t0)[2],t2);}

/* k5254 in k5247 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5256,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[326],t1);
/* compiler.scm: 1099 emit-control-file-item */
t3=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5157 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_5159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1092 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1093 process-custom-declaration */
t4=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5135 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5137,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1088 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1089 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[317],((C_word*)t0)[2]);}}

/* k5139 in k5135 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5108 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1084 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5112 in k5108 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5094 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1081 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[17]));}

/* k5098 in k5094 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5073 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k5059 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[312]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4976 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4801(2,t4,t3);}

/* k4959 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1059 lset-intersection */
t4=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[301]));}

/* k4963 in k4959 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4930 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4905 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4866,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4890,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1039 stringify */
t5=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4888 in k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1039 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4864 in k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1040 ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[297],((C_word*)t0)[2]);}

/* k4867 in k4864 in k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4876,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4876(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4876(t4,C_SCHEME_FALSE);}}

/* k4874 in k4867 in k4864 in k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1042 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[298],lf[299]);}
else{
t2=((C_word*)t0)[2];
f_4872(2,t2,C_SCHEME_UNDEFINED);}}

/* k4870 in k4867 in k4864 in k4858 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4813(2,t3,C_SCHEME_UNDEFINED);}}

/* k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1033 ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[293],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4801(2,t2,C_SCHEME_UNDEFINED);}}

/* a4846 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4840 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),((C_word*)t0)[2],t2);}

/* k4820 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4831,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4830 in k4820 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4831,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1034 stringify */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4837 in a4830 in k4820 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1034 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4823 in k4820 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1035 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4827 in k4823 in k4820 in k4811 in k4808 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4801(2,t3,t2);}

/* k4799 in k4793 in a4790 in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[292]);}

/* check-decl in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4740(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4740,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4753,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4753(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4763(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4763(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1020 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4761 in check-decl in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4753(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4751 in check-decl in ##compiler#process-declaration in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1021 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[291],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1958,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1961,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1973,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1997,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2148,a[2]=t5,a[3]=t13,a[4]=t4,a[5]=t11,a[6]=t3,a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t17=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4682,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4695,a[2]=t2,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[123],C_retrieve(lf[288])))){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4732,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1003 newline */
t20=*((C_word*)lf[290]+1);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=t18;
f_4695(2,t19,C_SCHEME_UNDEFINED);}}

/* k4730 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1003 pretty-print */
t2=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1004 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[287]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4696 in k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1008 reverse */
t4=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4711 in k4696 in k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1011 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4720 in k4711 in k4696 in k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1012 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[284]),C_retrieve(lf[13]));}

/* k4724 in k4720 in k4711 in k4696 in k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 452  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4707 in k4696 in k4693 in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 1006 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2148(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4682,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4688,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4687 in mapwalk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4688,3,t0,t1,t2);}
/* compiler.scm: 1001 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2148(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 505  resolve-atom */
t9=((C_word*)((C_word*)t0)[8])[1];
f_2039(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2173,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 507  resolve-atom */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2039(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 509  constant? */
t7=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2185(2,t7,C_SCHEME_FALSE);}}}

/* k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 510  walk-literal */
t2=((C_word*)((C_word*)t0)[12])[1];
f_2130(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 511  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[111],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 515  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 977  constant? */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 975  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[283],((C_word*)t0)[10]);}}}}}

/* k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 978  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 982  caar */
t5=*((C_word*)lf[281]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4558(t4,C_SCHEME_FALSE);}}}

/* k4656 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4558(t2,(C_word)C_eqp(lf[159],t1));}

/* k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4558,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 985  emit-syntax-trace-info */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 997  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4643 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 998  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4682(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4565 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 986  ##sys#check-syntax */
t3=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[280]);}

/* k4568 in k4565 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4579(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4579(t4,C_SCHEME_FALSE);}}

/* k4577 in k4568 in k4565 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4579,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 989  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[278]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 990  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}}

/* k4599 in k4577 in k4568 in k4565 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 991  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2148(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4592 in k4577 in k4568 in k4565 in k4556 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 989  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2148(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4544 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 979  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[277],((C_word*)t0)[4]);}

/* k4547 in k4544 in k4541 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 980  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4682(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=f_1961(((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2218,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t2,a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 517  emit-syntax-trace-info */
t4=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}

/* k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[15]))){
t3=t2;
f_2221(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[15],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 520  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[274],((C_word*)t0)[2]);}
else{
/* compiler.scm: 521  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[275],((C_word*)t0)[15]);}}}

/* k4523 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 520  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[15]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 524  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[9]);}

/* k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[15],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 528  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[8]);}
else{
t4=t3;
f_2246(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 526  update-line-number-database! */
t4=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2237(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2235 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 527  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2148(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[13])[1];
f_2148(t4,((C_word*)t0)[12],t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 535  ##sys#check-syntax */
t4=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[113],((C_word*)t0)[14],lf[116]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[102]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 543  ##sys#check-syntax */
t5=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[102],((C_word*)t0)[14],lf[117]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[118]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[119]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[14]);
/* compiler.scm: 549  walk */
t6=((C_word*)((C_word*)t0)[13])[1];
f_2148(t6,((C_word*)t0)[12],t5,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[120]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 552  cadadr */
t7=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[14]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[125]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2380(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[270]);
if(C_truep(t8)){
t9=t7;
f_2380(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[271]);
if(C_truep(t9)){
t10=t7;
f_2380(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[103]);
t11=t7;
f_2380(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[8],lf[107])));}}}}}}}}}

/* k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[126]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2427(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 600  ##sys#check-syntax */
t6=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 614  ##sys#check-syntax */
t8=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 649  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2148(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[122]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 665  ##sys#check-syntax */
t12=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3092,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 704  unquotify */
t14=((C_word*)t0)[3];
f_1997(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3150,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 712  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2148(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 717  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2148(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 722  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 726  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 730  ##sys#check-syntax */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 742  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 745  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 748  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 751  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 754  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3360(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 761  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3427,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 772  gensym */
t33=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 785  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3501,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 805  gensym */
t34=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3703,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3721,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3846,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  call-with-current-continuation */
t37=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[242]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3919,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[244]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[267],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 947  ##sys#check-syntax */
t36=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[267],((C_word*)t0)[12],lf[269]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 965  ##sys#hash-table-ref */
t36=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4445(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4445(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4443 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 967  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 972  handle-call */
t2=((C_word*)t0)[7];
f_4316(t2,((C_word*)t0)[6]);}}

/* k4449 in k4443 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 969  handle-call */
t2=((C_word*)t0)[7];
f_4316(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 970  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2148(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4354 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1961(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 952  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2148(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 956  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2148(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 958  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 960  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2148(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t4=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 961  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2148(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4414 in k4354 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[103],t2));}

/* handle-call in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4316,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 936  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4682(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4318 in handle-call in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4326,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 938  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4324 in k4318 in handle-call in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 943  alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4329(2,t3,C_SCHEME_UNDEFINED);}}

/* k4338 in k4324 in k4318 in handle-call in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4340,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 940  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4327 in k4324 in k4318 in handle-call in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3952,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3974,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4300,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 879  valid-c-identifier? */
t14=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4298 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3974(2,t4,t3);}
else{
/* compiler.scm: 881  quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[265],((C_word*)t0)[3]);}}

/* k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4265(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4265(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4265(t11,(C_word)C_i_not(t10));}}}

/* k4263 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 886  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[264],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3977(2,t2,C_SCHEME_UNDEFINED);}}

/* k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 890  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4682(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4215,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4215(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4215,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 902  final-foreign-type */
t9=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4257 in loop in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 902  finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4253 in loop in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 901  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4249 in loop in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4239,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 904  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4215(t6,t3,t4,t5);}

/* k4237 in k4249 in loop in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[250]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4087(2,t7,f_4064(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4087(2,t7,f_4064(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[252]);
if(C_truep(t7)){
/* compiler.scm: 907  g300 */
t8=t6;
f_4087(2,t8,f_4064(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t8)){
/* compiler.scm: 907  g300 */
t9=t6;
f_4087(2,t9,f_4064(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4059(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4059(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t9)){
/* compiler.scm: 907  g301 */
t10=t4;
f_4059(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t10)){
/* compiler.scm: 907  g301 */
t11=t4;
f_4059(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t11)){
/* compiler.scm: 907  g301 */
t12=t4;
f_4059(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t12)){
/* compiler.scm: 907  g301 */
t13=t4;
f_4059(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t13)){
/* compiler.scm: 907  g302 */
t14=t6;
f_4087(2,t14,f_4022(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[261]))){
/* compiler.scm: 907  g302 */
t14=t6;
f_4087(2,t14,f_4022(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
/* compiler.scm: 907  g302 */
t15=t6;
f_4087(2,t15,(C_truep(t14)?f_4022(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[263]))?f_4022(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4085 in k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 905  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g300 in k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static C_word C_fcall f_4064(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g301 in k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_4059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4059,NULL,2,t0,t1);}
/* compiler.scm: 919  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g302 in k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static C_word C_fcall f_4022(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[246],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[247],lf[246]);
t7=(C_word)C_a_i_list(&a,3,lf[248],lf[246],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k4010 in k4006 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 891  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2148(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3994 in k3986 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3982 in k3975 in k3972 in a3951 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[244],t1));}

/* a3941 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 872  split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3918 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3919,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 867  process-declaration */
t4=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3915 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 865  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2148(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3846,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3852,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3864,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  with-exception-handler */
t5=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3863 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3885 in a3863 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3886r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3886r(t0,t1,t2);}}

static void C_ccall f_3886r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3891 in a3885 in a3863 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3892,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3869 in a3863 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 848  collapsable-literal? */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3875 in a3869 in a3863 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 850  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3851 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3857 in a3851 in a3845 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
/* compiler.scm: 846  quit */
t2=C_retrieve(lf[238]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[239],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3842 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[102],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 853  collapsable-literal? */
t8=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3791 in k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 854  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 857  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k3801 in k3791 in k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 858  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3804 in k3801 in k3791 in k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 859  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3808 in k3804 in k3801 in k3791 in k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[102],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 862  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2148(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3794 in k3791 in k3780 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3721,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3725,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 834  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3723 in a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 835  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3761 in k3723 in a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 835  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3727 in k3723 in a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3743,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3742 in k3727 in k3723 in a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3743,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[102],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3739 in k3727 in k3723 in a3720 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 837  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2148(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3702 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3711,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 833  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2148(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3709 in a3702 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 832  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 806  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 808  set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 811  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3662 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 811  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3600,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3612,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3616(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3616(t11,C_SCHEME_END_OF_LIST);}}

/* k3614 in k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_3616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3616,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 824  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3624(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3622 in k3614 in k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3610 in k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3608,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 825  alist-cons */
t4=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3606 in k3610 in k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 819  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3598 in k3639 in k3583 in k3577 in k3574 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 793  make-random-name */
t9=C_retrieve(lf[97]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3513(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 794  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3547 in k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 794  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3539 in k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3513(t3,t2);}

/* k3511 in k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_3513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3513,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 797  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3531 in k3511 in k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 799  alist-cons */
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3523 in k3531 in k3511 in k3508 in k3499 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3479 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3425 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 773  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3428 in k3425 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 774  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3431 in k3428 in k3425 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 775  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3435 in k3431 in k3428 in k3425 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 776  cons* */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3439 in k3435 in k3431 in k3428 in k3425 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 777  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2148(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3358 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3372(2,t3,t1);}
else{
/* compiler.scm: 763  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3370 in k3358 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3343 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 754  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3330 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 751  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3317 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 748  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3304 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 745  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3291 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 742  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3226,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3245,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3245(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_3245(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3245,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 737  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2148(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 738  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2148(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3270 in fold in k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 738  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3245(t3,t2,((C_word*)t0)[2]);}

/* k3274 in k3270 in fold in k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3263 in fold in k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3237 in k3224 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 732  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3211 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3196 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 723  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2148(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3169 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 718  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2148(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3173 in k3169 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3148 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3119 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 709  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4682(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3123 in k3119 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3090 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 704  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4682(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3094 in k3090 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1961(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 668  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2930,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 669  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2148(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2933,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 671  ##sys#alias-global-hook */
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2933(2,t4,C_SCHEME_UNDEFINED);}}

/* k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 674  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3041(t4,C_SCHEME_UNDEFINED);}}

/* k3065 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 675  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3069 in k3065 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3041(t3,t2);}

/* k3039 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_3041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3041,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 676  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3045 in k3039 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3047,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 680  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3060(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2933(2,t2,C_SCHEME_UNDEFINED);}}

/* k3058 in k3045 in k3039 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 677  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3048 in k3045 in k3039 in k3036 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 681  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2933(2,t2,C_SCHEME_UNDEFINED);}}

/* k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 682  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3026 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 683  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2936(2,t2,C_SCHEME_UNDEFINED);}}

/* k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 687  gensym */
t5=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 695  gensym */
t6=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2989 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 696  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3020 in k2989 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3014,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 700  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k3012 in k3020 in k2989 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2946 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2977 in k2946 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2967,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 691  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2965 in k2977 in k2946 in k2934 in k2931 in k2928 in k2925 in k2916 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 655  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2904 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 655  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2881 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 658  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2897 in k2881 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2898,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2894 in k2881 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 657  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2148(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2884 in k2881 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2889,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 661  set-real-names! */
f_1973(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2887 in k2884 in k2881 in k2878 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2624,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2830,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 617  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2828 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 618  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2624(2,t2,C_SCHEME_UNDEFINED);}}

/* a2840 in k2828 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2841,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2834 in k2828 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
/* compiler.scm: 620  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 623  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2629,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[122]),t2);}

/* k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 627  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2825 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 627  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 628  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2818 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2819,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 629  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2148(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 633  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2810(t4,C_SCHEME_FALSE);}}

/* k2815 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2810(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2808 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 631  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[159],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 635  set-real-names! */
f_1973(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2660(t4,t2);}
else{
t4=f_1961(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2660(t6,(C_word)C_i_not(t5));}}

/* k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2660,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 640  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2680(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2680(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2680(t5,C_SCHEME_FALSE);}}}}

/* k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 642  g169 */
t6=((C_word*)t0)[4];
f_2670(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2764,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2713(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2762 in k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[102]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2713(t3,C_SCHEME_FALSE);}}

/* k2758 in k2762 in k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2713(t2,C_SCHEME_FALSE);}}

/* k2754 in k2758 in k2762 in k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2713(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2713(t2,C_SCHEME_FALSE);}}

/* k2711 in k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2713,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 642  cadadr */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2718 in k2711 in k2678 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 642  g169 */
t3=((C_word*)t0)[3];
f_2670(t3,((C_word*)t0)[2],t1);}

/* g169 in k2658 in k2649 in k2643 in k2640 in k2637 in k2634 in k2631 in a2628 in k2622 in k2613 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2670,NULL,3,t0,t1,t2);}
/* compiler.scm: 644  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 602  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2550,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[122]),t1);}

/* k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 604  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2601 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 604  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 605  set-real-names! */
f_1973(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 606  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2582 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2583,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 607  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2148(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2589 in a2582 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2561 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 609  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2576 in k2561 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2577,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2569 in k2561 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 609  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2565 in k2561 in k2554 in k2551 in k2548 in k2545 in k2539 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2427,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 577  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2448,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2513(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 581  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2513(2,t6,C_SCHEME_FALSE);}}}

/* k2520 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2513(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 583  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2530 in k2520 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 582  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2511 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 589  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2475(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2475(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 585  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2485 in k2511 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2475(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2475(t2,C_SCHEME_FALSE);}}

/* a2500 in k2485 in k2511 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2501,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2497 in k2485 in k2511 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2475(t2,C_SCHEME_TRUE);}

/* k2473 in k2511 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2452(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 595  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2450 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 596  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2427(t4,t2,t3);}

/* k2457 in k2450 in a2447 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2441 in k2435 in loop in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
/* compiler.scm: 578  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2419 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 573  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2148(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2387 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2390 in k2387 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 567  ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2402 in k2390 in k2387 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2396 in k2390 in k2387 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2397,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),t2,((C_word*)t0)[2]);}

/* k2393 in k2390 in k2387 in k2378 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[127]);}

/* k2345 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2359,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 555  gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[123]);}}

/* k2357 in k2345 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 556  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2361 in k2357 in k2345 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2313 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* compiler.scm: 544  walk-literal */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2130(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2267 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 536  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2148(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2274 in k2267 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 537  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2148(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2278 in k2274 in k2267 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2284(2,t4,lf[114]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 540  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2148(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2282 in k2278 in k2274 in k2267 in k2244 in k2226 in k2219 in k2216 in k2210 in k2183 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[113],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2171 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 508  ##sys#alias-global-hook */
t2=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2165 in walk in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* walk-literal in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2130,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_retrieve(lf[93]))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2139,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 497  literal-rewrite-hook */
t7=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[102],t2));}}

/* a2138 in walk-literal in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2139,3,t0,t1,t2);}
/* walk21 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2148(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2039(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2039,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2043,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 472  ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2043(2,t7,C_SCHEME_FALSE);}}

/* k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 473  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2148(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 474  ##sys#hash-table-ref */
t3=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2056(2,t3,C_SCHEME_FALSE);}}}

/* k2054 in k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 476  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2148(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 480  final-foreign-type */
t5=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 488  final-foreign-type */
t6=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2102 in k2054 in k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[107],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 491  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2112 in k2102 in k2054 in k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 490  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2072 in k2054 in k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[103],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 483  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2082 in k2072 in k2054 in k2041 in resolve-atom in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 482  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[102]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2004(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2004(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2004(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2004(t4,C_SCHEME_FALSE);}}

/* k2002 in unquotify in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_2004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_fcall f_1973(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1979,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 459  for-each */
t5=*((C_word*)lf[101]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1978 in set-real-names! in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1979,4,t0,t1,t2,t3);}
/* compiler.scm: 459  set-real-name! */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static C_word C_fcall f_1961(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 429  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1956,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 430  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1954 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1891(2,t3,t2);}

/* k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 432  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 433  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1947 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1894(2,t3,t2);}

/* k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 435  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 436  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1940 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1897(2,t3,t2);}

/* k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 437  make-random-name */
t3=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[98]);}

/* k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[88]))){
/* compiler.scm: 440  vector-fill! */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[88]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 441  make-vector */
t5=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1933 in k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_1908(2,t3,t2);}

/* k1906 in k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 443  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 444  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1926 in k1906 in k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1911(2,t3,t2);}

/* k1909 in k1906 in k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 446  vector-fill! */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 447  make-vector */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1919 in k1909 in k1906 in k1903 in k1899 in k1895 in k1892 in k1889 in ##compiler#initialize-compiler in k1799 in k1795 in k1791 in k1787 in k1783 in k1779 in k1772 in k1769 in k1766 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[817] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1768compiler.scm",(void*)f_1768},
{"f_1771compiler.scm",(void*)f_1771},
{"f_1774compiler.scm",(void*)f_1774},
{"f_1781compiler.scm",(void*)f_1781},
{"f_1785compiler.scm",(void*)f_1785},
{"f_1789compiler.scm",(void*)f_1789},
{"f_1793compiler.scm",(void*)f_1793},
{"f_1797compiler.scm",(void*)f_1797},
{"f_1801compiler.scm",(void*)f_1801},
{"f_10145compiler.scm",(void*)f_10145},
{"f_11202compiler.scm",(void*)f_11202},
{"f_11205compiler.scm",(void*)f_11205},
{"f_11208compiler.scm",(void*)f_11208},
{"f_11211compiler.scm",(void*)f_11211},
{"f_11214compiler.scm",(void*)f_11214},
{"f_11002compiler.scm",(void*)f_11002},
{"f_11008compiler.scm",(void*)f_11008},
{"f_10235compiler.scm",(void*)f_10235},
{"f_10991compiler.scm",(void*)f_10991},
{"f_10988compiler.scm",(void*)f_10988},
{"f_10901compiler.scm",(void*)f_10901},
{"f_10965compiler.scm",(void*)f_10965},
{"f_10978compiler.scm",(void*)f_10978},
{"f_10959compiler.scm",(void*)f_10959},
{"f_10949compiler.scm",(void*)f_10949},
{"f_10922compiler.scm",(void*)f_10922},
{"f_10925compiler.scm",(void*)f_10925},
{"f_10873compiler.scm",(void*)f_10873},
{"f_10876compiler.scm",(void*)f_10876},
{"f_10830compiler.scm",(void*)f_10830},
{"f_10842compiler.scm",(void*)f_10842},
{"f_10833compiler.scm",(void*)f_10833},
{"f_10836compiler.scm",(void*)f_10836},
{"f_10710compiler.scm",(void*)f_10710},
{"f_10811compiler.scm",(void*)f_10811},
{"f_10799compiler.scm",(void*)f_10799},
{"f_10738compiler.scm",(void*)f_10738},
{"f_10744compiler.scm",(void*)f_10744},
{"f_10768compiler.scm",(void*)f_10768},
{"f_10760compiler.scm",(void*)f_10760},
{"f_10726compiler.scm",(void*)f_10726},
{"f_10669compiler.scm",(void*)f_10669},
{"f_10681compiler.scm",(void*)f_10681},
{"f_10685compiler.scm",(void*)f_10685},
{"f_10673compiler.scm",(void*)f_10673},
{"f_10485compiler.scm",(void*)f_10485},
{"f_10606compiler.scm",(void*)f_10606},
{"f_10612compiler.scm",(void*)f_10612},
{"f_10637compiler.scm",(void*)f_10637},
{"f_10618compiler.scm",(void*)f_10618},
{"f_10492compiler.scm",(void*)f_10492},
{"f_10597compiler.scm",(void*)f_10597},
{"f_10495compiler.scm",(void*)f_10495},
{"f_10498compiler.scm",(void*)f_10498},
{"f_10501compiler.scm",(void*)f_10501},
{"f_10539compiler.scm",(void*)f_10539},
{"f_10565compiler.scm",(void*)f_10565},
{"f_10546compiler.scm",(void*)f_10546},
{"f_10550compiler.scm",(void*)f_10550},
{"f_10523compiler.scm",(void*)f_10523},
{"f_10429compiler.scm",(void*)f_10429},
{"f_10438compiler.scm",(void*)f_10438},
{"f_10432compiler.scm",(void*)f_10432},
{"f_10413compiler.scm",(void*)f_10413},
{"f_10386compiler.scm",(void*)f_10386},
{"f_10369compiler.scm",(void*)f_10369},
{"f_10365compiler.scm",(void*)f_10365},
{"f_10358compiler.scm",(void*)f_10358},
{"f_10341compiler.scm",(void*)f_10341},
{"f_10337compiler.scm",(void*)f_10337},
{"f_10313compiler.scm",(void*)f_10313},
{"f_10293compiler.scm",(void*)f_10293},
{"f_10148compiler.scm",(void*)f_10148},
{"f_10152compiler.scm",(void*)f_10152},
{"f_10167compiler.scm",(void*)f_10167},
{"f_10177compiler.scm",(void*)f_10177},
{"f_10182compiler.scm",(void*)f_10182},
{"f_10227compiler.scm",(void*)f_10227},
{"f_10186compiler.scm",(void*)f_10186},
{"f_10192compiler.scm",(void*)f_10192},
{"f_10202compiler.scm",(void*)f_10202},
{"f_11014compiler.scm",(void*)f_11014},
{"f_11021compiler.scm",(void*)f_11021},
{"f_11083compiler.scm",(void*)f_11083},
{"f_11073compiler.scm",(void*)f_11073},
{"f_11047compiler.scm",(void*)f_11047},
{"f_11033compiler.scm",(void*)f_11033},
{"f_11108compiler.scm",(void*)f_11108},
{"f_11124compiler.scm",(void*)f_11124},
{"f_11131compiler.scm",(void*)f_11131},
{"f_11138compiler.scm",(void*)f_11138},
{"f_11112compiler.scm",(void*)f_11112},
{"f_11122compiler.scm",(void*)f_11122},
{"f_11094compiler.scm",(void*)f_11094},
{"f_11102compiler.scm",(void*)f_11102},
{"f_11140compiler.scm",(void*)f_11140},
{"f_11153compiler.scm",(void*)f_11153},
{"f_10136compiler.scm",(void*)f_10136},
{"f_10127compiler.scm",(void*)f_10127},
{"f_10118compiler.scm",(void*)f_10118},
{"f_10109compiler.scm",(void*)f_10109},
{"f_10100compiler.scm",(void*)f_10100},
{"f_10091compiler.scm",(void*)f_10091},
{"f_10082compiler.scm",(void*)f_10082},
{"f_10073compiler.scm",(void*)f_10073},
{"f_10064compiler.scm",(void*)f_10064},
{"f_10055compiler.scm",(void*)f_10055},
{"f_10046compiler.scm",(void*)f_10046},
{"f_10037compiler.scm",(void*)f_10037},
{"f_10028compiler.scm",(void*)f_10028},
{"f_10019compiler.scm",(void*)f_10019},
{"f_10010compiler.scm",(void*)f_10010},
{"f_10001compiler.scm",(void*)f_10001},
{"f_9992compiler.scm",(void*)f_9992},
{"f_9983compiler.scm",(void*)f_9983},
{"f_9974compiler.scm",(void*)f_9974},
{"f_9965compiler.scm",(void*)f_9965},
{"f_9956compiler.scm",(void*)f_9956},
{"f_9947compiler.scm",(void*)f_9947},
{"f_9938compiler.scm",(void*)f_9938},
{"f_9929compiler.scm",(void*)f_9929},
{"f_9920compiler.scm",(void*)f_9920},
{"f_9911compiler.scm",(void*)f_9911},
{"f_9902compiler.scm",(void*)f_9902},
{"f_9893compiler.scm",(void*)f_9893},
{"f_9884compiler.scm",(void*)f_9884},
{"f_9875compiler.scm",(void*)f_9875},
{"f_9869compiler.scm",(void*)f_9869},
{"f_9863compiler.scm",(void*)f_9863},
{"f_8629compiler.scm",(void*)f_8629},
{"f_9830compiler.scm",(void*)f_9830},
{"f_9833compiler.scm",(void*)f_9833},
{"f_9836compiler.scm",(void*)f_9836},
{"f_9839compiler.scm",(void*)f_9839},
{"f_9842compiler.scm",(void*)f_9842},
{"f_9857compiler.scm",(void*)f_9857},
{"f_9855compiler.scm",(void*)f_9855},
{"f_9845compiler.scm",(void*)f_9845},
{"f_9682compiler.scm",(void*)f_9682},
{"f_9688compiler.scm",(void*)f_9688},
{"f_8993compiler.scm",(void*)f_8993},
{"f_9012compiler.scm",(void*)f_9012},
{"f_9045compiler.scm",(void*)f_9045},
{"f_9572compiler.scm",(void*)f_9572},
{"f_9568compiler.scm",(void*)f_9568},
{"f_9561compiler.scm",(void*)f_9561},
{"f_9412compiler.scm",(void*)f_9412},
{"f_9418compiler.scm",(void*)f_9418},
{"f_9488compiler.scm",(void*)f_9488},
{"f_9518compiler.scm",(void*)f_9518},
{"f_9501compiler.scm",(void*)f_9501},
{"f_9505compiler.scm",(void*)f_9505},
{"f_9427compiler.scm",(void*)f_9427},
{"f_9474compiler.scm",(void*)f_9474},
{"f_9478compiler.scm",(void*)f_9478},
{"f_9454compiler.scm",(void*)f_9454},
{"f_9450compiler.scm",(void*)f_9450},
{"f_9141compiler.scm",(void*)f_9141},
{"f_9390compiler.scm",(void*)f_9390},
{"f_9145compiler.scm",(void*)f_9145},
{"f_9388compiler.scm",(void*)f_9388},
{"f_9148compiler.scm",(void*)f_9148},
{"f_9151compiler.scm",(void*)f_9151},
{"f_9157compiler.scm",(void*)f_9157},
{"f_9163compiler.scm",(void*)f_9163},
{"f_9169compiler.scm",(void*)f_9169},
{"f_9355compiler.scm",(void*)f_9355},
{"f_9358compiler.scm",(void*)f_9358},
{"f_9172compiler.scm",(void*)f_9172},
{"f_9331compiler.scm",(void*)f_9331},
{"f_9316compiler.scm",(void*)f_9316},
{"f_9312compiler.scm",(void*)f_9312},
{"f_9246compiler.scm",(void*)f_9246},
{"f_9271compiler.scm",(void*)f_9271},
{"f_9277compiler.scm",(void*)f_9277},
{"f_9288compiler.scm",(void*)f_9288},
{"f_9275compiler.scm",(void*)f_9275},
{"f_9257compiler.scm",(void*)f_9257},
{"f_9249compiler.scm",(void*)f_9249},
{"f_9234compiler.scm",(void*)f_9234},
{"f_9242compiler.scm",(void*)f_9242},
{"f_9195compiler.scm",(void*)f_9195},
{"f_9225compiler.scm",(void*)f_9225},
{"f_9217compiler.scm",(void*)f_9217},
{"f_9213compiler.scm",(void*)f_9213},
{"f_9209compiler.scm",(void*)f_9209},
{"f_9198compiler.scm",(void*)f_9198},
{"f_9066compiler.scm",(void*)f_9066},
{"f_9069compiler.scm",(void*)f_9069},
{"f_9121compiler.scm",(void*)f_9121},
{"f_9085compiler.scm",(void*)f_9085},
{"f_9114compiler.scm",(void*)f_9114},
{"f_9106compiler.scm",(void*)f_9106},
{"f_9051compiler.scm",(void*)f_9051},
{"f_9024compiler.scm",(void*)f_9024},
{"f_9030compiler.scm",(void*)f_9030},
{"f_9694compiler.scm",(void*)f_9694},
{"f_9701compiler.scm",(void*)f_9701},
{"f_9717compiler.scm",(void*)f_9717},
{"f_8659compiler.scm",(void*)f_8659},
{"f_8678compiler.scm",(void*)f_8678},
{"f_8957compiler.scm",(void*)f_8957},
{"f_8918compiler.scm",(void*)f_8918},
{"f_9733compiler.scm",(void*)f_9733},
{"f_9771compiler.scm",(void*)f_9771},
{"f_9797compiler.scm",(void*)f_9797},
{"f_9783compiler.scm",(void*)f_9783},
{"f_9762compiler.scm",(void*)f_9762},
{"f_9731compiler.scm",(void*)f_9731},
{"f_8931compiler.scm",(void*)f_8931},
{"f_8934compiler.scm",(void*)f_8934},
{"f_8945compiler.scm",(void*)f_8945},
{"f_8882compiler.scm",(void*)f_8882},
{"f_8774compiler.scm",(void*)f_8774},
{"f_8780compiler.scm",(void*)f_8780},
{"f_8792compiler.scm",(void*)f_8792},
{"f_8795compiler.scm",(void*)f_8795},
{"f_8798compiler.scm",(void*)f_8798},
{"f_8816compiler.scm",(void*)f_8816},
{"f_8823compiler.scm",(void*)f_8823},
{"f_8801compiler.scm",(void*)f_8801},
{"f_8804compiler.scm",(void*)f_8804},
{"f_8807compiler.scm",(void*)f_8807},
{"f_8768compiler.scm",(void*)f_8768},
{"f_8758compiler.scm",(void*)f_8758},
{"f_8741compiler.scm",(void*)f_8741},
{"f_8746compiler.scm",(void*)f_8746},
{"f_8699compiler.scm",(void*)f_8699},
{"f_8716compiler.scm",(void*)f_8716},
{"f_8703compiler.scm",(void*)f_8703},
{"f_8714compiler.scm",(void*)f_8714},
{"f_8689compiler.scm",(void*)f_8689},
{"f_8648compiler.scm",(void*)f_8648},
{"f_8657compiler.scm",(void*)f_8657},
{"f_8638compiler.scm",(void*)f_8638},
{"f_8643compiler.scm",(void*)f_8643},
{"f_8632compiler.scm",(void*)f_8632},
{"f_7104compiler.scm",(void*)f_7104},
{"f_7108compiler.scm",(void*)f_7108},
{"f_7858compiler.scm",(void*)f_7858},
{"f_7861compiler.scm",(void*)f_7861},
{"f_7865compiler.scm",(void*)f_7865},
{"f_7868compiler.scm",(void*)f_7868},
{"f_7881compiler.scm",(void*)f_7881},
{"f_8516compiler.scm",(void*)f_8516},
{"f_7885compiler.scm",(void*)f_7885},
{"f_8481compiler.scm",(void*)f_8481},
{"f_7892compiler.scm",(void*)f_7892},
{"f_8427compiler.scm",(void*)f_8427},
{"f_8430compiler.scm",(void*)f_8430},
{"f_8442compiler.scm",(void*)f_8442},
{"f_8436compiler.scm",(void*)f_8436},
{"f_7895compiler.scm",(void*)f_7895},
{"f_7898compiler.scm",(void*)f_7898},
{"f_8410compiler.scm",(void*)f_8410},
{"f_8402compiler.scm",(void*)f_8402},
{"f_8370compiler.scm",(void*)f_8370},
{"f_8376compiler.scm",(void*)f_8376},
{"f_7901compiler.scm",(void*)f_7901},
{"f_8332compiler.scm",(void*)f_8332},
{"f_8341compiler.scm",(void*)f_8341},
{"f_8344compiler.scm",(void*)f_8344},
{"f_7904compiler.scm",(void*)f_7904},
{"f_8233compiler.scm",(void*)f_8233},
{"f_8251compiler.scm",(void*)f_8251},
{"f_8294compiler.scm",(void*)f_8294},
{"f_8319compiler.scm",(void*)f_8319},
{"f_8315compiler.scm",(void*)f_8315},
{"f_8301compiler.scm",(void*)f_8301},
{"f_8304compiler.scm",(void*)f_8304},
{"f_8255compiler.scm",(void*)f_8255},
{"f_8261compiler.scm",(void*)f_8261},
{"f_7907compiler.scm",(void*)f_7907},
{"f_8211compiler.scm",(void*)f_8211},
{"f_8197compiler.scm",(void*)f_8197},
{"f_8204compiler.scm",(void*)f_8204},
{"f_8185compiler.scm",(void*)f_8185},
{"f_8170compiler.scm",(void*)f_8170},
{"f_7910compiler.scm",(void*)f_7910},
{"f_8082compiler.scm",(void*)f_8082},
{"f_8156compiler.scm",(void*)f_8156},
{"f_8088compiler.scm",(void*)f_8088},
{"f_8146compiler.scm",(void*)f_8146},
{"f_8138compiler.scm",(void*)f_8138},
{"f_8134compiler.scm",(void*)f_8134},
{"f_8091compiler.scm",(void*)f_8091},
{"f_8094compiler.scm",(void*)f_8094},
{"f_7913compiler.scm",(void*)f_7913},
{"f_7941compiler.scm",(void*)f_7941},
{"f_7962compiler.scm",(void*)f_7962},
{"f_7983compiler.scm",(void*)f_7983},
{"f_7989compiler.scm",(void*)f_7989},
{"f_7916compiler.scm",(void*)f_7916},
{"f_7922compiler.scm",(void*)f_7922},
{"f_7926compiler.scm",(void*)f_7926},
{"f_7871compiler.scm",(void*)f_7871},
{"f_7875compiler.scm",(void*)f_7875},
{"f_7878compiler.scm",(void*)f_7878},
{"f_7833compiler.scm",(void*)f_7833},
{"f_7843compiler.scm",(void*)f_7843},
{"f_7851compiler.scm",(void*)f_7851},
{"f_7819compiler.scm",(void*)f_7819},
{"f_7827compiler.scm",(void*)f_7827},
{"f_7698compiler.scm",(void*)f_7698},
{"f_7704compiler.scm",(void*)f_7704},
{"f_7117compiler.scm",(void*)f_7117},
{"f_7139compiler.scm",(void*)f_7139},
{"f_7660compiler.scm",(void*)f_7660},
{"f_7654compiler.scm",(void*)f_7654},
{"f_7627compiler.scm",(void*)f_7627},
{"f_7636compiler.scm",(void*)f_7636},
{"f_7621compiler.scm",(void*)f_7621},
{"f_7546compiler.scm",(void*)f_7546},
{"f_7575compiler.scm",(void*)f_7575},
{"f_7590compiler.scm",(void*)f_7590},
{"f_7594compiler.scm",(void*)f_7594},
{"f_7581compiler.scm",(void*)f_7581},
{"f_7549compiler.scm",(void*)f_7549},
{"f_7572compiler.scm",(void*)f_7572},
{"f_7552compiler.scm",(void*)f_7552},
{"f_7555compiler.scm",(void*)f_7555},
{"f_7558compiler.scm",(void*)f_7558},
{"f_7436compiler.scm",(void*)f_7436},
{"f_7528compiler.scm",(void*)f_7528},
{"f_7443compiler.scm",(void*)f_7443},
{"f_7518compiler.scm",(void*)f_7518},
{"f_7522compiler.scm",(void*)f_7522},
{"f_7446compiler.scm",(void*)f_7446},
{"f_7449compiler.scm",(void*)f_7449},
{"f_7503compiler.scm",(void*)f_7503},
{"f_7452compiler.scm",(void*)f_7452},
{"f_7455compiler.scm",(void*)f_7455},
{"f_7488compiler.scm",(void*)f_7488},
{"f_7458compiler.scm",(void*)f_7458},
{"f_7485compiler.scm",(void*)f_7485},
{"f_7461compiler.scm",(void*)f_7461},
{"f_7392compiler.scm",(void*)f_7392},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7396compiler.scm",(void*)f_7396},
{"f_7409compiler.scm",(void*)f_7409},
{"f_7400compiler.scm",(void*)f_7400},
{"f_7325compiler.scm",(void*)f_7325},
{"f_7330compiler.scm",(void*)f_7330},
{"f_7357compiler.scm",(void*)f_7357},
{"f_7360compiler.scm",(void*)f_7360},
{"f_7363compiler.scm",(void*)f_7363},
{"f_7348compiler.scm",(void*)f_7348},
{"f_7253compiler.scm",(void*)f_7253},
{"f_7301compiler.scm",(void*)f_7301},
{"f_7264compiler.scm",(void*)f_7264},
{"f_7283compiler.scm",(void*)f_7283},
{"f_7230compiler.scm",(void*)f_7230},
{"f_7233compiler.scm",(void*)f_7233},
{"f_7194compiler.scm",(void*)f_7194},
{"f_7151compiler.scm",(void*)f_7151},
{"f_7182compiler.scm",(void*)f_7182},
{"f_7710compiler.scm",(void*)f_7710},
{"f_7723compiler.scm",(void*)f_7723},
{"f_7783compiler.scm",(void*)f_7783},
{"f_7732compiler.scm",(void*)f_7732},
{"f_7735compiler.scm",(void*)f_7735},
{"f_7738compiler.scm",(void*)f_7738},
{"f_7813compiler.scm",(void*)f_7813},
{"f_7110compiler.scm",(void*)f_7110},
{"f_7095compiler.scm",(void*)f_7095},
{"f_7086compiler.scm",(void*)f_7086},
{"f_7077compiler.scm",(void*)f_7077},
{"f_7068compiler.scm",(void*)f_7068},
{"f_7059compiler.scm",(void*)f_7059},
{"f_7050compiler.scm",(void*)f_7050},
{"f_7041compiler.scm",(void*)f_7041},
{"f_7032compiler.scm",(void*)f_7032},
{"f_7023compiler.scm",(void*)f_7023},
{"f_7014compiler.scm",(void*)f_7014},
{"f_7008compiler.scm",(void*)f_7008},
{"f_7002compiler.scm",(void*)f_7002},
{"f_6327compiler.scm",(void*)f_6327},
{"f_6974compiler.scm",(void*)f_6974},
{"f_6889compiler.scm",(void*)f_6889},
{"f_6895compiler.scm",(void*)f_6895},
{"f_6915compiler.scm",(void*)f_6915},
{"f_6933compiler.scm",(void*)f_6933},
{"f_6942compiler.scm",(void*)f_6942},
{"f_6968compiler.scm",(void*)f_6968},
{"f_6956compiler.scm",(void*)f_6956},
{"f_6909compiler.scm",(void*)f_6909},
{"f_6873compiler.scm",(void*)f_6873},
{"f_6879compiler.scm",(void*)f_6879},
{"f_6748compiler.scm",(void*)f_6748},
{"f_6752compiler.scm",(void*)f_6752},
{"f_6755compiler.scm",(void*)f_6755},
{"f_6809compiler.scm",(void*)f_6809},
{"f_6805compiler.scm",(void*)f_6805},
{"f_6801compiler.scm",(void*)f_6801},
{"f_6780compiler.scm",(void*)f_6780},
{"f_6786compiler.scm",(void*)f_6786},
{"f_6797compiler.scm",(void*)f_6797},
{"f_6790compiler.scm",(void*)f_6790},
{"f_6778compiler.scm",(void*)f_6778},
{"f_6374compiler.scm",(void*)f_6374},
{"f_6396compiler.scm",(void*)f_6396},
{"f_6662compiler.scm",(void*)f_6662},
{"f_6819compiler.scm",(void*)f_6819},
{"f_6822compiler.scm",(void*)f_6822},
{"f_6867compiler.scm",(void*)f_6867},
{"f_6863compiler.scm",(void*)f_6863},
{"f_6859compiler.scm",(void*)f_6859},
{"f_6855compiler.scm",(void*)f_6855},
{"f_6627compiler.scm",(void*)f_6627},
{"f_6653compiler.scm",(void*)f_6653},
{"f_6577compiler.scm",(void*)f_6577},
{"f_6586compiler.scm",(void*)f_6586},
{"f_6614compiler.scm",(void*)f_6614},
{"f_6610compiler.scm",(void*)f_6610},
{"f_6564compiler.scm",(void*)f_6564},
{"f_6502compiler.scm",(void*)f_6502},
{"f_6525compiler.scm",(void*)f_6525},
{"f_6539compiler.scm",(void*)f_6539},
{"f_6408compiler.scm",(void*)f_6408},
{"f_6411compiler.scm",(void*)f_6411},
{"f_6487compiler.scm",(void*)f_6487},
{"f_6483compiler.scm",(void*)f_6483},
{"f_6479compiler.scm",(void*)f_6479},
{"f_6452compiler.scm",(void*)f_6452},
{"f_6463compiler.scm",(void*)f_6463},
{"f_6467compiler.scm",(void*)f_6467},
{"f_6446compiler.scm",(void*)f_6446},
{"f_6412compiler.scm",(void*)f_6412},
{"f_6423compiler.scm",(void*)f_6423},
{"f_6330compiler.scm",(void*)f_6330},
{"f_6334compiler.scm",(void*)f_6334},
{"f_6357compiler.scm",(void*)f_6357},
{"f_6368compiler.scm",(void*)f_6368},
{"f_6351compiler.scm",(void*)f_6351},
{"f_6237compiler.scm",(void*)f_6237},
{"f_6269compiler.scm",(void*)f_6269},
{"f_6288compiler.scm",(void*)f_6288},
{"f_6311compiler.scm",(void*)f_6311},
{"f_6294compiler.scm",(void*)f_6294},
{"f_6240compiler.scm",(void*)f_6240},
{"f_6246compiler.scm",(void*)f_6246},
{"f_6256compiler.scm",(void*)f_6256},
{"f_6156compiler.scm",(void*)f_6156},
{"f_6160compiler.scm",(void*)f_6160},
{"f_6163compiler.scm",(void*)f_6163},
{"f_6166compiler.scm",(void*)f_6166},
{"f_6182compiler.scm",(void*)f_6182},
{"f_6169compiler.scm",(void*)f_6169},
{"f_6172compiler.scm",(void*)f_6172},
{"f_6175compiler.scm",(void*)f_6175},
{"f_6119compiler.scm",(void*)f_6119},
{"f_6142compiler.scm",(void*)f_6142},
{"f_6129compiler.scm",(void*)f_6129},
{"f_6132compiler.scm",(void*)f_6132},
{"f_6135compiler.scm",(void*)f_6135},
{"f_6082compiler.scm",(void*)f_6082},
{"f_6105compiler.scm",(void*)f_6105},
{"f_6092compiler.scm",(void*)f_6092},
{"f_6095compiler.scm",(void*)f_6095},
{"f_6098compiler.scm",(void*)f_6098},
{"f_6037compiler.scm",(void*)f_6037},
{"f_6044compiler.scm",(void*)f_6044},
{"f_6050compiler.scm",(void*)f_6050},
{"f_5992compiler.scm",(void*)f_5992},
{"f_5999compiler.scm",(void*)f_5999},
{"f_6005compiler.scm",(void*)f_6005},
{"f_5838compiler.scm",(void*)f_5838},
{"f_5986compiler.scm",(void*)f_5986},
{"f_5842compiler.scm",(void*)f_5842},
{"f_5845compiler.scm",(void*)f_5845},
{"f_5848compiler.scm",(void*)f_5848},
{"f_5851compiler.scm",(void*)f_5851},
{"f_5854compiler.scm",(void*)f_5854},
{"f_5980compiler.scm",(void*)f_5980},
{"f_5864compiler.scm",(void*)f_5864},
{"f_5955compiler.scm",(void*)f_5955},
{"f_5963compiler.scm",(void*)f_5963},
{"f_5867compiler.scm",(void*)f_5867},
{"f_5907compiler.scm",(void*)f_5907},
{"f_5910compiler.scm",(void*)f_5910},
{"f_5929compiler.scm",(void*)f_5929},
{"f_5925compiler.scm",(void*)f_5925},
{"f_5921compiler.scm",(void*)f_5921},
{"f_5900compiler.scm",(void*)f_5900},
{"f_5890compiler.scm",(void*)f_5890},
{"f_5878compiler.scm",(void*)f_5878},
{"f_5829compiler.scm",(void*)f_5829},
{"f_5820compiler.scm",(void*)f_5820},
{"f_5811compiler.scm",(void*)f_5811},
{"f_5802compiler.scm",(void*)f_5802},
{"f_5793compiler.scm",(void*)f_5793},
{"f_5784compiler.scm",(void*)f_5784},
{"f_5775compiler.scm",(void*)f_5775},
{"f_5766compiler.scm",(void*)f_5766},
{"f_5757compiler.scm",(void*)f_5757},
{"f_5748compiler.scm",(void*)f_5748},
{"f_5739compiler.scm",(void*)f_5739},
{"f_5730compiler.scm",(void*)f_5730},
{"f_5721compiler.scm",(void*)f_5721},
{"f_5712compiler.scm",(void*)f_5712},
{"f_5703compiler.scm",(void*)f_5703},
{"f_5694compiler.scm",(void*)f_5694},
{"f_5688compiler.scm",(void*)f_5688},
{"f_5682compiler.scm",(void*)f_5682},
{"f_4737compiler.scm",(void*)f_4737},
{"f_4791compiler.scm",(void*)f_4791},
{"f_4795compiler.scm",(void*)f_4795},
{"f_5651compiler.scm",(void*)f_5651},
{"f_5661compiler.scm",(void*)f_5661},
{"f_5656compiler.scm",(void*)f_5656},
{"f_5623compiler.scm",(void*)f_5623},
{"f_5629compiler.scm",(void*)f_5629},
{"f_5605compiler.scm",(void*)f_5605},
{"f_5609compiler.scm",(void*)f_5609},
{"f_5577compiler.scm",(void*)f_5577},
{"f_5584compiler.scm",(void*)f_5584},
{"f_5560compiler.scm",(void*)f_5560},
{"f_5486compiler.scm",(void*)f_5486},
{"f_5490compiler.scm",(void*)f_5490},
{"f_5473compiler.scm",(void*)f_5473},
{"f_5465compiler.scm",(void*)f_5465},
{"f_5469compiler.scm",(void*)f_5469},
{"f_5310compiler.scm",(void*)f_5310},
{"f_5420compiler.scm",(void*)f_5420},
{"f_5409compiler.scm",(void*)f_5409},
{"f_5413compiler.scm",(void*)f_5413},
{"f_5380compiler.scm",(void*)f_5380},
{"f_5355compiler.scm",(void*)f_5355},
{"f_5330compiler.scm",(void*)f_5330},
{"f_5297compiler.scm",(void*)f_5297},
{"f_5249compiler.scm",(void*)f_5249},
{"f_5258compiler.scm",(void*)f_5258},
{"f_5256compiler.scm",(void*)f_5256},
{"f_5159compiler.scm",(void*)f_5159},
{"f_5137compiler.scm",(void*)f_5137},
{"f_5141compiler.scm",(void*)f_5141},
{"f_5110compiler.scm",(void*)f_5110},
{"f_5114compiler.scm",(void*)f_5114},
{"f_5096compiler.scm",(void*)f_5096},
{"f_5100compiler.scm",(void*)f_5100},
{"f_5075compiler.scm",(void*)f_5075},
{"f_5061compiler.scm",(void*)f_5061},
{"f_4978compiler.scm",(void*)f_4978},
{"f_4961compiler.scm",(void*)f_4961},
{"f_4965compiler.scm",(void*)f_4965},
{"f_4932compiler.scm",(void*)f_4932},
{"f_4907compiler.scm",(void*)f_4907},
{"f_4860compiler.scm",(void*)f_4860},
{"f_4890compiler.scm",(void*)f_4890},
{"f_4866compiler.scm",(void*)f_4866},
{"f_4869compiler.scm",(void*)f_4869},
{"f_4876compiler.scm",(void*)f_4876},
{"f_4872compiler.scm",(void*)f_4872},
{"f_4810compiler.scm",(void*)f_4810},
{"f_4813compiler.scm",(void*)f_4813},
{"f_4847compiler.scm",(void*)f_4847},
{"f_4841compiler.scm",(void*)f_4841},
{"f_4822compiler.scm",(void*)f_4822},
{"f_4831compiler.scm",(void*)f_4831},
{"f_4839compiler.scm",(void*)f_4839},
{"f_4825compiler.scm",(void*)f_4825},
{"f_4829compiler.scm",(void*)f_4829},
{"f_4801compiler.scm",(void*)f_4801},
{"f_4740compiler.scm",(void*)f_4740},
{"f_4763compiler.scm",(void*)f_4763},
{"f_4753compiler.scm",(void*)f_4753},
{"f_1958compiler.scm",(void*)f_1958},
{"f_4732compiler.scm",(void*)f_4732},
{"f_4695compiler.scm",(void*)f_4695},
{"f_4698compiler.scm",(void*)f_4698},
{"f_4713compiler.scm",(void*)f_4713},
{"f_4722compiler.scm",(void*)f_4722},
{"f_4726compiler.scm",(void*)f_4726},
{"f_4709compiler.scm",(void*)f_4709},
{"f_4682compiler.scm",(void*)f_4682},
{"f_4688compiler.scm",(void*)f_4688},
{"f_2148compiler.scm",(void*)f_2148},
{"f_2185compiler.scm",(void*)f_2185},
{"f_4543compiler.scm",(void*)f_4543},
{"f_4658compiler.scm",(void*)f_4658},
{"f_4558compiler.scm",(void*)f_4558},
{"f_4645compiler.scm",(void*)f_4645},
{"f_4567compiler.scm",(void*)f_4567},
{"f_4570compiler.scm",(void*)f_4570},
{"f_4579compiler.scm",(void*)f_4579},
{"f_4601compiler.scm",(void*)f_4601},
{"f_4594compiler.scm",(void*)f_4594},
{"f_4546compiler.scm",(void*)f_4546},
{"f_4549compiler.scm",(void*)f_4549},
{"f_2212compiler.scm",(void*)f_2212},
{"f_2218compiler.scm",(void*)f_2218},
{"f_4525compiler.scm",(void*)f_4525},
{"f_2221compiler.scm",(void*)f_2221},
{"f_2228compiler.scm",(void*)f_2228},
{"f_2237compiler.scm",(void*)f_2237},
{"f_2246compiler.scm",(void*)f_2246},
{"f_2380compiler.scm",(void*)f_2380},
{"f_4445compiler.scm",(void*)f_4445},
{"f_4451compiler.scm",(void*)f_4451},
{"f_4356compiler.scm",(void*)f_4356},
{"f_4416compiler.scm",(void*)f_4416},
{"f_4316compiler.scm",(void*)f_4316},
{"f_4320compiler.scm",(void*)f_4320},
{"f_4326compiler.scm",(void*)f_4326},
{"f_4340compiler.scm",(void*)f_4340},
{"f_4329compiler.scm",(void*)f_4329},
{"f_3952compiler.scm",(void*)f_3952},
{"f_4300compiler.scm",(void*)f_4300},
{"f_3974compiler.scm",(void*)f_3974},
{"f_4265compiler.scm",(void*)f_4265},
{"f_3977compiler.scm",(void*)f_3977},
{"f_3988compiler.scm",(void*)f_3988},
{"f_4215compiler.scm",(void*)f_4215},
{"f_4259compiler.scm",(void*)f_4259},
{"f_4255compiler.scm",(void*)f_4255},
{"f_4251compiler.scm",(void*)f_4251},
{"f_4239compiler.scm",(void*)f_4239},
{"f_4008compiler.scm",(void*)f_4008},
{"f_4087compiler.scm",(void*)f_4087},
{"f_4064compiler.scm",(void*)f_4064},
{"f_4059compiler.scm",(void*)f_4059},
{"f_4022compiler.scm",(void*)f_4022},
{"f_4012compiler.scm",(void*)f_4012},
{"f_3996compiler.scm",(void*)f_3996},
{"f_3984compiler.scm",(void*)f_3984},
{"f_3942compiler.scm",(void*)f_3942},
{"f_3919compiler.scm",(void*)f_3919},
{"f_3917compiler.scm",(void*)f_3917},
{"f_3846compiler.scm",(void*)f_3846},
{"f_3864compiler.scm",(void*)f_3864},
{"f_3886compiler.scm",(void*)f_3886},
{"f_3892compiler.scm",(void*)f_3892},
{"f_3870compiler.scm",(void*)f_3870},
{"f_3877compiler.scm",(void*)f_3877},
{"f_3852compiler.scm",(void*)f_3852},
{"f_3858compiler.scm",(void*)f_3858},
{"f_3844compiler.scm",(void*)f_3844},
{"f_3782compiler.scm",(void*)f_3782},
{"f_3793compiler.scm",(void*)f_3793},
{"f_3803compiler.scm",(void*)f_3803},
{"f_3806compiler.scm",(void*)f_3806},
{"f_3810compiler.scm",(void*)f_3810},
{"f_3796compiler.scm",(void*)f_3796},
{"f_3721compiler.scm",(void*)f_3721},
{"f_3725compiler.scm",(void*)f_3725},
{"f_3763compiler.scm",(void*)f_3763},
{"f_3729compiler.scm",(void*)f_3729},
{"f_3743compiler.scm",(void*)f_3743},
{"f_3741compiler.scm",(void*)f_3741},
{"f_3703compiler.scm",(void*)f_3703},
{"f_3711compiler.scm",(void*)f_3711},
{"f_3576compiler.scm",(void*)f_3576},
{"f_3579compiler.scm",(void*)f_3579},
{"f_3585compiler.scm",(void*)f_3585},
{"f_3664compiler.scm",(void*)f_3664},
{"f_3641compiler.scm",(void*)f_3641},
{"f_3616compiler.scm",(void*)f_3616},
{"f_3624compiler.scm",(void*)f_3624},
{"f_3612compiler.scm",(void*)f_3612},
{"f_3608compiler.scm",(void*)f_3608},
{"f_3600compiler.scm",(void*)f_3600},
{"f_3501compiler.scm",(void*)f_3501},
{"f_3510compiler.scm",(void*)f_3510},
{"f_3549compiler.scm",(void*)f_3549},
{"f_3541compiler.scm",(void*)f_3541},
{"f_3513compiler.scm",(void*)f_3513},
{"f_3533compiler.scm",(void*)f_3533},
{"f_3525compiler.scm",(void*)f_3525},
{"f_3481compiler.scm",(void*)f_3481},
{"f_3427compiler.scm",(void*)f_3427},
{"f_3430compiler.scm",(void*)f_3430},
{"f_3433compiler.scm",(void*)f_3433},
{"f_3437compiler.scm",(void*)f_3437},
{"f_3441compiler.scm",(void*)f_3441},
{"f_3360compiler.scm",(void*)f_3360},
{"f_3372compiler.scm",(void*)f_3372},
{"f_3345compiler.scm",(void*)f_3345},
{"f_3332compiler.scm",(void*)f_3332},
{"f_3319compiler.scm",(void*)f_3319},
{"f_3306compiler.scm",(void*)f_3306},
{"f_3293compiler.scm",(void*)f_3293},
{"f_3226compiler.scm",(void*)f_3226},
{"f_3245compiler.scm",(void*)f_3245},
{"f_3272compiler.scm",(void*)f_3272},
{"f_3276compiler.scm",(void*)f_3276},
{"f_3265compiler.scm",(void*)f_3265},
{"f_3239compiler.scm",(void*)f_3239},
{"f_3213compiler.scm",(void*)f_3213},
{"f_3198compiler.scm",(void*)f_3198},
{"f_3171compiler.scm",(void*)f_3171},
{"f_3175compiler.scm",(void*)f_3175},
{"f_3150compiler.scm",(void*)f_3150},
{"f_3121compiler.scm",(void*)f_3121},
{"f_3125compiler.scm",(void*)f_3125},
{"f_3092compiler.scm",(void*)f_3092},
{"f_3096compiler.scm",(void*)f_3096},
{"f_2918compiler.scm",(void*)f_2918},
{"f_2927compiler.scm",(void*)f_2927},
{"f_2930compiler.scm",(void*)f_2930},
{"f_3038compiler.scm",(void*)f_3038},
{"f_3067compiler.scm",(void*)f_3067},
{"f_3071compiler.scm",(void*)f_3071},
{"f_3041compiler.scm",(void*)f_3041},
{"f_3047compiler.scm",(void*)f_3047},
{"f_3060compiler.scm",(void*)f_3060},
{"f_3050compiler.scm",(void*)f_3050},
{"f_2933compiler.scm",(void*)f_2933},
{"f_3028compiler.scm",(void*)f_3028},
{"f_2936compiler.scm",(void*)f_2936},
{"f_2991compiler.scm",(void*)f_2991},
{"f_3022compiler.scm",(void*)f_3022},
{"f_3014compiler.scm",(void*)f_3014},
{"f_2948compiler.scm",(void*)f_2948},
{"f_2979compiler.scm",(void*)f_2979},
{"f_2967compiler.scm",(void*)f_2967},
{"f_2880compiler.scm",(void*)f_2880},
{"f_2906compiler.scm",(void*)f_2906},
{"f_2883compiler.scm",(void*)f_2883},
{"f_2898compiler.scm",(void*)f_2898},
{"f_2896compiler.scm",(void*)f_2896},
{"f_2886compiler.scm",(void*)f_2886},
{"f_2889compiler.scm",(void*)f_2889},
{"f_2615compiler.scm",(void*)f_2615},
{"f_2830compiler.scm",(void*)f_2830},
{"f_2841compiler.scm",(void*)f_2841},
{"f_2835compiler.scm",(void*)f_2835},
{"f_2624compiler.scm",(void*)f_2624},
{"f_2629compiler.scm",(void*)f_2629},
{"f_2633compiler.scm",(void*)f_2633},
{"f_2827compiler.scm",(void*)f_2827},
{"f_2636compiler.scm",(void*)f_2636},
{"f_2819compiler.scm",(void*)f_2819},
{"f_2639compiler.scm",(void*)f_2639},
{"f_2642compiler.scm",(void*)f_2642},
{"f_2817compiler.scm",(void*)f_2817},
{"f_2810compiler.scm",(void*)f_2810},
{"f_2645compiler.scm",(void*)f_2645},
{"f_2651compiler.scm",(void*)f_2651},
{"f_2660compiler.scm",(void*)f_2660},
{"f_2680compiler.scm",(void*)f_2680},
{"f_2764compiler.scm",(void*)f_2764},
{"f_2760compiler.scm",(void*)f_2760},
{"f_2756compiler.scm",(void*)f_2756},
{"f_2713compiler.scm",(void*)f_2713},
{"f_2720compiler.scm",(void*)f_2720},
{"f_2670compiler.scm",(void*)f_2670},
{"f_2541compiler.scm",(void*)f_2541},
{"f_2547compiler.scm",(void*)f_2547},
{"f_2550compiler.scm",(void*)f_2550},
{"f_2603compiler.scm",(void*)f_2603},
{"f_2553compiler.scm",(void*)f_2553},
{"f_2556compiler.scm",(void*)f_2556},
{"f_2583compiler.scm",(void*)f_2583},
{"f_2591compiler.scm",(void*)f_2591},
{"f_2563compiler.scm",(void*)f_2563},
{"f_2577compiler.scm",(void*)f_2577},
{"f_2571compiler.scm",(void*)f_2571},
{"f_2567compiler.scm",(void*)f_2567},
{"f_2427compiler.scm",(void*)f_2427},
{"f_2437compiler.scm",(void*)f_2437},
{"f_2448compiler.scm",(void*)f_2448},
{"f_2522compiler.scm",(void*)f_2522},
{"f_2532compiler.scm",(void*)f_2532},
{"f_2513compiler.scm",(void*)f_2513},
{"f_2487compiler.scm",(void*)f_2487},
{"f_2501compiler.scm",(void*)f_2501},
{"f_2499compiler.scm",(void*)f_2499},
{"f_2475compiler.scm",(void*)f_2475},
{"f_2452compiler.scm",(void*)f_2452},
{"f_2459compiler.scm",(void*)f_2459},
{"f_2442compiler.scm",(void*)f_2442},
{"f_2421compiler.scm",(void*)f_2421},
{"f_2389compiler.scm",(void*)f_2389},
{"f_2392compiler.scm",(void*)f_2392},
{"f_2403compiler.scm",(void*)f_2403},
{"f_2397compiler.scm",(void*)f_2397},
{"f_2395compiler.scm",(void*)f_2395},
{"f_2347compiler.scm",(void*)f_2347},
{"f_2359compiler.scm",(void*)f_2359},
{"f_2363compiler.scm",(void*)f_2363},
{"f_2315compiler.scm",(void*)f_2315},
{"f_2269compiler.scm",(void*)f_2269},
{"f_2276compiler.scm",(void*)f_2276},
{"f_2280compiler.scm",(void*)f_2280},
{"f_2284compiler.scm",(void*)f_2284},
{"f_2173compiler.scm",(void*)f_2173},
{"f_2167compiler.scm",(void*)f_2167},
{"f_2130compiler.scm",(void*)f_2130},
{"f_2139compiler.scm",(void*)f_2139},
{"f_2039compiler.scm",(void*)f_2039},
{"f_2043compiler.scm",(void*)f_2043},
{"f_2056compiler.scm",(void*)f_2056},
{"f_2104compiler.scm",(void*)f_2104},
{"f_2114compiler.scm",(void*)f_2114},
{"f_2074compiler.scm",(void*)f_2074},
{"f_2084compiler.scm",(void*)f_2084},
{"f_1997compiler.scm",(void*)f_1997},
{"f_2004compiler.scm",(void*)f_2004},
{"f_1973compiler.scm",(void*)f_1973},
{"f_1979compiler.scm",(void*)f_1979},
{"f_1961compiler.scm",(void*)f_1961},
{"f_1887compiler.scm",(void*)f_1887},
{"f_1956compiler.scm",(void*)f_1956},
{"f_1891compiler.scm",(void*)f_1891},
{"f_1949compiler.scm",(void*)f_1949},
{"f_1894compiler.scm",(void*)f_1894},
{"f_1942compiler.scm",(void*)f_1942},
{"f_1897compiler.scm",(void*)f_1897},
{"f_1901compiler.scm",(void*)f_1901},
{"f_1905compiler.scm",(void*)f_1905},
{"f_1935compiler.scm",(void*)f_1935},
{"f_1908compiler.scm",(void*)f_1908},
{"f_1928compiler.scm",(void*)f_1928},
{"f_1911compiler.scm",(void*)f_1911},
{"f_1921compiler.scm",(void*)f_1921},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
