/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-09 11:03
   Version 3.3.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   compiled 2008-07-02 on debian (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[578];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11217)
static void C_ccall f_11217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11220)
static void C_ccall f_11220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11223)
static void C_ccall f_11223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11226)
static void C_ccall f_11226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11014)
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11020)
static void C_ccall f_11020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10247)
static void C_fcall f_10247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11000)
static void C_ccall f_11000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10913)
static void C_fcall f_10913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10977)
static void C_ccall f_10977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10971)
static void C_ccall f_10971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10934)
static void C_fcall f_10934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10937)
static void C_ccall f_10937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10885)
static void C_fcall f_10885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10888)
static void C_ccall f_10888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10854)
static void C_fcall f_10854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10845)
static void C_fcall f_10845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10823)
static void C_ccall f_10823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10811)
static void C_ccall f_10811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10750)
static void C_ccall f_10750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10756)
static void C_fcall f_10756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10780)
static void C_ccall f_10780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10630)
static void C_fcall f_10630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10504)
static void C_ccall f_10504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10609)
static void C_ccall f_10609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10507)
static void C_ccall f_10507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10513)
static void C_ccall f_10513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10558)
static void C_fcall f_10558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10535)
static void C_ccall f_10535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10441)
static void C_ccall f_10441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10450)
static void C_fcall f_10450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10444)
static void C_fcall f_10444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10425)
static void C_ccall f_10425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10381)
static void C_ccall f_10381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10377)
static void C_ccall f_10377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10370)
static void C_ccall f_10370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_ccall f_10349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10325)
static void C_ccall f_10325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10160)
static void C_fcall f_10160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10164)
static void C_ccall f_10164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_ccall f_10179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10189)
static void C_ccall f_10189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10194)
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10198)
static void C_ccall f_10198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10204)
static void C_fcall f_10204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10214)
static void C_ccall f_10214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11026)
static void C_fcall f_11026(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11045)
static void C_ccall f_11045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11120)
static void C_fcall f_11120(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11143)
static void C_ccall f_11143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11124)
static void C_ccall f_11124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11134)
static void C_ccall f_11134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11106)
static void C_fcall f_11106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11114)
static void C_ccall f_11114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11152)
static void C_fcall f_11152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10094)
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10085)
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10076)
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10067)
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10040)
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10013)
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9995)
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9914)
static void C_ccall f_9914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_ccall f_9845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9848)
static void C_ccall f_9848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9867)
static void C_ccall f_9867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9694)
static void C_fcall f_9694(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9005)
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9024)
static void C_fcall f_9024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9057)
static void C_fcall f_9057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9584)
static void C_ccall f_9584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9573)
static void C_fcall f_9573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9517)
static void C_ccall f_9517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9490)
static void C_ccall f_9490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9402)
static void C_ccall f_9402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9181)
static void C_fcall f_9181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9367)
static void C_ccall f_9367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9258)
static void C_ccall f_9258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9289)
static void C_ccall f_9289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9287)
static void C_ccall f_9287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9237)
static void C_ccall f_9237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9229)
static void C_ccall f_9229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9221)
static void C_ccall f_9221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9081)
static void C_ccall f_9081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9133)
static void C_ccall f_9133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_ccall f_9118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9036)
static void C_ccall f_9036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9706)
static void C_fcall f_9706(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9729)
static void C_ccall f_9729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8671)
static void C_fcall f_8671(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8690)
static void C_fcall f_8690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9783)
static void C_fcall f_9783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9809)
static void C_ccall f_9809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_fcall f_9795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8792)
static void C_fcall f_8792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8810)
static void C_fcall f_8810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8828)
static void C_fcall f_8828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8835)
static void C_ccall f_8835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8816)
static void C_ccall f_8816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8819)
static void C_ccall f_8819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_fcall f_8780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_fcall f_8770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8753)
static void C_ccall f_8753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_ccall f_8758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8726)
static void C_ccall f_8726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8701)
static void C_ccall f_8701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8660)
static void C_fcall f_8660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8650)
static void C_fcall f_8650(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_fcall f_8644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7897)
static void C_ccall f_7897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_fcall f_8493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_fcall f_8439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8454)
static void C_fcall f_8454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8448)
static void C_fcall f_8448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8388)
static void C_fcall f_8388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_fcall f_8344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_fcall f_8356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_fcall f_8245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_fcall f_8313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_fcall f_8273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8223)
static void C_ccall f_8223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_fcall f_8209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_fcall f_8197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_fcall f_8182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8158)
static void C_ccall f_8158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_fcall f_8103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_fcall f_7953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7974)
static void C_fcall f_7974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7995)
static void C_fcall f_7995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_fcall f_7934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_fcall f_7890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_fcall f_7845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7831)
static void C_fcall f_7831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7710)
static void C_fcall f_7710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7716)
static void C_ccall f_7716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7129)
static void C_fcall f_7129(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7151)
static void C_fcall f_7151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static void C_ccall f_7672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_fcall f_7587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_fcall f_7602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7593)
static void C_fcall f_7593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7534)
static void C_ccall f_7534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_fcall f_7467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_fcall f_7500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_fcall f_7470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_fcall f_7342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_ccall f_7194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_fcall f_7722(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7744)
static void C_fcall f_7744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_fcall f_7825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7122)
static C_word C_fcall f_7122(C_word t0);
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7044)
static void C_ccall f_7044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6901)
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6907)
static void C_fcall f_6907(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_fcall f_6885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6760)
static void C_fcall f_6760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6408)
static void C_fcall f_6408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6674)
static void C_fcall f_6674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_fcall f_6342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6281)
static void C_fcall f_6281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_fcall f_6252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6258)
static void C_fcall f_6258(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6172)
static void C_fcall f_6172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_fcall f_6175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_fcall f_6178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4803)
static void C_fcall f_4803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_fcall f_5477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_fcall f_5171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_fcall f_4888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_fcall f_4752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_fcall f_4765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_fcall f_4694(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_fcall f_4570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_fcall f_4591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_fcall f_2392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_fcall f_4328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_fcall f_4277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static C_word C_fcall f_4076(C_word *a,C_word t0);
C_noret_decl(f_4071)
static void C_fcall f_4071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static C_word C_fcall f_4034(C_word *a,C_word t0);
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_fcall f_3628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_fcall f_3525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_fcall f_3257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_fcall f_3053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_fcall f_2822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_fcall f_2672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_fcall f_2692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_fcall f_2725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_fcall f_1985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1973)
static C_word C_fcall f_1973(C_word t0,C_word t1);
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11014)
static void C_fcall trf_11014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11014(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11014(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10247)
static void C_fcall trf_10247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10247(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10247(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10913)
static void C_fcall trf_10913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10913(t0,t1);}

C_noret_decl(trf_10934)
static void C_fcall trf_10934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10934(t0,t1);}

C_noret_decl(trf_10885)
static void C_fcall trf_10885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10885(t0,t1);}

C_noret_decl(trf_10854)
static void C_fcall trf_10854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10854(t0,t1);}

C_noret_decl(trf_10845)
static void C_fcall trf_10845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10845(t0,t1);}

C_noret_decl(trf_10756)
static void C_fcall trf_10756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10756(t0,t1);}

C_noret_decl(trf_10630)
static void C_fcall trf_10630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10630(t0,t1);}

C_noret_decl(trf_10558)
static void C_fcall trf_10558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10558(t0,t1);}

C_noret_decl(trf_10450)
static void C_fcall trf_10450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10450(t0,t1);}

C_noret_decl(trf_10444)
static void C_fcall trf_10444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10444(t0,t1);}

C_noret_decl(trf_10160)
static void C_fcall trf_10160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10160(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10160(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10194)
static void C_fcall trf_10194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10194(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10194(t0,t1,t2,t3);}

C_noret_decl(trf_10204)
static void C_fcall trf_10204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10204(t0,t1);}

C_noret_decl(trf_11026)
static void C_fcall trf_11026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11026(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11026(t0,t1,t2);}

C_noret_decl(trf_11120)
static void C_fcall trf_11120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11120(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11120(t0,t1,t2);}

C_noret_decl(trf_11106)
static void C_fcall trf_11106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11106(t0,t1,t2);}

C_noret_decl(trf_11152)
static void C_fcall trf_11152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11152(t0,t1);}

C_noret_decl(trf_9694)
static void C_fcall trf_9694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9694(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9694(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9005)
static void C_fcall trf_9005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9005(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9005(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9024)
static void C_fcall trf_9024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9024(t0,t1);}

C_noret_decl(trf_9057)
static void C_fcall trf_9057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9057(t0,t1);}

C_noret_decl(trf_9573)
static void C_fcall trf_9573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9573(t0,t1);}

C_noret_decl(trf_9181)
static void C_fcall trf_9181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9181(t0,t1);}

C_noret_decl(trf_9706)
static void C_fcall trf_9706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9706(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9706(t0,t1,t2,t3);}

C_noret_decl(trf_8671)
static void C_fcall trf_8671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8671(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8671(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8690)
static void C_fcall trf_8690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8690(t0,t1);}

C_noret_decl(trf_9783)
static void C_fcall trf_9783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9783(t0,t1);}

C_noret_decl(trf_9795)
static void C_fcall trf_9795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9795(t0,t1);}

C_noret_decl(trf_8792)
static void C_fcall trf_8792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8792(t0,t1);}

C_noret_decl(trf_8810)
static void C_fcall trf_8810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8810(t0,t1);}

C_noret_decl(trf_8828)
static void C_fcall trf_8828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8828(t0,t1);}

C_noret_decl(trf_8780)
static void C_fcall trf_8780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8780(t0,t1);}

C_noret_decl(trf_8770)
static void C_fcall trf_8770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8770(t0,t1);}

C_noret_decl(trf_8660)
static void C_fcall trf_8660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8660(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8660(t0,t1,t2);}

C_noret_decl(trf_8650)
static void C_fcall trf_8650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8650(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8650(t0,t1,t2,t3);}

C_noret_decl(trf_8644)
static void C_fcall trf_8644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8644(t0,t1,t2,t3);}

C_noret_decl(trf_8493)
static void C_fcall trf_8493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8493(t0,t1);}

C_noret_decl(trf_8439)
static void C_fcall trf_8439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8439(t0,t1);}

C_noret_decl(trf_8454)
static void C_fcall trf_8454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8454(t0,t1);}

C_noret_decl(trf_8448)
static void C_fcall trf_8448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8448(t0,t1);}

C_noret_decl(trf_8388)
static void C_fcall trf_8388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8388(t0,t1);}

C_noret_decl(trf_8344)
static void C_fcall trf_8344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8344(t0,t1);}

C_noret_decl(trf_8356)
static void C_fcall trf_8356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8356(t0,t1);}

C_noret_decl(trf_8245)
static void C_fcall trf_8245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8245(t0,t1);}

C_noret_decl(trf_8313)
static void C_fcall trf_8313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8313(t0,t1);}

C_noret_decl(trf_8273)
static void C_fcall trf_8273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8273(t0,t1);}

C_noret_decl(trf_8209)
static void C_fcall trf_8209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8209(t0,t1);}

C_noret_decl(trf_8197)
static void C_fcall trf_8197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8197(t0,t1);}

C_noret_decl(trf_8182)
static void C_fcall trf_8182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8182(t0,t1);}

C_noret_decl(trf_8103)
static void C_fcall trf_8103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8103(t0,t1);}

C_noret_decl(trf_7953)
static void C_fcall trf_7953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7953(t0,t1);}

C_noret_decl(trf_7974)
static void C_fcall trf_7974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7974(t0,t1);}

C_noret_decl(trf_7995)
static void C_fcall trf_7995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7995(t0,t1);}

C_noret_decl(trf_7934)
static void C_fcall trf_7934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7934(t0,t1);}

C_noret_decl(trf_7890)
static void C_fcall trf_7890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7890(t0,t1);}

C_noret_decl(trf_7845)
static void C_fcall trf_7845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7845(t0,t1,t2,t3);}

C_noret_decl(trf_7831)
static void C_fcall trf_7831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7831(t0,t1,t2,t3);}

C_noret_decl(trf_7710)
static void C_fcall trf_7710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7710(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7710(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7129)
static void C_fcall trf_7129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7129(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7129(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7151)
static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7151(t0,t1);}

C_noret_decl(trf_7587)
static void C_fcall trf_7587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7587(t0,t1);}

C_noret_decl(trf_7602)
static void C_fcall trf_7602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7602(t0,t1);}

C_noret_decl(trf_7593)
static void C_fcall trf_7593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7593(t0,t1);}

C_noret_decl(trf_7467)
static void C_fcall trf_7467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7467(t0,t1);}

C_noret_decl(trf_7500)
static void C_fcall trf_7500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7500(t0,t1);}

C_noret_decl(trf_7470)
static void C_fcall trf_7470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7470(t0,t1);}

C_noret_decl(trf_7342)
static void C_fcall trf_7342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7342(t0,t1,t2,t3);}

C_noret_decl(trf_7722)
static void C_fcall trf_7722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7722(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7722(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7735(t0,t1);}

C_noret_decl(trf_7744)
static void C_fcall trf_7744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7744(t0,t1);}

C_noret_decl(trf_7825)
static void C_fcall trf_7825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7825(t0,t1,t2,t3);}

C_noret_decl(trf_6901)
static void C_fcall trf_6901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6901(t0,t1,t2,t3);}

C_noret_decl(trf_6907)
static void C_fcall trf_6907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6907(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6907(t0,t1,t2,t3);}

C_noret_decl(trf_6885)
static void C_fcall trf_6885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6885(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6885(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6760)
static void C_fcall trf_6760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6760(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6760(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6386)
static void C_fcall trf_6386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6386(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6386(t0,t1,t2,t3);}

C_noret_decl(trf_6408)
static void C_fcall trf_6408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6408(t0,t1);}

C_noret_decl(trf_6674)
static void C_fcall trf_6674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6674(t0,t1);}

C_noret_decl(trf_6514)
static void C_fcall trf_6514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6514(t0,t1,t2,t3);}

C_noret_decl(trf_6342)
static void C_fcall trf_6342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6342(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6342(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6281)
static void C_fcall trf_6281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6281(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6281(t0,t1,t2);}

C_noret_decl(trf_6252)
static void C_fcall trf_6252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6252(t0,t1,t2);}

C_noret_decl(trf_6258)
static void C_fcall trf_6258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6258(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6258(t0,t1,t2);}

C_noret_decl(trf_6172)
static void C_fcall trf_6172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6172(t0,t1);}

C_noret_decl(trf_6175)
static void C_fcall trf_6175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6175(t0,t1);}

C_noret_decl(trf_6178)
static void C_fcall trf_6178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6178(t0,t1);}

C_noret_decl(trf_5876)
static void C_fcall trf_5876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5876(t0,t1);}

C_noret_decl(trf_4803)
static void C_fcall trf_4803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4803(t0,t1);}

C_noret_decl(trf_5477)
static void C_fcall trf_5477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5477(t0,t1);}

C_noret_decl(trf_5171)
static void C_fcall trf_5171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5171(t0,t1);}

C_noret_decl(trf_4888)
static void C_fcall trf_4888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4888(t0,t1);}

C_noret_decl(trf_4752)
static void C_fcall trf_4752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4752(t0,t1,t2,t3);}

C_noret_decl(trf_4765)
static void C_fcall trf_4765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4765(t0,t1);}

C_noret_decl(trf_4694)
static void C_fcall trf_4694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4694(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4694(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2160(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4570)
static void C_fcall trf_4570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4570(t0,t1);}

C_noret_decl(trf_4591)
static void C_fcall trf_4591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4591(t0,t1);}

C_noret_decl(trf_2392)
static void C_fcall trf_2392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2392(t0,t1);}

C_noret_decl(trf_4328)
static void C_fcall trf_4328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4328(t0,t1);}

C_noret_decl(trf_4277)
static void C_fcall trf_4277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4277(t0,t1);}

C_noret_decl(trf_4227)
static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4227(t0,t1,t2,t3);}

C_noret_decl(trf_4071)
static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4071(t0,t1);}

C_noret_decl(trf_3628)
static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3628(t0,t1);}

C_noret_decl(trf_3525)
static void C_fcall trf_3525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3525(t0,t1);}

C_noret_decl(trf_3257)
static void C_fcall trf_3257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3257(t0,t1,t2);}

C_noret_decl(trf_3053)
static void C_fcall trf_3053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3053(t0,t1);}

C_noret_decl(trf_2822)
static void C_fcall trf_2822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2822(t0,t1);}

C_noret_decl(trf_2672)
static void C_fcall trf_2672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2672(t0,t1);}

C_noret_decl(trf_2692)
static void C_fcall trf_2692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2692(t0,t1);}

C_noret_decl(trf_2725)
static void C_fcall trf_2725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2725(t0,t1);}

C_noret_decl(trf_2682)
static void C_fcall trf_2682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2682(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2682(t0,t1,t2);}

C_noret_decl(trf_2439)
static void C_fcall trf_2439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2439(t0,t1,t2);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2487(t0,t1);}

C_noret_decl(trf_2142)
static void C_fcall trf_2142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2142(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2142(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2051(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2016(t0,t1);}

C_noret_decl(trf_1985)
static void C_fcall trf_1985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1985(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5592)){
C_save(t1);
C_rereclaim2(5592*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,578);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],29,"\010compilerliteral-rewrite-hook");
lf[94]=C_h_intern(&lf[94],28,"\010compilerinitialize-compiler");
lf[95]=C_h_intern(&lf[95],12,"vector-fill!");
lf[96]=C_h_intern(&lf[96],11,"make-vector");
lf[97]=C_h_intern(&lf[97],25,"\010compilermake-random-name");
lf[98]=C_h_intern(&lf[98],12,"profile-info");
lf[99]=C_h_intern(&lf[99],32,"\010compilercanonicalize-expression");
lf[100]=C_h_intern(&lf[100],23,"\010compilerset-real-name!");
lf[101]=C_h_intern(&lf[101],8,"for-each");
lf[102]=C_h_intern(&lf[102],5,"quote");
lf[103]=C_h_intern(&lf[103],15,"\004coreinline_ref");
lf[104]=C_h_intern(&lf[104],36,"\010compilerforeign-type-convert-result");
lf[105]=C_h_intern(&lf[105],30,"\010compilerfinish-foreign-result");
lf[106]=C_h_intern(&lf[106],27,"\010compilerfinal-foreign-type");
lf[107]=C_h_intern(&lf[107],19,"\004coreinline_loc_ref");
lf[108]=C_h_intern(&lf[108],18,"\003syshash-table-ref");
lf[109]=C_h_intern(&lf[109],21,"\003sysalias-global-hook");
lf[110]=C_h_intern(&lf[110],12,"syntax-error");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[112]=C_h_intern(&lf[112],24,"\003syssyntax-error-culprit");
lf[113]=C_h_intern(&lf[113],2,"if");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],16,"\003syscheck-syntax");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_h_intern(&lf[118],10,"\004corecheck");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[120]=C_h_intern(&lf[120],14,"\004coreimmutable");
lf[121]=C_h_intern(&lf[121],10,"alist-cons");
lf[122]=C_h_intern(&lf[122],6,"gensym");
lf[123]=C_h_intern(&lf[123],1,"c");
lf[124]=C_h_intern(&lf[124],6,"cadadr");
lf[125]=C_h_intern(&lf[125],14,"\004coreundefined");
lf[126]=C_h_intern(&lf[126],23,"\004corerequire-for-syntax");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],10,"lset-union");
lf[129]=C_h_intern(&lf[129],3,"eq\077");
lf[130]=C_h_intern(&lf[130],22,"\003syshash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[237]=C_h_intern(&lf[237],29,"\010compilercollapsable-literal\077");
lf[238]=C_h_intern(&lf[238],4,"quit");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[240]=C_h_intern(&lf[240],22,"with-exception-handler");
lf[241]=C_h_intern(&lf[241],30,"call-with-current-continuation");
lf[242]=C_h_intern(&lf[242],12,"\004coredeclare");
lf[243]=C_h_intern(&lf[243],28,"\010compilerprocess-declaration");
lf[244]=C_h_intern(&lf[244],29,"\004coreforeign-callback-wrapper");
lf[245]=C_h_intern(&lf[245],8,"split-at");
lf[246]=C_h_intern(&lf[246],1,"r");
lf[247]=C_h_intern(&lf[247],17,"\003sysmake-c-string");
lf[248]=C_h_intern(&lf[248],3,"and");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[252]=C_h_intern(&lf[252],25,"nonnull-unsigned-c-string");
lf[253]=C_h_intern(&lf[253],16,"nonnull-c-string");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[256]=C_h_intern(&lf[256],18,"unsigned-c-string*");
lf[257]=C_h_intern(&lf[257],9,"c-string*");
lf[258]=C_h_intern(&lf[258],13,"c-string-list");
lf[259]=C_h_intern(&lf[259],14,"c-string-list*");
lf[260]=C_h_intern(&lf[260],8,"c-string");
lf[261]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[262]=C_h_intern(&lf[262],17,"unsigned-c-string");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[266]=C_h_intern(&lf[266],28,"\010compilervalid-c-identifier\077");
lf[267]=C_h_intern(&lf[267],8,"location");
lf[268]=C_h_intern(&lf[268],17,"\003sysmake-locative");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[270]=C_h_intern(&lf[270],13,"\004corecallunit");
lf[271]=C_h_intern(&lf[271],14,"\004coreprimitive");
lf[272]=C_h_intern(&lf[272],37,"\010compilerupdate-line-number-database!");
lf[273]=C_h_intern(&lf[273],23,"\003sysmacroexpand-1-local");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[276]=C_h_intern(&lf[276],31,"\010compileremit-syntax-trace-info");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[278]=C_h_intern(&lf[278],4,"list");
lf[279]=C_h_intern(&lf[279],1,"t");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[281]=C_h_intern(&lf[281],4,"caar");
lf[282]=C_h_intern(&lf[282],18,"\010compilerconstant\077");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[284]=C_h_intern(&lf[284],26,"\010compilerinternal-bindings");
lf[285]=C_h_intern(&lf[285],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[286]=C_h_intern(&lf[286],7,"reverse");
lf[287]=C_h_intern(&lf[287],22,"\003sysclear-trace-buffer");
lf[288]=C_h_intern(&lf[288],26,"\010compilerdebugging-chicken");
lf[289]=C_h_intern(&lf[289],12,"pretty-print");
lf[290]=C_h_intern(&lf[290],7,"newline");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],4,"uses");
lf[294]=C_h_intern(&lf[294],29,"\010compilerstring->c-identifier");
lf[295]=C_h_intern(&lf[295],18,"\010compilerstringify");
lf[296]=C_h_intern(&lf[296],17,"register-feature!");
lf[297]=C_h_intern(&lf[297],4,"unit");
lf[298]=C_h_intern(&lf[298],5,"usage");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[300]=C_h_intern(&lf[300],34,"\010compilerdefault-standard-bindings");
lf[301]=C_h_intern(&lf[301],34,"\010compilerdefault-extended-bindings");
lf[302]=C_h_intern(&lf[302],18,"usual-integrations");
lf[303]=C_h_intern(&lf[303],17,"lset-intersection");
lf[304]=C_h_intern(&lf[304],6,"fixnum");
lf[305]=C_h_intern(&lf[305],17,"fixnum-arithmetic");
lf[306]=C_h_intern(&lf[306],23,"\005matchset-error-control");
lf[307]=C_h_intern(&lf[307],12,"\000unspecified");
lf[308]=C_h_intern(&lf[308],4,"safe");
lf[309]=C_h_intern(&lf[309],18,"interrupts-enabled");
lf[310]=C_h_intern(&lf[310],18,"disable-interrupts");
lf[311]=C_h_intern(&lf[311],15,"disable-warning");
lf[312]=C_h_intern(&lf[312],26,"\010compilerdisabled-warnings");
lf[313]=C_h_intern(&lf[313],12,"safe-globals");
lf[314]=C_h_intern(&lf[314],38,"no-procedure-checks-for-usual-bindings");
lf[315]=C_h_intern(&lf[315],18,"bound-to-procedure");
lf[316]=C_h_intern(&lf[316],15,"foreign-declare");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[318]=C_h_intern(&lf[318],5,"every");
lf[319]=C_h_intern(&lf[319],7,"string\077");
lf[320]=C_h_intern(&lf[320],14,"custom-declare");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[322]=C_h_intern(&lf[322],35,"\010compilerprocess-custom-declaration");
lf[323]=C_h_intern(&lf[323],9,"c-options");
lf[324]=C_h_intern(&lf[324],31,"\010compileremit-control-file-item");
lf[325]=C_h_intern(&lf[325],12,"link-options");
lf[326]=C_h_intern(&lf[326],12,"post-process");
lf[327]=C_h_intern(&lf[327],17,"string-substitute");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[329]=C_h_intern(&lf[329],24,"pathname-strip-extension");
lf[330]=C_h_intern(&lf[330],5,"block");
lf[331]=C_h_intern(&lf[331],8,"separate");
lf[332]=C_h_intern(&lf[332],20,"keep-shadowed-macros");
lf[333]=C_h_intern(&lf[333],6,"unused");
lf[334]=C_h_intern(&lf[334],3,"not");
lf[335]=C_h_intern(&lf[335],15,"lset-difference");
lf[336]=C_h_intern(&lf[336],6,"inline");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[338]=C_h_intern(&lf[338],15,"run-time-macros");
lf[339]=C_h_intern(&lf[339],25,"\003sysenable-runtime-macros");
lf[340]=C_h_intern(&lf[340],12,"block-global");
lf[341]=C_h_intern(&lf[341],4,"hide");
lf[342]=C_h_intern(&lf[342],6,"export");
lf[343]=C_h_intern(&lf[343],12,"emit-exports");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[345]=C_h_intern(&lf[345],30,"emit-external-prototypes-first");
lf[346]=C_h_intern(&lf[346],11,"lambda-lift");
lf[347]=C_h_intern(&lf[347],12,"inline-limit");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[349]=C_h_intern(&lf[349],8,"constant");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[351]=C_h_intern(&lf[351],7,"symbol\077");
lf[352]=C_h_intern(&lf[352],6,"import");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[354]=C_h_intern(&lf[354],9,"partition");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[358]=C_h_intern(&lf[358],17,"make-foreign-stub");
lf[359]=C_h_intern(&lf[359],12,"foreign-stub");
lf[360]=C_h_intern(&lf[360],13,"foreign-stub\077");
lf[361]=C_h_intern(&lf[361],20,"foreign-stub-id-set!");
lf[362]=C_h_intern(&lf[362],14,"\003sysblock-set!");
lf[363]=C_h_intern(&lf[363],15,"foreign-stub-id");
lf[364]=C_h_intern(&lf[364],29,"foreign-stub-return-type-set!");
lf[365]=C_h_intern(&lf[365],24,"foreign-stub-return-type");
lf[366]=C_h_intern(&lf[366],22,"foreign-stub-name-set!");
lf[367]=C_h_intern(&lf[367],17,"foreign-stub-name");
lf[368]=C_h_intern(&lf[368],32,"foreign-stub-argument-types-set!");
lf[369]=C_h_intern(&lf[369],27,"foreign-stub-argument-types");
lf[370]=C_h_intern(&lf[370],32,"foreign-stub-argument-names-set!");
lf[371]=C_h_intern(&lf[371],27,"foreign-stub-argument-names");
lf[372]=C_h_intern(&lf[372],22,"foreign-stub-body-set!");
lf[373]=C_h_intern(&lf[373],17,"foreign-stub-body");
lf[374]=C_h_intern(&lf[374],21,"foreign-stub-cps-set!");
lf[375]=C_h_intern(&lf[375],16,"foreign-stub-cps");
lf[376]=C_h_intern(&lf[376],26,"foreign-stub-callback-set!");
lf[377]=C_h_intern(&lf[377],21,"foreign-stub-callback");
lf[378]=C_h_intern(&lf[378],28,"\010compilercreate-foreign-stub");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[382]=C_h_intern(&lf[382],37,"\010compilerestimate-foreign-result-size");
lf[383]=C_h_intern(&lf[383],4,"stub");
lf[384]=C_h_intern(&lf[384],1,"a");
lf[385]=C_h_intern(&lf[385],13,"list-tabulate");
lf[386]=C_h_intern(&lf[386],6,"second");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[389]=C_h_intern(&lf[389],4,"cadr");
lf[390]=C_h_intern(&lf[390],3,"car");
lf[391]=C_h_intern(&lf[391],4,"void");
lf[392]=C_h_intern(&lf[392],24,"\003sysline-number-database");
lf[393]=C_h_intern(&lf[393],31,"\010compilerperform-cps-conversion");
lf[394]=C_h_intern(&lf[394],4,"node");
lf[395]=C_h_intern(&lf[395],11,"\004corelambda");
lf[396]=C_h_intern(&lf[396],9,"\004corecall");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[398]=C_h_intern(&lf[398],16,"\010compilervarnode");
lf[399]=C_h_intern(&lf[399],1,"k");
lf[400]=C_h_intern(&lf[400],13,"\004corevariable");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[402]=C_h_intern(&lf[402],2,"f_");
lf[403]=C_h_intern(&lf[403],26,"make-foreign-callback-stub");
lf[404]=C_h_intern(&lf[404],13,"\010compilerbomb");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[406]=C_h_intern(&lf[406],15,"\004coreglobal-ref");
lf[407]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[408]=C_h_intern(&lf[408],6,"values");
lf[409]=C_h_intern(&lf[409],21,"foreign-callback-stub");
lf[410]=C_h_intern(&lf[410],22,"foreign-callback-stub\077");
lf[411]=C_h_intern(&lf[411],29,"foreign-callback-stub-id-set!");
lf[412]=C_h_intern(&lf[412],24,"foreign-callback-stub-id");
lf[413]=C_h_intern(&lf[413],31,"foreign-callback-stub-name-set!");
lf[414]=C_h_intern(&lf[414],26,"foreign-callback-stub-name");
lf[415]=C_h_intern(&lf[415],37,"foreign-callback-stub-qualifiers-set!");
lf[416]=C_h_intern(&lf[416],32,"foreign-callback-stub-qualifiers");
lf[417]=C_h_intern(&lf[417],38,"foreign-callback-stub-return-type-set!");
lf[418]=C_h_intern(&lf[418],33,"foreign-callback-stub-return-type");
lf[419]=C_h_intern(&lf[419],41,"foreign-callback-stub-argument-types-set!");
lf[420]=C_h_intern(&lf[420],36,"foreign-callback-stub-argument-types");
lf[421]=C_h_intern(&lf[421],27,"\010compileranalyze-expression");
lf[422]=C_h_intern(&lf[422],17,"\010compilercollect!");
lf[423]=C_h_intern(&lf[423],10,"references");
lf[424]=C_h_intern(&lf[424],13,"\010compilerput!");
lf[425]=C_h_intern(&lf[425],9,"undefined");
lf[426]=C_h_intern(&lf[426],7,"unknown");
lf[427]=C_h_intern(&lf[427],5,"value");
lf[428]=C_h_intern(&lf[428],12,"\010compilerget");
lf[429]=C_h_intern(&lf[429],4,"home");
lf[430]=C_h_intern(&lf[430],16,"\010compilerget-all");
lf[431]=C_h_intern(&lf[431],8,"captured");
lf[432]=C_h_intern(&lf[432],6,"global");
lf[433]=C_h_intern(&lf[433],12,"\004corerecurse");
lf[434]=C_h_intern(&lf[434],44,"\010compileroptimizable-rest-argument-operators");
lf[435]=C_h_intern(&lf[435],15,"\010compilercount!");
lf[436]=C_h_intern(&lf[436],16,"o-r/access-count");
lf[437]=C_h_intern(&lf[437],14,"rest-parameter");
lf[438]=C_h_intern(&lf[438],16,"standard-binding");
lf[439]=C_h_intern(&lf[439],10,"call-sites");
lf[440]=C_h_intern(&lf[440],18,"\004coredirect_lambda");
lf[441]=C_h_intern(&lf[441],6,"simple");
lf[442]=C_h_intern(&lf[442],28,"\010compilersimple-lambda-node\077");
lf[443]=C_h_intern(&lf[443],6,"vector");
lf[444]=C_h_intern(&lf[444],12,"contained-in");
lf[445]=C_h_intern(&lf[445],8,"contains");
lf[446]=C_h_intern(&lf[446],8,"assigned");
lf[447]=C_h_intern(&lf[447],16,"assigned-locally");
lf[448]=C_h_intern(&lf[448],15,"potential-value");
lf[449]=C_h_intern(&lf[449],5,"redef");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[452]=C_h_intern(&lf[452],16,"extended-binding");
lf[453]=C_h_intern(&lf[453],9,"\004coreproc");
lf[454]=C_h_intern(&lf[454],3,"any");
lf[455]=C_h_intern(&lf[455],9,"replacing");
lf[456]=C_h_intern(&lf[456],10,"replacable");
lf[457]=C_h_intern(&lf[457],9,"removable");
lf[458]=C_h_intern(&lf[458],37,"\010compilerexpression-has-side-effects\077");
lf[459]=C_h_intern(&lf[459],21,"has-unused-parameters");
lf[460]=C_h_intern(&lf[460],13,"explicit-rest");
lf[461]=C_h_intern(&lf[461],11,"collapsable");
lf[462]=C_h_intern(&lf[462],12,"contractable");
lf[463]=C_h_intern(&lf[463],9,"inlinable");
lf[464]=C_h_intern(&lf[464],28,"\010compilerscan-free-variables");
lf[465]=C_h_intern(&lf[465],5,"boxed");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[468]=C_h_intern(&lf[468],23,"\003syshash-table-for-each");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"p");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[473]=C_h_intern(&lf[473],37,"\010compilerinitialize-analysis-database");
lf[474]=C_h_intern(&lf[474],35,"\010compilerperform-closure-conversion");
lf[475]=C_h_intern(&lf[475],12,"customizable");
lf[476]=C_h_intern(&lf[476],20,"node-parameters-set!");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[478]=C_h_intern(&lf[478],28,"\010compilersource-info->string");
lf[479]=C_h_intern(&lf[479],8,"toplevel");
lf[480]=C_h_intern(&lf[480],18,"captured-variables");
lf[481]=C_h_intern(&lf[481],12,"closure-size");
lf[482]=C_h_intern(&lf[482],8,"\004coreref");
lf[483]=C_h_intern(&lf[483],10,"\004coreunbox");
lf[484]=C_h_intern(&lf[484],8,"\004corebox");
lf[485]=C_h_intern(&lf[485],12,"\004coreclosure");
lf[486]=C_h_intern(&lf[486],14,"\010compilerqnode");
lf[487]=C_h_intern(&lf[487],20,"\003sysmake-lambda-info");
lf[488]=C_h_intern(&lf[488],1,"\077");
lf[489]=C_h_intern(&lf[489],8,"->string");
lf[490]=C_h_intern(&lf[490],18,"\010compilerreal-name");
lf[491]=C_h_intern(&lf[491],10,"fold-right");
lf[492]=C_h_intern(&lf[492],10,"boxed-rest");
lf[493]=C_h_intern(&lf[493],6,"filter");
lf[494]=C_h_intern(&lf[494],16,"\004coreupdatebox_i");
lf[495]=C_h_intern(&lf[495],14,"\004coreupdatebox");
lf[496]=C_h_intern(&lf[496],13,"\004coreupdate_i");
lf[497]=C_h_intern(&lf[497],11,"\004coreupdate");
lf[498]=C_h_intern(&lf[498],19,"\010compilerimmediate\077");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[500]=C_h_intern(&lf[500],11,"\004coreswitch");
lf[501]=C_h_intern(&lf[501],9,"\004corecond");
lf[502]=C_h_intern(&lf[502],16,"\004coredirect_call");
lf[503]=C_h_intern(&lf[503],11,"\004corereturn");
lf[504]=C_h_intern(&lf[504],1,"o");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[506]=C_h_intern(&lf[506],16,"\003sysmake-promise");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[510]=C_h_intern(&lf[510],19,"make-lambda-literal");
lf[511]=C_h_intern(&lf[511],14,"lambda-literal");
lf[512]=C_h_intern(&lf[512],15,"lambda-literal\077");
lf[513]=C_h_intern(&lf[513],22,"lambda-literal-id-set!");
lf[514]=C_h_intern(&lf[514],17,"lambda-literal-id");
lf[515]=C_h_intern(&lf[515],28,"lambda-literal-external-set!");
lf[516]=C_h_intern(&lf[516],23,"lambda-literal-external");
lf[517]=C_h_intern(&lf[517],29,"lambda-literal-arguments-set!");
lf[518]=C_h_intern(&lf[518],24,"lambda-literal-arguments");
lf[519]=C_h_intern(&lf[519],34,"lambda-literal-argument-count-set!");
lf[520]=C_h_intern(&lf[520],29,"lambda-literal-argument-count");
lf[521]=C_h_intern(&lf[521],33,"lambda-literal-rest-argument-set!");
lf[522]=C_h_intern(&lf[522],28,"lambda-literal-rest-argument");
lf[523]=C_h_intern(&lf[523],31,"lambda-literal-temporaries-set!");
lf[524]=C_h_intern(&lf[524],26,"lambda-literal-temporaries");
lf[525]=C_h_intern(&lf[525],37,"lambda-literal-callee-signatures-set!");
lf[526]=C_h_intern(&lf[526],32,"lambda-literal-callee-signatures");
lf[527]=C_h_intern(&lf[527],29,"lambda-literal-allocated-set!");
lf[528]=C_h_intern(&lf[528],24,"lambda-literal-allocated");
lf[529]=C_h_intern(&lf[529],35,"lambda-literal-directly-called-set!");
lf[530]=C_h_intern(&lf[530],30,"lambda-literal-directly-called");
lf[531]=C_h_intern(&lf[531],32,"lambda-literal-closure-size-set!");
lf[532]=C_h_intern(&lf[532],27,"lambda-literal-closure-size");
lf[533]=C_h_intern(&lf[533],27,"lambda-literal-looping-set!");
lf[534]=C_h_intern(&lf[534],22,"lambda-literal-looping");
lf[535]=C_h_intern(&lf[535],32,"lambda-literal-customizable-set!");
lf[536]=C_h_intern(&lf[536],27,"lambda-literal-customizable");
lf[537]=C_h_intern(&lf[537],38,"lambda-literal-rest-argument-mode-set!");
lf[538]=C_h_intern(&lf[538],33,"lambda-literal-rest-argument-mode");
lf[539]=C_h_intern(&lf[539],24,"lambda-literal-body-set!");
lf[540]=C_h_intern(&lf[540],19,"lambda-literal-body");
lf[541]=C_h_intern(&lf[541],26,"lambda-literal-direct-set!");
lf[542]=C_h_intern(&lf[542],21,"lambda-literal-direct");
lf[543]=C_h_intern(&lf[543],36,"\010compilerprepare-for-code-generation");
lf[544]=C_h_intern(&lf[544],14,"\004coreimmediate");
lf[545]=C_h_intern(&lf[545],3,"fix");
lf[546]=C_h_intern(&lf[546],4,"bool");
lf[547]=C_h_intern(&lf[547],4,"char");
lf[548]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[549]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[551]=C_h_intern(&lf[551],36,"\010compilermake-block-variable-literal");
lf[552]=C_h_intern(&lf[552],36,"\010compilerblock-variable-literal-name");
lf[553]=C_h_intern(&lf[553],32,"\010compilerblock-variable-literal\077");
lf[554]=C_h_intern(&lf[554],10,"list-index");
lf[555]=C_h_intern(&lf[555],11,"\004coreglobal");
lf[556]=C_h_intern(&lf[556],10,"\004corelocal");
lf[557]=C_h_intern(&lf[557],12,"\004coreliteral");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[560]=C_h_intern(&lf[560],4,"none");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[563]=C_h_intern(&lf[563],7,"butlast");
lf[564]=C_h_intern(&lf[564],9,"\004corebind");
lf[565]=C_h_intern(&lf[565],13,"\004coresetlocal");
lf[566]=C_h_intern(&lf[566],16,"\004coresetglobal_i");
lf[567]=C_h_intern(&lf[567],14,"\004coresetglobal");
lf[568]=C_h_intern(&lf[568],1,"=");
lf[569]=C_h_intern(&lf[569],4,"type");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[572]=C_h_intern(&lf[572],20,"\010compilerbig-fixnum\077");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[577]=C_h_intern(&lf[577],14,"make-parameter");
C_register_lf2(lf,578,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1769 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1772 in k1769 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1775 in k1772 in k1769 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 311  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 312  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 313  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 314  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 315  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 316  make-parameter */
t4=C_retrieve(lf[577]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_set_block_item(lf[93],0,C_SCHEME_FALSE);
t87=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1899,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1970,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4749,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5694,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5700,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5706,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5715,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5724,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5733,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5742,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5751,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5760,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5769,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5778,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5787,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5796,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5805,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5814,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5823,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5832,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5841,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5850,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6004,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6049,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6094,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6131,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6168,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6249,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[393]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6339,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7014,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[410]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7020,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7026,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7035,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[413]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7044,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7053,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7062,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7071,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7080,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7089,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7098,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7107,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7116,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[474]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8641,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9875,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[512]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9881,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[513]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9887,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9896,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[515]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9905,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9914,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9923,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9932,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9941,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9950,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9959,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9968,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9977,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9986,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9995,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10004,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10013,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10022,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10031,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10040,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10049,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10058,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10067,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10076,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10085,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10094,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10103,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10112,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10121,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10130,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10139,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10148,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10157,tmp=(C_word)a,a+=2,tmp));
t163=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t163+1)))(2,t163,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10157,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11152,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11106,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11120,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11026,a[2]=t7,a[3]=t5,a[4]=t25,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10194,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10160,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10247,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11014,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11214,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2314 debugging */
t37=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[470],lf[576]);}

/* k11212 in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2315 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10247(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11215 in k11212 in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2316 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[575],((C_word*)((C_word*)t0)[2])[1]);}

/* k11218 in k11215 in k11212 in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2317 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[574],((C_word*)((C_word*)t0)[2])[1]);}

/* k11221 in k11218 in k11215 in k11212 in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2318 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[573],((C_word*)((C_word*)t0)[2])[1]);}

/* k11224 in k11221 in k11218 in k11215 in k11212 in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2319 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_11014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11014,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11020,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a11019 in mapwalk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11020,3,t0,t1,t2);}
/* compiler.scm: 2272 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10247(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10247,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[125]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[453]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[400]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2106 walk-var */
t16=((C_word*)t0)[16];
f_10160(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[406]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2109 walk-global */
t17=((C_word*)t0)[15];
f_10194(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[502]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10305,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2113 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_11014(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10325,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2117 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_11014(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10349,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10353,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2120 estimate-foreign-result-size */
t22=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10377,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10381,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2124 estimate-foreign-result-size */
t23=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[485]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10398,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2129 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11014(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[484]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10425,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2133 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[495]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10441,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2137 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_11014(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[395]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[440]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[440]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10497,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2157 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[484],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10681,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2214 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10722,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2220 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[396]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10842,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2244 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[568]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[433]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10885,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10885(t32,t31);}
else{
t30=t29;
f_10885(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10913,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11000,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2255 big-fixnum? */
t33=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10913(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11003,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2269 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_11014(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k11001 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10998 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10913(t2,(C_word)C_i_not(t1));}

/* k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10913,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2256 immediate-literal */
f_11152(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[304],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10961,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2259 big-fixnum? */
t5=C_retrieve(lf[572]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10934(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10971,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 literal */
t4=((C_word*)t0)[2];
f_11026(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2266 immediate? */
t3=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10975 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10977,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2266 immediate-literal */
f_11152(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10990,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2267 literal */
t3=((C_word*)t0)[2];
f_11026(t3,t2,((C_word*)t0)[3]);}}

/* k10988 in k10975 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10990,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10969 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10971,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* k10959 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10934(t2,(C_word)C_i_not(t1));}

/* k10932 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2260 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[569],lf[570],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2264 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[571],((C_word*)t0)[4]);}}

/* k10935 in k10932 in k10911 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2263 immediate-literal */
f_11152(((C_word*)t0)[2],t2);}

/* k10883 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10885,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10888,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2251 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11014(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10886 in k10883 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10888,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10840 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10842,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10854,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10854(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10854(t6,C_SCHEME_FALSE);}}

/* k10852 in k10840 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10845(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10845(t2,C_SCHEME_UNDEFINED);}}

/* k10843 in k10840 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10848,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2247 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11014(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10846 in k10843 in k10840 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10848,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10722,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10738,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2222 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10247(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10811,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10811(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10811(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10811(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10823,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2228 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[438]);}}}}}

/* k10821 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10811(2,t2,t1);}
else{
/* compiler.scm: 2229 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10809 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10811,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[102]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2231 immediate? */
t8=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10750(2,t6,C_SCHEME_FALSE);}}

/* k10748 in k10809 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10750,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10756(t6,t5);}
else{
t4=t3;
f_10756(t4,C_SCHEME_UNDEFINED);}}

/* k10754 in k10748 in k10809 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10756,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[566]:lf[567]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10780,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2237 blockvar-literal */
t4=((C_word*)t0)[4];
f_11120(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2238 literal */
t4=((C_word*)t0)[2];
f_11026(t4,t3,((C_word*)t0)[3]);}}

/* k10778 in k10754 in k10748 in k10809 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10780,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10772,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2240 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10247(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10770 in k10778 in k10754 in k10748 in k10809 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10772,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10736 in k10720 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10738,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[565],((C_word*)t0)[2],t2));}

/* k10679 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2215 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10691 in k10679 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2215 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10695 in k10691 in k10679 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2215 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10247(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10683 in k10679 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[564],((C_word*)t0)[2],t2));}

/* a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10497,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10618,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2163 get */
t8=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[423]);}
else{
t7=t6;
f_10504(2,t7,C_SCHEME_FALSE);}}

/* k10616 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2164 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}

/* k10622 in k10616 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10504(2,t2,lf[278]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10649,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2165 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[492]);}}

/* k10647 in k10622 in k10616 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10630(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10630(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10628 in k10622 in k10616 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10504(2,t2,lf[560]);}
else{
/* compiler.scm: 2166 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437]);}}

/* k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10507,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10609,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[560],t1);
if(C_truep(t5)){
/* compiler.scm: 2170 butlast */
t6=C_retrieve(lf[563]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10609(2,t6,((C_word*)t0)[7]);}}

/* k10607 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2167 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10247(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10510,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[560]);
if(C_truep(t3)){
/* compiler.scm: 2175 debugging */
t4=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[504],lf[561],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[443]);
if(C_truep(t4)){
/* compiler.scm: 2176 debugging */
t5=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[504],lf[562],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10510(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2178 bomb */
t4=C_retrieve(lf[404]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[559],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10513(2,t4,C_SCHEME_UNDEFINED);}}

/* k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10535,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10551,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2190 get */
t7=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[481]);}

/* k10549 in k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10551,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10558(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10577,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2194 debugging */
t7=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[504],lf[558],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10558(t6,C_SCHEME_FALSE);}}}

/* k10575 in k10549 in k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10558(t2,C_SCHEME_TRUE);}

/* k10556 in k10549 in k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10562(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2196 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[475]);}}

/* k10560 in k10556 in k10549 in k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2180 make-lambda-literal */
t2=C_retrieve(lf[510]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10533 in k10511 in k10508 in k10505 in k10502 in a10496 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10535,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[394],lf[453],t9,C_SCHEME_END_OF_LIST));}

/* k10439 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10444,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10450,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10450(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10450(t6,C_SCHEME_FALSE);}}

/* k10448 in k10439 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10444(t4,lf[494]);}
else{
t2=((C_word*)t0)[3];
f_10444(t2,((C_word*)t0)[2]);}}

/* k10442 in k10439 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10444,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10423 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10425,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],((C_word*)t0)[2],t2));}

/* k10396 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10398,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t1));}

/* k10379 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2124 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10375 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10377,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10370,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2125 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11014(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10368 in k10375 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10370,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10351 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2120 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10347 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10349,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10323 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10325,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10303 in walk in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10305,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10160,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10164,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2074 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10162 in walk-var in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10164,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[556],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2075 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10177 in k10162 in walk-var in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10189,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2075 literal */
t3=((C_word*)t0)[5];
f_11026(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2076 walk-global */
t2=((C_word*)t0)[3];
f_10194(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10187 in k10177 in k10162 in walk-var in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10189,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[557],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10194,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10198(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10198(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10198(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10198(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10239,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2083 get */
t9=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[438]);}}}}}

/* k10237 in walk-global in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10198(2,t2,t1);}
else{
/* compiler.scm: 2084 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[452]);}}

/* k10196 in walk-global in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10198,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10204(t6,t5);}
else{
t4=t3;
f_10204(t4,C_SCHEME_UNDEFINED);}}

/* k10202 in k10196 in walk-global in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_10204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10204,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2090 blockvar-literal */
t3=((C_word*)t0)[3];
f_11120(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2091 literal */
t3=((C_word*)t0)[2];
f_11026(t3,t2,((C_word*)t0)[5]);}}

/* k10212 in k10202 in k10196 in walk-global in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10214,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[555],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_11026(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11026,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2275 immediate? */
t4=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11031 in literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11033,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2275 immediate-literal */
f_11152(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11045,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11059,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2278 list-index */
t4=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_11045(2,t3,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11085,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2284 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11095,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2286 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}}}}

/* k11093 in k11031 in literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2287 new-literal */
t2=((C_word*)t0)[3];
f_11106(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k11083 in k11031 in literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11085,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* a11058 in k11031 in literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11059,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k11043 in k11031 in literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2280 new-literal */
t2=((C_word*)t0)[3];
f_11106(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_11120(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11120,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11124,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11136,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2295 list-index */
t5=C_retrieve(lf[554]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11135 in blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11143,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2297 block-variable-literal? */
t4=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11141 in a11135 in blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11143,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2298 block-variable-literal-name */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11148 in k11141 in a11135 in blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11122 in blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11124,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11134,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2300 make-block-variable-literal */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11132 in k11122 in blockvar-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2300 new-literal */
t2=((C_word*)t0)[3];
f_11106(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_11106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11106,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11114,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2291 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11112 in new-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_11152(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11152,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[125],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11165(2,t6,(C_word)C_a_i_list(&a,2,lf[545],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11165(2,t6,(C_word)C_a_i_list(&a,2,lf[546],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11165(2,t6,(C_word)C_a_i_list(&a,2,lf[547],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11165(2,t6,lf[548]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11165(2,t6,lf[549]);}
else{
/* compiler.scm: 2311 bomb */
t6=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[550]);}}}}}}}

/* k11163 in immediate-literal in ##compiler#prepare-for-code-generation in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11165,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[544],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10148,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10139,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10130,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10121,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10112,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10103,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10094,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10085,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10076,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10067,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10058,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10049,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10040,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10031,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10022,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10013,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10004,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9995,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9986,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9977,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9968,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9959,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9950,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9941,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9932,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9923,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9914,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9905,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9896,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[511]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9887,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[511]);
/* compiler.scm: 2044 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9881,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[511]));}

/* make-lambda-literal in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9875,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[511],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8641,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8644,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8650,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8660,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8671,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9706,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9005,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9694,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9842,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2032 debugging */
t22=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[470],lf[509]);}

/* k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2033 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8671(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2034 debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[504],lf[508],((C_word*)((C_word*)t0)[2])[1]);}

/* k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2035 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[507]);}

/* k9849 in k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9854,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2036 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9005(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9852 in k9849 in k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9857,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9857(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9867,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9869,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2038 ##sys#make-promise */
t6=*((C_word*)lf[506]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9868 in k9852 in k9849 in k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9869,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9865 in k9852 in k9849 in k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2038 debugging */
t2=C_retrieve(lf[469]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[504],lf[505],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9855 in k9852 in k9849 in k9846 in k9843 in k9840 in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9694(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9694,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9700,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9699 in maptransform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9700,3,t0,t1,t2);}
/* compiler.scm: 2004 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9005(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9005,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_9024(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t13)){
t14=t12;
f_9024(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[453]);
t15=t12;
f_9024(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[406])));}}}

/* k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9024,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9036,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1879 ref-var */
f_9706(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[113]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_9057(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[396]);
if(C_truep(t5)){
t6=t4;
f_9057(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_9057(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_9057(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[270]);
if(C_truep(t8)){
t9=t4;
f_9057(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[103]);
if(C_truep(t9)){
t10=t4;
f_9057(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_9057(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[500]);
if(C_truep(t11)){
t12=t4;
f_9057(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[501]);
if(C_truep(t12)){
t13=t4;
f_9057(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[502]);
if(C_truep(t13)){
t14=t4;
f_9057(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[433]);
if(C_truep(t14)){
t15=t4;
f_9057(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[503]);
if(C_truep(t15)){
t16=t4;
f_9057(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[107]);
t17=t4;
f_9057(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9057,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1887 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9694(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1891 test */
t5=((C_word*)t0)[4];
f_8644(t5,t4,t3,lf[465]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[395]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[440]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9153,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1907 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9424,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[102],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1967 immediate? */
t13=C_retrieve(lf[498]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9424(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[394],lf[453],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9573,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9580,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9584,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1998 ##sys#make-lambda-info */
t16=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9573(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 2001 bomb */
t7=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[499]);}}}}}}

/* k9582 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1998 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9578 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9580,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9573(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9571 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9573,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9424,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[125],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1969 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9430,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1971 test */
t3=((C_word*)t0)[3];
f_8644(t3,t2,((C_word*)t0)[2],lf[465]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1983 test */
t3=((C_word*)t0)[3];
f_8644(t3,t2,((C_word*)t0)[2],lf[465]);}}

/* k9498 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9500,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1987 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9530,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1991 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_9005(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9528 in k9498 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[175],((C_word*)t0)[2],t2));}

/* k9511 in k9498 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9517,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1988 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9005(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9515 in k9511 in k9498 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9517,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9437 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9439,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[494]:lf[495]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1975 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[496]:lf[497]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9484 in k9437 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9490,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1982 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9005(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9488 in k9484 in k9437 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9490,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9464 in k9437 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1976 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9005(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9460 in k9464 in k9437 in k9428 in k9422 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9462,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9153,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1910 filter */
t7=C_retrieve(lf[493]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9401 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9402,3,t0,t1,t2);}
/* compiler.scm: 1910 test */
t3=((C_word*)t0)[2];
f_8644(t3,t1,t2,lf[465]);}

/* k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9400,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[122]),t1);}

/* k9398 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1911 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1912 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[123]);}

/* k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[479]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1914 test */
t4=((C_word*)t0)[2];
f_8644(t4,t3,t2,lf[480]);}

/* k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1915 test */
t4=((C_word*)t0)[2];
f_8644(t4,t3,((C_word*)t0)[17],lf[481]);}

/* k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9175,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9181(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9181(t4,C_SCHEME_FALSE);}}

/* k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9181,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9184,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1921 test */
t4=((C_word*)t0)[2];
f_8644(t4,t3,((C_word*)t0)[6],lf[465]);}
else{
t3=t2;
f_9184(2,t3,C_SCHEME_FALSE);}}

/* k9365 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9367,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1922 test */
t3=((C_word*)t0)[2];
f_8644(t3,t2,((C_word*)t0)[6],lf[437]);}
else{
t2=((C_word*)t0)[4];
f_9184(2,t2,C_SCHEME_FALSE);}}

/* k9368 in k9365 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1923 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[492],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9184(2,t2,C_SCHEME_FALSE);}}

/* k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9184,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9328,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9343,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9342 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9343,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9326 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1933 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1942 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9005(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9269,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9283,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1947 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9261(2,t3,t1);}}

/* k9281 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9287,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9289,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9288 in k9281 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1948 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9298 in a9288 in k9281 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9300,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2));}

/* k9285 in k9281 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1944 fold-right */
t2=C_retrieve(lf[491]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9268 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9269,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[394],lf[152],t5,t6));}

/* k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9261,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9245 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9246,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1951 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9252 in a9245 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1951 ref-var */
f_9706(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9221,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9225,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9229,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9237,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1959 real-name */
t7=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9210(2,t3,t1);}}

/* k9235 in k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9237,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[488]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1959 ->string */
t5=C_retrieve(lf[489]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9227 in k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1958 ##sys#make-lambda-info */
t2=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9223 in k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1957 qnode */
t2=C_retrieve(lf[486]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9219 in k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9221,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1954 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9208 in k9205 in k9259 in k9256 in k9322 in k9182 in k9179 in k9173 in k9167 in k9161 in k9158 in k9155 in a9152 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[485],((C_word*)t0)[2],t2));}

/* k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1892 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9079 in k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9081,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9097,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1896 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_9005(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1903 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9694(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9131 in k9079 in k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9133,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t1));}

/* k9095 in k9079 in k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9097,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1899 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9124 in k9095 in k9079 in k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9126,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[484],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1900 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9005(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9116 in k9124 in k9095 in k9079 in k9076 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9118,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k9061 in k9055 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9034 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9042,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1880 test */
t3=((C_word*)t0)[3];
f_8644(t3,t2,((C_word*)t0)[2],lf[465]);}

/* k9040 in k9034 in k9022 in transform in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9042,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[483],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9706(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9706,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9713,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2008 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9711 in ref-var in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9713,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9729,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2011 varnode */
t5=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9727 in k9711 in ref-var in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9729,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[482],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8671(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8671,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[102]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8690(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[400]);
if(C_truep(t13)){
t14=t12;
f_8690(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[125]);
if(C_truep(t14)){
t15=t12;
f_8690(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[453]);
if(C_truep(t15)){
t16=t12;
f_8690(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[271]);
t17=t12;
f_8690(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[406])));}}}}}

/* k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8690,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8701,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1816 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[396]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[400],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8753,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8780,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8894,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1832 test */
t19=((C_word*)t0)[3];
f_8644(t19,t18,t16,lf[426]);}
else{
t15=t14;
f_8780(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8770(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[395]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[440]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1856 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8968 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8969,3,t0,t1,t2);}
/* compiler.scm: 1866 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8671(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8930,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[479]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9745,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9745(3,t14,t10,t6);}

/* walk in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9745,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[400]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9774,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2023 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[102]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9783(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[125]);
if(C_truep(t12)){
t13=t11;
f_9783(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[271]);
if(C_truep(t13)){
t14=t11;
f_9783(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[453]);
if(C_truep(t14)){
t15=t11;
f_9783(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[103]);
t16=t11;
f_9783(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[406])));}}}}}}

/* k9781 in walk in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9783,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9795,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9809,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2027 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9795(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9807 in k9781 in walk in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9795(t3,t2);}

/* k9793 in k9781 in walk in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_9795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2028 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9745(3,t3,((C_word*)t0)[2],t2);}

/* k9772 in walk in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9741 in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_9743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9743,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8943,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1862 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[481],t3);}

/* k8941 in k9741 in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8946,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1863 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[480],((C_word*)t0)[2]);}

/* k8944 in k8941 in k9741 in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8946,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1864 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8955 in k8944 in k8941 in k9741 in a8929 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1864 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8671(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8892 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8786(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1832 test */
t2=((C_word*)t0)[3];
f_8644(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[427]);}}

/* k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8792(t4,(C_word)C_eqp(lf[395],t3));}
else{
t3=t2;
f_8792(t3,C_SCHEME_FALSE);}}

/* k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8792,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1837 test */
t6=((C_word*)t0)[2];
f_8644(t6,t5,((C_word*)t0)[6],lf[423]);}
else{
t2=((C_word*)t0)[8];
f_8780(t2,C_SCHEME_END_OF_LIST);}}

/* k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1838 test */
t3=((C_word*)t0)[2];
f_8644(t3,t2,((C_word*)t0)[7],lf[439]);}

/* k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8810(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8810(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8810(t3,C_SCHEME_FALSE);}}

/* k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8810,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8828,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8828(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8828(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8828(t4,C_SCHEME_FALSE);}}

/* k8826 in k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8828,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1846 source-info->string */
t3=C_retrieve(lf[478]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8813(2,t2,C_SCHEME_UNDEFINED);}}

/* k8833 in k8826 in k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1844 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[477],t1);}

/* k8811 in k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1847 register-direct-call! */
t3=((C_word*)t0)[2];
f_8660(t3,t2,((C_word*)t0)[6]);}

/* k8814 in k8811 in k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8819,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1848 register-customizable! */
t3=((C_word*)t0)[3];
f_8650(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8819(2,t3,C_SCHEME_UNDEFINED);}}

/* k8817 in k8814 in k8811 in k8808 in k8805 in k8802 in k8790 in k8784 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8819,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8780(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8778 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8780,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8770(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8768 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8770,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1825 node-parameters-set! */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8751 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8758,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8757 in k8751 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8758,3,t0,t1,t2);}
/* compiler.scm: 1853 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8671(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8710 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8711,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8727 in a8710 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8728,3,t0,t1,t2);}
/* compiler.scm: 1817 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8671(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8713 in a8710 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8715,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8726,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1818 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8724 in k8713 in a8710 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1818 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8671(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8700 in k8688 in gather in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8701,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1816 split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8660,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1803 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[129]+1),C_retrieve(lf[63]),t2);}

/* k8667 in register-direct-call! in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8650(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8650,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8655,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1798 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8653 in register-customizable! in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1799 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[475],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8644(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8644,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1795 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7116,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7120,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1416 make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7122,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7825,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7129,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7710,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7831,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7845,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7870,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1586 initialize-analysis-database */
t18=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1589 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[472]);}

/* k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7873,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1591 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7129(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1594 debugging */
t3=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[470],lf[471]);}

/* k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1595 ##sys#hash-table-for-each */
t4=C_retrieve(lf[468]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7893,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7897,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8528,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8527 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8528,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[426]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[423]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[448]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[439]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[446]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[447]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[425]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[432]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[437]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7897,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8493(t10,(C_word)C_eqp(lf[395],t9));}
else{
t7=t6;
f_8493(t7,C_SCHEME_FALSE);}}

/* k8491 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1641 set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7904(2,t2,C_SCHEME_UNDEFINED);}}

/* k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8439(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8439(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8439(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8439(t4,C_SCHEME_FALSE);}}

/* k8437 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8439,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1650 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[467],((C_word*)t0)[3]);}
else{
t3=t2;
f_8442(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7907(2,t2,C_SCHEME_UNDEFINED);}}

/* k8440 in k8437 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8454,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8454(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8454(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8454(t5,C_SCHEME_FALSE);}}}

/* k8452 in k8440 in k8437 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8448(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8448(t2,C_SCHEME_FALSE);}}

/* k8446 in k8440 in k8437 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1654 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[466],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7907(2,t2,C_SCHEME_UNDEFINED);}}

/* k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1658 quick-put! */
f_7831(t2,((C_word*)t0)[8],lf[465],C_SCHEME_TRUE);}
else{
t4=t2;
f_7910(2,t4,C_SCHEME_UNDEFINED);}}

/* k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8382(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8414,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8422,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1667 scan-free-variables */
t13=C_retrieve(lf[464]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8382(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7913(2,t3,C_SCHEME_UNDEFINED);}}

/* k8420 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1667 every */
t2=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8413 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8414,3,t0,t1,t2);}
/* compiler.scm: 1667 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[432]);}

/* k8380 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8382,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8388,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8388(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8388(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7913(2,t2,C_SCHEME_UNDEFINED);}}

/* k8386 in k8380 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1669 quick-put! */
f_7831(((C_word*)t0)[3],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1670 quick-put! */
f_7831(((C_word*)t0)[3],((C_word*)t0)[2],lf[463],C_SCHEME_TRUE);}}

/* k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8344,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8344(t6,(C_word)C_eqp(lf[102],t5));}
else{
t4=t3;
f_8344(t4,C_SCHEME_FALSE);}}

/* k8342 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8344,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1678 collapsable-literal? */
t6=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7916(2,t2,C_SCHEME_UNDEFINED);}}

/* k8351 in k8342 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8356(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8356(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8354 in k8351 in k8342 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1680 quick-put! */
f_7831(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7916(2,t2,C_SCHEME_UNDEFINED);}}

/* k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8245,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[395],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8245(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8245(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7919(2,t3,C_SCHEME_UNDEFINED);}}

/* k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1694 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7919(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7919(2,t2,C_SCHEME_UNDEFINED);}}

/* a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8263,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8267(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8305 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8306,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8313,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8331,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1700 get */
t5=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[423]);}

/* k8329 in a8305 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8331,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8313(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1701 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}

/* k8325 in k8329 in a8305 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8313(t2,(C_word)C_i_not(t1));}

/* k8311 in a8305 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1702 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[333],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8314 in k8311 in a8305 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8265 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8273(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8273(t3,C_SCHEME_FALSE);}}

/* k8271 in k8265 in a8262 in k8243 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1708 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[459],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1711 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[460],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8182(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[400],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8209(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8223,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1719 get */
t15=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[432]);}}
else{
t6=t5;
f_8197(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8182(t5,C_SCHEME_FALSE);}}}

/* k8221 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8209(t2,(C_word)C_i_not(t1));}

/* k8207 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8209,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1720 expression-has-side-effects? */
t3=C_retrieve(lf[458]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8197(t2,C_SCHEME_FALSE);}}

/* k8214 in k8207 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8197(t2,(C_word)C_i_not(t1));}

/* k8195 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8182(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8180 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1722 quick-put! */
f_7831(((C_word*)t0)[3],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7922(2,t2,C_SCHEME_UNDEFINED);}}

/* k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[400],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8094,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1734 get */
t11=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[423]);}
else{
t7=t2;
f_7925(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7925(2,t4,C_SCHEME_UNDEFINED);}}

/* k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8168,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1735 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[426]);}

/* k8166 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8100(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1735 get */
t2=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[427]);}}

/* k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8103,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8103(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8158,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1736 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[431]);}}

/* k8156 in k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8158,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8103(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8103(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1740 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[446]);}}
else{
t4=((C_word*)t0)[6];
f_8103(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8103(t2,C_SCHEME_FALSE);}}}

/* k8148 in k8156 in k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8150,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8103(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8103(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8146,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1741 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[432]);}}}

/* k8144 in k8148 in k8156 in k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8103(t2,(C_word)C_i_not(t1));}

/* k8101 in k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_8103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8103,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1742 quick-put! */
f_7831(t2,((C_word*)t0)[2],lf[456],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7925(2,t2,C_SCHEME_UNDEFINED);}}

/* k8104 in k8101 in k8098 in k8092 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1743 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7928,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7953(t6,(C_word)C_eqp(lf[395],t5));}
else{
t4=t3;
f_7953(t4,C_SCHEME_FALSE);}}

/* k7951 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7953,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7928(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7974,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7974(t11,(C_word)C_eqp(lf[396],t10));}
else{
t10=t8;
f_7974(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7974(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7928(2,t2,C_SCHEME_UNDEFINED);}}

/* k7972 in k7951 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7974,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[400],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7995(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7995(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7995(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7928(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7928(2,t2,C_SCHEME_UNDEFINED);}}

/* k7993 in k7972 in k7951 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7995,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8001,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1763 quick-put! */
f_7831(t4,((C_word*)t0)[2],lf[456],t3);}
else{
t2=((C_word*)t0)[5];
f_7928(2,t2,C_SCHEME_UNDEFINED);}}

/* k7999 in k7993 in k7972 in k7951 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1764 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[455],C_SCHEME_TRUE);}

/* k7926 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7934(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7934(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7934(t3,C_SCHEME_FALSE);}}

/* k7932 in k7926 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1774 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7936 in k7932 in k7926 in k7923 in k7920 in k7917 in k7914 in k7911 in k7908 in k7905 in k7902 in k7895 in a7892 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1775 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[437],lf[443]);}

/* k7881 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1781 lset-difference */
t3=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7885 in k7881 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7890(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7890(t5,t4);}}

/* k7888 in k7885 in k7881 in k7878 in k7875 in k7871 in k7868 in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7845,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7855,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1581 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[445]);}}

/* k7853 in contains? in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7855,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1583 any */
t3=C_retrieve(lf[454]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7862 in k7853 in contains? in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7863,3,t0,t1,t2);}
/* compiler.scm: 1583 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7845(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7831(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7831,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7839,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1576 alist-cons */
t7=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7837 in quick-put! in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7710,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7716,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7715 in walkeach in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7716,3,t0,t1,t2);}
/* compiler.scm: 1550 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7129(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7129(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7129,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7122(C_fix(1));
t13=(C_word)C_eqp(t11,lf[102]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7151(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
t16=t14;
f_7151(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[453])));}}

/* k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7163,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1432 ref */
t5=((C_word*)t0)[8];
f_7825(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[406]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7206,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1440 ref */
t6=((C_word*)t0)[8];
f_7825(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[270]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[433]));
if(C_truep(t5)){
t6=f_7122(C_fix(1));
/* compiler.scm: 1446 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7710(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[396]);
if(C_truep(t6)){
t7=f_7122(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[400],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7265,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1453 collect! */
t16=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[439],t15);}
else{
t12=t9;
f_7242(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7337,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1467 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7122(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1480 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[395]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[440]));
if(C_truep(t10)){
t11=f_7122(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1493 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7633,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1524 get */
t17=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[438]);}
else{
t15=t14;
f_7558(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[271]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7666,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7672,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1543 ##sys#hash-table-ref */
t17=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7672(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7672(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7672(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1547 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7710(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7670 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1544 set-real-name! */
t2=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7666(2,t2,C_SCHEME_UNDEFINED);}}

/* k7664 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1545 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7710(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7637 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1525 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[449],lf[450],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1526 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[452]);}}

/* k7646 in k7637 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1527 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[449],lf[451],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7633(2,t2,C_SCHEME_UNDEFINED);}}

/* k7631 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1528 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[448],((C_word*)t0)[2]);}

/* k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7587(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7587(t5,(C_word)C_i_not(t4));}}

/* k7585 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7587,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7122(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7602(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7602(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7602(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7593(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7561(2,t2,C_SCHEME_UNDEFINED);}}

/* k7600 in k7585 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7602,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1534 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7593(t2,C_SCHEME_UNDEFINED);}}

/* k7604 in k7600 in k7585 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7593(t3,t2);}

/* k7591 in k7585 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1535 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7559 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7584,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1536 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7582 in k7559 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1536 assign */
t2=((C_word*)t0)[6];
f_7722(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7562 in k7559 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7567(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1537 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[447],C_SCHEME_TRUE);}}

/* k7565 in k7562 in k7559 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1538 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[446],C_SCHEME_TRUE);}

/* k7568 in k7565 in k7562 in k7559 in k7556 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1539 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7129(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7448,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1499 collect! */
t9=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[445],t5);}
else{
t8=t7;
f_7455(2,t8,C_SCHEME_UNDEFINED);}}

/* k7538 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1500 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[444],((C_word*)t0)[2]);}

/* k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7529 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7530,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7534,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1503 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[429],((C_word*)t0)[2]);}

/* k7532 in a7529 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1504 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[426],C_SCHEME_TRUE);}

/* k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[443]:lf[278]);
/* compiler.scm: 1507 put! */
t5=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[437],t4);}
else{
t3=t2;
f_7461(2,t3,C_SCHEME_UNDEFINED);}}

/* k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1511 simple-lambda-node? */
t4=C_retrieve(lf[442]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7513 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1511 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7464(2,t2,C_SCHEME_UNDEFINED);}}

/* k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7464,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7467(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7467(t5,t4);}}

/* k7465 in k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7467,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7500,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7500(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7500(t4,C_SCHEME_FALSE);}}

/* k7498 in k7465 in k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7470(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7470(t2,C_SCHEME_UNDEFINED);}}

/* k7468 in k7465 in k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7470(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7470,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1516 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7495 in k7468 in k7465 in k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1516 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7129(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7471 in k7468 in k7465 in k7462 in k7459 in k7456 in k7453 in a7447 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7403 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7404,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7422 in a7403 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7423,3,t0,t1,t2);}
/* compiler.scm: 1484 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[426],C_SCHEME_TRUE);}

/* k7406 in a7403 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7412,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7421,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1488 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7419 in k7406 in a7403 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1488 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7129(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7410 in k7406 in a7403 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7337,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7342(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7342,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7360,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1470 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7369,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1473 put! */
t7=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[429],((C_word*)t0)[8]);}}

/* k7367 in loop in k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7372,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1474 assign */
t3=((C_word*)t0)[4];
f_7722(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7370 in k7367 in loop in k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7375,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1475 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7129(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7373 in k7370 in k7367 in loop in k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1476 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7342(t4,((C_word*)t0)[2],t2,t3);}

/* k7358 in loop in k7335 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1470 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7129(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7263 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1455 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[438]);}

/* k7311 in k7263 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7313,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[434])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7276,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7242(2,t3,C_SCHEME_UNDEFINED);}}

/* a7275 in k7311 in k7263 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7276,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[400],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7295,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1461 get */
t10=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[437]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7293 in a7275 in k7311 in k7263 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1461 count! */
t2=C_retrieve(lf[435]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7240 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1463 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7129(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7243 in k7240 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1464 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7710(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7204 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7122(C_fix(1));
/* compiler.scm: 1442 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}

/* k7161 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7163,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7122(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1435 put! */
t3=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[431],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1436 get */
t4=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[432]);}}}

/* k7192 in k7161 in k7149 in walk in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1436 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[432],C_SCHEME_TRUE);}}

/* assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7722(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7722,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[125],t7);
if(C_truep(t8)){
/* compiler.scm: 1554 put! */
t9=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[425],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7735,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[400],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7735(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7735(t13,C_SCHEME_FALSE);}}}

/* k7733 in assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7744(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7744(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1559 get */
t6=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[349]);}}}}

/* k7793 in k7733 in assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7744(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7742 in k7733 in assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7744,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1562 get-all */
t3=C_retrieve(lf[430]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[426],lf[427]);}
else{
/* compiler.scm: 1570 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}

/* k7745 in k7742 in k7733 in assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1563 get */
t3=C_retrieve(lf[428]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[429]);}

/* k7748 in k7745 in k7742 in k7733 in assign in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[426],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[427],((C_word*)t0)[7]))){
/* compiler.scm: 1566 put! */
t2=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1568 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[427],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1569 put! */
t4=C_retrieve(lf[424]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[426],C_SCHEME_TRUE);}}}}

/* ref in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_7825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7825,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1573 collect! */
t4=C_retrieve(lf[422]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[423],t3);}

/* grow in k7118 in ##compiler#analyze-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static C_word C_fcall f_7122(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7107,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7098,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7089,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7080,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7071,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7062,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7053,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7044,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7035,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[409]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7026,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[409]);
/* compiler.scm: 1405 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7020,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[409]));}

/* make-foreign-callback-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7014,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[409],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6339,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6342,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6386,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6760,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6885,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6901,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6986,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1400 walk */
t21=((C_word*)t6)[1];
f_6386(t21,t1,t2,*((C_word*)lf[408]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6986,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[407]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[103]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[107]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1398 every */
t8=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6901,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6907(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6907(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6907,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6921,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1381 reverse */
t5=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1382 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6986(3,t6,t4,t5);}}

/* k6925 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1383 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6907(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1385 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[384]);}}

/* k6943 in k6925 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6945,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1386 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6386(t4,((C_word*)t0)[2],t2,t3);}

/* a6953 in k6943 in k6925 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6954,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6980,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1391 varnode */
t7=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6978 in a6953 in k6943 in k6925 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1390 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6907(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6966 in a6953 in k6943 in k6925 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6919 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1381 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6885,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6891,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1374 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6901(t7,t1,t4,t6);}

/* a6890 in walk-inline-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6891,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[394],t3,t4,t2);
/* compiler.scm: 1377 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6760,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6764,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1350 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1351 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6821,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6817,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1355 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6815 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1355 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6813,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1356 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6901(t6,t4,((C_word*)t0)[2],t5);}

/* a6791 in k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6798,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1359 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6386(t4,t1,((C_word*)t0)[2],t3);}

/* a6797 in a6791 in k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6798,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6802,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1361 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6807 in a6797 in a6791 in k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1361 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6800 in a6797 in a6791 in k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[394],lf[396],((C_word*)t0)[2],t1));}

/* k6788 in k6811 in k6819 in k6765 in k6762 in walk-call in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6386,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[400]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6408(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[102]);
if(C_truep(t14)){
t15=t13;
f_6408(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[125]);
if(C_truep(t15)){
t16=t13;
f_6408(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[271]);
t17=t13;
f_6408(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[406])));}}}}

/* k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6408,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1307 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1308 gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[399]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6514,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6514(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6576,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[402]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1330 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[279]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6639,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[402]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6674(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6674(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[103]);
if(C_truep(t10)){
t11=t8;
f_6674(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6674(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[107]);
t13=t8;
f_6674(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6674,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1344 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6885(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1345 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6760(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[270]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6831,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1364 gensym */
t8=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[399]);}
else{
/* compiler.scm: 1347 bomb */
t4=C_retrieve(lf[404]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[405]);}}}}

/* k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1365 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6832 in k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6834,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[402]);}

/* k6877 in k6832 in k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6875,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1369 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6873 in k6877 in k6832 in k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1369 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6869 in k6877 in k6832 in k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6871,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1371 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6865 in k6869 in k6877 in k6832 in k6829 in k6672 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[270],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t4));}

/* k6637 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6639,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[403]),t1,((C_word*)t0)[2]);}

/* k6663 in k6637 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1341 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6342(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6587 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6589,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1331 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6386(t4,((C_word*)t0)[2],t2,t3);}

/* a6597 in k6587 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6598,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[394],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6622,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6626,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1335 varnode */
t10=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6624 in a6597 in k6587 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1335 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6620 in a6597 in k6587 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6622,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6574 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1329 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6342(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6514(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6514,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1323 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6386(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1324 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6386(t6,t1,t4,t5);}}

/* a6536 in loop in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6537,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6551,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1328 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6514(t8,t5,t6,t7);}

/* k6549 in a6536 in loop in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6551,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1309 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}

/* k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6424,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6499,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[402]);}

/* k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6495,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1314 varnode */
t6=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6493 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1314 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6489 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1315 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6386(t7,t4,t5,t6);}

/* a6463 in k6489 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6464,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1319 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6386(t5,t3,t4,((C_word*)t0)[2]);}

/* k6473 in a6463 in k6489 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1320 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6386(t4,t2,t3,((C_word*)t0)[2]);}

/* k6477 in k6473 in a6463 in k6489 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[113],C_SCHEME_END_OF_LIST,t2));}

/* k6456 in k6489 in k6497 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6458,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6424,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6435,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1310 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6433 in k1 in k6421 in k6418 in k6406 in walk in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[401],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6342,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6346,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1295 gensym */
t7=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[399]);}

/* k6344 in cps-lambda in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1298 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6386(t7,t4,t5,t6);}

/* a6368 in k6344 in cps-lambda in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6380,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1300 varnode */
t4=C_retrieve(lf[398]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6378 in a6368 in k6344 in cps-lambda in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[394],lf[396],lf[397],t2));}

/* k6361 in k6344 in cps-lambda in ##compiler#perform-cps-conversion in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[394],lf[395],((C_word*)t0)[4],t2);
/* compiler.scm: 1296 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6249,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6252,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6281,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1287 walk */
t10=((C_word*)t7)[1];
f_6281(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6281,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1282 ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[392]),t5);}
else{
/* compiler.scm: 1286 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6252(t5,t1,t2);}}}

/* k6298 in walk in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6306(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1284 alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6321 in k6298 in walk in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1284 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[392]),((C_word*)t0)[2],t1);}

/* k6304 in k6298 in walk in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1285 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6252(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6252,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6258,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6258(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6258(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6258,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6268,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1276 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6281(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6266 in loop in mapupdate in ##compiler#update-line-number-database! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1277 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6258(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6168,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6172,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6172(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6172(t5,C_SCHEME_FALSE);}}

/* k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6172,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6175(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6175(t3,lf[391]);}}

/* k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6175,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6178(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6178(t4,(C_word)C_i_cadr(t3));}}

/* k6176 in k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_6178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6178,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6181,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[389]+1),t4);}

/* k6192 in k6176 in k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6179 in k6176 in k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6182 in k6179 in k6176 in k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6185 in k6182 in k6179 in k6176 in k6173 in k6170 in ##compiler#expand-foreign-primitive in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1266 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6131,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6154,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6152 in ##compiler#expand-foreign-callback-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6139 in ##compiler#expand-foreign-callback-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6142 in k6139 in ##compiler#expand-foreign-callback-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6147,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6145 in k6142 in k6139 in ##compiler#expand-foreign-callback-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1257 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6094,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6104,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6117,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[389]+1),t9);}

/* k6115 in ##compiler#expand-foreign-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6102 in ##compiler#expand-foreign-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6107,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[390]+1),((C_word*)t0)[2]);}

/* k6105 in k6102 in ##compiler#expand-foreign-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[389]+1),((C_word*)t0)[2]);}

/* k6108 in k6105 in k6102 in ##compiler#expand-foreign-lambda* in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1249 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1236 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6056(2,t6,t4);}
else{
/* compiler.scm: 1238 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[388],t4);}}}

/* k6054 in ##compiler#expand-foreign-callback-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6062,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6060 in k6054 in ##compiler#expand-foreign-callback-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1241 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6004,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6011,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1227 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_6011(2,t6,t4);}
else{
/* compiler.scm: 1229 quit */
t6=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[387],t4);}}}

/* k6009 in ##compiler#expand-foreign-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6017,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[386]+1),t5);}

/* k6015 in k6009 in ##compiler#expand-foreign-lambda in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1232 create-foreign-stub */
t2=C_retrieve(lf[378]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5850,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5854,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5998,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1200 list-tabulate */
t12=C_retrieve(lf[385]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5997 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5998,3,t0,t1,t2);}
/* compiler.scm: 1200 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[384]);}

/* k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1201 gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}

/* k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1202 gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1203 estimate-foreign-result-size */
t3=C_retrieve(lf[382]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1204 set-real-name! */
t3=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1206 make-foreign-stub */
t3=C_retrieve(lf[358]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5992,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[271],((C_word*)t0)[2]);
t7=t5;
f_5876(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5876(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5876,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5967,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1212 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5966 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5967,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5975,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1212 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5973 in a5966 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1212 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[379]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5902,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[380],t1);
/* compiler.scm: 1217 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1218 final-foreign-type */
t7=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5917 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1219 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5920 in k5917 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5922,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[381],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5933,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1222 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5939 in k5920 in k5917 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1222 finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5935 in k5920 in k5917 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1221 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5931 in k5920 in k5917 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5902(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5910 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1217 foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5900 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5888 in k5877 in k5874 in k5990 in k5864 in k5861 in k5858 in k5855 in k5852 in ##compiler#create-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5841,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5832,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5823,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5814,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5805,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5796,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5787,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5778,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5769,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5760,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5751,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5742,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5733,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5724,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5715,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[359]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5706,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[359]);
/* compiler.scm: 1189 ##sys#block-set! */
t5=*((C_word*)lf[362]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5700,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[359]));}

/* make-foreign-stub in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5694,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[359],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4749,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4752,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4803(t5,t1);}

/* a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4803(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4803,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4807(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1025 syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[357],((C_word*)t0)[3]);}}

/* k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[293]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[296]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[297]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1037 check-decl */
f_4752(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t9=t3;
f_4813(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4919,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1047 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t10=t3;
f_4813(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4944,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1051 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[300]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[301]));
t12=t3;
f_4813(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4973,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1058 lset-intersection */
t12=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[129]+1),t10,C_retrieve(lf[300]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1061 check-decl */
f_4752(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[304]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[305]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[304]);
t13=t3;
f_4813(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4813(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1067 ##match#set-error-control */
t15=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[307]);}
else{
t14=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4813(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4813(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4813(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4813(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4813(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[310]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4813(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[311]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5073,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1074 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[312]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1075 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4813(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5108,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1079 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1083 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[316]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1087 every */
t28=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[319]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5171(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5171(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5171(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[323]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[323],t28);
/* compiler.scm: 1095 emit-control-file-item */
t30=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[325]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[325],t29);
/* compiler.scm: 1097 emit-control-file-item */
t31=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[326]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1100 pathname-strip-extension */
t31=C_retrieve(lf[329]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4813(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[331]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4813(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[332]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4813(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[333]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1106 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1108 check-decl */
f_4752(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[338]);
if(C_truep(t35)){
t36=C_set_block_item(lf[339],0,C_SCHEME_TRUE);
t37=t3;
f_4813(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[340]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[341]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5477,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1142 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5477(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5498,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1146 lset-difference */
t41=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[129]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[343]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1150 quit */
t41=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[344],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4813(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4813(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[345]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4813(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4813(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4813(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4813(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5572,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1159 lset-union */
t46=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[129]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5589,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1161 check-decl */
f_4752(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1169 every */
t47=C_retrieve(lf[318]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[351]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[352]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5663,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1173 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1183 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[356],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5662 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5663,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5673,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5672 in a5662 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5673,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[355]);}

/* k5666 in a5662 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5634 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5641,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1174 partition */
t4=C_retrieve(lf[354]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5640 in a5634 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5641,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1178 quit */
t3=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[353],t2);}}}

/* k5615 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1170 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1171 quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[350],((C_word*)t0)[2]);}}

/* k5619 in k5615 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5587 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5596(2,t4,t2);}
else{
/* compiler.scm: 1166 quit */
t4=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[348],((C_word*)t0)[3]);}}

/* k5594 in k5587 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5570 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5496 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1147 lset-union */
t6=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],t5);}

/* k5500 in k5496 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5483 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5477(t3,t2);}

/* k5475 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5477,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1143 lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5479 in k5475 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4813(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1113 lset-difference */
t7=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4813(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5367,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1117 lset-difference */
t8=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[129]+1),C_retrieve(lf[301]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4813(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1121 lset-union */
t9=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[129]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[302]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4813(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5421,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1128 lset-difference */
t10=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[129]+1),C_retrieve(lf[300]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1131 check-decl */
f_4752(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5430 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[309]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4813(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[308]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1136 ##match#set-error-control */
t6=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[307]);}
else{
/* compiler.scm: 1137 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[337],((C_word*)t0)[3]);}}}

/* k5419 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1129 lset-difference */
t4=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[301]),((C_word*)t0)[2]);}

/* k5423 in k5419 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5390 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5365 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5340 in k5320 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5307 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5259 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5270,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5269 in k5259 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5270,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[327]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[328],((C_word*)t0)[2],t2);}

/* k5266 in k5259 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[326],t1);
/* compiler.scm: 1099 emit-control-file-item */
t3=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5169 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1092 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1093 process-custom-declaration */
t4=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5147 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1088 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1089 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[317],((C_word*)t0)[2]);}}

/* k5151 in k5147 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5120 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1084 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5124 in k5120 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5106 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1081 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[300]),C_retrieve(lf[301]),C_retrieve(lf[17]));}

/* k5110 in k5106 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5085 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k5071 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[312]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4988 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4813(2,t4,t3);}

/* k4971 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1059 lset-intersection */
t4=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve(lf[301]));}

/* k4975 in k4971 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4942 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4917 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4878,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1039 stringify */
t5=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4900 in k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1039 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4876 in k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1040 ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[297],((C_word*)t0)[2]);}

/* k4879 in k4876 in k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4888,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4888(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4888(t4,C_SCHEME_FALSE);}}

/* k4886 in k4879 in k4876 in k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1042 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[298],lf[299]);}
else{
t2=((C_word*)t0)[2];
f_4884(2,t2,C_SCHEME_UNDEFINED);}}

/* k4882 in k4879 in k4876 in k4870 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4825(2,t3,C_SCHEME_UNDEFINED);}}

/* k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1033 ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[293],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4813(2,t2,C_SCHEME_UNDEFINED);}}

/* a4858 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4852 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4853,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),((C_word*)t0)[2],t2);}

/* k4832 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4843,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4842 in k4832 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4843,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4851,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1034 stringify */
t4=C_retrieve(lf[295]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4849 in a4842 in k4832 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1034 string->c-identifier */
t2=C_retrieve(lf[294]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4835 in k4832 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1035 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4839 in k4835 in k4832 in k4823 in k4820 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4813(2,t3,t2);}

/* k4811 in k4805 in a4802 in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[292]);}

/* check-decl in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4752(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4752,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4765,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4765(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4775(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4775(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1020 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4773 in check-decl in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4765(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4763 in check-decl in ##compiler#process-declaration in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1021 syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[291],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[41],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1973,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1985,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2009,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2142,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2160,a[2]=t5,a[3]=t13,a[4]=t4,a[5]=t11,a[6]=t3,a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t17=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4707,a[2]=t2,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[123],C_retrieve(lf[288])))){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1003 newline */
t20=*((C_word*)lf[290]+1);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=t18;
f_4707(2,t19,C_SCHEME_UNDEFINED);}}

/* k4742 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1003 pretty-print */
t2=C_retrieve(lf[289]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1004 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[287]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4708 in k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1008 reverse */
t4=*((C_word*)lf[286]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4723 in k4708 in k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4734,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1011 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4732 in k4723 in k4708 in k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1012 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[284]),C_retrieve(lf[13]));}

/* k4736 in k4732 in k4723 in k4708 in k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 452  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4719 in k4708 in k4705 in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 1006 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2160(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4694(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4694,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4700,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4699 in mapwalk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4700,3,t0,t1,t2);}
/* compiler.scm: 1001 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2160(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 505  resolve-atom */
t9=((C_word*)((C_word*)t0)[8])[1];
f_2051(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 507  resolve-atom */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2051(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 509  constant? */
t7=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2197(2,t7,C_SCHEME_FALSE);}}}

/* k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 510  walk-literal */
t2=((C_word*)((C_word*)t0)[12])[1];
f_2142(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 511  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[111],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[5],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 515  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 977  constant? */
t5=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 975  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[283],((C_word*)t0)[10]);}}}}}

/* k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 978  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 982  caar */
t5=*((C_word*)lf[281]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4570(t4,C_SCHEME_FALSE);}}}

/* k4668 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4570(t2,(C_word)C_eqp(lf[159],t1));}

/* k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 985  emit-syntax-trace-info */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 997  emit-syntax-trace-info */
t3=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4655 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 998  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4694(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4577 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 986  ##sys#check-syntax */
t3=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[280]);}

/* k4580 in k4577 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4591(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4591(t4,C_SCHEME_FALSE);}}

/* k4589 in k4580 in k4577 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 989  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[278]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 990  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}}

/* k4611 in k4589 in k4580 in k4577 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4613,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 991  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2160(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4604 in k4589 in k4580 in k4577 in k4568 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 989  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2160(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4556 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 979  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[277],((C_word*)t0)[4]);}

/* k4559 in k4556 in k4553 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 980  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4694(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=f_1973(((C_word*)t0)[13],((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2230,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t2,a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 517  emit-syntax-trace-info */
t4=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}

/* k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[15]))){
t3=t2;
f_2233(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[15],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 520  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[274],((C_word*)t0)[2]);}
else{
/* compiler.scm: 521  syntax-error */
t3=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[275],((C_word*)t0)[15]);}}}

/* k4535 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 520  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[15]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 524  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[9]);}

/* k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[15],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 528  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[8]);}
else{
t4=t3;
f_2258(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 526  update-line-number-database! */
t4=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2249(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2247 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 527  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2160(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[13])[1];
f_2160(t4,((C_word*)t0)[12],t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[113]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 535  ##sys#check-syntax */
t4=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[113],((C_word*)t0)[14],lf[116]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[102]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 543  ##sys#check-syntax */
t5=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[102],((C_word*)t0)[14],lf[117]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[118]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[119]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[14]);
/* compiler.scm: 549  walk */
t6=((C_word*)((C_word*)t0)[13])[1];
f_2160(t6,((C_word*)t0)[12],t5,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[120]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 552  cadadr */
t7=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[14]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[125]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2392(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[270]);
if(C_truep(t8)){
t9=t7;
f_2392(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[271]);
if(C_truep(t9)){
t10=t7;
f_2392(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[103]);
t11=t7;
f_2392(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[8],lf[107])));}}}}}}}}}

/* k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[237],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2392,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[126]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2439(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 600  ##sys#check-syntax */
t6=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 614  ##sys#check-syntax */
t8=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 649  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2160(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[122]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 665  ##sys#check-syntax */
t12=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 704  unquotify */
t14=((C_word*)t0)[3];
f_2009(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 712  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2160(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 717  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2160(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 722  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 726  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 730  ##sys#check-syntax */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 742  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 745  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 748  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 751  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 754  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3372(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 761  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3439,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 772  gensym */
t33=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 785  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3513,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 805  gensym */
t34=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3715,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3733,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3858,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  call-with-current-continuation */
t37=*((C_word*)lf[241]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[242]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3931,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[244]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 872  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[267],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 947  ##sys#check-syntax */
t36=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[267],((C_word*)t0)[12],lf[269]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 965  ##sys#hash-table-ref */
t36=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4457(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4457(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4455 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 967  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 972  handle-call */
t2=((C_word*)t0)[7];
f_4328(t2,((C_word*)t0)[6]);}}

/* k4461 in k4455 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 969  handle-call */
t2=((C_word*)t0)[7];
f_4328(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 970  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2160(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4366 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4368,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1973(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 952  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2160(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 956  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2160(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 958  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t7=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 960  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2160(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[102],lf[267]);
t4=(C_word)C_a_i_list(&a,5,lf[268],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 961  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2160(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4426 in k4366 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[103],t2));}

/* handle-call in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4328,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 936  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4694(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4330 in handle-call in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4332,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4338,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 938  ##sys#hash-table-ref */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4336 in k4330 in handle-call in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 943  alist-cons */
t5=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4341(2,t3,C_SCHEME_UNDEFINED);}}

/* k4350 in k4336 in k4330 in handle-call in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 940  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4339 in k4336 in k4330 in handle-call in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3964,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3986,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 879  valid-c-identifier? */
t14=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4310 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3986(2,t4,t3);}
else{
/* compiler.scm: 881  quit */
t2=C_retrieve(lf[238]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[265],((C_word*)t0)[3]);}}

/* k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4277(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4277(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4277(t11,(C_word)C_i_not(t10));}}}

/* k4275 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 886  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[264],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3989(2,t2,C_SCHEME_UNDEFINED);}}

/* k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 890  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4694(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4008,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4227(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4263,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 902  final-foreign-type */
t9=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4269 in loop in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 902  finish-foreign-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4265 in loop in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 901  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4261 in loop in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4263,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 904  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4227(t6,t3,t4,t5);}

/* k4249 in k4261 in loop in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[250]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4099(2,t7,f_4076(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[251]))){
/* compiler.scm: 907  g300 */
t7=t6;
f_4099(2,t7,f_4076(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[252]);
if(C_truep(t7)){
/* compiler.scm: 907  g300 */
t8=t6;
f_4099(2,t8,f_4076(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[253]);
if(C_truep(t8)){
/* compiler.scm: 907  g300 */
t9=t6;
f_4099(2,t9,f_4076(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4071(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[255]))){
/* compiler.scm: 907  g301 */
t9=t4;
f_4071(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t9)){
/* compiler.scm: 907  g301 */
t10=t4;
f_4071(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[257]);
if(C_truep(t10)){
/* compiler.scm: 907  g301 */
t11=t4;
f_4071(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[258]);
if(C_truep(t11)){
/* compiler.scm: 907  g301 */
t12=t4;
f_4071(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t12)){
/* compiler.scm: 907  g301 */
t13=t4;
f_4071(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t13)){
/* compiler.scm: 907  g302 */
t14=t6;
f_4099(2,t14,f_4034(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[261]))){
/* compiler.scm: 907  g302 */
t14=t6;
f_4099(2,t14,f_4034(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
/* compiler.scm: 907  g302 */
t15=t6;
f_4099(2,t15,(C_truep(t14)?f_4034(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[263]))?f_4034(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4097 in k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 905  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g300 in k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static C_word C_fcall f_4076(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[247],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g301 in k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4071,NULL,2,t0,t1);}
/* compiler.scm: 919  syntax-error */
t2=C_retrieve(lf[110]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g302 in k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static C_word C_fcall f_4034(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[246],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[247],lf[246]);
t7=(C_word)C_a_i_list(&a,3,lf[248],lf[246],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k4022 in k4018 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 891  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2160(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4006 in k3998 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3994 in k3987 in k3984 in a3963 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[244],t1));}

/* a3953 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 872  split-at */
t3=C_retrieve(lf[245]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3930 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3931,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 867  process-declaration */
t4=C_retrieve(lf[243]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3927 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 865  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2160(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3864,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3876,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  with-exception-handler */
t5=C_retrieve(lf[240]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3875 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3897 in a3875 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3898r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3898r(t0,t1,t2);}}

static void C_ccall f_3898r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3904,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3903 in a3897 in a3875 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3881 in a3875 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 848  collapsable-literal? */
t3=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3887 in a3881 in a3875 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 850  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3863 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3864,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 844  g263 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3869 in a3863 in a3857 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
/* compiler.scm: 846  quit */
t2=C_retrieve(lf[238]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[239],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3854 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[102],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 853  collapsable-literal? */
t8=C_retrieve(lf[237]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3803 in k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 854  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 857  gensym */
t3=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k3813 in k3803 in k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 858  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3816 in k3813 in k3803 in k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 859  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3820 in k3816 in k3813 in k3803 in k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3822,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[102],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 862  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2160(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3806 in k3803 in k3792 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3737,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 834  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3735 in a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3775,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 835  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3773 in k3735 in a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 835  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3739 in k3735 in a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3755,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3754 in k3739 in k3735 in a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3755,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[102],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3751 in k3739 in k3735 in a3732 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 837  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2160(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3714 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3723,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 833  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2160(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3721 in a3714 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 832  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 806  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 808  set-real-name! */
t6=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3597,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 811  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3674 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 811  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[102],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3612,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3628(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3628(t11,C_SCHEME_END_OF_LIST);}}

/* k3626 in k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 824  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3636(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3634 in k3626 in k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 452  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3622 in k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 825  alist-cons */
t4=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3618 in k3622 in k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 819  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3610 in k3651 in k3595 in k3589 in k3586 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 793  make-random-name */
t9=C_retrieve(lf[97]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3525(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3553,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 794  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3559 in k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 794  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3551 in k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3525(t3,t2);}

/* k3523 in k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3525,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 797  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3543 in k3523 in k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 799  alist-cons */
t6=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3535 in k3543 in k3523 in k3520 in k3511 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3491 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3437 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 773  gensym */
t3=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3440 in k3437 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 774  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3443 in k3440 in k3437 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 775  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3447 in k3443 in k3440 in k3437 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 776  cons* */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3451 in k3447 in k3443 in k3440 in k3437 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 777  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2160(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3370 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3384(2,t3,t1);}
else{
/* compiler.scm: 763  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3382 in k3370 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3355 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 754  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3342 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 751  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3329 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 748  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3316 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 745  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3303 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 742  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3257,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3257(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3257,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 737  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2160(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 738  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2160(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3282 in fold in k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3288,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 738  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3257(t3,t2,((C_word*)t0)[2]);}

/* k3286 in k3282 in fold in k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3275 in fold in k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3249 in k3236 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 732  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3223 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3208 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 723  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2160(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3181 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3187,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 718  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2160(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3185 in k3181 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3160 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3131 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 709  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4694(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3135 in k3131 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3102 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 704  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4694(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3106 in k3102 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3108,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1973(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 668  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2942,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 669  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2160(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2945,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 671  ##sys#alias-global-hook */
t5=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2945(2,t4,C_SCHEME_UNDEFINED);}}

/* k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 674  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[129]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_3053(t4,C_SCHEME_UNDEFINED);}}

/* k3077 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 675  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[129]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3081 in k3077 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_3053(t3,t2);}

/* k3051 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3053,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 676  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3057 in k3051 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 680  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3072(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2945(2,t2,C_SCHEME_UNDEFINED);}}

/* k3070 in k3057 in k3051 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 677  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3060 in k3057 in k3051 in k3048 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 681  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2945(2,t2,C_SCHEME_UNDEFINED);}}

/* k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 682  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3038 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 683  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2948(2,t2,C_SCHEME_UNDEFINED);}}

/* k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 687  gensym */
t5=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 695  gensym */
t6=C_retrieve(lf[122]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k3001 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 696  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3032 in k3001 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3026,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 700  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k3024 in k3032 in k3001 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2958 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2989 in k2958 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2979,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 691  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2977 in k2989 in k2958 in k2946 in k2943 in k2940 in k2937 in k2928 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 655  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2916 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 655  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2893 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2910,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 658  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2909 in k2893 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2910,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2906 in k2893 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 657  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2160(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2896 in k2893 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2901,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 661  set-real-names! */
f_1985(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2899 in k2896 in k2893 in k2890 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[10]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2636,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 617  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2840 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 618  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2636(2,t2,C_SCHEME_UNDEFINED);}}

/* a2852 in k2840 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2853,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2846 in k2840 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
/* compiler.scm: 620  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 623  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2641,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[122]),t2);}

/* k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 627  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2837 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 627  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 628  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[14]);}

/* a2830 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2831,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 629  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2160(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 633  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t4=t3;
f_2822(t4,C_SCHEME_FALSE);}}

/* k2827 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2822(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2820 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 631  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[159],t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 635  set-real-names! */
f_1985(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_2672(t4,t2);}
else{
t4=f_1973(((C_word*)t0)[10],((C_word*)t0)[2]);
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
t6=t3;
f_2672(t6,(C_word)C_i_not(t5));}}

/* k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2672,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 640  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2692(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2692(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2692(t5,C_SCHEME_FALSE);}}}}

/* k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2692(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2692,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* compiler.scm: 642  g169 */
t6=((C_word*)t0)[4];
f_2682(t6,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t3;
f_2725(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2774 in k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[102]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2725(t3,C_SCHEME_FALSE);}}

/* k2770 in k2774 in k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 642  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2725(t2,C_SCHEME_FALSE);}}

/* k2766 in k2770 in k2774 in k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2725(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2725(t2,C_SCHEME_FALSE);}}

/* k2723 in k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2725,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 642  cadadr */
t3=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2730 in k2723 in k2690 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 642  g169 */
t3=((C_word*)t0)[3];
f_2682(t3,((C_word*)t0)[2],t1);}

/* g169 in k2670 in k2661 in k2655 in k2652 in k2649 in k2646 in k2643 in a2640 in k2634 in k2625 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2682,NULL,3,t0,t1,t2);}
/* compiler.scm: 644  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 602  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2562,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[122]),t1);}

/* k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 604  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2613 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 604  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 605  set-real-names! */
f_1985(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2595,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 606  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2594 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2595,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 607  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2160(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2601 in a2594 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2573 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 609  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2588 in k2573 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2589,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2581 in k2573 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 609  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2577 in k2573 in k2566 in k2563 in k2560 in k2557 in k2551 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2439,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2449,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 577  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2460,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2525(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 581  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2525(2,t6,C_SCHEME_FALSE);}}}

/* k2532 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2525(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 583  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2542 in k2532 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 582  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2523 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 589  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2487(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2487(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 585  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2497 in k2523 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2487(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2487(t2,C_SCHEME_FALSE);}}

/* a2512 in k2497 in k2523 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2513,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2509 in k2497 in k2523 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2487(t2,C_SCHEME_TRUE);}

/* k2485 in k2523 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2464(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 595  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2462 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 596  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2439(t4,t2,t3);}

/* k2469 in k2462 in a2459 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2453 in k2447 in loop in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
/* compiler.scm: 578  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2431 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 573  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2160(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2399 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2402 in k2399 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 567  ##sys#hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2414 in k2402 in k2399 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2408 in k2402 in k2399 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2409,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[129]+1),t2,((C_word*)t0)[2]);}

/* k2405 in k2402 in k2399 in k2390 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[127]);}

/* k2357 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 555  gensym */
t4=C_retrieve(lf[122]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[123]);}}

/* k2369 in k2357 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 556  alist-cons */
t3=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2373 in k2369 in k2357 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2325 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* compiler.scm: 544  walk-literal */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2142(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2279 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 536  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2160(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2286 in k2279 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 537  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2160(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2290 in k2286 in k2279 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2296(2,t4,lf[114]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 540  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2160(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2294 in k2290 in k2286 in k2279 in k2256 in k2238 in k2231 in k2228 in k2222 in k2195 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[113],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2183 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 508  ##sys#alias-global-hook */
t2=C_retrieve(lf[109]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2177 in walk in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* walk-literal in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2142,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_retrieve(lf[93]))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2151,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 497  literal-rewrite-hook */
t7=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[102],t2));}}

/* a2150 in walk-literal in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2151,3,t0,t1,t2);}
/* walk21 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2160(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2051,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2055,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 472  ##sys#hash-table-ref */
t7=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2055(2,t7,C_SCHEME_FALSE);}}

/* k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 473  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2160(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 474  ##sys#hash-table-ref */
t3=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2068(2,t3,C_SCHEME_FALSE);}}}

/* k2066 in k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 476  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2160(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 480  final-foreign-type */
t5=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 488  final-foreign-type */
t6=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2114 in k2066 in k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[107],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 491  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2124 in k2114 in k2066 in k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 490  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2084 in k2066 in k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[103],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 483  finish-foreign-result */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2094 in k2084 in k2066 in k2053 in resolve-atom in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 482  foreign-type-convert-result */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2016,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[102]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_2016(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_2016(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2016(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2016(t4,C_SCHEME_FALSE);}}

/* k2014 in unquotify in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_1985(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1985,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1991,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 459  for-each */
t5=*((C_word*)lf[101]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1990 in set-real-names! in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1991,4,t0,t1,t2,t3);}
/* compiler.scm: 459  set-real-name! */
t4=C_retrieve(lf[100]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static C_word C_fcall f_1973(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 429  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 430  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1966 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1903(2,t3,t2);}

/* k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 432  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 433  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1959 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1906(2,t3,t2);}

/* k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 435  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 436  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1952 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1909(2,t3,t2);}

/* k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 437  make-random-name */
t3=C_retrieve(lf[97]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[98]);}

/* k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[88]))){
/* compiler.scm: 440  vector-fill! */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[88]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1947,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 441  make-vector */
t5=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1945 in k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=((C_word*)t0)[2];
f_1920(2,t3,t2);}

/* k1918 in k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 443  vector-fill! */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 444  make-vector */
t4=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1938 in k1918 in k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1923(2,t3,t2);}

/* k1921 in k1918 in k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 446  vector-fill! */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 447  make-vector */
t3=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1931 in k1921 in k1918 in k1915 in k1911 in k1907 in k1904 in k1901 in ##compiler#initialize-compiler in k1811 in k1807 in k1803 in k1799 in k1795 in k1791 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[820] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1771compiler.scm",(void*)f_1771},
{"f_1774compiler.scm",(void*)f_1774},
{"f_1777compiler.scm",(void*)f_1777},
{"f_1780compiler.scm",(void*)f_1780},
{"f_1783compiler.scm",(void*)f_1783},
{"f_1786compiler.scm",(void*)f_1786},
{"f_1793compiler.scm",(void*)f_1793},
{"f_1797compiler.scm",(void*)f_1797},
{"f_1801compiler.scm",(void*)f_1801},
{"f_1805compiler.scm",(void*)f_1805},
{"f_1809compiler.scm",(void*)f_1809},
{"f_1813compiler.scm",(void*)f_1813},
{"f_10157compiler.scm",(void*)f_10157},
{"f_11214compiler.scm",(void*)f_11214},
{"f_11217compiler.scm",(void*)f_11217},
{"f_11220compiler.scm",(void*)f_11220},
{"f_11223compiler.scm",(void*)f_11223},
{"f_11226compiler.scm",(void*)f_11226},
{"f_11014compiler.scm",(void*)f_11014},
{"f_11020compiler.scm",(void*)f_11020},
{"f_10247compiler.scm",(void*)f_10247},
{"f_11003compiler.scm",(void*)f_11003},
{"f_11000compiler.scm",(void*)f_11000},
{"f_10913compiler.scm",(void*)f_10913},
{"f_10977compiler.scm",(void*)f_10977},
{"f_10990compiler.scm",(void*)f_10990},
{"f_10971compiler.scm",(void*)f_10971},
{"f_10961compiler.scm",(void*)f_10961},
{"f_10934compiler.scm",(void*)f_10934},
{"f_10937compiler.scm",(void*)f_10937},
{"f_10885compiler.scm",(void*)f_10885},
{"f_10888compiler.scm",(void*)f_10888},
{"f_10842compiler.scm",(void*)f_10842},
{"f_10854compiler.scm",(void*)f_10854},
{"f_10845compiler.scm",(void*)f_10845},
{"f_10848compiler.scm",(void*)f_10848},
{"f_10722compiler.scm",(void*)f_10722},
{"f_10823compiler.scm",(void*)f_10823},
{"f_10811compiler.scm",(void*)f_10811},
{"f_10750compiler.scm",(void*)f_10750},
{"f_10756compiler.scm",(void*)f_10756},
{"f_10780compiler.scm",(void*)f_10780},
{"f_10772compiler.scm",(void*)f_10772},
{"f_10738compiler.scm",(void*)f_10738},
{"f_10681compiler.scm",(void*)f_10681},
{"f_10693compiler.scm",(void*)f_10693},
{"f_10697compiler.scm",(void*)f_10697},
{"f_10685compiler.scm",(void*)f_10685},
{"f_10497compiler.scm",(void*)f_10497},
{"f_10618compiler.scm",(void*)f_10618},
{"f_10624compiler.scm",(void*)f_10624},
{"f_10649compiler.scm",(void*)f_10649},
{"f_10630compiler.scm",(void*)f_10630},
{"f_10504compiler.scm",(void*)f_10504},
{"f_10609compiler.scm",(void*)f_10609},
{"f_10507compiler.scm",(void*)f_10507},
{"f_10510compiler.scm",(void*)f_10510},
{"f_10513compiler.scm",(void*)f_10513},
{"f_10551compiler.scm",(void*)f_10551},
{"f_10577compiler.scm",(void*)f_10577},
{"f_10558compiler.scm",(void*)f_10558},
{"f_10562compiler.scm",(void*)f_10562},
{"f_10535compiler.scm",(void*)f_10535},
{"f_10441compiler.scm",(void*)f_10441},
{"f_10450compiler.scm",(void*)f_10450},
{"f_10444compiler.scm",(void*)f_10444},
{"f_10425compiler.scm",(void*)f_10425},
{"f_10398compiler.scm",(void*)f_10398},
{"f_10381compiler.scm",(void*)f_10381},
{"f_10377compiler.scm",(void*)f_10377},
{"f_10370compiler.scm",(void*)f_10370},
{"f_10353compiler.scm",(void*)f_10353},
{"f_10349compiler.scm",(void*)f_10349},
{"f_10325compiler.scm",(void*)f_10325},
{"f_10305compiler.scm",(void*)f_10305},
{"f_10160compiler.scm",(void*)f_10160},
{"f_10164compiler.scm",(void*)f_10164},
{"f_10179compiler.scm",(void*)f_10179},
{"f_10189compiler.scm",(void*)f_10189},
{"f_10194compiler.scm",(void*)f_10194},
{"f_10239compiler.scm",(void*)f_10239},
{"f_10198compiler.scm",(void*)f_10198},
{"f_10204compiler.scm",(void*)f_10204},
{"f_10214compiler.scm",(void*)f_10214},
{"f_11026compiler.scm",(void*)f_11026},
{"f_11033compiler.scm",(void*)f_11033},
{"f_11095compiler.scm",(void*)f_11095},
{"f_11085compiler.scm",(void*)f_11085},
{"f_11059compiler.scm",(void*)f_11059},
{"f_11045compiler.scm",(void*)f_11045},
{"f_11120compiler.scm",(void*)f_11120},
{"f_11136compiler.scm",(void*)f_11136},
{"f_11143compiler.scm",(void*)f_11143},
{"f_11150compiler.scm",(void*)f_11150},
{"f_11124compiler.scm",(void*)f_11124},
{"f_11134compiler.scm",(void*)f_11134},
{"f_11106compiler.scm",(void*)f_11106},
{"f_11114compiler.scm",(void*)f_11114},
{"f_11152compiler.scm",(void*)f_11152},
{"f_11165compiler.scm",(void*)f_11165},
{"f_10148compiler.scm",(void*)f_10148},
{"f_10139compiler.scm",(void*)f_10139},
{"f_10130compiler.scm",(void*)f_10130},
{"f_10121compiler.scm",(void*)f_10121},
{"f_10112compiler.scm",(void*)f_10112},
{"f_10103compiler.scm",(void*)f_10103},
{"f_10094compiler.scm",(void*)f_10094},
{"f_10085compiler.scm",(void*)f_10085},
{"f_10076compiler.scm",(void*)f_10076},
{"f_10067compiler.scm",(void*)f_10067},
{"f_10058compiler.scm",(void*)f_10058},
{"f_10049compiler.scm",(void*)f_10049},
{"f_10040compiler.scm",(void*)f_10040},
{"f_10031compiler.scm",(void*)f_10031},
{"f_10022compiler.scm",(void*)f_10022},
{"f_10013compiler.scm",(void*)f_10013},
{"f_10004compiler.scm",(void*)f_10004},
{"f_9995compiler.scm",(void*)f_9995},
{"f_9986compiler.scm",(void*)f_9986},
{"f_9977compiler.scm",(void*)f_9977},
{"f_9968compiler.scm",(void*)f_9968},
{"f_9959compiler.scm",(void*)f_9959},
{"f_9950compiler.scm",(void*)f_9950},
{"f_9941compiler.scm",(void*)f_9941},
{"f_9932compiler.scm",(void*)f_9932},
{"f_9923compiler.scm",(void*)f_9923},
{"f_9914compiler.scm",(void*)f_9914},
{"f_9905compiler.scm",(void*)f_9905},
{"f_9896compiler.scm",(void*)f_9896},
{"f_9887compiler.scm",(void*)f_9887},
{"f_9881compiler.scm",(void*)f_9881},
{"f_9875compiler.scm",(void*)f_9875},
{"f_8641compiler.scm",(void*)f_8641},
{"f_9842compiler.scm",(void*)f_9842},
{"f_9845compiler.scm",(void*)f_9845},
{"f_9848compiler.scm",(void*)f_9848},
{"f_9851compiler.scm",(void*)f_9851},
{"f_9854compiler.scm",(void*)f_9854},
{"f_9869compiler.scm",(void*)f_9869},
{"f_9867compiler.scm",(void*)f_9867},
{"f_9857compiler.scm",(void*)f_9857},
{"f_9694compiler.scm",(void*)f_9694},
{"f_9700compiler.scm",(void*)f_9700},
{"f_9005compiler.scm",(void*)f_9005},
{"f_9024compiler.scm",(void*)f_9024},
{"f_9057compiler.scm",(void*)f_9057},
{"f_9584compiler.scm",(void*)f_9584},
{"f_9580compiler.scm",(void*)f_9580},
{"f_9573compiler.scm",(void*)f_9573},
{"f_9424compiler.scm",(void*)f_9424},
{"f_9430compiler.scm",(void*)f_9430},
{"f_9500compiler.scm",(void*)f_9500},
{"f_9530compiler.scm",(void*)f_9530},
{"f_9513compiler.scm",(void*)f_9513},
{"f_9517compiler.scm",(void*)f_9517},
{"f_9439compiler.scm",(void*)f_9439},
{"f_9486compiler.scm",(void*)f_9486},
{"f_9490compiler.scm",(void*)f_9490},
{"f_9466compiler.scm",(void*)f_9466},
{"f_9462compiler.scm",(void*)f_9462},
{"f_9153compiler.scm",(void*)f_9153},
{"f_9402compiler.scm",(void*)f_9402},
{"f_9157compiler.scm",(void*)f_9157},
{"f_9400compiler.scm",(void*)f_9400},
{"f_9160compiler.scm",(void*)f_9160},
{"f_9163compiler.scm",(void*)f_9163},
{"f_9169compiler.scm",(void*)f_9169},
{"f_9175compiler.scm",(void*)f_9175},
{"f_9181compiler.scm",(void*)f_9181},
{"f_9367compiler.scm",(void*)f_9367},
{"f_9370compiler.scm",(void*)f_9370},
{"f_9184compiler.scm",(void*)f_9184},
{"f_9343compiler.scm",(void*)f_9343},
{"f_9328compiler.scm",(void*)f_9328},
{"f_9324compiler.scm",(void*)f_9324},
{"f_9258compiler.scm",(void*)f_9258},
{"f_9283compiler.scm",(void*)f_9283},
{"f_9289compiler.scm",(void*)f_9289},
{"f_9300compiler.scm",(void*)f_9300},
{"f_9287compiler.scm",(void*)f_9287},
{"f_9269compiler.scm",(void*)f_9269},
{"f_9261compiler.scm",(void*)f_9261},
{"f_9246compiler.scm",(void*)f_9246},
{"f_9254compiler.scm",(void*)f_9254},
{"f_9207compiler.scm",(void*)f_9207},
{"f_9237compiler.scm",(void*)f_9237},
{"f_9229compiler.scm",(void*)f_9229},
{"f_9225compiler.scm",(void*)f_9225},
{"f_9221compiler.scm",(void*)f_9221},
{"f_9210compiler.scm",(void*)f_9210},
{"f_9078compiler.scm",(void*)f_9078},
{"f_9081compiler.scm",(void*)f_9081},
{"f_9133compiler.scm",(void*)f_9133},
{"f_9097compiler.scm",(void*)f_9097},
{"f_9126compiler.scm",(void*)f_9126},
{"f_9118compiler.scm",(void*)f_9118},
{"f_9063compiler.scm",(void*)f_9063},
{"f_9036compiler.scm",(void*)f_9036},
{"f_9042compiler.scm",(void*)f_9042},
{"f_9706compiler.scm",(void*)f_9706},
{"f_9713compiler.scm",(void*)f_9713},
{"f_9729compiler.scm",(void*)f_9729},
{"f_8671compiler.scm",(void*)f_8671},
{"f_8690compiler.scm",(void*)f_8690},
{"f_8969compiler.scm",(void*)f_8969},
{"f_8930compiler.scm",(void*)f_8930},
{"f_9745compiler.scm",(void*)f_9745},
{"f_9783compiler.scm",(void*)f_9783},
{"f_9809compiler.scm",(void*)f_9809},
{"f_9795compiler.scm",(void*)f_9795},
{"f_9774compiler.scm",(void*)f_9774},
{"f_9743compiler.scm",(void*)f_9743},
{"f_8943compiler.scm",(void*)f_8943},
{"f_8946compiler.scm",(void*)f_8946},
{"f_8957compiler.scm",(void*)f_8957},
{"f_8894compiler.scm",(void*)f_8894},
{"f_8786compiler.scm",(void*)f_8786},
{"f_8792compiler.scm",(void*)f_8792},
{"f_8804compiler.scm",(void*)f_8804},
{"f_8807compiler.scm",(void*)f_8807},
{"f_8810compiler.scm",(void*)f_8810},
{"f_8828compiler.scm",(void*)f_8828},
{"f_8835compiler.scm",(void*)f_8835},
{"f_8813compiler.scm",(void*)f_8813},
{"f_8816compiler.scm",(void*)f_8816},
{"f_8819compiler.scm",(void*)f_8819},
{"f_8780compiler.scm",(void*)f_8780},
{"f_8770compiler.scm",(void*)f_8770},
{"f_8753compiler.scm",(void*)f_8753},
{"f_8758compiler.scm",(void*)f_8758},
{"f_8711compiler.scm",(void*)f_8711},
{"f_8728compiler.scm",(void*)f_8728},
{"f_8715compiler.scm",(void*)f_8715},
{"f_8726compiler.scm",(void*)f_8726},
{"f_8701compiler.scm",(void*)f_8701},
{"f_8660compiler.scm",(void*)f_8660},
{"f_8669compiler.scm",(void*)f_8669},
{"f_8650compiler.scm",(void*)f_8650},
{"f_8655compiler.scm",(void*)f_8655},
{"f_8644compiler.scm",(void*)f_8644},
{"f_7116compiler.scm",(void*)f_7116},
{"f_7120compiler.scm",(void*)f_7120},
{"f_7870compiler.scm",(void*)f_7870},
{"f_7873compiler.scm",(void*)f_7873},
{"f_7877compiler.scm",(void*)f_7877},
{"f_7880compiler.scm",(void*)f_7880},
{"f_7893compiler.scm",(void*)f_7893},
{"f_8528compiler.scm",(void*)f_8528},
{"f_7897compiler.scm",(void*)f_7897},
{"f_8493compiler.scm",(void*)f_8493},
{"f_7904compiler.scm",(void*)f_7904},
{"f_8439compiler.scm",(void*)f_8439},
{"f_8442compiler.scm",(void*)f_8442},
{"f_8454compiler.scm",(void*)f_8454},
{"f_8448compiler.scm",(void*)f_8448},
{"f_7907compiler.scm",(void*)f_7907},
{"f_7910compiler.scm",(void*)f_7910},
{"f_8422compiler.scm",(void*)f_8422},
{"f_8414compiler.scm",(void*)f_8414},
{"f_8382compiler.scm",(void*)f_8382},
{"f_8388compiler.scm",(void*)f_8388},
{"f_7913compiler.scm",(void*)f_7913},
{"f_8344compiler.scm",(void*)f_8344},
{"f_8353compiler.scm",(void*)f_8353},
{"f_8356compiler.scm",(void*)f_8356},
{"f_7916compiler.scm",(void*)f_7916},
{"f_8245compiler.scm",(void*)f_8245},
{"f_8263compiler.scm",(void*)f_8263},
{"f_8306compiler.scm",(void*)f_8306},
{"f_8331compiler.scm",(void*)f_8331},
{"f_8327compiler.scm",(void*)f_8327},
{"f_8313compiler.scm",(void*)f_8313},
{"f_8316compiler.scm",(void*)f_8316},
{"f_8267compiler.scm",(void*)f_8267},
{"f_8273compiler.scm",(void*)f_8273},
{"f_7919compiler.scm",(void*)f_7919},
{"f_8223compiler.scm",(void*)f_8223},
{"f_8209compiler.scm",(void*)f_8209},
{"f_8216compiler.scm",(void*)f_8216},
{"f_8197compiler.scm",(void*)f_8197},
{"f_8182compiler.scm",(void*)f_8182},
{"f_7922compiler.scm",(void*)f_7922},
{"f_8094compiler.scm",(void*)f_8094},
{"f_8168compiler.scm",(void*)f_8168},
{"f_8100compiler.scm",(void*)f_8100},
{"f_8158compiler.scm",(void*)f_8158},
{"f_8150compiler.scm",(void*)f_8150},
{"f_8146compiler.scm",(void*)f_8146},
{"f_8103compiler.scm",(void*)f_8103},
{"f_8106compiler.scm",(void*)f_8106},
{"f_7925compiler.scm",(void*)f_7925},
{"f_7953compiler.scm",(void*)f_7953},
{"f_7974compiler.scm",(void*)f_7974},
{"f_7995compiler.scm",(void*)f_7995},
{"f_8001compiler.scm",(void*)f_8001},
{"f_7928compiler.scm",(void*)f_7928},
{"f_7934compiler.scm",(void*)f_7934},
{"f_7938compiler.scm",(void*)f_7938},
{"f_7883compiler.scm",(void*)f_7883},
{"f_7887compiler.scm",(void*)f_7887},
{"f_7890compiler.scm",(void*)f_7890},
{"f_7845compiler.scm",(void*)f_7845},
{"f_7855compiler.scm",(void*)f_7855},
{"f_7863compiler.scm",(void*)f_7863},
{"f_7831compiler.scm",(void*)f_7831},
{"f_7839compiler.scm",(void*)f_7839},
{"f_7710compiler.scm",(void*)f_7710},
{"f_7716compiler.scm",(void*)f_7716},
{"f_7129compiler.scm",(void*)f_7129},
{"f_7151compiler.scm",(void*)f_7151},
{"f_7672compiler.scm",(void*)f_7672},
{"f_7666compiler.scm",(void*)f_7666},
{"f_7639compiler.scm",(void*)f_7639},
{"f_7648compiler.scm",(void*)f_7648},
{"f_7633compiler.scm",(void*)f_7633},
{"f_7558compiler.scm",(void*)f_7558},
{"f_7587compiler.scm",(void*)f_7587},
{"f_7602compiler.scm",(void*)f_7602},
{"f_7606compiler.scm",(void*)f_7606},
{"f_7593compiler.scm",(void*)f_7593},
{"f_7561compiler.scm",(void*)f_7561},
{"f_7584compiler.scm",(void*)f_7584},
{"f_7564compiler.scm",(void*)f_7564},
{"f_7567compiler.scm",(void*)f_7567},
{"f_7570compiler.scm",(void*)f_7570},
{"f_7448compiler.scm",(void*)f_7448},
{"f_7540compiler.scm",(void*)f_7540},
{"f_7455compiler.scm",(void*)f_7455},
{"f_7530compiler.scm",(void*)f_7530},
{"f_7534compiler.scm",(void*)f_7534},
{"f_7458compiler.scm",(void*)f_7458},
{"f_7461compiler.scm",(void*)f_7461},
{"f_7515compiler.scm",(void*)f_7515},
{"f_7464compiler.scm",(void*)f_7464},
{"f_7467compiler.scm",(void*)f_7467},
{"f_7500compiler.scm",(void*)f_7500},
{"f_7470compiler.scm",(void*)f_7470},
{"f_7497compiler.scm",(void*)f_7497},
{"f_7473compiler.scm",(void*)f_7473},
{"f_7404compiler.scm",(void*)f_7404},
{"f_7423compiler.scm",(void*)f_7423},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7421compiler.scm",(void*)f_7421},
{"f_7412compiler.scm",(void*)f_7412},
{"f_7337compiler.scm",(void*)f_7337},
{"f_7342compiler.scm",(void*)f_7342},
{"f_7369compiler.scm",(void*)f_7369},
{"f_7372compiler.scm",(void*)f_7372},
{"f_7375compiler.scm",(void*)f_7375},
{"f_7360compiler.scm",(void*)f_7360},
{"f_7265compiler.scm",(void*)f_7265},
{"f_7313compiler.scm",(void*)f_7313},
{"f_7276compiler.scm",(void*)f_7276},
{"f_7295compiler.scm",(void*)f_7295},
{"f_7242compiler.scm",(void*)f_7242},
{"f_7245compiler.scm",(void*)f_7245},
{"f_7206compiler.scm",(void*)f_7206},
{"f_7163compiler.scm",(void*)f_7163},
{"f_7194compiler.scm",(void*)f_7194},
{"f_7722compiler.scm",(void*)f_7722},
{"f_7735compiler.scm",(void*)f_7735},
{"f_7795compiler.scm",(void*)f_7795},
{"f_7744compiler.scm",(void*)f_7744},
{"f_7747compiler.scm",(void*)f_7747},
{"f_7750compiler.scm",(void*)f_7750},
{"f_7825compiler.scm",(void*)f_7825},
{"f_7122compiler.scm",(void*)f_7122},
{"f_7107compiler.scm",(void*)f_7107},
{"f_7098compiler.scm",(void*)f_7098},
{"f_7089compiler.scm",(void*)f_7089},
{"f_7080compiler.scm",(void*)f_7080},
{"f_7071compiler.scm",(void*)f_7071},
{"f_7062compiler.scm",(void*)f_7062},
{"f_7053compiler.scm",(void*)f_7053},
{"f_7044compiler.scm",(void*)f_7044},
{"f_7035compiler.scm",(void*)f_7035},
{"f_7026compiler.scm",(void*)f_7026},
{"f_7020compiler.scm",(void*)f_7020},
{"f_7014compiler.scm",(void*)f_7014},
{"f_6339compiler.scm",(void*)f_6339},
{"f_6986compiler.scm",(void*)f_6986},
{"f_6901compiler.scm",(void*)f_6901},
{"f_6907compiler.scm",(void*)f_6907},
{"f_6927compiler.scm",(void*)f_6927},
{"f_6945compiler.scm",(void*)f_6945},
{"f_6954compiler.scm",(void*)f_6954},
{"f_6980compiler.scm",(void*)f_6980},
{"f_6968compiler.scm",(void*)f_6968},
{"f_6921compiler.scm",(void*)f_6921},
{"f_6885compiler.scm",(void*)f_6885},
{"f_6891compiler.scm",(void*)f_6891},
{"f_6760compiler.scm",(void*)f_6760},
{"f_6764compiler.scm",(void*)f_6764},
{"f_6767compiler.scm",(void*)f_6767},
{"f_6821compiler.scm",(void*)f_6821},
{"f_6817compiler.scm",(void*)f_6817},
{"f_6813compiler.scm",(void*)f_6813},
{"f_6792compiler.scm",(void*)f_6792},
{"f_6798compiler.scm",(void*)f_6798},
{"f_6809compiler.scm",(void*)f_6809},
{"f_6802compiler.scm",(void*)f_6802},
{"f_6790compiler.scm",(void*)f_6790},
{"f_6386compiler.scm",(void*)f_6386},
{"f_6408compiler.scm",(void*)f_6408},
{"f_6674compiler.scm",(void*)f_6674},
{"f_6831compiler.scm",(void*)f_6831},
{"f_6834compiler.scm",(void*)f_6834},
{"f_6879compiler.scm",(void*)f_6879},
{"f_6875compiler.scm",(void*)f_6875},
{"f_6871compiler.scm",(void*)f_6871},
{"f_6867compiler.scm",(void*)f_6867},
{"f_6639compiler.scm",(void*)f_6639},
{"f_6665compiler.scm",(void*)f_6665},
{"f_6589compiler.scm",(void*)f_6589},
{"f_6598compiler.scm",(void*)f_6598},
{"f_6626compiler.scm",(void*)f_6626},
{"f_6622compiler.scm",(void*)f_6622},
{"f_6576compiler.scm",(void*)f_6576},
{"f_6514compiler.scm",(void*)f_6514},
{"f_6537compiler.scm",(void*)f_6537},
{"f_6551compiler.scm",(void*)f_6551},
{"f_6420compiler.scm",(void*)f_6420},
{"f_6423compiler.scm",(void*)f_6423},
{"f_6499compiler.scm",(void*)f_6499},
{"f_6495compiler.scm",(void*)f_6495},
{"f_6491compiler.scm",(void*)f_6491},
{"f_6464compiler.scm",(void*)f_6464},
{"f_6475compiler.scm",(void*)f_6475},
{"f_6479compiler.scm",(void*)f_6479},
{"f_6458compiler.scm",(void*)f_6458},
{"f_6424compiler.scm",(void*)f_6424},
{"f_6435compiler.scm",(void*)f_6435},
{"f_6342compiler.scm",(void*)f_6342},
{"f_6346compiler.scm",(void*)f_6346},
{"f_6369compiler.scm",(void*)f_6369},
{"f_6380compiler.scm",(void*)f_6380},
{"f_6363compiler.scm",(void*)f_6363},
{"f_6249compiler.scm",(void*)f_6249},
{"f_6281compiler.scm",(void*)f_6281},
{"f_6300compiler.scm",(void*)f_6300},
{"f_6323compiler.scm",(void*)f_6323},
{"f_6306compiler.scm",(void*)f_6306},
{"f_6252compiler.scm",(void*)f_6252},
{"f_6258compiler.scm",(void*)f_6258},
{"f_6268compiler.scm",(void*)f_6268},
{"f_6168compiler.scm",(void*)f_6168},
{"f_6172compiler.scm",(void*)f_6172},
{"f_6175compiler.scm",(void*)f_6175},
{"f_6178compiler.scm",(void*)f_6178},
{"f_6194compiler.scm",(void*)f_6194},
{"f_6181compiler.scm",(void*)f_6181},
{"f_6184compiler.scm",(void*)f_6184},
{"f_6187compiler.scm",(void*)f_6187},
{"f_6131compiler.scm",(void*)f_6131},
{"f_6154compiler.scm",(void*)f_6154},
{"f_6141compiler.scm",(void*)f_6141},
{"f_6144compiler.scm",(void*)f_6144},
{"f_6147compiler.scm",(void*)f_6147},
{"f_6094compiler.scm",(void*)f_6094},
{"f_6117compiler.scm",(void*)f_6117},
{"f_6104compiler.scm",(void*)f_6104},
{"f_6107compiler.scm",(void*)f_6107},
{"f_6110compiler.scm",(void*)f_6110},
{"f_6049compiler.scm",(void*)f_6049},
{"f_6056compiler.scm",(void*)f_6056},
{"f_6062compiler.scm",(void*)f_6062},
{"f_6004compiler.scm",(void*)f_6004},
{"f_6011compiler.scm",(void*)f_6011},
{"f_6017compiler.scm",(void*)f_6017},
{"f_5850compiler.scm",(void*)f_5850},
{"f_5998compiler.scm",(void*)f_5998},
{"f_5854compiler.scm",(void*)f_5854},
{"f_5857compiler.scm",(void*)f_5857},
{"f_5860compiler.scm",(void*)f_5860},
{"f_5863compiler.scm",(void*)f_5863},
{"f_5866compiler.scm",(void*)f_5866},
{"f_5992compiler.scm",(void*)f_5992},
{"f_5876compiler.scm",(void*)f_5876},
{"f_5967compiler.scm",(void*)f_5967},
{"f_5975compiler.scm",(void*)f_5975},
{"f_5879compiler.scm",(void*)f_5879},
{"f_5919compiler.scm",(void*)f_5919},
{"f_5922compiler.scm",(void*)f_5922},
{"f_5941compiler.scm",(void*)f_5941},
{"f_5937compiler.scm",(void*)f_5937},
{"f_5933compiler.scm",(void*)f_5933},
{"f_5912compiler.scm",(void*)f_5912},
{"f_5902compiler.scm",(void*)f_5902},
{"f_5890compiler.scm",(void*)f_5890},
{"f_5841compiler.scm",(void*)f_5841},
{"f_5832compiler.scm",(void*)f_5832},
{"f_5823compiler.scm",(void*)f_5823},
{"f_5814compiler.scm",(void*)f_5814},
{"f_5805compiler.scm",(void*)f_5805},
{"f_5796compiler.scm",(void*)f_5796},
{"f_5787compiler.scm",(void*)f_5787},
{"f_5778compiler.scm",(void*)f_5778},
{"f_5769compiler.scm",(void*)f_5769},
{"f_5760compiler.scm",(void*)f_5760},
{"f_5751compiler.scm",(void*)f_5751},
{"f_5742compiler.scm",(void*)f_5742},
{"f_5733compiler.scm",(void*)f_5733},
{"f_5724compiler.scm",(void*)f_5724},
{"f_5715compiler.scm",(void*)f_5715},
{"f_5706compiler.scm",(void*)f_5706},
{"f_5700compiler.scm",(void*)f_5700},
{"f_5694compiler.scm",(void*)f_5694},
{"f_4749compiler.scm",(void*)f_4749},
{"f_4803compiler.scm",(void*)f_4803},
{"f_4807compiler.scm",(void*)f_4807},
{"f_5663compiler.scm",(void*)f_5663},
{"f_5673compiler.scm",(void*)f_5673},
{"f_5668compiler.scm",(void*)f_5668},
{"f_5635compiler.scm",(void*)f_5635},
{"f_5641compiler.scm",(void*)f_5641},
{"f_5617compiler.scm",(void*)f_5617},
{"f_5621compiler.scm",(void*)f_5621},
{"f_5589compiler.scm",(void*)f_5589},
{"f_5596compiler.scm",(void*)f_5596},
{"f_5572compiler.scm",(void*)f_5572},
{"f_5498compiler.scm",(void*)f_5498},
{"f_5502compiler.scm",(void*)f_5502},
{"f_5485compiler.scm",(void*)f_5485},
{"f_5477compiler.scm",(void*)f_5477},
{"f_5481compiler.scm",(void*)f_5481},
{"f_5322compiler.scm",(void*)f_5322},
{"f_5432compiler.scm",(void*)f_5432},
{"f_5421compiler.scm",(void*)f_5421},
{"f_5425compiler.scm",(void*)f_5425},
{"f_5392compiler.scm",(void*)f_5392},
{"f_5367compiler.scm",(void*)f_5367},
{"f_5342compiler.scm",(void*)f_5342},
{"f_5309compiler.scm",(void*)f_5309},
{"f_5261compiler.scm",(void*)f_5261},
{"f_5270compiler.scm",(void*)f_5270},
{"f_5268compiler.scm",(void*)f_5268},
{"f_5171compiler.scm",(void*)f_5171},
{"f_5149compiler.scm",(void*)f_5149},
{"f_5153compiler.scm",(void*)f_5153},
{"f_5122compiler.scm",(void*)f_5122},
{"f_5126compiler.scm",(void*)f_5126},
{"f_5108compiler.scm",(void*)f_5108},
{"f_5112compiler.scm",(void*)f_5112},
{"f_5087compiler.scm",(void*)f_5087},
{"f_5073compiler.scm",(void*)f_5073},
{"f_4990compiler.scm",(void*)f_4990},
{"f_4973compiler.scm",(void*)f_4973},
{"f_4977compiler.scm",(void*)f_4977},
{"f_4944compiler.scm",(void*)f_4944},
{"f_4919compiler.scm",(void*)f_4919},
{"f_4872compiler.scm",(void*)f_4872},
{"f_4902compiler.scm",(void*)f_4902},
{"f_4878compiler.scm",(void*)f_4878},
{"f_4881compiler.scm",(void*)f_4881},
{"f_4888compiler.scm",(void*)f_4888},
{"f_4884compiler.scm",(void*)f_4884},
{"f_4822compiler.scm",(void*)f_4822},
{"f_4825compiler.scm",(void*)f_4825},
{"f_4859compiler.scm",(void*)f_4859},
{"f_4853compiler.scm",(void*)f_4853},
{"f_4834compiler.scm",(void*)f_4834},
{"f_4843compiler.scm",(void*)f_4843},
{"f_4851compiler.scm",(void*)f_4851},
{"f_4837compiler.scm",(void*)f_4837},
{"f_4841compiler.scm",(void*)f_4841},
{"f_4813compiler.scm",(void*)f_4813},
{"f_4752compiler.scm",(void*)f_4752},
{"f_4775compiler.scm",(void*)f_4775},
{"f_4765compiler.scm",(void*)f_4765},
{"f_1970compiler.scm",(void*)f_1970},
{"f_4744compiler.scm",(void*)f_4744},
{"f_4707compiler.scm",(void*)f_4707},
{"f_4710compiler.scm",(void*)f_4710},
{"f_4725compiler.scm",(void*)f_4725},
{"f_4734compiler.scm",(void*)f_4734},
{"f_4738compiler.scm",(void*)f_4738},
{"f_4721compiler.scm",(void*)f_4721},
{"f_4694compiler.scm",(void*)f_4694},
{"f_4700compiler.scm",(void*)f_4700},
{"f_2160compiler.scm",(void*)f_2160},
{"f_2197compiler.scm",(void*)f_2197},
{"f_4555compiler.scm",(void*)f_4555},
{"f_4670compiler.scm",(void*)f_4670},
{"f_4570compiler.scm",(void*)f_4570},
{"f_4657compiler.scm",(void*)f_4657},
{"f_4579compiler.scm",(void*)f_4579},
{"f_4582compiler.scm",(void*)f_4582},
{"f_4591compiler.scm",(void*)f_4591},
{"f_4613compiler.scm",(void*)f_4613},
{"f_4606compiler.scm",(void*)f_4606},
{"f_4558compiler.scm",(void*)f_4558},
{"f_4561compiler.scm",(void*)f_4561},
{"f_2224compiler.scm",(void*)f_2224},
{"f_2230compiler.scm",(void*)f_2230},
{"f_4537compiler.scm",(void*)f_4537},
{"f_2233compiler.scm",(void*)f_2233},
{"f_2240compiler.scm",(void*)f_2240},
{"f_2249compiler.scm",(void*)f_2249},
{"f_2258compiler.scm",(void*)f_2258},
{"f_2392compiler.scm",(void*)f_2392},
{"f_4457compiler.scm",(void*)f_4457},
{"f_4463compiler.scm",(void*)f_4463},
{"f_4368compiler.scm",(void*)f_4368},
{"f_4428compiler.scm",(void*)f_4428},
{"f_4328compiler.scm",(void*)f_4328},
{"f_4332compiler.scm",(void*)f_4332},
{"f_4338compiler.scm",(void*)f_4338},
{"f_4352compiler.scm",(void*)f_4352},
{"f_4341compiler.scm",(void*)f_4341},
{"f_3964compiler.scm",(void*)f_3964},
{"f_4312compiler.scm",(void*)f_4312},
{"f_3986compiler.scm",(void*)f_3986},
{"f_4277compiler.scm",(void*)f_4277},
{"f_3989compiler.scm",(void*)f_3989},
{"f_4000compiler.scm",(void*)f_4000},
{"f_4227compiler.scm",(void*)f_4227},
{"f_4271compiler.scm",(void*)f_4271},
{"f_4267compiler.scm",(void*)f_4267},
{"f_4263compiler.scm",(void*)f_4263},
{"f_4251compiler.scm",(void*)f_4251},
{"f_4020compiler.scm",(void*)f_4020},
{"f_4099compiler.scm",(void*)f_4099},
{"f_4076compiler.scm",(void*)f_4076},
{"f_4071compiler.scm",(void*)f_4071},
{"f_4034compiler.scm",(void*)f_4034},
{"f_4024compiler.scm",(void*)f_4024},
{"f_4008compiler.scm",(void*)f_4008},
{"f_3996compiler.scm",(void*)f_3996},
{"f_3954compiler.scm",(void*)f_3954},
{"f_3931compiler.scm",(void*)f_3931},
{"f_3929compiler.scm",(void*)f_3929},
{"f_3858compiler.scm",(void*)f_3858},
{"f_3876compiler.scm",(void*)f_3876},
{"f_3898compiler.scm",(void*)f_3898},
{"f_3904compiler.scm",(void*)f_3904},
{"f_3882compiler.scm",(void*)f_3882},
{"f_3889compiler.scm",(void*)f_3889},
{"f_3864compiler.scm",(void*)f_3864},
{"f_3870compiler.scm",(void*)f_3870},
{"f_3856compiler.scm",(void*)f_3856},
{"f_3794compiler.scm",(void*)f_3794},
{"f_3805compiler.scm",(void*)f_3805},
{"f_3815compiler.scm",(void*)f_3815},
{"f_3818compiler.scm",(void*)f_3818},
{"f_3822compiler.scm",(void*)f_3822},
{"f_3808compiler.scm",(void*)f_3808},
{"f_3733compiler.scm",(void*)f_3733},
{"f_3737compiler.scm",(void*)f_3737},
{"f_3775compiler.scm",(void*)f_3775},
{"f_3741compiler.scm",(void*)f_3741},
{"f_3755compiler.scm",(void*)f_3755},
{"f_3753compiler.scm",(void*)f_3753},
{"f_3715compiler.scm",(void*)f_3715},
{"f_3723compiler.scm",(void*)f_3723},
{"f_3588compiler.scm",(void*)f_3588},
{"f_3591compiler.scm",(void*)f_3591},
{"f_3597compiler.scm",(void*)f_3597},
{"f_3676compiler.scm",(void*)f_3676},
{"f_3653compiler.scm",(void*)f_3653},
{"f_3628compiler.scm",(void*)f_3628},
{"f_3636compiler.scm",(void*)f_3636},
{"f_3624compiler.scm",(void*)f_3624},
{"f_3620compiler.scm",(void*)f_3620},
{"f_3612compiler.scm",(void*)f_3612},
{"f_3513compiler.scm",(void*)f_3513},
{"f_3522compiler.scm",(void*)f_3522},
{"f_3561compiler.scm",(void*)f_3561},
{"f_3553compiler.scm",(void*)f_3553},
{"f_3525compiler.scm",(void*)f_3525},
{"f_3545compiler.scm",(void*)f_3545},
{"f_3537compiler.scm",(void*)f_3537},
{"f_3493compiler.scm",(void*)f_3493},
{"f_3439compiler.scm",(void*)f_3439},
{"f_3442compiler.scm",(void*)f_3442},
{"f_3445compiler.scm",(void*)f_3445},
{"f_3449compiler.scm",(void*)f_3449},
{"f_3453compiler.scm",(void*)f_3453},
{"f_3372compiler.scm",(void*)f_3372},
{"f_3384compiler.scm",(void*)f_3384},
{"f_3357compiler.scm",(void*)f_3357},
{"f_3344compiler.scm",(void*)f_3344},
{"f_3331compiler.scm",(void*)f_3331},
{"f_3318compiler.scm",(void*)f_3318},
{"f_3305compiler.scm",(void*)f_3305},
{"f_3238compiler.scm",(void*)f_3238},
{"f_3257compiler.scm",(void*)f_3257},
{"f_3284compiler.scm",(void*)f_3284},
{"f_3288compiler.scm",(void*)f_3288},
{"f_3277compiler.scm",(void*)f_3277},
{"f_3251compiler.scm",(void*)f_3251},
{"f_3225compiler.scm",(void*)f_3225},
{"f_3210compiler.scm",(void*)f_3210},
{"f_3183compiler.scm",(void*)f_3183},
{"f_3187compiler.scm",(void*)f_3187},
{"f_3162compiler.scm",(void*)f_3162},
{"f_3133compiler.scm",(void*)f_3133},
{"f_3137compiler.scm",(void*)f_3137},
{"f_3104compiler.scm",(void*)f_3104},
{"f_3108compiler.scm",(void*)f_3108},
{"f_2930compiler.scm",(void*)f_2930},
{"f_2939compiler.scm",(void*)f_2939},
{"f_2942compiler.scm",(void*)f_2942},
{"f_3050compiler.scm",(void*)f_3050},
{"f_3079compiler.scm",(void*)f_3079},
{"f_3083compiler.scm",(void*)f_3083},
{"f_3053compiler.scm",(void*)f_3053},
{"f_3059compiler.scm",(void*)f_3059},
{"f_3072compiler.scm",(void*)f_3072},
{"f_3062compiler.scm",(void*)f_3062},
{"f_2945compiler.scm",(void*)f_2945},
{"f_3040compiler.scm",(void*)f_3040},
{"f_2948compiler.scm",(void*)f_2948},
{"f_3003compiler.scm",(void*)f_3003},
{"f_3034compiler.scm",(void*)f_3034},
{"f_3026compiler.scm",(void*)f_3026},
{"f_2960compiler.scm",(void*)f_2960},
{"f_2991compiler.scm",(void*)f_2991},
{"f_2979compiler.scm",(void*)f_2979},
{"f_2892compiler.scm",(void*)f_2892},
{"f_2918compiler.scm",(void*)f_2918},
{"f_2895compiler.scm",(void*)f_2895},
{"f_2910compiler.scm",(void*)f_2910},
{"f_2908compiler.scm",(void*)f_2908},
{"f_2898compiler.scm",(void*)f_2898},
{"f_2901compiler.scm",(void*)f_2901},
{"f_2627compiler.scm",(void*)f_2627},
{"f_2842compiler.scm",(void*)f_2842},
{"f_2853compiler.scm",(void*)f_2853},
{"f_2847compiler.scm",(void*)f_2847},
{"f_2636compiler.scm",(void*)f_2636},
{"f_2641compiler.scm",(void*)f_2641},
{"f_2645compiler.scm",(void*)f_2645},
{"f_2839compiler.scm",(void*)f_2839},
{"f_2648compiler.scm",(void*)f_2648},
{"f_2831compiler.scm",(void*)f_2831},
{"f_2651compiler.scm",(void*)f_2651},
{"f_2654compiler.scm",(void*)f_2654},
{"f_2829compiler.scm",(void*)f_2829},
{"f_2822compiler.scm",(void*)f_2822},
{"f_2657compiler.scm",(void*)f_2657},
{"f_2663compiler.scm",(void*)f_2663},
{"f_2672compiler.scm",(void*)f_2672},
{"f_2692compiler.scm",(void*)f_2692},
{"f_2776compiler.scm",(void*)f_2776},
{"f_2772compiler.scm",(void*)f_2772},
{"f_2768compiler.scm",(void*)f_2768},
{"f_2725compiler.scm",(void*)f_2725},
{"f_2732compiler.scm",(void*)f_2732},
{"f_2682compiler.scm",(void*)f_2682},
{"f_2553compiler.scm",(void*)f_2553},
{"f_2559compiler.scm",(void*)f_2559},
{"f_2562compiler.scm",(void*)f_2562},
{"f_2615compiler.scm",(void*)f_2615},
{"f_2565compiler.scm",(void*)f_2565},
{"f_2568compiler.scm",(void*)f_2568},
{"f_2595compiler.scm",(void*)f_2595},
{"f_2603compiler.scm",(void*)f_2603},
{"f_2575compiler.scm",(void*)f_2575},
{"f_2589compiler.scm",(void*)f_2589},
{"f_2583compiler.scm",(void*)f_2583},
{"f_2579compiler.scm",(void*)f_2579},
{"f_2439compiler.scm",(void*)f_2439},
{"f_2449compiler.scm",(void*)f_2449},
{"f_2460compiler.scm",(void*)f_2460},
{"f_2534compiler.scm",(void*)f_2534},
{"f_2544compiler.scm",(void*)f_2544},
{"f_2525compiler.scm",(void*)f_2525},
{"f_2499compiler.scm",(void*)f_2499},
{"f_2513compiler.scm",(void*)f_2513},
{"f_2511compiler.scm",(void*)f_2511},
{"f_2487compiler.scm",(void*)f_2487},
{"f_2464compiler.scm",(void*)f_2464},
{"f_2471compiler.scm",(void*)f_2471},
{"f_2454compiler.scm",(void*)f_2454},
{"f_2433compiler.scm",(void*)f_2433},
{"f_2401compiler.scm",(void*)f_2401},
{"f_2404compiler.scm",(void*)f_2404},
{"f_2415compiler.scm",(void*)f_2415},
{"f_2409compiler.scm",(void*)f_2409},
{"f_2407compiler.scm",(void*)f_2407},
{"f_2359compiler.scm",(void*)f_2359},
{"f_2371compiler.scm",(void*)f_2371},
{"f_2375compiler.scm",(void*)f_2375},
{"f_2327compiler.scm",(void*)f_2327},
{"f_2281compiler.scm",(void*)f_2281},
{"f_2288compiler.scm",(void*)f_2288},
{"f_2292compiler.scm",(void*)f_2292},
{"f_2296compiler.scm",(void*)f_2296},
{"f_2185compiler.scm",(void*)f_2185},
{"f_2179compiler.scm",(void*)f_2179},
{"f_2142compiler.scm",(void*)f_2142},
{"f_2151compiler.scm",(void*)f_2151},
{"f_2051compiler.scm",(void*)f_2051},
{"f_2055compiler.scm",(void*)f_2055},
{"f_2068compiler.scm",(void*)f_2068},
{"f_2116compiler.scm",(void*)f_2116},
{"f_2126compiler.scm",(void*)f_2126},
{"f_2086compiler.scm",(void*)f_2086},
{"f_2096compiler.scm",(void*)f_2096},
{"f_2009compiler.scm",(void*)f_2009},
{"f_2016compiler.scm",(void*)f_2016},
{"f_1985compiler.scm",(void*)f_1985},
{"f_1991compiler.scm",(void*)f_1991},
{"f_1973compiler.scm",(void*)f_1973},
{"f_1899compiler.scm",(void*)f_1899},
{"f_1968compiler.scm",(void*)f_1968},
{"f_1903compiler.scm",(void*)f_1903},
{"f_1961compiler.scm",(void*)f_1961},
{"f_1906compiler.scm",(void*)f_1906},
{"f_1954compiler.scm",(void*)f_1954},
{"f_1909compiler.scm",(void*)f_1909},
{"f_1913compiler.scm",(void*)f_1913},
{"f_1917compiler.scm",(void*)f_1917},
{"f_1947compiler.scm",(void*)f_1947},
{"f_1920compiler.scm",(void*)f_1920},
{"f_1940compiler.scm",(void*)f_1940},
{"f_1923compiler.scm",(void*)f_1923},
{"f_1933compiler.scm",(void*)f_1933},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
