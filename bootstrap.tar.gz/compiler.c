/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-12-23 00:26
   Version 2.737 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann	compiled 2007-12-09 on o317b.o.pppool.de (Darwin)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[582];


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_ccall f_11148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11151)
static void C_ccall f_11151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_fcall f_10952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10958)
static void C_ccall f_10958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10185)
static void C_fcall f_10185(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10851)
static void C_fcall f_10851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10915)
static void C_ccall f_10915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10909)
static void C_ccall f_10909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10872)
static void C_fcall f_10872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10875)
static void C_ccall f_10875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10823)
static void C_fcall f_10823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10826)
static void C_ccall f_10826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10780)
static void C_ccall f_10780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10792)
static void C_fcall f_10792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_fcall f_10783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10786)
static void C_ccall f_10786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10761)
static void C_ccall f_10761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10688)
static void C_ccall f_10688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_fcall f_10694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10635)
static void C_ccall f_10635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10623)
static void C_ccall f_10623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_ccall f_10435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10556)
static void C_ccall f_10556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_fcall f_10568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10442)
static void C_ccall f_10442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10445)
static void C_ccall f_10445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10448)
static void C_ccall f_10448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10515)
static void C_ccall f_10515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10496)
static void C_fcall f_10496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10473)
static void C_ccall f_10473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10379)
static void C_ccall f_10379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_fcall f_10388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10382)
static void C_fcall f_10382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10336)
static void C_ccall f_10336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10319)
static void C_ccall f_10319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10315)
static void C_ccall f_10315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10291)
static void C_ccall f_10291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10098)
static void C_fcall f_10098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10102)
static void C_ccall f_10102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10117)
static void C_ccall f_10117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10132)
static void C_fcall f_10132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_ccall f_10136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_fcall f_10142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10152)
static void C_ccall f_10152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10964)
static void C_fcall f_10964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10971)
static void C_ccall f_10971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11026)
static void C_ccall f_11026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10977)
static void C_ccall f_10977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10993)
static void C_ccall f_10993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_fcall f_11058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11074)
static void C_ccall f_11074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11081)
static void C_ccall f_11081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11088)
static void C_ccall f_11088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11072)
static void C_ccall f_11072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_fcall f_11044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11090)
static void C_fcall f_11090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11094)
static void C_ccall f_11094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10077)
static void C_ccall f_10077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10068)
static void C_ccall f_10068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10050)
static void C_ccall f_10050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10032)
static void C_ccall f_10032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10014)
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10005)
static void C_ccall f_10005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9969)
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9960)
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9951)
static void C_ccall f_9951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9942)
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9915)
static void C_ccall f_9915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9906)
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9897)
static void C_ccall f_9897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9825)
static void C_ccall f_9825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9819)
static void C_ccall f_9819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9813)
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9780)
static void C_ccall f_9780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9807)
static void C_ccall f_9807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9805)
static void C_ccall f_9805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9632)
static void C_fcall f_9632(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8943)
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8962)
static void C_fcall f_8962(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_fcall f_8995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_fcall f_9511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9362)
static void C_ccall f_9362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9368)
static void C_ccall f_9368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9340)
static void C_ccall f_9340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9095)
static void C_ccall f_9095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9119)
static void C_fcall f_9119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_ccall f_9308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9266)
static void C_ccall f_9266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9221)
static void C_ccall f_9221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9192)
static void C_ccall f_9192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9159)
static void C_ccall f_9159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9644)
static void C_fcall f_9644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_fcall f_8609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8628)
static void C_fcall f_8628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8907)
static void C_ccall f_8907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9683)
static void C_ccall f_9683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9721)
static void C_fcall f_9721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9733)
static void C_fcall f_9733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9712)
static void C_ccall f_9712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9681)
static void C_ccall f_9681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_ccall f_8881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8895)
static void C_ccall f_8895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8832)
static void C_ccall f_8832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_fcall f_8730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_fcall f_8748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_fcall f_8766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8718)
static void C_fcall f_8718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8708)
static void C_fcall f_8708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_ccall f_8691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_fcall f_8598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8588)
static void C_fcall f_8588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8582)
static void C_fcall f_8582(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_ccall f_7831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8431)
static void C_fcall f_8431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_fcall f_8377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_ccall f_8380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8392)
static void C_fcall f_8392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8386)
static void C_fcall f_8386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8326)
static void C_fcall f_8326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8282)
static void C_fcall f_8282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8294)
static void C_fcall f_8294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8183)
static void C_fcall f_8183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_fcall f_8251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8211)
static void C_fcall f_8211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_fcall f_8147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_fcall f_8135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_fcall f_8120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_fcall f_8041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8044)
static void C_ccall f_8044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_fcall f_7891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_fcall f_7912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7933)
static void C_fcall f_7933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_fcall f_7872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_fcall f_7828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_fcall f_7783(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7801)
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7769)
static void C_fcall f_7769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7777)
static void C_ccall f_7777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7648)
static void C_fcall f_7648(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7067)
static void C_fcall f_7067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7089)
static void C_fcall f_7089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_ccall f_7610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_fcall f_7525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_fcall f_7540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_fcall f_7531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7386)
static void C_ccall f_7386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_fcall f_7405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_fcall f_7438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_fcall f_7408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7435)
static void C_ccall f_7435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_fcall f_7660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7673)
static void C_fcall f_7673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_fcall f_7682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_fcall f_7763(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7060)
static C_word C_fcall f_7060(C_word t0);
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6839)
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6845)
static void C_fcall f_6845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_fcall f_6823(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6698)
static void C_fcall f_6698(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_fcall f_6324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6346)
static void C_fcall f_6346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_fcall f_6612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_fcall f_6452(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_fcall f_6280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_fcall f_6190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6196)
static void C_fcall f_6196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6110)
static void C_fcall f_6110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_fcall f_6116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6132)
static void C_ccall f_6132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_fcall f_5814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4741)
static void C_fcall f_4741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_fcall f_5415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_fcall f_5109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_fcall f_4826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_fcall f_4703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_fcall f_4508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_fcall f_4529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_fcall f_2335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_fcall f_4266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_fcall f_4215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static C_word C_fcall f_4014(C_word *a,C_word t0);
C_noret_decl(f_4009)
static void C_fcall f_4009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static C_word C_fcall f_3972(C_word *a,C_word t0);
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_fcall f_3557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_fcall f_3454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_fcall f_2982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_fcall f_2751(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_fcall f_2635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_fcall f_2668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1984)
static void C_fcall f_1984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_fcall f_1953(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1941)
static C_word C_fcall f_1941(C_word t0,C_word t1);
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10952)
static void C_fcall trf_10952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10952(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10952(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10185)
static void C_fcall trf_10185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10185(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10185(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10851)
static void C_fcall trf_10851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10851(t0,t1);}

C_noret_decl(trf_10872)
static void C_fcall trf_10872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10872(t0,t1);}

C_noret_decl(trf_10823)
static void C_fcall trf_10823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10823(t0,t1);}

C_noret_decl(trf_10792)
static void C_fcall trf_10792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10792(t0,t1);}

C_noret_decl(trf_10783)
static void C_fcall trf_10783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10783(t0,t1);}

C_noret_decl(trf_10694)
static void C_fcall trf_10694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10694(t0,t1);}

C_noret_decl(trf_10568)
static void C_fcall trf_10568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10568(t0,t1);}

C_noret_decl(trf_10496)
static void C_fcall trf_10496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10496(t0,t1);}

C_noret_decl(trf_10388)
static void C_fcall trf_10388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10388(t0,t1);}

C_noret_decl(trf_10382)
static void C_fcall trf_10382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10382(t0,t1);}

C_noret_decl(trf_10098)
static void C_fcall trf_10098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10098(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10098(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10132)
static void C_fcall trf_10132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10132(t0,t1,t2,t3);}

C_noret_decl(trf_10142)
static void C_fcall trf_10142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10142(t0,t1);}

C_noret_decl(trf_10964)
static void C_fcall trf_10964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10964(t0,t1,t2);}

C_noret_decl(trf_11058)
static void C_fcall trf_11058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11058(t0,t1,t2);}

C_noret_decl(trf_11044)
static void C_fcall trf_11044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11044(t0,t1,t2);}

C_noret_decl(trf_11090)
static void C_fcall trf_11090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11090(t0,t1);}

C_noret_decl(trf_9632)
static void C_fcall trf_9632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9632(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9632(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8943)
static void C_fcall trf_8943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8943(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8943(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8962)
static void C_fcall trf_8962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8962(t0,t1);}

C_noret_decl(trf_8995)
static void C_fcall trf_8995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8995(t0,t1);}

C_noret_decl(trf_9511)
static void C_fcall trf_9511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9511(t0,t1);}

C_noret_decl(trf_9119)
static void C_fcall trf_9119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9119(t0,t1);}

C_noret_decl(trf_9644)
static void C_fcall trf_9644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9644(t0,t1,t2,t3);}

C_noret_decl(trf_8609)
static void C_fcall trf_8609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8609(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8609(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8628)
static void C_fcall trf_8628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8628(t0,t1);}

C_noret_decl(trf_9721)
static void C_fcall trf_9721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9721(t0,t1);}

C_noret_decl(trf_9733)
static void C_fcall trf_9733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9733(t0,t1);}

C_noret_decl(trf_8730)
static void C_fcall trf_8730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8730(t0,t1);}

C_noret_decl(trf_8748)
static void C_fcall trf_8748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8748(t0,t1);}

C_noret_decl(trf_8766)
static void C_fcall trf_8766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8766(t0,t1);}

C_noret_decl(trf_8718)
static void C_fcall trf_8718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8718(t0,t1);}

C_noret_decl(trf_8708)
static void C_fcall trf_8708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8708(t0,t1);}

C_noret_decl(trf_8598)
static void C_fcall trf_8598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8598(t0,t1,t2);}

C_noret_decl(trf_8588)
static void C_fcall trf_8588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8588(t0,t1,t2,t3);}

C_noret_decl(trf_8582)
static void C_fcall trf_8582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8582(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8582(t0,t1,t2,t3);}

C_noret_decl(trf_8431)
static void C_fcall trf_8431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8431(t0,t1);}

C_noret_decl(trf_8377)
static void C_fcall trf_8377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8377(t0,t1);}

C_noret_decl(trf_8392)
static void C_fcall trf_8392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8392(t0,t1);}

C_noret_decl(trf_8386)
static void C_fcall trf_8386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8386(t0,t1);}

C_noret_decl(trf_8326)
static void C_fcall trf_8326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8326(t0,t1);}

C_noret_decl(trf_8282)
static void C_fcall trf_8282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8282(t0,t1);}

C_noret_decl(trf_8294)
static void C_fcall trf_8294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8294(t0,t1);}

C_noret_decl(trf_8183)
static void C_fcall trf_8183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8183(t0,t1);}

C_noret_decl(trf_8251)
static void C_fcall trf_8251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8251(t0,t1);}

C_noret_decl(trf_8211)
static void C_fcall trf_8211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8211(t0,t1);}

C_noret_decl(trf_8147)
static void C_fcall trf_8147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8147(t0,t1);}

C_noret_decl(trf_8135)
static void C_fcall trf_8135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8135(t0,t1);}

C_noret_decl(trf_8120)
static void C_fcall trf_8120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8120(t0,t1);}

C_noret_decl(trf_8041)
static void C_fcall trf_8041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8041(t0,t1);}

C_noret_decl(trf_7891)
static void C_fcall trf_7891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7891(t0,t1);}

C_noret_decl(trf_7912)
static void C_fcall trf_7912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7912(t0,t1);}

C_noret_decl(trf_7933)
static void C_fcall trf_7933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7933(t0,t1);}

C_noret_decl(trf_7872)
static void C_fcall trf_7872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7872(t0,t1);}

C_noret_decl(trf_7828)
static void C_fcall trf_7828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7828(t0,t1);}

C_noret_decl(trf_7783)
static void C_fcall trf_7783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7783(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7783(t0,t1,t2,t3);}

C_noret_decl(trf_7769)
static void C_fcall trf_7769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7769(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7769(t0,t1,t2,t3);}

C_noret_decl(trf_7648)
static void C_fcall trf_7648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7648(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7648(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7067)
static void C_fcall trf_7067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7067(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7067(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7089)
static void C_fcall trf_7089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7089(t0,t1);}

C_noret_decl(trf_7525)
static void C_fcall trf_7525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7525(t0,t1);}

C_noret_decl(trf_7540)
static void C_fcall trf_7540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7540(t0,t1);}

C_noret_decl(trf_7531)
static void C_fcall trf_7531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7531(t0,t1);}

C_noret_decl(trf_7405)
static void C_fcall trf_7405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7405(t0,t1);}

C_noret_decl(trf_7438)
static void C_fcall trf_7438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7438(t0,t1);}

C_noret_decl(trf_7408)
static void C_fcall trf_7408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7408(t0,t1);}

C_noret_decl(trf_7280)
static void C_fcall trf_7280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7280(t0,t1,t2,t3);}

C_noret_decl(trf_7660)
static void C_fcall trf_7660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7660(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7660(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7673)
static void C_fcall trf_7673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7673(t0,t1);}

C_noret_decl(trf_7682)
static void C_fcall trf_7682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7682(t0,t1);}

C_noret_decl(trf_7763)
static void C_fcall trf_7763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7763(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7763(t0,t1,t2,t3);}

C_noret_decl(trf_6839)
static void C_fcall trf_6839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6839(t0,t1,t2,t3);}

C_noret_decl(trf_6845)
static void C_fcall trf_6845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6845(t0,t1,t2,t3);}

C_noret_decl(trf_6823)
static void C_fcall trf_6823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6823(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6823(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6698)
static void C_fcall trf_6698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6698(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6698(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6324)
static void C_fcall trf_6324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6324(t0,t1,t2,t3);}

C_noret_decl(trf_6346)
static void C_fcall trf_6346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6346(t0,t1);}

C_noret_decl(trf_6612)
static void C_fcall trf_6612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6612(t0,t1);}

C_noret_decl(trf_6452)
static void C_fcall trf_6452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6452(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6452(t0,t1,t2,t3);}

C_noret_decl(trf_6280)
static void C_fcall trf_6280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6280(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6280(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6219(t0,t1,t2);}

C_noret_decl(trf_6190)
static void C_fcall trf_6190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6190(t0,t1,t2);}

C_noret_decl(trf_6196)
static void C_fcall trf_6196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6196(t0,t1,t2);}

C_noret_decl(trf_6110)
static void C_fcall trf_6110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6110(t0,t1);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6113(t0,t1);}

C_noret_decl(trf_6116)
static void C_fcall trf_6116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6116(t0,t1);}

C_noret_decl(trf_5814)
static void C_fcall trf_5814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5814(t0,t1);}

C_noret_decl(trf_4741)
static void C_fcall trf_4741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4741(t0,t1);}

C_noret_decl(trf_5415)
static void C_fcall trf_5415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5415(t0,t1);}

C_noret_decl(trf_5109)
static void C_fcall trf_5109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5109(t0,t1);}

C_noret_decl(trf_4826)
static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4826(t0,t1);}

C_noret_decl(trf_4690)
static void C_fcall trf_4690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4690(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4690(t0,t1,t2,t3);}

C_noret_decl(trf_4703)
static void C_fcall trf_4703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4703(t0,t1);}

C_noret_decl(trf_4632)
static void C_fcall trf_4632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4632(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4632(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2110(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4508)
static void C_fcall trf_4508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4508(t0,t1);}

C_noret_decl(trf_4529)
static void C_fcall trf_4529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4529(t0,t1);}

C_noret_decl(trf_2335)
static void C_fcall trf_2335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2335(t0,t1);}

C_noret_decl(trf_4266)
static void C_fcall trf_4266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4266(t0,t1);}

C_noret_decl(trf_4215)
static void C_fcall trf_4215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4215(t0,t1);}

C_noret_decl(trf_4165)
static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4165(t0,t1,t2,t3);}

C_noret_decl(trf_4009)
static void C_fcall trf_4009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4009(t0,t1);}

C_noret_decl(trf_3557)
static void C_fcall trf_3557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3557(t0,t1);}

C_noret_decl(trf_3454)
static void C_fcall trf_3454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3454(t0,t1);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3186(t0,t1,t2);}

C_noret_decl(trf_2982)
static void C_fcall trf_2982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2982(t0,t1);}

C_noret_decl(trf_2751)
static void C_fcall trf_2751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2751(t0,t1);}

C_noret_decl(trf_2635)
static void C_fcall trf_2635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2635(t0,t1);}

C_noret_decl(trf_2668)
static void C_fcall trf_2668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2668(t0,t1);}

C_noret_decl(trf_2625)
static void C_fcall trf_2625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2625(t0,t1,t2);}

C_noret_decl(trf_2382)
static void C_fcall trf_2382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2382(t0,t1,t2);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2430(t0,t1);}

C_noret_decl(trf_2019)
static void C_fcall trf_2019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2019(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2019(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1984)
static void C_fcall trf_1984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1984(t0,t1);}

C_noret_decl(trf_1953)
static void C_fcall trf_1953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1953(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1953(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5622)){
C_save(t1);
C_rereclaim2(5622*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,582);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],28,"\010compilerinitialize-compiler");
lf[94]=C_h_intern(&lf[94],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],11,"make-vector");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],25,"\010compilermake-random-name");
lf[99]=C_h_intern(&lf[99],12,"profile-info");
lf[100]=C_h_intern(&lf[100],32,"\010compilercanonicalize-expression");
lf[101]=C_h_intern(&lf[101],23,"\010compilerset-real-name!");
lf[102]=C_h_intern(&lf[102],8,"for-each");
lf[103]=C_h_intern(&lf[103],5,"quote");
lf[104]=C_h_intern(&lf[104],15,"\004coreinline_ref");
lf[105]=C_h_intern(&lf[105],36,"\010compilerforeign-type-convert-result");
lf[106]=C_h_intern(&lf[106],30,"\010compilerfinish-foreign-result");
lf[107]=C_h_intern(&lf[107],27,"\010compilerfinal-foreign-type");
lf[108]=C_h_intern(&lf[108],19,"\004coreinline_loc_ref");
lf[109]=C_h_intern(&lf[109],18,"\003syshash-table-ref");
lf[110]=C_h_intern(&lf[110],21,"\003sysalias-global-hook");
lf[111]=C_h_intern(&lf[111],12,"syntax-error");
lf[112]=C_static_string(C_heaptop,19,"illegal atomic form");
lf[113]=C_h_intern(&lf[113],24,"\003syssyntax-error-culprit");
lf[114]=C_h_intern(&lf[114],2,"if");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[115]=C_h_pair(C_restore,tmp);
lf[116]=C_h_intern(&lf[116],16,"\003syscheck-syntax");
tmp=C_intern(C_heaptop,2,"if");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
lf[117]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[118]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[119]=C_h_intern(&lf[119],10,"\004corecheck");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_TRUE;
C_save(tmp);
lf[120]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[121]=C_h_intern(&lf[121],14,"\004coreimmutable");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],6,"gensym");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],6,"cadadr");
lf[126]=C_h_intern(&lf[126],14,"\004coreundefined");
lf[127]=C_h_intern(&lf[127],23,"\004corerequire-for-syntax");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[128]=C_h_pair(C_restore,tmp);
lf[129]=C_h_intern(&lf[129],10,"lset-union");
lf[130]=C_h_intern(&lf[130],18,"hash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[136]=C_h_pair(C_restore,tmp);
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_static_string(C_heaptop,41,"extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
tmp=C_intern(C_heaptop,3,"let");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[158]=C_h_pair(C_restore,tmp);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[172]=C_h_pair(C_restore,tmp);
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_static_string(C_heaptop,26,"assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_static_string(C_heaptop,43,"assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_static_string(C_heaptop,10,"in line ~S");
lf[189]=C_static_string(C_heaptop,0,"");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[193]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[200]=C_h_pair(C_restore,tmp);
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[202]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[203]=C_h_pair(C_restore,tmp);
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[215]=C_h_pair(C_restore,tmp);
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[220]=C_h_pair(C_restore,tmp);
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[223]=C_h_pair(C_restore,tmp);
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_static_string(C_heaptop,1,"&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_static_string(C_heaptop,16,"C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[235]=C_h_pair(C_restore,tmp);
lf[236]=C_static_string(C_heaptop,8,"constant");
lf[237]=C_h_intern(&lf[237],5,"const");
lf[238]=C_static_string(C_heaptop,64,"value for constant binding appears not to be a valid literal: ~s");
lf[239]=C_h_intern(&lf[239],23,"\010compilerbasic-literal\077");
lf[240]=C_h_intern(&lf[240],29,"\010compilercollapsable-literal\077");
lf[241]=C_h_intern(&lf[241],4,"quit");
lf[242]=C_static_string(C_heaptop,56,"error in constant evaluation of ~S for named constant ~S");
lf[243]=C_h_intern(&lf[243],22,"with-exception-handler");
lf[244]=C_h_intern(&lf[244],30,"call-with-current-continuation");
lf[245]=C_h_intern(&lf[245],12,"\004coredeclare");
lf[246]=C_h_intern(&lf[246],28,"\010compilerprocess-declaration");
lf[247]=C_h_intern(&lf[247],29,"\004coreforeign-callback-wrapper");
lf[248]=C_h_intern(&lf[248],8,"split-at");
lf[249]=C_h_intern(&lf[249],1,"r");
lf[250]=C_h_intern(&lf[250],17,"\003sysmake-c-string");
lf[251]=C_h_intern(&lf[251],3,"and");
lf[252]=C_static_string(C_heaptop,47,"not a valid result type for callback procedures");
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"nonnull-c-string");
C_save(tmp);
lf[253]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,25,"nonnull-unsigned-c-string");
C_save(tmp);
lf[254]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[255]=C_h_intern(&lf[255],25,"nonnull-unsigned-c-string");
lf[256]=C_h_intern(&lf[256],16,"nonnull-c-string");
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"c-string*");
C_save(tmp);
lf[257]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"unsigned-c-string*");
C_save(tmp);
lf[258]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[259]=C_h_intern(&lf[259],18,"unsigned-c-string*");
lf[260]=C_h_intern(&lf[260],9,"c-string*");
lf[261]=C_h_intern(&lf[261],13,"c-string-list");
lf[262]=C_h_intern(&lf[262],14,"c-string-list*");
lf[263]=C_h_intern(&lf[263],8,"c-string");
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,17,"unsigned-c-string");
C_save(tmp);
lf[264]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[265]=C_h_intern(&lf[265],17,"unsigned-c-string");
tmp=C_intern(C_heaptop,5,"const");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"c-string");
C_save(tmp);
lf[266]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[267]=C_static_string(C_heaptop,65,"non-matching or invalid argument list to foreign callback-wrapper");
lf[268]=C_static_string(C_heaptop,60,"name `~S\047 of external definition is not a valid C identifier");
lf[269]=C_h_intern(&lf[269],28,"\010compilervalid-c-identifier\077");
lf[270]=C_h_intern(&lf[270],8,"location");
lf[271]=C_h_intern(&lf[271],17,"\003sysmake-locative");
tmp=C_intern(C_heaptop,8,"location");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[272]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[273]=C_h_intern(&lf[273],13,"\004corecallunit");
lf[274]=C_h_intern(&lf[274],14,"\004coreprimitive");
lf[275]=C_h_intern(&lf[275],37,"\010compilerupdate-line-number-database!");
lf[276]=C_h_intern(&lf[276],23,"\003sysmacroexpand-1-local");
lf[277]=C_static_string(C_heaptop,35,"(in line ~s) - malformed expression");
lf[278]=C_static_string(C_heaptop,20,"malformed expression");
lf[279]=C_h_intern(&lf[279],31,"\010compileremit-syntax-trace-info");
lf[280]=C_static_string(C_heaptop,32,"literal in operator position: ~S");
lf[281]=C_h_intern(&lf[281],4,"list");
lf[282]=C_h_intern(&lf[282],1,"t");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[283]=C_h_pair(C_restore,tmp);
lf[284]=C_h_intern(&lf[284],4,"caar");
lf[285]=C_h_intern(&lf[285],18,"\010compilerconstant\077");
lf[286]=C_static_string(C_heaptop,20,"malformed expression");
lf[287]=C_h_intern(&lf[287],26,"\010compilerinternal-bindings");
lf[288]=C_h_intern(&lf[288],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[289]=C_h_intern(&lf[289],7,"reverse");
lf[290]=C_h_intern(&lf[290],22,"\003sysclear-trace-buffer");
lf[291]=C_h_intern(&lf[291],26,"\010compilerdebugging-chicken");
lf[292]=C_h_intern(&lf[292],12,"pretty-print");
lf[293]=C_h_intern(&lf[293],7,"newline");
lf[294]=C_static_string(C_heaptop,19,"invalid declaration");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[295]=C_h_pair(C_restore,tmp);
lf[296]=C_h_intern(&lf[296],4,"uses");
lf[297]=C_h_intern(&lf[297],29,"\010compilerstring->c-identifier");
lf[298]=C_h_intern(&lf[298],18,"\010compilerstringify");
lf[299]=C_h_intern(&lf[299],17,"register-feature!");
lf[300]=C_h_intern(&lf[300],4,"unit");
lf[301]=C_h_intern(&lf[301],5,"usage");
lf[302]=C_static_string(C_heaptop,51,"unit was already given a name (new name is ignored)");
lf[303]=C_h_intern(&lf[303],15,"hash-table-set!");
lf[304]=C_h_intern(&lf[304],34,"\010compilerdefault-standard-bindings");
lf[305]=C_h_intern(&lf[305],34,"\010compilerdefault-extended-bindings");
lf[306]=C_h_intern(&lf[306],18,"usual-integrations");
lf[307]=C_h_intern(&lf[307],17,"lset-intersection");
lf[308]=C_h_intern(&lf[308],6,"fixnum");
lf[309]=C_h_intern(&lf[309],17,"fixnum-arithmetic");
lf[310]=C_h_intern(&lf[310],23,"\005matchset-error-control");
lf[311]=C_h_intern(&lf[311],12,"\000unspecified");
lf[312]=C_h_intern(&lf[312],4,"safe");
lf[313]=C_h_intern(&lf[313],18,"interrupts-enabled");
lf[314]=C_h_intern(&lf[314],18,"disable-interrupts");
lf[315]=C_h_intern(&lf[315],15,"disable-warning");
lf[316]=C_h_intern(&lf[316],26,"\010compilerdisabled-warnings");
lf[317]=C_h_intern(&lf[317],12,"safe-globals");
lf[318]=C_h_intern(&lf[318],38,"no-procedure-checks-for-usual-bindings");
lf[319]=C_h_intern(&lf[319],18,"bound-to-procedure");
lf[320]=C_h_intern(&lf[320],15,"foreign-declare");
lf[321]=C_static_string(C_heaptop,19,"invalid declaration");
lf[322]=C_h_intern(&lf[322],5,"every");
lf[323]=C_h_intern(&lf[323],7,"string\077");
lf[324]=C_h_intern(&lf[324],14,"custom-declare");
lf[325]=C_static_string(C_heaptop,19,"invalid declaration");
lf[326]=C_h_intern(&lf[326],35,"\010compilerprocess-custom-declaration");
lf[327]=C_h_intern(&lf[327],9,"c-options");
lf[328]=C_h_intern(&lf[328],31,"\010compileremit-control-file-item");
lf[329]=C_h_intern(&lf[329],12,"link-options");
lf[330]=C_h_intern(&lf[330],12,"post-process");
lf[331]=C_h_intern(&lf[331],17,"string-substitute");
lf[332]=C_static_string(C_heaptop,3,"\134$@");
lf[333]=C_h_intern(&lf[333],24,"pathname-strip-extension");
lf[334]=C_h_intern(&lf[334],5,"block");
lf[335]=C_h_intern(&lf[335],8,"separate");
lf[336]=C_h_intern(&lf[336],20,"keep-shadowed-macros");
lf[337]=C_h_intern(&lf[337],6,"unused");
lf[338]=C_h_intern(&lf[338],3,"not");
lf[339]=C_h_intern(&lf[339],15,"lset-difference");
lf[340]=C_h_intern(&lf[340],6,"inline");
lf[341]=C_static_string(C_heaptop,34,"illegal declaration specifier `~s\047");
lf[342]=C_h_intern(&lf[342],15,"run-time-macros");
lf[343]=C_h_intern(&lf[343],25,"\003sysenable-runtime-macros");
lf[344]=C_h_intern(&lf[344],12,"block-global");
lf[345]=C_h_intern(&lf[345],4,"hide");
lf[346]=C_h_intern(&lf[346],6,"export");
lf[347]=C_h_intern(&lf[347],12,"emit-exports");
lf[348]=C_static_string(C_heaptop,34,"invalid `emit-exports\047 declaration");
lf[349]=C_h_intern(&lf[349],30,"emit-external-prototypes-first");
lf[350]=C_h_intern(&lf[350],11,"lambda-lift");
lf[351]=C_h_intern(&lf[351],12,"inline-limit");
lf[352]=C_static_string(C_heaptop,46,"invalid argument to `inline-limit\047 declaration");
lf[353]=C_h_intern(&lf[353],8,"constant");
lf[354]=C_static_string(C_heaptop,47,"invalid arguments to `constant\047 declaration: ~S");
lf[355]=C_h_intern(&lf[355],7,"symbol\077");
lf[356]=C_h_intern(&lf[356],6,"import");
lf[357]=C_static_string(C_heaptop,58,"argument to `import\047 declaration is not a string or symbol");
lf[358]=C_h_intern(&lf[358],9,"partition");
lf[359]=C_static_string(C_heaptop,6,"<here>");
lf[360]=C_static_string(C_heaptop,34,"illegal declaration specifier `~s\047");
lf[361]=C_static_string(C_heaptop,33,"invalid declaration specification");
lf[362]=C_h_intern(&lf[362],17,"make-foreign-stub");
lf[363]=C_h_intern(&lf[363],12,"foreign-stub");
lf[364]=C_h_intern(&lf[364],13,"foreign-stub\077");
lf[365]=C_h_intern(&lf[365],20,"foreign-stub-id-set!");
lf[366]=C_h_intern(&lf[366],14,"\003sysblock-set!");
lf[367]=C_h_intern(&lf[367],15,"foreign-stub-id");
lf[368]=C_h_intern(&lf[368],29,"foreign-stub-return-type-set!");
lf[369]=C_h_intern(&lf[369],24,"foreign-stub-return-type");
lf[370]=C_h_intern(&lf[370],22,"foreign-stub-name-set!");
lf[371]=C_h_intern(&lf[371],17,"foreign-stub-name");
lf[372]=C_h_intern(&lf[372],32,"foreign-stub-argument-types-set!");
lf[373]=C_h_intern(&lf[373],27,"foreign-stub-argument-types");
lf[374]=C_h_intern(&lf[374],32,"foreign-stub-argument-names-set!");
lf[375]=C_h_intern(&lf[375],27,"foreign-stub-argument-names");
lf[376]=C_h_intern(&lf[376],22,"foreign-stub-body-set!");
lf[377]=C_h_intern(&lf[377],17,"foreign-stub-body");
lf[378]=C_h_intern(&lf[378],21,"foreign-stub-cps-set!");
lf[379]=C_h_intern(&lf[379],16,"foreign-stub-cps");
lf[380]=C_h_intern(&lf[380],26,"foreign-stub-callback-set!");
lf[381]=C_h_intern(&lf[381],21,"foreign-stub-callback");
lf[382]=C_h_intern(&lf[382],28,"\010compilercreate-foreign-stub");
tmp=C_intern(C_heaptop,6,"\003sysgc");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[383]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[384]=C_h_pair(C_restore,tmp);
lf[385]=C_static_string(C_heaptop,16,"C_a_i_bytevector");
lf[386]=C_h_intern(&lf[386],37,"\010compilerestimate-foreign-result-size");
lf[387]=C_h_intern(&lf[387],4,"stub");
lf[388]=C_h_intern(&lf[388],1,"a");
lf[389]=C_h_intern(&lf[389],13,"list-tabulate");
lf[390]=C_h_intern(&lf[390],6,"second");
lf[391]=C_static_string(C_heaptop,45,"name `~s\047 of foreign procedure has wrong type");
lf[392]=C_static_string(C_heaptop,45,"name `~s\047 of foreign procedure has wrong type");
lf[393]=C_h_intern(&lf[393],4,"cadr");
lf[394]=C_h_intern(&lf[394],3,"car");
lf[395]=C_h_intern(&lf[395],4,"void");
lf[396]=C_h_intern(&lf[396],24,"\003sysline-number-database");
lf[397]=C_h_intern(&lf[397],31,"\010compilerperform-cps-conversion");
lf[398]=C_h_intern(&lf[398],4,"node");
lf[399]=C_h_intern(&lf[399],11,"\004corelambda");
lf[400]=C_h_intern(&lf[400],9,"\004corecall");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[401]=C_h_pair(C_restore,tmp);
lf[402]=C_h_intern(&lf[402],16,"\010compilervarnode");
lf[403]=C_h_intern(&lf[403],1,"k");
lf[404]=C_h_intern(&lf[404],13,"\004corevariable");
tmp=C_SCHEME_TRUE;
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[405]=C_h_pair(C_restore,tmp);
lf[406]=C_h_intern(&lf[406],2,"f_");
lf[407]=C_h_intern(&lf[407],26,"make-foreign-callback-stub");
lf[408]=C_h_intern(&lf[408],13,"\010compilerbomb");
lf[409]=C_static_string(C_heaptop,14,"bad node (cps)");
lf[410]=C_h_intern(&lf[410],15,"\004coreglobal-ref");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"\004corevariable");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"\004coreglobal-ref");
C_save(tmp);
lf[411]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
lf[412]=C_h_intern(&lf[412],6,"values");
lf[413]=C_h_intern(&lf[413],21,"foreign-callback-stub");
lf[414]=C_h_intern(&lf[414],22,"foreign-callback-stub\077");
lf[415]=C_h_intern(&lf[415],29,"foreign-callback-stub-id-set!");
lf[416]=C_h_intern(&lf[416],24,"foreign-callback-stub-id");
lf[417]=C_h_intern(&lf[417],31,"foreign-callback-stub-name-set!");
lf[418]=C_h_intern(&lf[418],26,"foreign-callback-stub-name");
lf[419]=C_h_intern(&lf[419],37,"foreign-callback-stub-qualifiers-set!");
lf[420]=C_h_intern(&lf[420],32,"foreign-callback-stub-qualifiers");
lf[421]=C_h_intern(&lf[421],38,"foreign-callback-stub-return-type-set!");
lf[422]=C_h_intern(&lf[422],33,"foreign-callback-stub-return-type");
lf[423]=C_h_intern(&lf[423],41,"foreign-callback-stub-argument-types-set!");
lf[424]=C_h_intern(&lf[424],36,"foreign-callback-stub-argument-types");
lf[425]=C_h_intern(&lf[425],27,"\010compileranalyze-expression");
lf[426]=C_h_intern(&lf[426],17,"\010compilercollect!");
lf[427]=C_h_intern(&lf[427],10,"references");
lf[428]=C_h_intern(&lf[428],13,"\010compilerput!");
lf[429]=C_h_intern(&lf[429],9,"undefined");
lf[430]=C_h_intern(&lf[430],7,"unknown");
lf[431]=C_h_intern(&lf[431],5,"value");
lf[432]=C_h_intern(&lf[432],12,"\010compilerget");
lf[433]=C_h_intern(&lf[433],4,"home");
lf[434]=C_h_intern(&lf[434],16,"\010compilerget-all");
lf[435]=C_h_intern(&lf[435],8,"captured");
lf[436]=C_h_intern(&lf[436],6,"global");
lf[437]=C_h_intern(&lf[437],12,"\004corerecurse");
lf[438]=C_h_intern(&lf[438],44,"\010compileroptimizable-rest-argument-operators");
lf[439]=C_h_intern(&lf[439],15,"\010compilercount!");
lf[440]=C_h_intern(&lf[440],16,"o-r/access-count");
lf[441]=C_h_intern(&lf[441],14,"rest-parameter");
lf[442]=C_h_intern(&lf[442],16,"standard-binding");
lf[443]=C_h_intern(&lf[443],10,"call-sites");
lf[444]=C_h_intern(&lf[444],18,"\004coredirect_lambda");
lf[445]=C_h_intern(&lf[445],6,"simple");
lf[446]=C_h_intern(&lf[446],28,"\010compilersimple-lambda-node\077");
lf[447]=C_h_intern(&lf[447],6,"vector");
lf[448]=C_h_intern(&lf[448],12,"contained-in");
lf[449]=C_h_intern(&lf[449],8,"contains");
lf[450]=C_h_intern(&lf[450],8,"assigned");
lf[451]=C_h_intern(&lf[451],16,"assigned-locally");
lf[452]=C_h_intern(&lf[452],15,"potential-value");
lf[453]=C_h_intern(&lf[453],5,"redef");
lf[454]=C_static_string(C_heaptop,37,"redefinition of standard binding `~S\047");
lf[455]=C_static_string(C_heaptop,37,"redefinition of extended binding `~S\047");
lf[456]=C_h_intern(&lf[456],16,"extended-binding");
lf[457]=C_h_intern(&lf[457],9,"\004coreproc");
lf[458]=C_h_intern(&lf[458],3,"any");
lf[459]=C_h_intern(&lf[459],9,"replacing");
lf[460]=C_h_intern(&lf[460],10,"replacable");
lf[461]=C_h_intern(&lf[461],9,"removable");
lf[462]=C_h_intern(&lf[462],37,"\010compilerexpression-has-side-effects\077");
lf[463]=C_h_intern(&lf[463],21,"has-unused-parameters");
lf[464]=C_h_intern(&lf[464],13,"explicit-rest");
lf[465]=C_h_intern(&lf[465],11,"collapsable");
lf[466]=C_h_intern(&lf[466],12,"contractable");
lf[467]=C_h_intern(&lf[467],9,"inlinable");
lf[468]=C_h_intern(&lf[468],28,"\010compilerscan-free-variables");
lf[469]=C_h_intern(&lf[469],5,"boxed");
lf[470]=C_static_string(C_heaptop,34,"global variable `~S\047 is never used");
lf[471]=C_static_string(C_heaptop,58,"local assignment to unused variable `~S\047 may be unintended");
lf[472]=C_h_intern(&lf[472],23,"\003syshash-table-for-each");
lf[473]=C_h_intern(&lf[473],18,"\010compilerdebugging");
lf[474]=C_h_intern(&lf[474],1,"p");
lf[475]=C_static_string(C_heaptop,27,"analysis gathering phase...");
lf[476]=C_static_string(C_heaptop,27,"analysis traversal phase...");
lf[477]=C_h_intern(&lf[477],37,"\010compilerinitialize-analysis-database");
lf[478]=C_h_intern(&lf[478],35,"\010compilerperform-closure-conversion");
lf[479]=C_h_intern(&lf[479],12,"customizable");
lf[480]=C_h_intern(&lf[480],20,"node-parameters-set!");
lf[481]=C_static_string(C_heaptop,57,"known procedure called with wrong number of arguments: ~A");
lf[482]=C_h_intern(&lf[482],28,"\010compilersource-info->string");
lf[483]=C_h_intern(&lf[483],8,"toplevel");
lf[484]=C_h_intern(&lf[484],18,"captured-variables");
lf[485]=C_h_intern(&lf[485],12,"closure-size");
lf[486]=C_h_intern(&lf[486],8,"\004coreref");
lf[487]=C_h_intern(&lf[487],10,"\004coreunbox");
lf[488]=C_h_intern(&lf[488],8,"\004corebox");
lf[489]=C_h_intern(&lf[489],12,"\004coreclosure");
lf[490]=C_h_intern(&lf[490],14,"\010compilerqnode");
lf[491]=C_h_intern(&lf[491],20,"\003sysmake-lambda-info");
lf[492]=C_h_intern(&lf[492],1,"\077");
lf[493]=C_h_intern(&lf[493],8,"->string");
lf[494]=C_h_intern(&lf[494],18,"\010compilerreal-name");
lf[495]=C_h_intern(&lf[495],10,"fold-right");
lf[496]=C_h_intern(&lf[496],10,"boxed-rest");
lf[497]=C_h_intern(&lf[497],6,"filter");
lf[498]=C_h_intern(&lf[498],16,"\004coreupdatebox_i");
lf[499]=C_h_intern(&lf[499],14,"\004coreupdatebox");
lf[500]=C_h_intern(&lf[500],13,"\004coreupdate_i");
lf[501]=C_h_intern(&lf[501],11,"\004coreupdate");
lf[502]=C_h_intern(&lf[502],19,"\010compilerimmediate\077");
lf[503]=C_static_string(C_heaptop,19,"bad node (closure2)");
lf[504]=C_h_intern(&lf[504],11,"\004coreswitch");
lf[505]=C_h_intern(&lf[505],9,"\004corecond");
lf[506]=C_h_intern(&lf[506],16,"\004coredirect_call");
lf[507]=C_h_intern(&lf[507],11,"\004corereturn");
lf[508]=C_h_intern(&lf[508],1,"o");
lf[509]=C_static_string(C_heaptop,22,"calls to known targets");
lf[510]=C_h_intern(&lf[510],16,"\003sysmake-promise");
lf[511]=C_static_string(C_heaptop,42,"closure conversion transformation phase...");
lf[512]=C_static_string(C_heaptop,23,"customizable procedures");
lf[513]=C_static_string(C_heaptop,37,"closure conversion gathering phase...");
lf[514]=C_h_intern(&lf[514],19,"make-lambda-literal");
lf[515]=C_h_intern(&lf[515],14,"lambda-literal");
lf[516]=C_h_intern(&lf[516],15,"lambda-literal\077");
lf[517]=C_h_intern(&lf[517],22,"lambda-literal-id-set!");
lf[518]=C_h_intern(&lf[518],17,"lambda-literal-id");
lf[519]=C_h_intern(&lf[519],28,"lambda-literal-external-set!");
lf[520]=C_h_intern(&lf[520],23,"lambda-literal-external");
lf[521]=C_h_intern(&lf[521],29,"lambda-literal-arguments-set!");
lf[522]=C_h_intern(&lf[522],24,"lambda-literal-arguments");
lf[523]=C_h_intern(&lf[523],34,"lambda-literal-argument-count-set!");
lf[524]=C_h_intern(&lf[524],29,"lambda-literal-argument-count");
lf[525]=C_h_intern(&lf[525],33,"lambda-literal-rest-argument-set!");
lf[526]=C_h_intern(&lf[526],28,"lambda-literal-rest-argument");
lf[527]=C_h_intern(&lf[527],31,"lambda-literal-temporaries-set!");
lf[528]=C_h_intern(&lf[528],26,"lambda-literal-temporaries");
lf[529]=C_h_intern(&lf[529],37,"lambda-literal-callee-signatures-set!");
lf[530]=C_h_intern(&lf[530],32,"lambda-literal-callee-signatures");
lf[531]=C_h_intern(&lf[531],29,"lambda-literal-allocated-set!");
lf[532]=C_h_intern(&lf[532],24,"lambda-literal-allocated");
lf[533]=C_h_intern(&lf[533],35,"lambda-literal-directly-called-set!");
lf[534]=C_h_intern(&lf[534],30,"lambda-literal-directly-called");
lf[535]=C_h_intern(&lf[535],32,"lambda-literal-closure-size-set!");
lf[536]=C_h_intern(&lf[536],27,"lambda-literal-closure-size");
lf[537]=C_h_intern(&lf[537],27,"lambda-literal-looping-set!");
lf[538]=C_h_intern(&lf[538],22,"lambda-literal-looping");
lf[539]=C_h_intern(&lf[539],32,"lambda-literal-customizable-set!");
lf[540]=C_h_intern(&lf[540],27,"lambda-literal-customizable");
lf[541]=C_h_intern(&lf[541],38,"lambda-literal-rest-argument-mode-set!");
lf[542]=C_h_intern(&lf[542],33,"lambda-literal-rest-argument-mode");
lf[543]=C_h_intern(&lf[543],24,"lambda-literal-body-set!");
lf[544]=C_h_intern(&lf[544],19,"lambda-literal-body");
lf[545]=C_h_intern(&lf[545],26,"lambda-literal-direct-set!");
lf[546]=C_h_intern(&lf[546],21,"lambda-literal-direct");
lf[547]=C_h_intern(&lf[547],36,"\010compilerprepare-for-code-generation");
lf[548]=C_h_intern(&lf[548],14,"\004coreimmediate");
lf[549]=C_h_intern(&lf[549],3,"fix");
lf[550]=C_h_intern(&lf[550],4,"bool");
lf[551]=C_h_intern(&lf[551],4,"char");
tmp=C_intern(C_heaptop,3,"nil");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[552]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,3,"eof");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[553]=C_h_pair(C_restore,tmp);
lf[554]=C_static_string(C_heaptop,23,"bad immediate (prepare)");
lf[555]=C_h_intern(&lf[555],36,"\010compilermake-block-variable-literal");
lf[556]=C_h_intern(&lf[556],36,"\010compilerblock-variable-literal-name");
lf[557]=C_h_intern(&lf[557],32,"\010compilerblock-variable-literal\077");
lf[558]=C_h_intern(&lf[558],10,"list-index");
lf[559]=C_h_intern(&lf[559],11,"\004coreglobal");
lf[560]=C_h_intern(&lf[560],10,"\004corelocal");
lf[561]=C_h_intern(&lf[561],12,"\004coreliteral");
lf[562]=C_static_string(C_heaptop,33,"identified direct recursive calls");
lf[563]=C_static_string(C_heaptop,17,"bad direct lambda");
lf[564]=C_h_intern(&lf[564],4,"none");
lf[565]=C_static_string(C_heaptop,20,"unused rest argument");
lf[566]=C_static_string(C_heaptop,32,"rest argument accessed as vector");
lf[567]=C_h_intern(&lf[567],7,"butlast");
lf[568]=C_h_intern(&lf[568],9,"\004corebind");
lf[569]=C_h_intern(&lf[569],13,"\004coresetlocal");
lf[570]=C_h_intern(&lf[570],16,"\004coresetglobal_i");
lf[571]=C_h_intern(&lf[571],14,"\004coresetglobal");
lf[572]=C_h_intern(&lf[572],1,"=");
lf[573]=C_h_intern(&lf[573],4,"type");
lf[574]=C_static_string(C_heaptop,48,"coerced inexact literal number `~S\047 to fixnum ~S");
lf[575]=C_static_string(C_heaptop,45,"can not coerce inexact literal `~S\047 to fixnum");
lf[576]=C_h_intern(&lf[576],20,"\010compilerbig-fixnum\077");
lf[577]=C_static_string(C_heaptop,23,"fast global assignments");
lf[578]=C_static_string(C_heaptop,22,"fast global references");
lf[579]=C_static_string(C_heaptop,24,"fast box initializations");
lf[580]=C_static_string(C_heaptop,20,"preparation phase...");
lf[581]=C_h_intern(&lf[581],14,"make-parameter");
C_register_lf2(lf,582,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1753 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1756 in k1753 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1759 in k1756 in k1753 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 318  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 319  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 320  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 321  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 322  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 323  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1873,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1938,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4687,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5632,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5638,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5644,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5653,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5662,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5671,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5680,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5689,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5698,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5707,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5716,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5734,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5743,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5752,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5761,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5779,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[382]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5788,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5942,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5987,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6032,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6069,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6106,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6187,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[397]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6277,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6952,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6958,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6964,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6973,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6982,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6991,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7000,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7009,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7018,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7027,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7036,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7045,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7054,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8579,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9813,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9819,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9825,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9834,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9843,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9852,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9861,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9870,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9879,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9888,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9897,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9906,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9915,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9924,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9933,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9942,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9951,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9960,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9969,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9978,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9987,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9996,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10005,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10014,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10023,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10032,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10041,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10050,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10059,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10068,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[545]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10077,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[546]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10086,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[547]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10095,tmp=(C_word)a,a+=2,tmp));
t162=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t162+1)))(2,t162,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10095,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11090,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11044,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11058,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10964,a[2]=t5,a[3]=t25,a[4]=t7,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10132,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10098,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10185,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10952,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11139,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2309 debugging */
t37=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[474],lf[580]);}

/* k11137 in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11142,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2310 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10185(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11140 in k11137 in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2311 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[579],((C_word*)((C_word*)t0)[2])[1]);}

/* k11143 in k11140 in k11137 in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2312 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[578],((C_word*)((C_word*)t0)[2])[1]);}

/* k11146 in k11143 in k11140 in k11137 in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2313 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[577],((C_word*)((C_word*)t0)[2])[1]);}

/* k11149 in k11146 in k11143 in k11140 in k11137 in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2314 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10952,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10958,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a10957 in mapwalk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10958,3,t0,t1,t2);}
/* compiler.scm: 2270 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10185(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10185(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10185,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[126]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[457]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[404]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2104 walk-var */
t16=((C_word*)t0)[16];
f_10098(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[410]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2107 walk-global */
t17=((C_word*)t0)[15];
f_10132(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[506]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10243,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2111 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_10952(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10263,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2115 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_10952(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[104]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10287,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10291,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2118 estimate-foreign-result-size */
t22=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[108]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10315,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10319,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2122 estimate-foreign-result-size */
t23=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[489]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10336,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2127 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10952(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[488]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10363,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2131 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[499]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10379,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2135 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10952(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[399]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[444]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[444]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10435,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2155 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[488],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10619,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2212 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10660,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2218 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[400]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10780,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2242 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[572]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[437]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10823,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10823(t32,t31);}
else{
t30=t29;
f_10823(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10851,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10938,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2253 big-fixnum? */
t33=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10851(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10941,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2267 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_10952(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10939 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10941,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10936 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10851(t2,(C_word)C_i_not(t1));}

/* k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10851,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2254 immediate-literal */
f_11090(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[308],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2257 big-fixnum? */
t5=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10872(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10909,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2263 literal */
t4=((C_word*)t0)[2];
f_10964(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2264 immediate? */
t3=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10913 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10915,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2264 immediate-literal */
f_11090(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10928,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 literal */
t3=((C_word*)t0)[2];
f_10964(t3,t2,((C_word*)t0)[3]);}}

/* k10926 in k10913 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10928,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* k10907 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10909,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* k10897 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10872(t2,(C_word)C_i_not(t1));}

/* k10870 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10872,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2258 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[573],lf[574],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2262 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[575],((C_word*)t0)[4]);}}

/* k10873 in k10870 in k10849 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2261 immediate-literal */
f_11090(((C_word*)t0)[2],t2);}

/* k10821 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10823,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10826,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2249 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10952(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10824 in k10821 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10826,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10778 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10780,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10792,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10792(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10792(t6,C_SCHEME_FALSE);}}

/* k10790 in k10778 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10783(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10783(t2,C_SCHEME_UNDEFINED);}}

/* k10781 in k10778 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10783,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10786,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2245 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10952(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10784 in k10781 in k10778 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10786,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10660,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10676,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2220 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10185(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10749,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10749(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10749(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10749(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10761,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2226 get */
t8=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[442]);}}}}}

/* k10759 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10749(2,t2,t1);}
else{
/* compiler.scm: 2227 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456]);}}

/* k10747 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[103]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2229 immediate? */
t8=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10688(2,t6,C_SCHEME_FALSE);}}

/* k10686 in k10747 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10688,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10694(t6,t5);}
else{
t4=t3;
f_10694(t4,C_SCHEME_UNDEFINED);}}

/* k10692 in k10686 in k10747 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10694,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[570]:lf[571]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10718,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2235 blockvar-literal */
t4=((C_word*)t0)[4];
f_11058(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2236 literal */
t4=((C_word*)t0)[2];
f_10964(t4,t3,((C_word*)t0)[3]);}}

/* k10716 in k10692 in k10686 in k10747 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10718,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10710,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2238 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10185(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10708 in k10716 in k10692 in k10686 in k10747 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10710,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10674 in k10658 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[569],((C_word*)t0)[2],t2));}

/* k10617 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10623,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2213 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10629 in k10617 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10635,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2213 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10633 in k10629 in k10617 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2213 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10185(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10621 in k10617 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10623,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[568],((C_word*)t0)[2],t2));}

/* a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10435(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10435,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10556,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2161 get */
t8=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[427]);}
else{
t7=t6;
f_10442(2,t7,C_SCHEME_FALSE);}}

/* k10554 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10562,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2162 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}

/* k10560 in k10554 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10562,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10442(2,t2,lf[281]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10587,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2163 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[496]);}}

/* k10585 in k10560 in k10554 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10568(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10568(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10566 in k10560 in k10554 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10442(2,t2,lf[564]);}
else{
/* compiler.scm: 2164 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441]);}}

/* k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10445,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10547,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[564],t1);
if(C_truep(t5)){
/* compiler.scm: 2168 butlast */
t6=C_retrieve(lf[567]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10547(2,t6,((C_word*)t0)[7]);}}

/* k10545 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2165 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10185(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[564]);
if(C_truep(t3)){
/* compiler.scm: 2173 debugging */
t4=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[508],lf[565],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[447]);
if(C_truep(t4)){
/* compiler.scm: 2174 debugging */
t5=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[508],lf[566],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10448(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2176 bomb */
t4=C_retrieve(lf[408]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[563],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10451(2,t4,C_SCHEME_UNDEFINED);}}

/* k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10473,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10489,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2188 get */
t7=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[485]);}

/* k10487 in k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10489,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10496(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10515,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2192 debugging */
t7=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[508],lf[562],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10496(t6,C_SCHEME_FALSE);}}}

/* k10513 in k10487 in k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10496(t2,C_SCHEME_TRUE);}

/* k10494 in k10487 in k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10496,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10500(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2194 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[479]);}}

/* k10498 in k10494 in k10487 in k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2178 make-lambda-literal */
t2=C_retrieve(lf[514]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10471 in k10449 in k10446 in k10443 in k10440 in a10434 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[398],lf[457],t9,C_SCHEME_END_OF_LIST));}

/* k10377 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10382,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10388,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[404],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10388(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10388(t6,C_SCHEME_FALSE);}}

/* k10386 in k10377 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10382(t4,lf[498]);}
else{
t2=((C_word*)t0)[3];
f_10382(t2,((C_word*)t0)[2]);}}

/* k10380 in k10377 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10382,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10361 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[488],((C_word*)t0)[2],t2));}

/* k10334 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10336,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t1));}

/* k10317 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2122 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10313 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10315,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2123 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_10952(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10306 in k10313 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10289 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2118 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10285 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10287,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10261 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10263,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10241 in walk in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10098,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10102,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2072 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10100 in walk-var in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10102,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[560],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2073 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10115 in k10100 in walk-var in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10117,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10127,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2073 literal */
t3=((C_word*)t0)[5];
f_10964(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2074 walk-global */
t2=((C_word*)t0)[3];
f_10132(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10125 in k10115 in k10100 in walk-var in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10127,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10132,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10136(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10136(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10136(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10136(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10177,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2081 get */
t9=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[442]);}}}}}

/* k10175 in walk-global in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10136(2,t2,t1);}
else{
/* compiler.scm: 2082 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456]);}}

/* k10134 in walk-global in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10136,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10142(t6,t5);}
else{
t4=t3;
f_10142(t4,C_SCHEME_UNDEFINED);}}

/* k10140 in k10134 in walk-global in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10142,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2088 blockvar-literal */
t3=((C_word*)t0)[3];
f_11058(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2089 literal */
t3=((C_word*)t0)[2];
f_10964(t3,t2,((C_word*)t0)[5]);}}

/* k10150 in k10140 in k10134 in walk-global in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10152,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_10964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10964,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2273 immediate? */
t4=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10969 in literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10971,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2273 immediate-literal */
f_11090(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11026,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2275 list-index */
t4=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_10977(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10977(2,t3,C_SCHEME_FALSE);}}}

/* a11025 in k10969 in literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11026,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10975 in k10969 in literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10977,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10993,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2281 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11003,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2283 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k11001 in k10975 in k10969 in literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2284 new-literal */
t2=((C_word*)t0)[3];
f_11044(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10991 in k10975 in k10969 in literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10993,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_11058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11058,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11062,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11074,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2292 list-index */
t5=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11073 in blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11074,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11081,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2294 block-variable-literal? */
t4=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11079 in a11073 in blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11081,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2295 block-variable-literal-name */
t3=C_retrieve(lf[556]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11086 in k11079 in a11073 in blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11060 in blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11062,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11072,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2297 make-block-variable-literal */
t3=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11070 in k11060 in blockvar-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2297 new-literal */
t2=((C_word*)t0)[3];
f_11044(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_11044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11044,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11052,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2288 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11050 in new-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_11090(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11090,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11094,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_11094(2,t4,(C_word)C_a_i_list(&a,2,lf[549],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t4=t3;
f_11094(2,t4,(C_word)C_a_i_list(&a,2,lf[550],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t3;
f_11094(2,t4,(C_word)C_a_i_list(&a,2,lf[551],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_11094(2,t4,lf[552]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t3;
f_11094(2,t4,lf[553]);}
else{
/* compiler.scm: 2306 bomb */
t4=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[554]);}}}}}}

/* k11092 in immediate-literal in ##compiler#prepare-for-code-generation in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_11094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11094,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[548],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10086,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10077,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10068,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10059,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10050,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10041,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10032,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10023,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10014,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_10005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10005,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9996,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9987,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9978,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9969,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9960,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9951,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9942,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9933,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9924,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9915,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9906,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9897,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9888,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9879,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9870,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9861,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9852,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9843,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9834,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9825,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9819,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[515]));}

/* make-lambda-literal in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9813,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[515],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8579,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8582,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8588,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8598,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8609,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9644,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8943,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9632,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9780,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2030 debugging */
t22=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[474],lf[513]);}

/* k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2031 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8609(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2032 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[512],((C_word*)((C_word*)t0)[2])[1]);}

/* k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2033 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[511]);}

/* k9787 in k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9792,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2034 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8943(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9790 in k9787 in k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9795,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9795(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9805,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9807,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2036 ##sys#make-promise */
t6=*((C_word*)lf[510]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9806 in k9790 in k9787 in k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9807,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9803 in k9790 in k9787 in k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2036 debugging */
t2=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[508],lf[509],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9793 in k9790 in k9787 in k9784 in k9781 in k9778 in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9632(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9632,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9638,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9637 in maptransform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9638,3,t0,t1,t2);}
/* compiler.scm: 2002 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8943(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8943,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8962(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t13)){
t14=t12;
f_8962(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[457]);
t15=t12;
f_8962(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[410])));}}}

/* k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8962,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[404]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8974,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1877 ref-var */
f_9644(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[114]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_8995(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[400]);
if(C_truep(t5)){
t6=t4;
f_8995(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_8995(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_8995(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[273]);
if(C_truep(t8)){
t9=t4;
f_8995(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[104]);
if(C_truep(t9)){
t10=t4;
f_8995(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_8995(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[504]);
if(C_truep(t11)){
t12=t4;
f_8995(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[505]);
if(C_truep(t12)){
t13=t4;
f_8995(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[506]);
if(C_truep(t13)){
t14=t4;
f_8995(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[437]);
if(C_truep(t14)){
t15=t4;
f_8995(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[507]);
if(C_truep(t15)){
t16=t4;
f_8995(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[108]);
t17=t4;
f_8995(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8995,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1885 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9632(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9016,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1889 test */
t5=((C_word*)t0)[4];
f_8582(t5,t4,t3,lf[469]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[399]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[444]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1905 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9362,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[103],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1965 immediate? */
t13=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9362(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[398],lf[457],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9511,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9518,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9522,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1996 ##sys#make-lambda-info */
t16=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9511(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 1999 bomb */
t7=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[503]);}}}}}}

/* k9520 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1996 qnode */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9516 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9511(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9509 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9511,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t2));}

/* k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9362,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1967 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9368,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1969 test */
t3=((C_word*)t0)[3];
f_8582(t3,t2,((C_word*)t0)[2],lf[469]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 test */
t3=((C_word*)t0)[3];
f_8582(t3,t2,((C_word*)t0)[2],lf[469]);}}

/* k9436 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9438,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1985 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9468,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1989 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8943(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9466 in k9436 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9468,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[175],((C_word*)t0)[2],t2));}

/* k9449 in k9436 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9455,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1986 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8943(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9453 in k9449 in k9436 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9455,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9375 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9377,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1973 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[500]:lf[501]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1979 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9422 in k9375 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1980 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8943(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9426 in k9422 in k9375 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9428,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9402 in k9375 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9404,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[486],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9400,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1974 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8943(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9398 in k9402 in k9375 in k9366 in k9360 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9400,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9091,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1908 filter */
t7=C_retrieve(lf[497]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9339 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9340,3,t0,t1,t2);}
/* compiler.scm: 1908 test */
t3=((C_word*)t0)[2];
f_8582(t3,t1,t2,lf[469]);}

/* k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9338,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[123]),t1);}

/* k9336 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1909 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1910 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[124]);}

/* k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[483]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1912 test */
t4=((C_word*)t0)[2];
f_8582(t4,t3,t2,lf[484]);}

/* k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1913 test */
t4=((C_word*)t0)[2];
f_8582(t4,t3,((C_word*)t0)[17],lf[485]);}

/* k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9119(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9119(t4,C_SCHEME_FALSE);}}

/* k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9119,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1919 test */
t4=((C_word*)t0)[2];
f_8582(t4,t3,((C_word*)t0)[6],lf[469]);}
else{
t3=t2;
f_9122(2,t3,C_SCHEME_FALSE);}}

/* k9303 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9305,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1920 test */
t3=((C_word*)t0)[2];
f_8582(t3,t2,((C_word*)t0)[6],lf[441]);}
else{
t2=((C_word*)t0)[4];
f_9122(2,t2,C_SCHEME_FALSE);}}

/* k9306 in k9303 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1921 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[496],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9122(2,t2,C_SCHEME_FALSE);}}

/* k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9262,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9266,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9281,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9280 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9281,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9264 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1931 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9262,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1940 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8943(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9207,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9221,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1945 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9199(2,t3,t1);}}

/* k9219 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9225,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9227,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9226 in k9219 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9227,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9238,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1946 varnode */
t5=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9236 in a9226 in k9219 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9238,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[488],C_SCHEME_END_OF_LIST,t2));}

/* k9223 in k9219 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1942 fold-right */
t2=C_retrieve(lf[495]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9206 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9207,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[398],lf[152],t5,t6));}

/* k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9199,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9145,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9183 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9184,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1949 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9190 in a9183 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1949 ref-var */
f_9644(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9148,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9159,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9167,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9175,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1957 real-name */
t7=C_retrieve(lf[494]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9148(2,t3,t1);}}

/* k9173 in k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9175,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[492]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1957 ->string */
t5=C_retrieve(lf[493]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9165 in k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1956 ##sys#make-lambda-info */
t2=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9161 in k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1955 qnode */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9157 in k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9159,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1952 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9146 in k9143 in k9197 in k9194 in k9260 in k9120 in k9117 in k9111 in k9105 in k9099 in k9096 in k9093 in a9090 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9148,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t2));}

/* k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1890 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9017 in k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9019,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9035,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1894 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8943(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1901 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9632(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9069 in k9017 in k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t1));}

/* k9033 in k9017 in k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1897 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9062 in k9033 in k9017 in k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9064,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[488],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9056,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1898 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8943(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9054 in k9062 in k9033 in k9017 in k9014 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t4));}

/* k8999 in k8993 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9001,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k8972 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1878 test */
t3=((C_word*)t0)[3];
f_8582(t3,t2,((C_word*)t0)[2],lf[469]);}

/* k8978 in k8972 in k8960 in transform in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[487],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9644(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9644,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9651,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2006 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9649 in ref-var in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9651,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9667,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2009 varnode */
t5=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9665 in k9649 in ref-var in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9667,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[486],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8609(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8609,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8628(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[404]);
if(C_truep(t13)){
t14=t12;
f_8628(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t14)){
t15=t12;
f_8628(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[457]);
if(C_truep(t15)){
t16=t12;
f_8628(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[274]);
t17=t12;
f_8628(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[410])));}}}}}

/* k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8628,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1814 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[400]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[404],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8691,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8708,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8718,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8832,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1830 test */
t19=((C_word*)t0)[3];
f_8582(t19,t18,t16,lf[430]);}
else{
t15=t14;
f_8718(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8708(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[399]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[444]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1854 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8907,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8906 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8907,3,t0,t1,t2);}
/* compiler.scm: 1864 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8609(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8868,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[483]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9683,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9683(3,t14,t10,t6);}

/* walk in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9683,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[404]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9712,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2021 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[103]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9721(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[126]);
if(C_truep(t12)){
t13=t11;
f_9721(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[274]);
if(C_truep(t13)){
t14=t11;
f_9721(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[457]);
if(C_truep(t14)){
t15=t11;
f_9721(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[104]);
t16=t11;
f_9721(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[410])));}}}}}}

/* k9719 in walk in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9721,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9733,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9747,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2025 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9733(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9745 in k9719 in walk in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9733(t3,t2);}

/* k9731 in k9719 in walk in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_9733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2026 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9683(3,t3,((C_word*)t0)[2],t2);}

/* k9710 in walk in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9679 in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_9681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9681,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8881,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1860 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[485],t3);}

/* k8879 in k9679 in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1861 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[484],((C_word*)t0)[2]);}

/* k8882 in k8879 in k9679 in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8895,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1862 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8893 in k8882 in k8879 in k9679 in a8867 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1862 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8609(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8830 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8724(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1830 test */
t2=((C_word*)t0)[3];
f_8582(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[431]);}}

/* k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8730(t4,(C_word)C_eqp(lf[399],t3));}
else{
t3=t2;
f_8730(t3,C_SCHEME_FALSE);}}

/* k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8730,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1835 test */
t6=((C_word*)t0)[2];
f_8582(t6,t5,((C_word*)t0)[6],lf[427]);}
else{
t2=((C_word*)t0)[8];
f_8718(t2,C_SCHEME_END_OF_LIST);}}

/* k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8745,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1836 test */
t3=((C_word*)t0)[2];
f_8582(t3,t2,((C_word*)t0)[7],lf[443]);}

/* k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8748(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8748(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8748(t3,C_SCHEME_FALSE);}}

/* k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8748,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8766(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8766(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8766(t4,C_SCHEME_FALSE);}}

/* k8764 in k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8766,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1844 source-info->string */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8751(2,t2,C_SCHEME_UNDEFINED);}}

/* k8771 in k8764 in k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1842 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[481],t1);}

/* k8749 in k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1845 register-direct-call! */
t3=((C_word*)t0)[2];
f_8598(t3,t2,((C_word*)t0)[6]);}

/* k8752 in k8749 in k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1846 register-customizable! */
t3=((C_word*)t0)[3];
f_8588(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8757(2,t3,C_SCHEME_UNDEFINED);}}

/* k8755 in k8752 in k8749 in k8746 in k8743 in k8740 in k8728 in k8722 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8757,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8718(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8716 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8718,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8708(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8706 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8708,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1823 node-parameters-set! */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8689 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8696,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8695 in k8689 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8696,3,t0,t1,t2);}
/* compiler.scm: 1851 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8609(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8648 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8649,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8665 in a8648 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8666,3,t0,t1,t2);}
/* compiler.scm: 1815 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8609(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8651 in a8648 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8653,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1816 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8662 in k8651 in a8648 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1816 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8609(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8638 in k8626 in gather in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8639,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1814 split-at */
t3=C_retrieve(lf[248]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8598,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8607,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1801 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),C_retrieve(lf[63]),t2);}

/* k8605 in register-direct-call! in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8588,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8593,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1796 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8591 in register-customizable! in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1797 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[479],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8582(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8582,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1793 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7054,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1414 make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7060,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7763,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7067,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7648,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7769,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7783,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1584 initialize-analysis-database */
t18=C_retrieve(lf[477]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1587 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[476]);}

/* k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1589 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7067(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1592 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[475]);}

/* k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1593 ##sys#hash-table-for-each */
t4=C_retrieve(lf[472]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7831,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7835,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8466,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8465 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8466,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[430]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[435]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[452]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[443]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[450]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[451]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[429]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[440]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[441]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8431,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8431(t10,(C_word)C_eqp(lf[399],t9));}
else{
t7=t6;
f_8431(t7,C_SCHEME_FALSE);}}

/* k8429 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1639 set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7842(2,t2,C_SCHEME_UNDEFINED);}}

/* k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8377(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8377(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8377(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8377(t4,C_SCHEME_FALSE);}}

/* k8375 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8377,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1648 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[471],((C_word*)t0)[3]);}
else{
t3=t2;
f_8380(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7845(2,t2,C_SCHEME_UNDEFINED);}}

/* k8378 in k8375 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8392,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8392(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8392(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8392(t5,C_SCHEME_FALSE);}}}

/* k8390 in k8378 in k8375 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8386(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8386(t2,C_SCHEME_FALSE);}}

/* k8384 in k8378 in k8375 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1652 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[470],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7845(2,t2,C_SCHEME_UNDEFINED);}}

/* k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1656 quick-put! */
f_7769(t2,((C_word*)t0)[8],lf[469],C_SCHEME_TRUE);}
else{
t4=t2;
f_7848(2,t4,C_SCHEME_UNDEFINED);}}

/* k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[399],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8320(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8360,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1665 scan-free-variables */
t13=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8320(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7851(2,t3,C_SCHEME_UNDEFINED);}}

/* k8358 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1665 every */
t2=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8351 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8352,3,t0,t1,t2);}
/* compiler.scm: 1665 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[436]);}

/* k8318 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8326(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8326(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7851(2,t2,C_SCHEME_UNDEFINED);}}

/* k8324 in k8318 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1667 quick-put! */
f_7769(((C_word*)t0)[3],((C_word*)t0)[2],lf[466],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1668 quick-put! */
f_7769(((C_word*)t0)[3],((C_word*)t0)[2],lf[467],C_SCHEME_TRUE);}}

/* k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8282,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8282(t6,(C_word)C_eqp(lf[103],t5));}
else{
t4=t3;
f_8282(t4,C_SCHEME_FALSE);}}

/* k8280 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8282,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1676 collapsable-literal? */
t6=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7854(2,t2,C_SCHEME_UNDEFINED);}}

/* k8289 in k8280 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8294(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8294(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8292 in k8289 in k8280 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1678 quick-put! */
f_7769(((C_word*)t0)[3],((C_word*)t0)[2],lf[465],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7854(2,t2,C_SCHEME_UNDEFINED);}}

/* k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8183,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[399],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8183(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8183(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7857(2,t3,C_SCHEME_UNDEFINED);}}

/* k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8183,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1692 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7857(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7857(2,t2,C_SCHEME_UNDEFINED);}}

/* a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8201,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8205(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8243 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8244,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8251,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8269,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1698 get */
t5=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[427]);}

/* k8267 in a8243 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8269,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8251(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1699 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}}

/* k8263 in k8267 in a8243 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8251(t2,(C_word)C_i_not(t1));}

/* k8249 in a8243 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8251,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1700 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[337],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8252 in k8249 in a8243 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8203 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8211,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8211(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8211(t3,C_SCHEME_FALSE);}}

/* k8209 in k8203 in a8200 in k8181 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8211,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1706 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[463],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1709 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[464],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8120,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8120(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8135,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[404],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8147(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8161,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1717 get */
t15=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[436]);}}
else{
t6=t5;
f_8135(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8120(t5,C_SCHEME_FALSE);}}}

/* k8159 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8147(t2,(C_word)C_i_not(t1));}

/* k8145 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8147,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1718 expression-has-side-effects? */
t3=C_retrieve(lf[462]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8135(t2,C_SCHEME_FALSE);}}

/* k8152 in k8145 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8135(t2,(C_word)C_i_not(t1));}

/* k8133 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8135(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8120(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8118 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1720 quick-put! */
f_7769(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7860(2,t2,C_SCHEME_UNDEFINED);}}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[404],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1732 get */
t11=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[427]);}
else{
t7=t2;
f_7863(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7863(2,t4,C_SCHEME_UNDEFINED);}}

/* k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8038,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1733 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[430]);}

/* k8104 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8038(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1733 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[431]);}}

/* k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8041(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1734 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[435]);}}

/* k8094 in k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8041(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8041(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1738 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}}
else{
t4=((C_word*)t0)[6];
f_8041(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8041(t2,C_SCHEME_FALSE);}}}

/* k8086 in k8094 in k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8088,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8041(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8041(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1739 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}}}

/* k8082 in k8086 in k8094 in k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8041(t2,(C_word)C_i_not(t1));}

/* k8039 in k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_8041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8041,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1740 quick-put! */
f_7769(t2,((C_word*)t0)[2],lf[460],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7863(2,t2,C_SCHEME_UNDEFINED);}}

/* k8042 in k8039 in k8036 in k8030 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_8044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1741 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7891(t6,(C_word)C_eqp(lf[399],t5));}
else{
t4=t3;
f_7891(t4,C_SCHEME_FALSE);}}

/* k7889 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7891,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7866(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7912,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7912(t11,(C_word)C_eqp(lf[400],t10));}
else{
t10=t8;
f_7912(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7912(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* k7910 in k7889 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7912,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[404],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[404],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7933(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7933(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7933(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7866(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* k7931 in k7910 in k7889 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7933,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7939,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1761 quick-put! */
f_7769(t4,((C_word*)t0)[2],lf[460],t3);}
else{
t2=((C_word*)t0)[5];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* k7937 in k7931 in k7910 in k7889 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1762 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7872(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7872(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7872(t3,C_SCHEME_FALSE);}}

/* k7870 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7872,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1772 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7874 in k7870 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7833 in a7830 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1773 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441],lf[447]);}

/* k7819 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1779 lset-difference */
t3=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7823 in k7819 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7825,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7828(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7828(t5,t4);}}

/* k7826 in k7823 in k7819 in k7816 in k7813 in k7809 in k7806 in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7783(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7783,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7793,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1579 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[449]);}}

/* k7791 in contains? in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7793,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1581 any */
t3=C_retrieve(lf[458]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7800 in k7791 in contains? in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7801,3,t0,t1,t2);}
/* compiler.scm: 1581 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7783(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7769(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7769,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1574 alist-cons */
t7=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7775 in quick-put! in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7648(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7648,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7654,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7653 in walkeach in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7654,3,t0,t1,t2);}
/* compiler.scm: 1548 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7067(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7067,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7060(C_fix(1));
t13=(C_word)C_eqp(t11,lf[103]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7089(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
t16=t14;
f_7089(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[457])));}}

/* k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7089,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[404]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7101,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1430 ref */
t5=((C_word*)t0)[8];
f_7763(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[410]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7144,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1438 ref */
t6=((C_word*)t0)[8];
f_7763(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[273]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[437]));
if(C_truep(t5)){
t6=f_7060(C_fix(1));
/* compiler.scm: 1444 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7648(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[400]);
if(C_truep(t6)){
t7=f_7060(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[404],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7203,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1451 collect! */
t16=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[443],t15);}
else{
t12=t9;
f_7180(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7275,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1465 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7060(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1478 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[399]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[444]));
if(C_truep(t10)){
t11=f_7060(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7386,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1491 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7496,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7571,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1522 get */
t17=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[442]);}
else{
t15=t14;
f_7496(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[274]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7610,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1541 ##sys#hash-table-ref */
t17=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7610(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7610(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7610(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1545 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7648(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7608 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1542 set-real-name! */
t2=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7604(2,t2,C_SCHEME_UNDEFINED);}}

/* k7602 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1543 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7648(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7575 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1523 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[453],lf[454],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1524 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[456]);}}

/* k7584 in k7575 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1525 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[453],lf[455],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7571(2,t2,C_SCHEME_UNDEFINED);}}

/* k7569 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1526 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[452],((C_word*)t0)[2]);}

/* k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7525,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7525(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7525(t5,(C_word)C_i_not(t4));}}

/* k7523 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7525,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7060(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7540(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7540(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7540(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7531(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7499(2,t2,C_SCHEME_UNDEFINED);}}

/* k7538 in k7523 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7540,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1532 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7531(t2,C_SCHEME_UNDEFINED);}}

/* k7542 in k7538 in k7523 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7531(t3,t2);}

/* k7529 in k7523 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1533 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}

/* k7497 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7522,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1534 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7520 in k7497 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1534 assign */
t2=((C_word*)t0)[6];
f_7660(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7500 in k7497 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7505(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1535 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[451],C_SCHEME_TRUE);}}

/* k7503 in k7500 in k7497 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1536 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450],C_SCHEME_TRUE);}

/* k7506 in k7503 in k7500 in k7497 in k7494 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1537 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7067(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7386,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7393,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7478,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1497 collect! */
t9=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[449],t5);}
else{
t8=t7;
f_7393(2,t8,C_SCHEME_UNDEFINED);}}

/* k7476 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1498 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[448],((C_word*)t0)[2]);}

/* k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7467 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7468,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7472,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1501 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[433],((C_word*)t0)[2]);}

/* k7470 in a7467 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1502 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[430],C_SCHEME_TRUE);}

/* k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[447]:lf[281]);
/* compiler.scm: 1505 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[441],t4);}
else{
t3=t2;
f_7399(2,t3,C_SCHEME_UNDEFINED);}}

/* k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1509 simple-lambda-node? */
t4=C_retrieve(lf[446]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7451 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1509 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[445],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7402(2,t2,C_SCHEME_UNDEFINED);}}

/* k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7402,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7405(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7405(t5,t4);}}

/* k7403 in k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7405,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7438(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7438(t4,C_SCHEME_FALSE);}}

/* k7436 in k7403 in k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7408(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7408(t2,C_SCHEME_UNDEFINED);}}

/* k7406 in k7403 in k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7435,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1514 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7433 in k7406 in k7403 in k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1514 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7067(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7409 in k7406 in k7403 in k7400 in k7397 in k7394 in k7391 in a7385 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7341 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7342,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7360 in a7341 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7361,3,t0,t1,t2);}
/* compiler.scm: 1482 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[430],C_SCHEME_TRUE);}

/* k7344 in a7341 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7346,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7350,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1486 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7357 in k7344 in a7341 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1486 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7067(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7348 in k7344 in a7341 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7280(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7280,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1468 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1471 put! */
t7=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[433],((C_word*)t0)[8]);}}

/* k7305 in loop in k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7310,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1472 assign */
t3=((C_word*)t0)[4];
f_7660(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7308 in k7305 in loop in k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1473 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7067(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7311 in k7308 in k7305 in loop in k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1474 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7280(t4,((C_word*)t0)[2],t2,t3);}

/* k7296 in loop in k7273 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1468 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7067(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7201 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1453 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[442]);}

/* k7249 in k7201 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7251,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[438])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7214,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7180(2,t3,C_SCHEME_UNDEFINED);}}

/* a7213 in k7249 in k7201 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7214,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[404],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7233,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1459 get */
t10=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[441]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7231 in a7213 in k7249 in k7201 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1459 count! */
t2=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[440]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7178 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1461 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7067(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7181 in k7178 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1462 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7648(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7142 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7060(C_fix(1));
/* compiler.scm: 1440 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}

/* k7099 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7060(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1433 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[435],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7132,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1434 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[436]);}}}

/* k7130 in k7099 in k7087 in walk in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1434 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}}

/* assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7660,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[126],t7);
if(C_truep(t8)){
/* compiler.scm: 1552 put! */
t9=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[429],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7673,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[404],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7673(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7673(t13,C_SCHEME_FALSE);}}}

/* k7671 in assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7673,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7682(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7682(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1557 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[353]);}}}}

/* k7731 in k7671 in assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7682(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7680 in k7671 in assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7682,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1560 get-all */
t3=C_retrieve(lf[434]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[430],lf[431]);}
else{
/* compiler.scm: 1568 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}}

/* k7683 in k7680 in k7671 in assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1561 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[433]);}

/* k7686 in k7683 in k7680 in k7671 in assign in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[430],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[431],((C_word*)t0)[7]))){
/* compiler.scm: 1564 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1566 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[431],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1567 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}}}}

/* ref in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_7763(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7763,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1571 collect! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[427],t3);}

/* grow in k7056 in ##compiler#analyze-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static C_word C_fcall f_7060(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7045,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7036,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7027,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7018,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7009,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7000,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6991,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6982,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6973,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6964,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6958,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[413]));}

/* make-foreign-callback-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6952,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[413],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6277,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6280,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6324,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6823,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6839,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6924,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1398 walk */
t21=((C_word*)t6)[1];
f_6324(t21,t1,t2,*((C_word*)lf[412]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6924,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[411]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[104]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[108]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1396 every */
t8=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6839,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6845(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6845,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1379 reverse */
t5=*((C_word*)lf[289]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1380 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6924(3,t6,t4,t5);}}

/* k6863 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1381 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6845(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1383 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[388]);}}

/* k6881 in k6863 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1384 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6324(t4,((C_word*)t0)[2],t2,t3);}

/* a6891 in k6881 in k6863 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6892,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6906,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6918,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1389 varnode */
t7=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6916 in a6891 in k6881 in k6863 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1388 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6845(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6904 in a6891 in k6881 in k6863 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6857 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1379 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6823(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6823,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6829,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1372 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6839(t7,t1,t4,t6);}

/* a6828 in walk-inline-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6829,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[398],t3,t4,t2);
/* compiler.scm: 1375 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6698(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6698,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6702,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1348 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[403]);}

/* k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1349 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[406]);}

/* k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6755,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1353 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6753 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1353 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6751,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6728,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1354 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6839(t6,t4,((C_word*)t0)[2],t5);}

/* a6729 in k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1357 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6324(t4,t1,((C_word*)t0)[2],t3);}

/* a6735 in a6729 in k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6736,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6747,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1359 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6745 in a6735 in a6729 in k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1359 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6738 in a6735 in a6729 in k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6740,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[400],((C_word*)t0)[2],t1));}

/* k6726 in k6749 in k6757 in k6703 in k6700 in walk-call in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6728,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6324,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[404]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6346,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6346(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t14)){
t15=t13;
f_6346(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t15)){
t16=t13;
f_6346(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[274]);
t17=t13;
f_6346(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[410])));}}}}

/* k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6346,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1305 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1306 gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[403]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6452(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[406]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1328 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[282]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[247]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[406]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6612(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6612(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t10)){
t11=t8;
f_6612(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6612(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t13=t8;
f_6612(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6612,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1342 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6823(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1343 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6698(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[273]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6769,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1362 gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[403]);}
else{
/* compiler.scm: 1345 bomb */
t4=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[409]);}}}}

/* k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1363 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6770 in k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6772,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[406]);}

/* k6815 in k6770 in k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6813,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1367 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6811 in k6815 in k6770 in k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1367 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6807 in k6815 in k6770 in k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1369 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6803 in k6807 in k6815 in k6770 in k6767 in k6610 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[273],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t4));}

/* k6575 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6603,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[407]),t1,((C_word*)t0)[2]);}

/* k6601 in k6575 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6603,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1339 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6280(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6525 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1329 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6324(t4,((C_word*)t0)[2],t2,t3);}

/* a6535 in k6525 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6536,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[398],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6564,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1333 varnode */
t10=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6562 in a6535 in k6525 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1333 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6558 in a6535 in k6525 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6560,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6512 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1327 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6280(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6452(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6452,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1321 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6324(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1322 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6324(t6,t1,t4,t5);}}

/* a6474 in loop in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6475,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6489,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1326 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6452(t8,t5,t6,t7);}

/* k6487 in a6474 in loop in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1307 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[406]);}

/* k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6433,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1312 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6431 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1312 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6427 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6429,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1313 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6324(t7,t4,t5,t6);}

/* a6401 in k6427 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1317 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6324(t5,t3,t4,((C_word*)t0)[2]);}

/* k6411 in a6401 in k6427 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1318 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6324(t4,t2,t3,((C_word*)t0)[2]);}

/* k6415 in k6411 in a6401 in k6427 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[114],C_SCHEME_END_OF_LIST,t2));}

/* k6394 in k6427 in k6435 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6373,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1308 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6371 in k1 in k6359 in k6356 in k6344 in walk in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[400],lf[405],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6280,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6284,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1293 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[403]);}

/* k6282 in cps-lambda in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6307,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1296 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6324(t7,t4,t5,t6);}

/* a6306 in k6282 in cps-lambda in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6307,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6318,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1298 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6316 in a6306 in k6282 in cps-lambda in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[400],lf[401],t2));}

/* k6299 in k6282 in cps-lambda in ##compiler#perform-cps-conversion in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[4],t2);
/* compiler.scm: 1294 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6187,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6190,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6219,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1285 walk */
t10=((C_word*)t7)[1];
f_6219(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6219,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6238,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1280 ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[396]),t5);}
else{
/* compiler.scm: 1284 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6190(t5,t1,t2);}}}

/* k6236 in walk in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6238,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6244(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1282 alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6259 in k6236 in walk in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1282 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[396]),((C_word*)t0)[2],t1);}

/* k6242 in k6236 in walk in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1283 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6190(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6190,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6196(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6196,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1274 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6219(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6204 in loop in mapupdate in ##compiler#update-line-number-database! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1275 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6196(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6110,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6110(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6110(t5,C_SCHEME_FALSE);}}

/* k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6110,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6113(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6113(t3,lf[395]);}}

/* k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6113,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6116(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6116(t4,(C_word)C_i_cadr(t3));}}

/* k6114 in k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_6116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6116,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6119,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[393]+1),t4);}

/* k6130 in k6114 in k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6117 in k6114 in k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6120 in k6117 in k6114 in k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in ##compiler#expand-foreign-primitive in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1264 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6069,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6079,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6092,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[393]+1),t9);}

/* k6090 in ##compiler#expand-foreign-callback-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6077 in ##compiler#expand-foreign-callback-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6082,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6080 in k6077 in ##compiler#expand-foreign-callback-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6083 in k6080 in k6077 in ##compiler#expand-foreign-callback-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1255 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6032,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6042,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6055,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[393]+1),t9);}

/* k6053 in ##compiler#expand-foreign-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6040 in ##compiler#expand-foreign-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6045,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6043 in k6040 in ##compiler#expand-foreign-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6046 in k6043 in k6040 in ##compiler#expand-foreign-lambda* in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1247 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5987,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5994,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1234 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5994(2,t6,t4);}
else{
/* compiler.scm: 1236 quit */
t6=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[392],t4);}}}

/* k5992 in ##compiler#expand-foreign-callback-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5994,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6000,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[390]+1),t5);}

/* k5998 in k5992 in ##compiler#expand-foreign-callback-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1239 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5942,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5949,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1225 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5949(2,t6,t4);}
else{
/* compiler.scm: 1227 quit */
t6=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[391],t4);}}}

/* k5947 in ##compiler#expand-foreign-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5955,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[390]+1),t5);}

/* k5953 in k5947 in ##compiler#expand-foreign-lambda in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1230 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5788,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5792,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5936,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1198 list-tabulate */
t12=C_retrieve(lf[389]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5935 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5936,3,t0,t1,t2);}
/* compiler.scm: 1198 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[388]);}

/* k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1199 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[387]);}

/* k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1200 gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1201 estimate-foreign-result-size */
t3=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1202 set-real-name! */
t3=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5930,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1204 make-foreign-stub */
t3=C_retrieve(lf[362]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5930,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[274],((C_word*)t0)[2]);
t7=t5;
f_5814(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5814(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_5814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5814,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5905,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1210 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5904 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5905,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5913,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1210 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5911 in a5904 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1210 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[383]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5840,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[384],t1);
/* compiler.scm: 1215 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1216 final-foreign-type */
t7=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5855 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1217 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5858 in k5855 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[385],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5871,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1220 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5877 in k5858 in k5855 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1220 finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5873 in k5858 in k5855 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1219 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5869 in k5858 in k5855 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5840(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5848 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1215 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5838 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5840,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5826 in k5815 in k5812 in k5928 in k5802 in k5799 in k5796 in k5793 in k5790 in ##compiler#create-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5779,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5770,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5761,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5752,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5743,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5734,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5725,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5716,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5707,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5698,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5689,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5680,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5671,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5662,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5653,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5644,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5638,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[363]));}

/* make-foreign-stub in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5632,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[363],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4687,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4741(t5,t1);}

/* a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4741,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4745(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1023 syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[361],((C_word*)t0)[3]);}}

/* k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[296]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[299]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[300]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1035 check-decl */
f_4690(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[304]));
t9=t3;
f_4751(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4857,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1045 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[305]));
t10=t3;
f_4751(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4882,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1049 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[306]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[304]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[305]));
t12=t3;
f_4751(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1056 lset-intersection */
t12=C_retrieve(lf[307]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),t10,C_retrieve(lf[304]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1059 check-decl */
f_4690(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[308]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[309]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[308]);
t13=t3;
f_4751(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4751(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1065 ##match#set-error-control */
t15=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[311]);}
else{
t14=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4751(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4751(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4751(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4751(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4751(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4751(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1072 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[316]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5025,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1073 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[317]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4751(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5046,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1077 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[304]),C_retrieve(lf[305]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[319]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1081 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1085 every */
t28=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[323]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5109(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5109(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5109(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[327],t28);
/* compiler.scm: 1093 emit-control-file-item */
t30=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[329],t29);
/* compiler.scm: 1095 emit-control-file-item */
t31=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1098 pathname-strip-extension */
t31=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4751(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4751(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4751(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5247,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1104 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[338]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1106 check-decl */
f_4690(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t35)){
t36=C_set_block_item(lf[343],0,C_SCHEME_TRUE);
t37=t3;
f_4751(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[344]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[345]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5415,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5423,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1140 lset-difference */
t41=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5415(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1144 lset-difference */
t41=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1148 quit */
t41=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[348],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4751(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4751(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4751(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[350]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4751(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4751(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4751(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1157 lset-union */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[97]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[351]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5527,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1159 check-decl */
f_4690(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1167 every */
t47=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[355]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[356]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5601,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1171 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1181 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[360],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5600 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5601,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5606,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5611,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5610 in a5600 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5611,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[359]);}

/* k5604 in a5600 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5572 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5579,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1172 partition */
t4=C_retrieve(lf[358]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5578 in a5572 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5579,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1176 quit */
t3=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[357],t2);}}}

/* k5553 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1168 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1169 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[354],((C_word*)t0)[2]);}}

/* k5557 in k5553 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5525 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5534(2,t4,t2);}
else{
/* compiler.scm: 1164 quit */
t4=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[352],((C_word*)t0)[3]);}}

/* k5532 in k5525 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5508 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5434 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1145 lset-union */
t6=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k5438 in k5434 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5421 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5415(t3,t2);}

/* k5413 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_5415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5415,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1141 lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5417 in k5413 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4751(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1111 lset-difference */
t7=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[97]+1),C_retrieve(lf[304]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4751(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1115 lset-difference */
t8=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[97]+1),C_retrieve(lf[305]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4751(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1119 lset-union */
t9=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[97]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[306]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4751(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5359,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1126 lset-difference */
t10=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[97]+1),C_retrieve(lf[304]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1129 check-decl */
f_4690(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5368 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4751(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1134 ##match#set-error-control */
t6=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[311]);}
else{
/* compiler.scm: 1135 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[341],((C_word*)t0)[3]);}}}

/* k5357 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5359,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5363,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1127 lset-difference */
t4=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[305]),((C_word*)t0)[2]);}

/* k5361 in k5357 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5328 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5303 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5278 in k5258 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5245 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5197 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5208,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5207 in k5197 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5208,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[331]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[332],((C_word*)t0)[2],t2);}

/* k5204 in k5197 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[330],t1);
/* compiler.scm: 1097 emit-control-file-item */
t3=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5107 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_5109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1090 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[325],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1091 process-custom-declaration */
t4=C_retrieve(lf[326]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5085 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1086 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1087 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[321],((C_word*)t0)[2]);}}

/* k5089 in k5085 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5058 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1082 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5062 in k5058 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5044 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5046,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1079 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[304]),C_retrieve(lf[305]),C_retrieve(lf[17]));}

/* k5048 in k5044 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5023 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k5009 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[316]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4926 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4751(2,t4,t3);}

/* k4909 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1057 lset-intersection */
t4=C_retrieve(lf[307]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[305]));}

/* k4913 in k4909 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4880 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4855 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4840,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1037 stringify */
t5=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4838 in k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1037 string->c-identifier */
t2=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4814 in k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1038 hash-table-set! */
t3=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[300],((C_word*)t0)[2]);}

/* k4817 in k4814 in k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4826(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4826(t4,C_SCHEME_FALSE);}}

/* k4824 in k4817 in k4814 in k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1040 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[301],lf[302]);}
else{
t2=((C_word*)t0)[2];
f_4822(2,t2,C_SCHEME_UNDEFINED);}}

/* k4820 in k4817 in k4814 in k4808 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4763(2,t3,C_SCHEME_UNDEFINED);}}

/* k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1031 hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[296],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4751(2,t2,C_SCHEME_UNDEFINED);}}

/* a4796 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4790 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4791,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),((C_word*)t0)[2],t2);}

/* k4770 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4781,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4780 in k4770 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4781,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4789,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1032 stringify */
t4=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4787 in a4780 in k4770 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1032 string->c-identifier */
t2=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4773 in k4770 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1033 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4777 in k4773 in k4770 in k4761 in k4758 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4751(2,t3,t2);}

/* k4749 in k4743 in a4740 in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[295]);}

/* check-decl in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4690(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4690,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4703,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4703(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4713,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4713(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4713(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1018 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4711 in check-decl in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4703(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4701 in check-decl in ##compiler#process-declaration in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1019 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[294],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1938,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1941,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1953,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1977,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2110,a[2]=t5,a[3]=t11,a[4]=t4,a[5]=t9,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4632,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4645,a[2]=t2,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[124],C_retrieve(lf[291])))){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4682,a[2]=t2,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1001 newline */
t17=*((C_word*)lf[293]+1);
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t16=t15;
f_4645(2,t16,C_SCHEME_UNDEFINED);}}

/* k4680 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1001 pretty-print */
t2=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1002 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4646 in k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1006 reverse */
t4=*((C_word*)lf[289]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4661 in k4646 in k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4672,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1009 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4670 in k4661 in k4646 in k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1010 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[287]),C_retrieve(lf[13]));}

/* k4674 in k4670 in k4661 in k4646 in k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 455  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4657 in k4646 in k4643 in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 1004 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2110(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4632,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4637 in mapwalk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4638,3,t0,t1,t2);}
/* compiler.scm: 999  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2110(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 503  resolve-atom */
t9=((C_word*)((C_word*)t0)[7])[1];
f_2019(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 505  resolve-atom */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2019(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 507  constant? */
t7=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2147(2,t7,C_SCHEME_FALSE);}}}

/* k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[10]));}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 508  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[112],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 512  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 975  constant? */
t5=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 973  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[286],((C_word*)t0)[10]);}}}}}

/* k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 976  emit-syntax-trace-info */
t3=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 980  caar */
t5=*((C_word*)lf[284]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4508(t4,C_SCHEME_FALSE);}}}

/* k4606 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4508(t2,(C_word)C_eqp(lf[159],t1));}

/* k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4508,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 983  emit-syntax-trace-info */
t5=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 995  emit-syntax-trace-info */
t3=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4593 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 996  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4632(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4515 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 984  ##sys#check-syntax */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[283]);}

/* k4518 in k4515 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4529(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4529(t4,C_SCHEME_FALSE);}}

/* k4527 in k4518 in k4515 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4529,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 987  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[281]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 988  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[282]);}}

/* k4549 in k4527 in k4518 in k4515 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 989  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2110(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4542 in k4527 in k4518 in k4515 in k4506 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 987  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2110(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4494 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 977  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[280],((C_word*)t0)[4]);}

/* k4497 in k4494 in k4491 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 978  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4632(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=f_1941(((C_word*)t0)[12],((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2180,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t2,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 514  emit-syntax-trace-info */
t4=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[10],C_SCHEME_FALSE);}

/* k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[14]))){
t3=t2;
f_2183(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 517  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[277],((C_word*)t0)[2]);}
else{
/* compiler.scm: 518  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[278],((C_word*)t0)[14]);}}}

/* k4473 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 517  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 521  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[8]);}

/* k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[14],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 525  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[7]);}
else{
t4=t3;
f_2208(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t1,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 523  update-line-number-database! */
t4=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2199(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2197 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 524  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2110(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[13]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 527  walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_2110(t4,((C_word*)t0)[11],t3,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 532  ##sys#check-syntax */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[114],((C_word*)t0)[13],lf[117]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[103]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 540  ##sys#check-syntax */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[103],((C_word*)t0)[13],lf[118]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[119]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[120]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* compiler.scm: 546  walk */
t6=((C_word*)((C_word*)t0)[12])[1];
f_2110(t6,((C_word*)t0)[11],t5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[121]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 549  cadadr */
t7=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[126]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2335(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[273]);
if(C_truep(t8)){
t9=t7;
f_2335(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[274]);
if(C_truep(t9)){
t10=t7;
f_2335(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[104]);
t11=t7;
f_2335(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[7],lf[108])));}}}}}}}}}

/* k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[236],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2335,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[127]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2382(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 597  ##sys#check-syntax */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 611  ##sys#check-syntax */
t8=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 642  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2110(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[123]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 658  ##sys#check-syntax */
t12=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 697  unquotify */
t14=((C_word*)t0)[3];
f_1977(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3091,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 705  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2110(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 710  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2110(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 715  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 719  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 723  ##sys#check-syntax */
t21=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 735  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 738  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 741  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 744  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 747  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3301(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 754  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3368,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 765  gensym */
t33=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 778  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3442,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 783  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 798  gensym */
t34=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3644,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3662,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3794,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3796,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  call-with-current-continuation */
t37=*((C_word*)lf[244]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[245]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3869,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[247]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3892,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 870  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[270],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 945  ##sys#check-syntax */
t36=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[270],((C_word*)t0)[12],lf[272]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 963  ##sys#hash-table-ref */
t36=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4395(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4395(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4393 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 965  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 970  handle-call */
t2=((C_word*)t0)[7];
f_4266(t2,((C_word*)t0)[6]);}}

/* k4399 in k4393 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 967  handle-call */
t2=((C_word*)t0)[7];
f_4266(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 968  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2110(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4304 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1941(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t7=(C_word)C_a_i_list(&a,5,lf[271],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 950  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2110(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 954  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2110(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 956  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t7=(C_word)C_a_i_list(&a,5,lf[271],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 958  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2110(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t4=(C_word)C_a_i_list(&a,5,lf[271],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 959  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2110(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4364 in k4304 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[104],t2));}

/* handle-call in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4266,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 934  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4632(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4268 in handle-call in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4276,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 936  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4274 in k4268 in handle-call in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 941  alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4279(2,t3,C_SCHEME_UNDEFINED);}}

/* k4288 in k4274 in k4268 in handle-call in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 938  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4277 in k4274 in k4268 in handle-call in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3902,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3924,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 877  valid-c-identifier? */
t14=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4248 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3924(2,t4,t3);}
else{
/* compiler.scm: 879  quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[268],((C_word*)t0)[3]);}}

/* k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4215(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4215(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4215(t11,(C_word)C_i_not(t10));}}}

/* k4213 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 884  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[267],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3927(2,t2,C_SCHEME_UNDEFINED);}}

/* k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 888  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4632(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4165,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4165(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4205,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4209,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 900  final-foreign-type */
t9=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4207 in loop in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 900  finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4203 in loop in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 899  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4199 in loop in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 902  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4165(t6,t3,t4,t5);}

/* k4187 in k4199 in loop in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[253]))){
/* compiler.scm: 905  g292 */
t7=t6;
f_4037(2,t7,f_4014(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 905  g292 */
t7=t6;
f_4037(2,t7,f_4014(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[255]);
if(C_truep(t7)){
/* compiler.scm: 905  g292 */
t8=t6;
f_4037(2,t8,f_4014(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t8)){
/* compiler.scm: 905  g292 */
t9=t6;
f_4037(2,t9,f_4014(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[257]))){
/* compiler.scm: 905  g293 */
t9=t4;
f_4009(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[258]))){
/* compiler.scm: 905  g293 */
t9=t4;
f_4009(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t9)){
/* compiler.scm: 905  g293 */
t10=t4;
f_4009(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t10)){
/* compiler.scm: 905  g293 */
t11=t4;
f_4009(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[261]);
if(C_truep(t11)){
/* compiler.scm: 905  g293 */
t12=t4;
f_4009(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
if(C_truep(t12)){
/* compiler.scm: 905  g293 */
t13=t4;
f_4009(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[263]);
if(C_truep(t13)){
/* compiler.scm: 905  g294 */
t14=t6;
f_4037(2,t14,f_3972(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[264]))){
/* compiler.scm: 905  g294 */
t14=t6;
f_4037(2,t14,f_3972(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[265]);
/* compiler.scm: 905  g294 */
t15=t6;
f_4037(2,t15,(C_truep(t14)?f_3972(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[266]))?f_3972(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4035 in k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 903  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g292 in k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static C_word C_fcall f_4014(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[250],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g293 in k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_4009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4009,NULL,2,t0,t1);}
/* compiler.scm: 917  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[252],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g294 in k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static C_word C_fcall f_3972(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[249],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[250],lf[249]);
t7=(C_word)C_a_i_list(&a,3,lf[251],lf[249],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k3960 in k3956 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 889  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2110(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3944 in k3936 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 455  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3932 in k3925 in k3922 in a3901 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[247],t1));}

/* a3891 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3892,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 870  split-at */
t3=C_retrieve(lf[248]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3868 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3869,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 865  process-declaration */
t4=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3865 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 863  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2110(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3802,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3814,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  with-exception-handler */
t5=C_retrieve(lf[243]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3813 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3835 in a3813 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3836r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3836r(t0,t1,t2);}}

static void C_ccall f_3836r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  g254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3841 in a3835 in a3813 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3819 in a3813 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 841  collapsable-literal? */
t3=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3825 in a3819 in a3813 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 843  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3801 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3802,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  g254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3807 in a3801 in a3795 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
/* compiler.scm: 839  quit */
t2=C_retrieve(lf[241]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[242],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3792 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[103],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 846  collapsable-literal? */
t8=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 847  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 850  basic-literal? */
t4=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k3778 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3744(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 851  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[237],lf[238],((C_word*)t0)[2]);}}

/* k3742 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 855  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}

/* k3745 in k3742 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 856  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3748 in k3745 in k3742 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 857  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3752 in k3748 in k3745 in k3742 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 860  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2110(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3735 in k3732 in k3721 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3662,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3666,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 827  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3664 in a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 828  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3702 in k3664 in a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 828  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3668 in k3664 in a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3684,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3683 in k3668 in k3664 in a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3684,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[103],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3680 in k3668 in k3664 in a3661 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 830  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2110(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3643 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3652,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 826  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2110(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3650 in a3643 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 825  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 799  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 801  set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3526,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 804  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3603 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 804  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3582,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3557(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3557(t11,C_SCHEME_END_OF_LIST);}}

/* k3555 in k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_3557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3557,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 817  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3565(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3563 in k3555 in k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 455  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3551 in k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 818  alist-cons */
t4=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3547 in k3551 in k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 812  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3539 in k3580 in k3524 in k3518 in k3515 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 786  make-random-name */
t9=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3454(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3482,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 787  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3488 in k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 787  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3480 in k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3454(t3,t2);}

/* k3452 in k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_3454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3454,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3472 in k3452 in k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 792  alist-cons */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3464 in k3472 in k3452 in k3449 in k3440 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3420 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3366 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 766  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3369 in k3366 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 767  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3372 in k3369 in k3366 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 768  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3376 in k3372 in k3369 in k3366 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 769  cons* */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3380 in k3376 in k3372 in k3369 in k3366 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3382,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 770  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2110(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3299 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3313(2,t3,t1);}
else{
/* compiler.scm: 756  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3311 in k3299 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3284 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 747  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3271 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 744  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3258 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 741  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3245 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 738  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3232 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 735  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3186,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3186(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_3186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 730  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2110(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3213,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 731  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2110(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3211 in fold in k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 731  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3186(t3,t2,((C_word*)t0)[2]);}

/* k3215 in k3211 in fold in k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3204 in fold in k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3178 in k3165 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 725  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3152 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3137 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 716  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2110(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3110 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3116,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 711  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2110(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3114 in k3110 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3089 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3060 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 702  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4632(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3064 in k3060 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3031 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 697  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4632(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3035 in k3031 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1941(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 661  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2871,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 662  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2110(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2874,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 664  ##sys#alias-global-hook */
t5=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2874(2,t4,C_SCHEME_UNDEFINED);}}

/* k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 667  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_2982(t4,C_SCHEME_UNDEFINED);}}

/* k3006 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 668  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3010 in k3006 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_2982(t3,t2);}

/* k2980 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2982,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 669  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2986 in k2980 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 673  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3001(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2874(2,t2,C_SCHEME_UNDEFINED);}}

/* k2999 in k2986 in k2980 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 670  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2989 in k2986 in k2980 in k2977 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 674  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2874(2,t2,C_SCHEME_UNDEFINED);}}

/* k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 675  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2967 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 676  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2877(2,t2,C_SCHEME_UNDEFINED);}}

/* k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 680  gensym */
t5=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  gensym */
t6=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2930 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 689  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2961 in k2930 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2955,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 693  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2953 in k2961 in k2930 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2887 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 681  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2918 in k2887 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2908,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 684  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2906 in k2918 in k2887 in k2875 in k2872 in k2869 in k2866 in k2857 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2845 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 648  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2822 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2839,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 651  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2838 in k2822 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2835 in k2822 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 650  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2110(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2825 in k2822 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2830,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 654  set-real-names! */
f_1953(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2828 in k2825 in k2822 in k2819 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2579,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 614  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2769 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 615  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2579(2,t2,C_SCHEME_UNDEFINED);}}

/* a2781 in k2769 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2782,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2775 in k2769 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
/* compiler.scm: 617  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 620  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2584,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[123]),t2);}

/* k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 624  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[8],t1);}

/* k2766 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 624  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 625  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[12]);}

/* a2759 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2760,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 626  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2110(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 630  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t4=t3;
f_2751(t4,C_SCHEME_FALSE);}}

/* k2756 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2751(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2749 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 628  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2635,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2635(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2635(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2635(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2603(2,t3,C_SCHEME_UNDEFINED);}}

/* k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2635,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 632  g159 */
t6=((C_word*)t0)[3];
f_2625(t6,((C_word*)t0)[2],t4);}
else{
t4=((C_word*)t0)[2];
f_2603(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t5=t3;
f_2668(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
f_2603(2,t2,C_SCHEME_FALSE);}}

/* k2717 in k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2668(t3,C_SCHEME_FALSE);}}

/* k2713 in k2717 in k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2668(t2,C_SCHEME_FALSE);}}

/* k2709 in k2713 in k2717 in k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2668(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2668(t2,C_SCHEME_FALSE);}}

/* k2666 in k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 632  cadadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
f_2603(2,t2,C_SCHEME_FALSE);}}

/* k2673 in k2666 in k2633 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 632  g159 */
t3=((C_word*)t0)[3];
f_2625(t3,((C_word*)t0)[2],t1);}

/* g159 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2625,NULL,3,t0,t1,t2);}
/* compiler.scm: 634  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k2601 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 636  set-real-names! */
f_1953(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2604 in k2601 in k2598 in k2595 in k2592 in k2589 in k2586 in a2583 in k2577 in k2568 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 638  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 599  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2505,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[123]),t1);}

/* k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 601  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2556 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 601  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 602  set-real-names! */
f_1953(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 603  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2537 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2538,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2546,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 604  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2110(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2544 in a2537 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2516 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 606  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2531 in k2516 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2532,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2524 in k2516 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 606  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2520 in k2516 in k2509 in k2506 in k2503 in k2500 in k2494 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2382,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2392,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 574  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2403,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2403,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2468(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 578  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2468(2,t6,C_SCHEME_FALSE);}}}

/* k2475 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2468(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 580  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2485 in k2475 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 579  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2466 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2468,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 586  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2430(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2430(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 582  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2440 in k2466 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2430(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2430(t2,C_SCHEME_FALSE);}}

/* a2455 in k2440 in k2466 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2456,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2452 in k2440 in k2466 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2430(t2,C_SCHEME_TRUE);}

/* k2428 in k2466 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2407(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 592  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2405 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 593  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2382(t4,t2,t3);}

/* k2412 in k2405 in a2402 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2396 in k2390 in loop in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
/* compiler.scm: 575  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2374 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 570  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2110(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2342 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2347,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2345 in k2342 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 564  hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2357 in k2345 in k2342 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2351 in k2345 in k2342 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2352,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2348 in k2345 in k2342 in k2333 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[128]);}

/* k2300 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 552  gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[124]);}}

/* k2312 in k2300 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 553  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2316 in k2312 in k2300 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2275 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2229 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 533  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2110(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2236 in k2229 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 534  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2110(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2240 in k2236 in k2229 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2246(2,t4,lf[115]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 537  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2110(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2244 in k2240 in k2236 in k2229 in k2206 in k2188 in k2181 in k2178 in k2172 in k2145 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[114],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2133 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 506  ##sys#alias-global-hook */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2127 in walk in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2019,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2023,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 475  ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2023(2,t7,C_SCHEME_FALSE);}}

/* k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 476  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2110(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 477  ##sys#hash-table-ref */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2036(2,t3,C_SCHEME_FALSE);}}}

/* k2034 in k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 479  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2110(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 483  final-foreign-type */
t5=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 491  final-foreign-type */
t6=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2082 in k2034 in k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[108],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 494  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2092 in k2082 in k2034 in k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 493  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2052 in k2034 in k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[104],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 486  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2062 in k2052 in k2034 in k2021 in resolve-atom in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 485  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1977,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[103]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_1984(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_1984(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_1984(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1984(t4,C_SCHEME_FALSE);}}

/* k1982 in unquotify in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_1984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_fcall f_1953(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1953,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1959,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 462  for-each */
t5=*((C_word*)lf[102]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1958 in set-real-names! in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1959,4,t0,t1,t2,t3);}
/* compiler.scm: 462  set-real-name! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static C_word C_fcall f_1941(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 434  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1934 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1877(2,t3,t2);}

/* k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 437  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1927 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1880(2,t3,t2);}

/* k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 440  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 441  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1920 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1883(2,t3,t2);}

/* k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 442  make-random-name */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[99]);}

/* k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1889 in k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 444  make-hash-table */
t4=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k1893 in k1889 in k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 446  vector-fill! */
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 447  make-vector */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1913 in k1893 in k1889 in k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1898(2,t3,t2);}

/* k1896 in k1893 in k1889 in k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 449  vector-fill! */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 450  make-vector */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1906 in k1896 in k1893 in k1889 in k1885 in k1881 in k1878 in k1875 in ##compiler#initialize-compiler in k1786 in k1782 in k1778 in k1774 in k1770 in k1766 in k1759 in k1756 in k1753 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[816] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1755compiler.scm",(void*)f_1755},
{"f_1758compiler.scm",(void*)f_1758},
{"f_1761compiler.scm",(void*)f_1761},
{"f_1768compiler.scm",(void*)f_1768},
{"f_1772compiler.scm",(void*)f_1772},
{"f_1776compiler.scm",(void*)f_1776},
{"f_1780compiler.scm",(void*)f_1780},
{"f_1784compiler.scm",(void*)f_1784},
{"f_1788compiler.scm",(void*)f_1788},
{"f_10095compiler.scm",(void*)f_10095},
{"f_11139compiler.scm",(void*)f_11139},
{"f_11142compiler.scm",(void*)f_11142},
{"f_11145compiler.scm",(void*)f_11145},
{"f_11148compiler.scm",(void*)f_11148},
{"f_11151compiler.scm",(void*)f_11151},
{"f_10952compiler.scm",(void*)f_10952},
{"f_10958compiler.scm",(void*)f_10958},
{"f_10185compiler.scm",(void*)f_10185},
{"f_10941compiler.scm",(void*)f_10941},
{"f_10938compiler.scm",(void*)f_10938},
{"f_10851compiler.scm",(void*)f_10851},
{"f_10915compiler.scm",(void*)f_10915},
{"f_10928compiler.scm",(void*)f_10928},
{"f_10909compiler.scm",(void*)f_10909},
{"f_10899compiler.scm",(void*)f_10899},
{"f_10872compiler.scm",(void*)f_10872},
{"f_10875compiler.scm",(void*)f_10875},
{"f_10823compiler.scm",(void*)f_10823},
{"f_10826compiler.scm",(void*)f_10826},
{"f_10780compiler.scm",(void*)f_10780},
{"f_10792compiler.scm",(void*)f_10792},
{"f_10783compiler.scm",(void*)f_10783},
{"f_10786compiler.scm",(void*)f_10786},
{"f_10660compiler.scm",(void*)f_10660},
{"f_10761compiler.scm",(void*)f_10761},
{"f_10749compiler.scm",(void*)f_10749},
{"f_10688compiler.scm",(void*)f_10688},
{"f_10694compiler.scm",(void*)f_10694},
{"f_10718compiler.scm",(void*)f_10718},
{"f_10710compiler.scm",(void*)f_10710},
{"f_10676compiler.scm",(void*)f_10676},
{"f_10619compiler.scm",(void*)f_10619},
{"f_10631compiler.scm",(void*)f_10631},
{"f_10635compiler.scm",(void*)f_10635},
{"f_10623compiler.scm",(void*)f_10623},
{"f_10435compiler.scm",(void*)f_10435},
{"f_10556compiler.scm",(void*)f_10556},
{"f_10562compiler.scm",(void*)f_10562},
{"f_10587compiler.scm",(void*)f_10587},
{"f_10568compiler.scm",(void*)f_10568},
{"f_10442compiler.scm",(void*)f_10442},
{"f_10547compiler.scm",(void*)f_10547},
{"f_10445compiler.scm",(void*)f_10445},
{"f_10448compiler.scm",(void*)f_10448},
{"f_10451compiler.scm",(void*)f_10451},
{"f_10489compiler.scm",(void*)f_10489},
{"f_10515compiler.scm",(void*)f_10515},
{"f_10496compiler.scm",(void*)f_10496},
{"f_10500compiler.scm",(void*)f_10500},
{"f_10473compiler.scm",(void*)f_10473},
{"f_10379compiler.scm",(void*)f_10379},
{"f_10388compiler.scm",(void*)f_10388},
{"f_10382compiler.scm",(void*)f_10382},
{"f_10363compiler.scm",(void*)f_10363},
{"f_10336compiler.scm",(void*)f_10336},
{"f_10319compiler.scm",(void*)f_10319},
{"f_10315compiler.scm",(void*)f_10315},
{"f_10308compiler.scm",(void*)f_10308},
{"f_10291compiler.scm",(void*)f_10291},
{"f_10287compiler.scm",(void*)f_10287},
{"f_10263compiler.scm",(void*)f_10263},
{"f_10243compiler.scm",(void*)f_10243},
{"f_10098compiler.scm",(void*)f_10098},
{"f_10102compiler.scm",(void*)f_10102},
{"f_10117compiler.scm",(void*)f_10117},
{"f_10127compiler.scm",(void*)f_10127},
{"f_10132compiler.scm",(void*)f_10132},
{"f_10177compiler.scm",(void*)f_10177},
{"f_10136compiler.scm",(void*)f_10136},
{"f_10142compiler.scm",(void*)f_10142},
{"f_10152compiler.scm",(void*)f_10152},
{"f_10964compiler.scm",(void*)f_10964},
{"f_10971compiler.scm",(void*)f_10971},
{"f_11026compiler.scm",(void*)f_11026},
{"f_10977compiler.scm",(void*)f_10977},
{"f_11003compiler.scm",(void*)f_11003},
{"f_10993compiler.scm",(void*)f_10993},
{"f_11058compiler.scm",(void*)f_11058},
{"f_11074compiler.scm",(void*)f_11074},
{"f_11081compiler.scm",(void*)f_11081},
{"f_11088compiler.scm",(void*)f_11088},
{"f_11062compiler.scm",(void*)f_11062},
{"f_11072compiler.scm",(void*)f_11072},
{"f_11044compiler.scm",(void*)f_11044},
{"f_11052compiler.scm",(void*)f_11052},
{"f_11090compiler.scm",(void*)f_11090},
{"f_11094compiler.scm",(void*)f_11094},
{"f_10086compiler.scm",(void*)f_10086},
{"f_10077compiler.scm",(void*)f_10077},
{"f_10068compiler.scm",(void*)f_10068},
{"f_10059compiler.scm",(void*)f_10059},
{"f_10050compiler.scm",(void*)f_10050},
{"f_10041compiler.scm",(void*)f_10041},
{"f_10032compiler.scm",(void*)f_10032},
{"f_10023compiler.scm",(void*)f_10023},
{"f_10014compiler.scm",(void*)f_10014},
{"f_10005compiler.scm",(void*)f_10005},
{"f_9996compiler.scm",(void*)f_9996},
{"f_9987compiler.scm",(void*)f_9987},
{"f_9978compiler.scm",(void*)f_9978},
{"f_9969compiler.scm",(void*)f_9969},
{"f_9960compiler.scm",(void*)f_9960},
{"f_9951compiler.scm",(void*)f_9951},
{"f_9942compiler.scm",(void*)f_9942},
{"f_9933compiler.scm",(void*)f_9933},
{"f_9924compiler.scm",(void*)f_9924},
{"f_9915compiler.scm",(void*)f_9915},
{"f_9906compiler.scm",(void*)f_9906},
{"f_9897compiler.scm",(void*)f_9897},
{"f_9888compiler.scm",(void*)f_9888},
{"f_9879compiler.scm",(void*)f_9879},
{"f_9870compiler.scm",(void*)f_9870},
{"f_9861compiler.scm",(void*)f_9861},
{"f_9852compiler.scm",(void*)f_9852},
{"f_9843compiler.scm",(void*)f_9843},
{"f_9834compiler.scm",(void*)f_9834},
{"f_9825compiler.scm",(void*)f_9825},
{"f_9819compiler.scm",(void*)f_9819},
{"f_9813compiler.scm",(void*)f_9813},
{"f_8579compiler.scm",(void*)f_8579},
{"f_9780compiler.scm",(void*)f_9780},
{"f_9783compiler.scm",(void*)f_9783},
{"f_9786compiler.scm",(void*)f_9786},
{"f_9789compiler.scm",(void*)f_9789},
{"f_9792compiler.scm",(void*)f_9792},
{"f_9807compiler.scm",(void*)f_9807},
{"f_9805compiler.scm",(void*)f_9805},
{"f_9795compiler.scm",(void*)f_9795},
{"f_9632compiler.scm",(void*)f_9632},
{"f_9638compiler.scm",(void*)f_9638},
{"f_8943compiler.scm",(void*)f_8943},
{"f_8962compiler.scm",(void*)f_8962},
{"f_8995compiler.scm",(void*)f_8995},
{"f_9522compiler.scm",(void*)f_9522},
{"f_9518compiler.scm",(void*)f_9518},
{"f_9511compiler.scm",(void*)f_9511},
{"f_9362compiler.scm",(void*)f_9362},
{"f_9368compiler.scm",(void*)f_9368},
{"f_9438compiler.scm",(void*)f_9438},
{"f_9468compiler.scm",(void*)f_9468},
{"f_9451compiler.scm",(void*)f_9451},
{"f_9455compiler.scm",(void*)f_9455},
{"f_9377compiler.scm",(void*)f_9377},
{"f_9424compiler.scm",(void*)f_9424},
{"f_9428compiler.scm",(void*)f_9428},
{"f_9404compiler.scm",(void*)f_9404},
{"f_9400compiler.scm",(void*)f_9400},
{"f_9091compiler.scm",(void*)f_9091},
{"f_9340compiler.scm",(void*)f_9340},
{"f_9095compiler.scm",(void*)f_9095},
{"f_9338compiler.scm",(void*)f_9338},
{"f_9098compiler.scm",(void*)f_9098},
{"f_9101compiler.scm",(void*)f_9101},
{"f_9107compiler.scm",(void*)f_9107},
{"f_9113compiler.scm",(void*)f_9113},
{"f_9119compiler.scm",(void*)f_9119},
{"f_9305compiler.scm",(void*)f_9305},
{"f_9308compiler.scm",(void*)f_9308},
{"f_9122compiler.scm",(void*)f_9122},
{"f_9281compiler.scm",(void*)f_9281},
{"f_9266compiler.scm",(void*)f_9266},
{"f_9262compiler.scm",(void*)f_9262},
{"f_9196compiler.scm",(void*)f_9196},
{"f_9221compiler.scm",(void*)f_9221},
{"f_9227compiler.scm",(void*)f_9227},
{"f_9238compiler.scm",(void*)f_9238},
{"f_9225compiler.scm",(void*)f_9225},
{"f_9207compiler.scm",(void*)f_9207},
{"f_9199compiler.scm",(void*)f_9199},
{"f_9184compiler.scm",(void*)f_9184},
{"f_9192compiler.scm",(void*)f_9192},
{"f_9145compiler.scm",(void*)f_9145},
{"f_9175compiler.scm",(void*)f_9175},
{"f_9167compiler.scm",(void*)f_9167},
{"f_9163compiler.scm",(void*)f_9163},
{"f_9159compiler.scm",(void*)f_9159},
{"f_9148compiler.scm",(void*)f_9148},
{"f_9016compiler.scm",(void*)f_9016},
{"f_9019compiler.scm",(void*)f_9019},
{"f_9071compiler.scm",(void*)f_9071},
{"f_9035compiler.scm",(void*)f_9035},
{"f_9064compiler.scm",(void*)f_9064},
{"f_9056compiler.scm",(void*)f_9056},
{"f_9001compiler.scm",(void*)f_9001},
{"f_8974compiler.scm",(void*)f_8974},
{"f_8980compiler.scm",(void*)f_8980},
{"f_9644compiler.scm",(void*)f_9644},
{"f_9651compiler.scm",(void*)f_9651},
{"f_9667compiler.scm",(void*)f_9667},
{"f_8609compiler.scm",(void*)f_8609},
{"f_8628compiler.scm",(void*)f_8628},
{"f_8907compiler.scm",(void*)f_8907},
{"f_8868compiler.scm",(void*)f_8868},
{"f_9683compiler.scm",(void*)f_9683},
{"f_9721compiler.scm",(void*)f_9721},
{"f_9747compiler.scm",(void*)f_9747},
{"f_9733compiler.scm",(void*)f_9733},
{"f_9712compiler.scm",(void*)f_9712},
{"f_9681compiler.scm",(void*)f_9681},
{"f_8881compiler.scm",(void*)f_8881},
{"f_8884compiler.scm",(void*)f_8884},
{"f_8895compiler.scm",(void*)f_8895},
{"f_8832compiler.scm",(void*)f_8832},
{"f_8724compiler.scm",(void*)f_8724},
{"f_8730compiler.scm",(void*)f_8730},
{"f_8742compiler.scm",(void*)f_8742},
{"f_8745compiler.scm",(void*)f_8745},
{"f_8748compiler.scm",(void*)f_8748},
{"f_8766compiler.scm",(void*)f_8766},
{"f_8773compiler.scm",(void*)f_8773},
{"f_8751compiler.scm",(void*)f_8751},
{"f_8754compiler.scm",(void*)f_8754},
{"f_8757compiler.scm",(void*)f_8757},
{"f_8718compiler.scm",(void*)f_8718},
{"f_8708compiler.scm",(void*)f_8708},
{"f_8691compiler.scm",(void*)f_8691},
{"f_8696compiler.scm",(void*)f_8696},
{"f_8649compiler.scm",(void*)f_8649},
{"f_8666compiler.scm",(void*)f_8666},
{"f_8653compiler.scm",(void*)f_8653},
{"f_8664compiler.scm",(void*)f_8664},
{"f_8639compiler.scm",(void*)f_8639},
{"f_8598compiler.scm",(void*)f_8598},
{"f_8607compiler.scm",(void*)f_8607},
{"f_8588compiler.scm",(void*)f_8588},
{"f_8593compiler.scm",(void*)f_8593},
{"f_8582compiler.scm",(void*)f_8582},
{"f_7054compiler.scm",(void*)f_7054},
{"f_7058compiler.scm",(void*)f_7058},
{"f_7808compiler.scm",(void*)f_7808},
{"f_7811compiler.scm",(void*)f_7811},
{"f_7815compiler.scm",(void*)f_7815},
{"f_7818compiler.scm",(void*)f_7818},
{"f_7831compiler.scm",(void*)f_7831},
{"f_8466compiler.scm",(void*)f_8466},
{"f_7835compiler.scm",(void*)f_7835},
{"f_8431compiler.scm",(void*)f_8431},
{"f_7842compiler.scm",(void*)f_7842},
{"f_8377compiler.scm",(void*)f_8377},
{"f_8380compiler.scm",(void*)f_8380},
{"f_8392compiler.scm",(void*)f_8392},
{"f_8386compiler.scm",(void*)f_8386},
{"f_7845compiler.scm",(void*)f_7845},
{"f_7848compiler.scm",(void*)f_7848},
{"f_8360compiler.scm",(void*)f_8360},
{"f_8352compiler.scm",(void*)f_8352},
{"f_8320compiler.scm",(void*)f_8320},
{"f_8326compiler.scm",(void*)f_8326},
{"f_7851compiler.scm",(void*)f_7851},
{"f_8282compiler.scm",(void*)f_8282},
{"f_8291compiler.scm",(void*)f_8291},
{"f_8294compiler.scm",(void*)f_8294},
{"f_7854compiler.scm",(void*)f_7854},
{"f_8183compiler.scm",(void*)f_8183},
{"f_8201compiler.scm",(void*)f_8201},
{"f_8244compiler.scm",(void*)f_8244},
{"f_8269compiler.scm",(void*)f_8269},
{"f_8265compiler.scm",(void*)f_8265},
{"f_8251compiler.scm",(void*)f_8251},
{"f_8254compiler.scm",(void*)f_8254},
{"f_8205compiler.scm",(void*)f_8205},
{"f_8211compiler.scm",(void*)f_8211},
{"f_7857compiler.scm",(void*)f_7857},
{"f_8161compiler.scm",(void*)f_8161},
{"f_8147compiler.scm",(void*)f_8147},
{"f_8154compiler.scm",(void*)f_8154},
{"f_8135compiler.scm",(void*)f_8135},
{"f_8120compiler.scm",(void*)f_8120},
{"f_7860compiler.scm",(void*)f_7860},
{"f_8032compiler.scm",(void*)f_8032},
{"f_8106compiler.scm",(void*)f_8106},
{"f_8038compiler.scm",(void*)f_8038},
{"f_8096compiler.scm",(void*)f_8096},
{"f_8088compiler.scm",(void*)f_8088},
{"f_8084compiler.scm",(void*)f_8084},
{"f_8041compiler.scm",(void*)f_8041},
{"f_8044compiler.scm",(void*)f_8044},
{"f_7863compiler.scm",(void*)f_7863},
{"f_7891compiler.scm",(void*)f_7891},
{"f_7912compiler.scm",(void*)f_7912},
{"f_7933compiler.scm",(void*)f_7933},
{"f_7939compiler.scm",(void*)f_7939},
{"f_7866compiler.scm",(void*)f_7866},
{"f_7872compiler.scm",(void*)f_7872},
{"f_7876compiler.scm",(void*)f_7876},
{"f_7821compiler.scm",(void*)f_7821},
{"f_7825compiler.scm",(void*)f_7825},
{"f_7828compiler.scm",(void*)f_7828},
{"f_7783compiler.scm",(void*)f_7783},
{"f_7793compiler.scm",(void*)f_7793},
{"f_7801compiler.scm",(void*)f_7801},
{"f_7769compiler.scm",(void*)f_7769},
{"f_7777compiler.scm",(void*)f_7777},
{"f_7648compiler.scm",(void*)f_7648},
{"f_7654compiler.scm",(void*)f_7654},
{"f_7067compiler.scm",(void*)f_7067},
{"f_7089compiler.scm",(void*)f_7089},
{"f_7610compiler.scm",(void*)f_7610},
{"f_7604compiler.scm",(void*)f_7604},
{"f_7577compiler.scm",(void*)f_7577},
{"f_7586compiler.scm",(void*)f_7586},
{"f_7571compiler.scm",(void*)f_7571},
{"f_7496compiler.scm",(void*)f_7496},
{"f_7525compiler.scm",(void*)f_7525},
{"f_7540compiler.scm",(void*)f_7540},
{"f_7544compiler.scm",(void*)f_7544},
{"f_7531compiler.scm",(void*)f_7531},
{"f_7499compiler.scm",(void*)f_7499},
{"f_7522compiler.scm",(void*)f_7522},
{"f_7502compiler.scm",(void*)f_7502},
{"f_7505compiler.scm",(void*)f_7505},
{"f_7508compiler.scm",(void*)f_7508},
{"f_7386compiler.scm",(void*)f_7386},
{"f_7478compiler.scm",(void*)f_7478},
{"f_7393compiler.scm",(void*)f_7393},
{"f_7468compiler.scm",(void*)f_7468},
{"f_7472compiler.scm",(void*)f_7472},
{"f_7396compiler.scm",(void*)f_7396},
{"f_7399compiler.scm",(void*)f_7399},
{"f_7453compiler.scm",(void*)f_7453},
{"f_7402compiler.scm",(void*)f_7402},
{"f_7405compiler.scm",(void*)f_7405},
{"f_7438compiler.scm",(void*)f_7438},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7435compiler.scm",(void*)f_7435},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7342compiler.scm",(void*)f_7342},
{"f_7361compiler.scm",(void*)f_7361},
{"f_7346compiler.scm",(void*)f_7346},
{"f_7359compiler.scm",(void*)f_7359},
{"f_7350compiler.scm",(void*)f_7350},
{"f_7275compiler.scm",(void*)f_7275},
{"f_7280compiler.scm",(void*)f_7280},
{"f_7307compiler.scm",(void*)f_7307},
{"f_7310compiler.scm",(void*)f_7310},
{"f_7313compiler.scm",(void*)f_7313},
{"f_7298compiler.scm",(void*)f_7298},
{"f_7203compiler.scm",(void*)f_7203},
{"f_7251compiler.scm",(void*)f_7251},
{"f_7214compiler.scm",(void*)f_7214},
{"f_7233compiler.scm",(void*)f_7233},
{"f_7180compiler.scm",(void*)f_7180},
{"f_7183compiler.scm",(void*)f_7183},
{"f_7144compiler.scm",(void*)f_7144},
{"f_7101compiler.scm",(void*)f_7101},
{"f_7132compiler.scm",(void*)f_7132},
{"f_7660compiler.scm",(void*)f_7660},
{"f_7673compiler.scm",(void*)f_7673},
{"f_7733compiler.scm",(void*)f_7733},
{"f_7682compiler.scm",(void*)f_7682},
{"f_7685compiler.scm",(void*)f_7685},
{"f_7688compiler.scm",(void*)f_7688},
{"f_7763compiler.scm",(void*)f_7763},
{"f_7060compiler.scm",(void*)f_7060},
{"f_7045compiler.scm",(void*)f_7045},
{"f_7036compiler.scm",(void*)f_7036},
{"f_7027compiler.scm",(void*)f_7027},
{"f_7018compiler.scm",(void*)f_7018},
{"f_7009compiler.scm",(void*)f_7009},
{"f_7000compiler.scm",(void*)f_7000},
{"f_6991compiler.scm",(void*)f_6991},
{"f_6982compiler.scm",(void*)f_6982},
{"f_6973compiler.scm",(void*)f_6973},
{"f_6964compiler.scm",(void*)f_6964},
{"f_6958compiler.scm",(void*)f_6958},
{"f_6952compiler.scm",(void*)f_6952},
{"f_6277compiler.scm",(void*)f_6277},
{"f_6924compiler.scm",(void*)f_6924},
{"f_6839compiler.scm",(void*)f_6839},
{"f_6845compiler.scm",(void*)f_6845},
{"f_6865compiler.scm",(void*)f_6865},
{"f_6883compiler.scm",(void*)f_6883},
{"f_6892compiler.scm",(void*)f_6892},
{"f_6918compiler.scm",(void*)f_6918},
{"f_6906compiler.scm",(void*)f_6906},
{"f_6859compiler.scm",(void*)f_6859},
{"f_6823compiler.scm",(void*)f_6823},
{"f_6829compiler.scm",(void*)f_6829},
{"f_6698compiler.scm",(void*)f_6698},
{"f_6702compiler.scm",(void*)f_6702},
{"f_6705compiler.scm",(void*)f_6705},
{"f_6759compiler.scm",(void*)f_6759},
{"f_6755compiler.scm",(void*)f_6755},
{"f_6751compiler.scm",(void*)f_6751},
{"f_6730compiler.scm",(void*)f_6730},
{"f_6736compiler.scm",(void*)f_6736},
{"f_6747compiler.scm",(void*)f_6747},
{"f_6740compiler.scm",(void*)f_6740},
{"f_6728compiler.scm",(void*)f_6728},
{"f_6324compiler.scm",(void*)f_6324},
{"f_6346compiler.scm",(void*)f_6346},
{"f_6612compiler.scm",(void*)f_6612},
{"f_6769compiler.scm",(void*)f_6769},
{"f_6772compiler.scm",(void*)f_6772},
{"f_6817compiler.scm",(void*)f_6817},
{"f_6813compiler.scm",(void*)f_6813},
{"f_6809compiler.scm",(void*)f_6809},
{"f_6805compiler.scm",(void*)f_6805},
{"f_6577compiler.scm",(void*)f_6577},
{"f_6603compiler.scm",(void*)f_6603},
{"f_6527compiler.scm",(void*)f_6527},
{"f_6536compiler.scm",(void*)f_6536},
{"f_6564compiler.scm",(void*)f_6564},
{"f_6560compiler.scm",(void*)f_6560},
{"f_6514compiler.scm",(void*)f_6514},
{"f_6452compiler.scm",(void*)f_6452},
{"f_6475compiler.scm",(void*)f_6475},
{"f_6489compiler.scm",(void*)f_6489},
{"f_6358compiler.scm",(void*)f_6358},
{"f_6361compiler.scm",(void*)f_6361},
{"f_6437compiler.scm",(void*)f_6437},
{"f_6433compiler.scm",(void*)f_6433},
{"f_6429compiler.scm",(void*)f_6429},
{"f_6402compiler.scm",(void*)f_6402},
{"f_6413compiler.scm",(void*)f_6413},
{"f_6417compiler.scm",(void*)f_6417},
{"f_6396compiler.scm",(void*)f_6396},
{"f_6362compiler.scm",(void*)f_6362},
{"f_6373compiler.scm",(void*)f_6373},
{"f_6280compiler.scm",(void*)f_6280},
{"f_6284compiler.scm",(void*)f_6284},
{"f_6307compiler.scm",(void*)f_6307},
{"f_6318compiler.scm",(void*)f_6318},
{"f_6301compiler.scm",(void*)f_6301},
{"f_6187compiler.scm",(void*)f_6187},
{"f_6219compiler.scm",(void*)f_6219},
{"f_6238compiler.scm",(void*)f_6238},
{"f_6261compiler.scm",(void*)f_6261},
{"f_6244compiler.scm",(void*)f_6244},
{"f_6190compiler.scm",(void*)f_6190},
{"f_6196compiler.scm",(void*)f_6196},
{"f_6206compiler.scm",(void*)f_6206},
{"f_6106compiler.scm",(void*)f_6106},
{"f_6110compiler.scm",(void*)f_6110},
{"f_6113compiler.scm",(void*)f_6113},
{"f_6116compiler.scm",(void*)f_6116},
{"f_6132compiler.scm",(void*)f_6132},
{"f_6119compiler.scm",(void*)f_6119},
{"f_6122compiler.scm",(void*)f_6122},
{"f_6125compiler.scm",(void*)f_6125},
{"f_6069compiler.scm",(void*)f_6069},
{"f_6092compiler.scm",(void*)f_6092},
{"f_6079compiler.scm",(void*)f_6079},
{"f_6082compiler.scm",(void*)f_6082},
{"f_6085compiler.scm",(void*)f_6085},
{"f_6032compiler.scm",(void*)f_6032},
{"f_6055compiler.scm",(void*)f_6055},
{"f_6042compiler.scm",(void*)f_6042},
{"f_6045compiler.scm",(void*)f_6045},
{"f_6048compiler.scm",(void*)f_6048},
{"f_5987compiler.scm",(void*)f_5987},
{"f_5994compiler.scm",(void*)f_5994},
{"f_6000compiler.scm",(void*)f_6000},
{"f_5942compiler.scm",(void*)f_5942},
{"f_5949compiler.scm",(void*)f_5949},
{"f_5955compiler.scm",(void*)f_5955},
{"f_5788compiler.scm",(void*)f_5788},
{"f_5936compiler.scm",(void*)f_5936},
{"f_5792compiler.scm",(void*)f_5792},
{"f_5795compiler.scm",(void*)f_5795},
{"f_5798compiler.scm",(void*)f_5798},
{"f_5801compiler.scm",(void*)f_5801},
{"f_5804compiler.scm",(void*)f_5804},
{"f_5930compiler.scm",(void*)f_5930},
{"f_5814compiler.scm",(void*)f_5814},
{"f_5905compiler.scm",(void*)f_5905},
{"f_5913compiler.scm",(void*)f_5913},
{"f_5817compiler.scm",(void*)f_5817},
{"f_5857compiler.scm",(void*)f_5857},
{"f_5860compiler.scm",(void*)f_5860},
{"f_5879compiler.scm",(void*)f_5879},
{"f_5875compiler.scm",(void*)f_5875},
{"f_5871compiler.scm",(void*)f_5871},
{"f_5850compiler.scm",(void*)f_5850},
{"f_5840compiler.scm",(void*)f_5840},
{"f_5828compiler.scm",(void*)f_5828},
{"f_5779compiler.scm",(void*)f_5779},
{"f_5770compiler.scm",(void*)f_5770},
{"f_5761compiler.scm",(void*)f_5761},
{"f_5752compiler.scm",(void*)f_5752},
{"f_5743compiler.scm",(void*)f_5743},
{"f_5734compiler.scm",(void*)f_5734},
{"f_5725compiler.scm",(void*)f_5725},
{"f_5716compiler.scm",(void*)f_5716},
{"f_5707compiler.scm",(void*)f_5707},
{"f_5698compiler.scm",(void*)f_5698},
{"f_5689compiler.scm",(void*)f_5689},
{"f_5680compiler.scm",(void*)f_5680},
{"f_5671compiler.scm",(void*)f_5671},
{"f_5662compiler.scm",(void*)f_5662},
{"f_5653compiler.scm",(void*)f_5653},
{"f_5644compiler.scm",(void*)f_5644},
{"f_5638compiler.scm",(void*)f_5638},
{"f_5632compiler.scm",(void*)f_5632},
{"f_4687compiler.scm",(void*)f_4687},
{"f_4741compiler.scm",(void*)f_4741},
{"f_4745compiler.scm",(void*)f_4745},
{"f_5601compiler.scm",(void*)f_5601},
{"f_5611compiler.scm",(void*)f_5611},
{"f_5606compiler.scm",(void*)f_5606},
{"f_5573compiler.scm",(void*)f_5573},
{"f_5579compiler.scm",(void*)f_5579},
{"f_5555compiler.scm",(void*)f_5555},
{"f_5559compiler.scm",(void*)f_5559},
{"f_5527compiler.scm",(void*)f_5527},
{"f_5534compiler.scm",(void*)f_5534},
{"f_5510compiler.scm",(void*)f_5510},
{"f_5436compiler.scm",(void*)f_5436},
{"f_5440compiler.scm",(void*)f_5440},
{"f_5423compiler.scm",(void*)f_5423},
{"f_5415compiler.scm",(void*)f_5415},
{"f_5419compiler.scm",(void*)f_5419},
{"f_5260compiler.scm",(void*)f_5260},
{"f_5370compiler.scm",(void*)f_5370},
{"f_5359compiler.scm",(void*)f_5359},
{"f_5363compiler.scm",(void*)f_5363},
{"f_5330compiler.scm",(void*)f_5330},
{"f_5305compiler.scm",(void*)f_5305},
{"f_5280compiler.scm",(void*)f_5280},
{"f_5247compiler.scm",(void*)f_5247},
{"f_5199compiler.scm",(void*)f_5199},
{"f_5208compiler.scm",(void*)f_5208},
{"f_5206compiler.scm",(void*)f_5206},
{"f_5109compiler.scm",(void*)f_5109},
{"f_5087compiler.scm",(void*)f_5087},
{"f_5091compiler.scm",(void*)f_5091},
{"f_5060compiler.scm",(void*)f_5060},
{"f_5064compiler.scm",(void*)f_5064},
{"f_5046compiler.scm",(void*)f_5046},
{"f_5050compiler.scm",(void*)f_5050},
{"f_5025compiler.scm",(void*)f_5025},
{"f_5011compiler.scm",(void*)f_5011},
{"f_4928compiler.scm",(void*)f_4928},
{"f_4911compiler.scm",(void*)f_4911},
{"f_4915compiler.scm",(void*)f_4915},
{"f_4882compiler.scm",(void*)f_4882},
{"f_4857compiler.scm",(void*)f_4857},
{"f_4810compiler.scm",(void*)f_4810},
{"f_4840compiler.scm",(void*)f_4840},
{"f_4816compiler.scm",(void*)f_4816},
{"f_4819compiler.scm",(void*)f_4819},
{"f_4826compiler.scm",(void*)f_4826},
{"f_4822compiler.scm",(void*)f_4822},
{"f_4760compiler.scm",(void*)f_4760},
{"f_4763compiler.scm",(void*)f_4763},
{"f_4797compiler.scm",(void*)f_4797},
{"f_4791compiler.scm",(void*)f_4791},
{"f_4772compiler.scm",(void*)f_4772},
{"f_4781compiler.scm",(void*)f_4781},
{"f_4789compiler.scm",(void*)f_4789},
{"f_4775compiler.scm",(void*)f_4775},
{"f_4779compiler.scm",(void*)f_4779},
{"f_4751compiler.scm",(void*)f_4751},
{"f_4690compiler.scm",(void*)f_4690},
{"f_4713compiler.scm",(void*)f_4713},
{"f_4703compiler.scm",(void*)f_4703},
{"f_1938compiler.scm",(void*)f_1938},
{"f_4682compiler.scm",(void*)f_4682},
{"f_4645compiler.scm",(void*)f_4645},
{"f_4648compiler.scm",(void*)f_4648},
{"f_4663compiler.scm",(void*)f_4663},
{"f_4672compiler.scm",(void*)f_4672},
{"f_4676compiler.scm",(void*)f_4676},
{"f_4659compiler.scm",(void*)f_4659},
{"f_4632compiler.scm",(void*)f_4632},
{"f_4638compiler.scm",(void*)f_4638},
{"f_2110compiler.scm",(void*)f_2110},
{"f_2147compiler.scm",(void*)f_2147},
{"f_4493compiler.scm",(void*)f_4493},
{"f_4608compiler.scm",(void*)f_4608},
{"f_4508compiler.scm",(void*)f_4508},
{"f_4595compiler.scm",(void*)f_4595},
{"f_4517compiler.scm",(void*)f_4517},
{"f_4520compiler.scm",(void*)f_4520},
{"f_4529compiler.scm",(void*)f_4529},
{"f_4551compiler.scm",(void*)f_4551},
{"f_4544compiler.scm",(void*)f_4544},
{"f_4496compiler.scm",(void*)f_4496},
{"f_4499compiler.scm",(void*)f_4499},
{"f_2174compiler.scm",(void*)f_2174},
{"f_2180compiler.scm",(void*)f_2180},
{"f_4475compiler.scm",(void*)f_4475},
{"f_2183compiler.scm",(void*)f_2183},
{"f_2190compiler.scm",(void*)f_2190},
{"f_2199compiler.scm",(void*)f_2199},
{"f_2208compiler.scm",(void*)f_2208},
{"f_2335compiler.scm",(void*)f_2335},
{"f_4395compiler.scm",(void*)f_4395},
{"f_4401compiler.scm",(void*)f_4401},
{"f_4306compiler.scm",(void*)f_4306},
{"f_4366compiler.scm",(void*)f_4366},
{"f_4266compiler.scm",(void*)f_4266},
{"f_4270compiler.scm",(void*)f_4270},
{"f_4276compiler.scm",(void*)f_4276},
{"f_4290compiler.scm",(void*)f_4290},
{"f_4279compiler.scm",(void*)f_4279},
{"f_3902compiler.scm",(void*)f_3902},
{"f_4250compiler.scm",(void*)f_4250},
{"f_3924compiler.scm",(void*)f_3924},
{"f_4215compiler.scm",(void*)f_4215},
{"f_3927compiler.scm",(void*)f_3927},
{"f_3938compiler.scm",(void*)f_3938},
{"f_4165compiler.scm",(void*)f_4165},
{"f_4209compiler.scm",(void*)f_4209},
{"f_4205compiler.scm",(void*)f_4205},
{"f_4201compiler.scm",(void*)f_4201},
{"f_4189compiler.scm",(void*)f_4189},
{"f_3958compiler.scm",(void*)f_3958},
{"f_4037compiler.scm",(void*)f_4037},
{"f_4014compiler.scm",(void*)f_4014},
{"f_4009compiler.scm",(void*)f_4009},
{"f_3972compiler.scm",(void*)f_3972},
{"f_3962compiler.scm",(void*)f_3962},
{"f_3946compiler.scm",(void*)f_3946},
{"f_3934compiler.scm",(void*)f_3934},
{"f_3892compiler.scm",(void*)f_3892},
{"f_3869compiler.scm",(void*)f_3869},
{"f_3867compiler.scm",(void*)f_3867},
{"f_3796compiler.scm",(void*)f_3796},
{"f_3814compiler.scm",(void*)f_3814},
{"f_3836compiler.scm",(void*)f_3836},
{"f_3842compiler.scm",(void*)f_3842},
{"f_3820compiler.scm",(void*)f_3820},
{"f_3827compiler.scm",(void*)f_3827},
{"f_3802compiler.scm",(void*)f_3802},
{"f_3808compiler.scm",(void*)f_3808},
{"f_3794compiler.scm",(void*)f_3794},
{"f_3723compiler.scm",(void*)f_3723},
{"f_3734compiler.scm",(void*)f_3734},
{"f_3780compiler.scm",(void*)f_3780},
{"f_3744compiler.scm",(void*)f_3744},
{"f_3747compiler.scm",(void*)f_3747},
{"f_3750compiler.scm",(void*)f_3750},
{"f_3754compiler.scm",(void*)f_3754},
{"f_3737compiler.scm",(void*)f_3737},
{"f_3662compiler.scm",(void*)f_3662},
{"f_3666compiler.scm",(void*)f_3666},
{"f_3704compiler.scm",(void*)f_3704},
{"f_3670compiler.scm",(void*)f_3670},
{"f_3684compiler.scm",(void*)f_3684},
{"f_3682compiler.scm",(void*)f_3682},
{"f_3644compiler.scm",(void*)f_3644},
{"f_3652compiler.scm",(void*)f_3652},
{"f_3517compiler.scm",(void*)f_3517},
{"f_3520compiler.scm",(void*)f_3520},
{"f_3526compiler.scm",(void*)f_3526},
{"f_3605compiler.scm",(void*)f_3605},
{"f_3582compiler.scm",(void*)f_3582},
{"f_3557compiler.scm",(void*)f_3557},
{"f_3565compiler.scm",(void*)f_3565},
{"f_3553compiler.scm",(void*)f_3553},
{"f_3549compiler.scm",(void*)f_3549},
{"f_3541compiler.scm",(void*)f_3541},
{"f_3442compiler.scm",(void*)f_3442},
{"f_3451compiler.scm",(void*)f_3451},
{"f_3490compiler.scm",(void*)f_3490},
{"f_3482compiler.scm",(void*)f_3482},
{"f_3454compiler.scm",(void*)f_3454},
{"f_3474compiler.scm",(void*)f_3474},
{"f_3466compiler.scm",(void*)f_3466},
{"f_3422compiler.scm",(void*)f_3422},
{"f_3368compiler.scm",(void*)f_3368},
{"f_3371compiler.scm",(void*)f_3371},
{"f_3374compiler.scm",(void*)f_3374},
{"f_3378compiler.scm",(void*)f_3378},
{"f_3382compiler.scm",(void*)f_3382},
{"f_3301compiler.scm",(void*)f_3301},
{"f_3313compiler.scm",(void*)f_3313},
{"f_3286compiler.scm",(void*)f_3286},
{"f_3273compiler.scm",(void*)f_3273},
{"f_3260compiler.scm",(void*)f_3260},
{"f_3247compiler.scm",(void*)f_3247},
{"f_3234compiler.scm",(void*)f_3234},
{"f_3167compiler.scm",(void*)f_3167},
{"f_3186compiler.scm",(void*)f_3186},
{"f_3213compiler.scm",(void*)f_3213},
{"f_3217compiler.scm",(void*)f_3217},
{"f_3206compiler.scm",(void*)f_3206},
{"f_3180compiler.scm",(void*)f_3180},
{"f_3154compiler.scm",(void*)f_3154},
{"f_3139compiler.scm",(void*)f_3139},
{"f_3112compiler.scm",(void*)f_3112},
{"f_3116compiler.scm",(void*)f_3116},
{"f_3091compiler.scm",(void*)f_3091},
{"f_3062compiler.scm",(void*)f_3062},
{"f_3066compiler.scm",(void*)f_3066},
{"f_3033compiler.scm",(void*)f_3033},
{"f_3037compiler.scm",(void*)f_3037},
{"f_2859compiler.scm",(void*)f_2859},
{"f_2868compiler.scm",(void*)f_2868},
{"f_2871compiler.scm",(void*)f_2871},
{"f_2979compiler.scm",(void*)f_2979},
{"f_3008compiler.scm",(void*)f_3008},
{"f_3012compiler.scm",(void*)f_3012},
{"f_2982compiler.scm",(void*)f_2982},
{"f_2988compiler.scm",(void*)f_2988},
{"f_3001compiler.scm",(void*)f_3001},
{"f_2991compiler.scm",(void*)f_2991},
{"f_2874compiler.scm",(void*)f_2874},
{"f_2969compiler.scm",(void*)f_2969},
{"f_2877compiler.scm",(void*)f_2877},
{"f_2932compiler.scm",(void*)f_2932},
{"f_2963compiler.scm",(void*)f_2963},
{"f_2955compiler.scm",(void*)f_2955},
{"f_2889compiler.scm",(void*)f_2889},
{"f_2920compiler.scm",(void*)f_2920},
{"f_2908compiler.scm",(void*)f_2908},
{"f_2821compiler.scm",(void*)f_2821},
{"f_2847compiler.scm",(void*)f_2847},
{"f_2824compiler.scm",(void*)f_2824},
{"f_2839compiler.scm",(void*)f_2839},
{"f_2837compiler.scm",(void*)f_2837},
{"f_2827compiler.scm",(void*)f_2827},
{"f_2830compiler.scm",(void*)f_2830},
{"f_2570compiler.scm",(void*)f_2570},
{"f_2771compiler.scm",(void*)f_2771},
{"f_2782compiler.scm",(void*)f_2782},
{"f_2776compiler.scm",(void*)f_2776},
{"f_2579compiler.scm",(void*)f_2579},
{"f_2584compiler.scm",(void*)f_2584},
{"f_2588compiler.scm",(void*)f_2588},
{"f_2768compiler.scm",(void*)f_2768},
{"f_2591compiler.scm",(void*)f_2591},
{"f_2760compiler.scm",(void*)f_2760},
{"f_2594compiler.scm",(void*)f_2594},
{"f_2597compiler.scm",(void*)f_2597},
{"f_2758compiler.scm",(void*)f_2758},
{"f_2751compiler.scm",(void*)f_2751},
{"f_2600compiler.scm",(void*)f_2600},
{"f_2635compiler.scm",(void*)f_2635},
{"f_2719compiler.scm",(void*)f_2719},
{"f_2715compiler.scm",(void*)f_2715},
{"f_2711compiler.scm",(void*)f_2711},
{"f_2668compiler.scm",(void*)f_2668},
{"f_2675compiler.scm",(void*)f_2675},
{"f_2625compiler.scm",(void*)f_2625},
{"f_2603compiler.scm",(void*)f_2603},
{"f_2606compiler.scm",(void*)f_2606},
{"f_2496compiler.scm",(void*)f_2496},
{"f_2502compiler.scm",(void*)f_2502},
{"f_2505compiler.scm",(void*)f_2505},
{"f_2558compiler.scm",(void*)f_2558},
{"f_2508compiler.scm",(void*)f_2508},
{"f_2511compiler.scm",(void*)f_2511},
{"f_2538compiler.scm",(void*)f_2538},
{"f_2546compiler.scm",(void*)f_2546},
{"f_2518compiler.scm",(void*)f_2518},
{"f_2532compiler.scm",(void*)f_2532},
{"f_2526compiler.scm",(void*)f_2526},
{"f_2522compiler.scm",(void*)f_2522},
{"f_2382compiler.scm",(void*)f_2382},
{"f_2392compiler.scm",(void*)f_2392},
{"f_2403compiler.scm",(void*)f_2403},
{"f_2477compiler.scm",(void*)f_2477},
{"f_2487compiler.scm",(void*)f_2487},
{"f_2468compiler.scm",(void*)f_2468},
{"f_2442compiler.scm",(void*)f_2442},
{"f_2456compiler.scm",(void*)f_2456},
{"f_2454compiler.scm",(void*)f_2454},
{"f_2430compiler.scm",(void*)f_2430},
{"f_2407compiler.scm",(void*)f_2407},
{"f_2414compiler.scm",(void*)f_2414},
{"f_2397compiler.scm",(void*)f_2397},
{"f_2376compiler.scm",(void*)f_2376},
{"f_2344compiler.scm",(void*)f_2344},
{"f_2347compiler.scm",(void*)f_2347},
{"f_2358compiler.scm",(void*)f_2358},
{"f_2352compiler.scm",(void*)f_2352},
{"f_2350compiler.scm",(void*)f_2350},
{"f_2302compiler.scm",(void*)f_2302},
{"f_2314compiler.scm",(void*)f_2314},
{"f_2318compiler.scm",(void*)f_2318},
{"f_2277compiler.scm",(void*)f_2277},
{"f_2231compiler.scm",(void*)f_2231},
{"f_2238compiler.scm",(void*)f_2238},
{"f_2242compiler.scm",(void*)f_2242},
{"f_2246compiler.scm",(void*)f_2246},
{"f_2135compiler.scm",(void*)f_2135},
{"f_2129compiler.scm",(void*)f_2129},
{"f_2019compiler.scm",(void*)f_2019},
{"f_2023compiler.scm",(void*)f_2023},
{"f_2036compiler.scm",(void*)f_2036},
{"f_2084compiler.scm",(void*)f_2084},
{"f_2094compiler.scm",(void*)f_2094},
{"f_2054compiler.scm",(void*)f_2054},
{"f_2064compiler.scm",(void*)f_2064},
{"f_1977compiler.scm",(void*)f_1977},
{"f_1984compiler.scm",(void*)f_1984},
{"f_1953compiler.scm",(void*)f_1953},
{"f_1959compiler.scm",(void*)f_1959},
{"f_1941compiler.scm",(void*)f_1941},
{"f_1873compiler.scm",(void*)f_1873},
{"f_1936compiler.scm",(void*)f_1936},
{"f_1877compiler.scm",(void*)f_1877},
{"f_1929compiler.scm",(void*)f_1929},
{"f_1880compiler.scm",(void*)f_1880},
{"f_1922compiler.scm",(void*)f_1922},
{"f_1883compiler.scm",(void*)f_1883},
{"f_1887compiler.scm",(void*)f_1887},
{"f_1891compiler.scm",(void*)f_1891},
{"f_1895compiler.scm",(void*)f_1895},
{"f_1915compiler.scm",(void*)f_1915},
{"f_1898compiler.scm",(void*)f_1898},
{"f_1908compiler.scm",(void*)f_1908},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
