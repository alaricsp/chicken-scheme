/* Generated from compiler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:15
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: compiler.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file compiler.c
   unit: compiler
*/

#include "chicken.h"


#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_DEFAULT_TARGET_STACK_SIZE
# define C_DEFAULT_TARGET_STACK_SIZE 0
#endif

#ifndef C_DEFAULT_TARGET_HEAP_SIZE
# define C_DEFAULT_TARGET_HEAP_SIZE 0
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[582];


C_noret_decl(C_compiler_toplevel)
C_externexport void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10098)
static void C_ccall f_10098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11155)
static void C_ccall f_11155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10955)
static void C_fcall f_10955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10188)
static void C_fcall f_10188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10944)
static void C_ccall f_10944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10854)
static void C_fcall f_10854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10918)
static void C_ccall f_10918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10931)
static void C_ccall f_10931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10902)
static void C_ccall f_10902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10875)
static void C_fcall f_10875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_ccall f_10878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10826)
static void C_fcall f_10826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10829)
static void C_ccall f_10829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10795)
static void C_fcall f_10795(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10786)
static void C_fcall f_10786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10663)
static void C_ccall f_10663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10764)
static void C_ccall f_10764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10691)
static void C_ccall f_10691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_fcall f_10697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10721)
static void C_ccall f_10721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10634)
static void C_ccall f_10634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10638)
static void C_ccall f_10638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_ccall f_10626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_ccall f_10438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10559)
static void C_ccall f_10559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10565)
static void C_ccall f_10565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_ccall f_10590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_fcall f_10571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10445)
static void C_ccall f_10445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10550)
static void C_ccall f_10550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10448)
static void C_ccall f_10448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10451)
static void C_ccall f_10451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_ccall f_10492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10499)
static void C_fcall f_10499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10382)
static void C_ccall f_10382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_fcall f_10391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_fcall f_10385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10339)
static void C_ccall f_10339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10318)
static void C_ccall f_10318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10266)
static void C_ccall f_10266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10101)
static void C_fcall f_10101(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10105)
static void C_ccall f_10105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10135)
static void C_fcall f_10135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10180)
static void C_ccall f_10180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_fcall f_10145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10155)
static void C_ccall f_10155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10967)
static void C_fcall f_10967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10974)
static void C_ccall f_10974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11029)
static void C_ccall f_11029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10980)
static void C_ccall f_10980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10996)
static void C_ccall f_10996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11061)
static void C_fcall f_11061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11077)
static void C_ccall f_11077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11091)
static void C_ccall f_11091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11075)
static void C_ccall f_11075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11047)
static void C_fcall f_11047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11055)
static void C_ccall f_11055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11093)
static void C_fcall f_11093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11106)
static void C_ccall f_11106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10089)
static void C_ccall f_10089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10071)
static void C_ccall f_10071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10044)
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10035)
static void C_ccall f_10035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10026)
static void C_ccall f_10026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10017)
static void C_ccall f_10017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10008)
static void C_ccall f_10008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9990)
static void C_ccall f_9990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9981)
static void C_ccall f_9981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9972)
static void C_ccall f_9972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9963)
static void C_ccall f_9963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9954)
static void C_ccall f_9954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9936)
static void C_ccall f_9936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9927)
static void C_ccall f_9927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9918)
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9909)
static void C_ccall f_9909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9891)
static void C_ccall f_9891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9882)
static void C_ccall f_9882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9864)
static void C_ccall f_9864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9846)
static void C_ccall f_9846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9816)
static void C_ccall f_9816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9808)
static void C_ccall f_9808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_fcall f_9635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8946)
static void C_fcall f_8946(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8965)
static void C_fcall f_8965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_fcall f_8998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9514)
static void C_fcall f_9514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9365)
static void C_ccall f_9365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9371)
static void C_ccall f_9371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9454)
static void C_ccall f_9454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static void C_ccall f_9380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9427)
static void C_ccall f_9427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9431)
static void C_ccall f_9431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9407)
static void C_ccall f_9407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9403)
static void C_ccall f_9403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9104)
static void C_ccall f_9104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_fcall f_9122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_ccall f_9308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9311)
static void C_ccall f_9311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9195)
static void C_ccall f_9195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_ccall f_9067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_fcall f_9647(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9654)
static void C_ccall f_9654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9670)
static void C_ccall f_9670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8612)
static void C_fcall f_8612(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8631)
static void C_fcall f_8631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8871)
static void C_ccall f_8871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9686)
static void C_ccall f_9686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9724)
static void C_fcall f_9724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9750)
static void C_ccall f_9750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9736)
static void C_fcall f_9736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8887)
static void C_ccall f_8887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8835)
static void C_ccall f_8835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_fcall f_8733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_fcall f_8751(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8769)
static void C_fcall f_8769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8721)
static void C_fcall f_8721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_fcall f_8711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8656)
static void C_ccall f_8656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8642)
static void C_ccall f_8642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8601)
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_fcall f_8591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_ccall f_7821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_fcall f_8434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_fcall f_8380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_fcall f_8395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_fcall f_8389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8355)
static void C_ccall f_8355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_fcall f_8329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8285)
static void C_fcall f_8285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_fcall f_8297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8186)
static void C_fcall f_8186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_fcall f_8254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8257)
static void C_ccall f_8257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_fcall f_8214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_fcall f_8150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_fcall f_8138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_fcall f_8123(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8035)
static void C_ccall f_8035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8044)
static void C_fcall f_8044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8047)
static void C_ccall f_8047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7894)
static void C_fcall f_7894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_fcall f_7915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7936)
static void C_fcall f_7936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_fcall f_7875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_ccall f_7824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7831)
static void C_fcall f_7831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7772)
static void C_fcall f_7772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7657)
static void C_ccall f_7657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7070)
static void C_fcall f_7070(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7092)
static void C_fcall f_7092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_ccall f_7607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_fcall f_7528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_fcall f_7543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_fcall f_7534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_fcall f_7408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_fcall f_7441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_fcall f_7411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_ccall f_7438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7283)
static void C_fcall f_7283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7254)
static void C_ccall f_7254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_ccall f_7186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7663)
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7676)
static void C_fcall f_7676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_ccall f_7736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_fcall f_7685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_fcall f_7766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7063)
static C_word C_fcall f_7063(C_word t0);
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6994)
static void C_ccall f_6994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6842)
static void C_fcall f_6842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6848)
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6826)
static void C_fcall f_6826(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6701)
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6733)
static void C_ccall f_6733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6349)
static void C_fcall f_6349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_fcall f_6615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_fcall f_6455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6432)
static void C_ccall f_6432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_fcall f_6193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_fcall f_6116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_fcall f_6119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_fcall f_5817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_fcall f_4744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_fcall f_5418(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_fcall f_5112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_fcall f_4829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_fcall f_4693(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_fcall f_4706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_fcall f_4635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2113)
static void C_fcall f_2113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_fcall f_4511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_fcall f_2338(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4269)
static void C_fcall f_4269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_fcall f_4218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_fcall f_4168(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static C_word C_fcall f_4017(C_word *a,C_word t0);
C_noret_decl(f_4012)
static void C_fcall f_4012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static C_word C_fcall f_3975(C_word *a,C_word t0);
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_fcall f_3560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_fcall f_3457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_fcall f_2754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_fcall f_2638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_fcall f_2671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_fcall f_2433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_fcall f_2022(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_fcall f_1987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_fcall f_1956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1944)
static C_word C_fcall f_1944(C_word t0,C_word t1);
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10955)
static void C_fcall trf_10955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10955(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10955(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10188)
static void C_fcall trf_10188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10188(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10188(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10854)
static void C_fcall trf_10854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10854(t0,t1);}

C_noret_decl(trf_10875)
static void C_fcall trf_10875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10875(t0,t1);}

C_noret_decl(trf_10826)
static void C_fcall trf_10826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10826(t0,t1);}

C_noret_decl(trf_10795)
static void C_fcall trf_10795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10795(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10795(t0,t1);}

C_noret_decl(trf_10786)
static void C_fcall trf_10786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10786(t0,t1);}

C_noret_decl(trf_10697)
static void C_fcall trf_10697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10697(t0,t1);}

C_noret_decl(trf_10571)
static void C_fcall trf_10571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10571(t0,t1);}

C_noret_decl(trf_10499)
static void C_fcall trf_10499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10499(t0,t1);}

C_noret_decl(trf_10391)
static void C_fcall trf_10391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10391(t0,t1);}

C_noret_decl(trf_10385)
static void C_fcall trf_10385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10385(t0,t1);}

C_noret_decl(trf_10101)
static void C_fcall trf_10101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10101(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10101(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10135)
static void C_fcall trf_10135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10135(t0,t1,t2,t3);}

C_noret_decl(trf_10145)
static void C_fcall trf_10145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10145(t0,t1);}

C_noret_decl(trf_10967)
static void C_fcall trf_10967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10967(t0,t1,t2);}

C_noret_decl(trf_11061)
static void C_fcall trf_11061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11061(t0,t1,t2);}

C_noret_decl(trf_11047)
static void C_fcall trf_11047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11047(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11047(t0,t1,t2);}

C_noret_decl(trf_11093)
static void C_fcall trf_11093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11093(t0,t1);}

C_noret_decl(trf_9635)
static void C_fcall trf_9635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9635(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9635(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8946)
static void C_fcall trf_8946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8946(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8946(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8965)
static void C_fcall trf_8965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8965(t0,t1);}

C_noret_decl(trf_8998)
static void C_fcall trf_8998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8998(t0,t1);}

C_noret_decl(trf_9514)
static void C_fcall trf_9514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9514(t0,t1);}

C_noret_decl(trf_9122)
static void C_fcall trf_9122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9122(t0,t1);}

C_noret_decl(trf_9647)
static void C_fcall trf_9647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9647(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9647(t0,t1,t2,t3);}

C_noret_decl(trf_8612)
static void C_fcall trf_8612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8612(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8612(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8631)
static void C_fcall trf_8631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8631(t0,t1);}

C_noret_decl(trf_9724)
static void C_fcall trf_9724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9724(t0,t1);}

C_noret_decl(trf_9736)
static void C_fcall trf_9736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9736(t0,t1);}

C_noret_decl(trf_8733)
static void C_fcall trf_8733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8733(t0,t1);}

C_noret_decl(trf_8751)
static void C_fcall trf_8751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8751(t0,t1);}

C_noret_decl(trf_8769)
static void C_fcall trf_8769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8769(t0,t1);}

C_noret_decl(trf_8721)
static void C_fcall trf_8721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8721(t0,t1);}

C_noret_decl(trf_8711)
static void C_fcall trf_8711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8711(t0,t1);}

C_noret_decl(trf_8601)
static void C_fcall trf_8601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8601(t0,t1,t2);}

C_noret_decl(trf_8591)
static void C_fcall trf_8591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8591(t0,t1,t2,t3);}

C_noret_decl(trf_8585)
static void C_fcall trf_8585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8585(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8585(t0,t1,t2,t3);}

C_noret_decl(trf_8434)
static void C_fcall trf_8434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8434(t0,t1);}

C_noret_decl(trf_8380)
static void C_fcall trf_8380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8380(t0,t1);}

C_noret_decl(trf_8395)
static void C_fcall trf_8395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8395(t0,t1);}

C_noret_decl(trf_8389)
static void C_fcall trf_8389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8389(t0,t1);}

C_noret_decl(trf_8329)
static void C_fcall trf_8329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8329(t0,t1);}

C_noret_decl(trf_8285)
static void C_fcall trf_8285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8285(t0,t1);}

C_noret_decl(trf_8297)
static void C_fcall trf_8297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8297(t0,t1);}

C_noret_decl(trf_8186)
static void C_fcall trf_8186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8186(t0,t1);}

C_noret_decl(trf_8254)
static void C_fcall trf_8254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8254(t0,t1);}

C_noret_decl(trf_8214)
static void C_fcall trf_8214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8214(t0,t1);}

C_noret_decl(trf_8150)
static void C_fcall trf_8150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8150(t0,t1);}

C_noret_decl(trf_8138)
static void C_fcall trf_8138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8138(t0,t1);}

C_noret_decl(trf_8123)
static void C_fcall trf_8123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8123(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8123(t0,t1);}

C_noret_decl(trf_8044)
static void C_fcall trf_8044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8044(t0,t1);}

C_noret_decl(trf_7894)
static void C_fcall trf_7894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7894(t0,t1);}

C_noret_decl(trf_7915)
static void C_fcall trf_7915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7915(t0,t1);}

C_noret_decl(trf_7936)
static void C_fcall trf_7936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7936(t0,t1);}

C_noret_decl(trf_7875)
static void C_fcall trf_7875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7875(t0,t1);}

C_noret_decl(trf_7831)
static void C_fcall trf_7831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7831(t0,t1);}

C_noret_decl(trf_7786)
static void C_fcall trf_7786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7786(t0,t1,t2,t3);}

C_noret_decl(trf_7772)
static void C_fcall trf_7772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7772(t0,t1,t2,t3);}

C_noret_decl(trf_7651)
static void C_fcall trf_7651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7651(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7651(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7070)
static void C_fcall trf_7070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7070(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7070(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7092)
static void C_fcall trf_7092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7092(t0,t1);}

C_noret_decl(trf_7528)
static void C_fcall trf_7528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7528(t0,t1);}

C_noret_decl(trf_7543)
static void C_fcall trf_7543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7543(t0,t1);}

C_noret_decl(trf_7534)
static void C_fcall trf_7534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7534(t0,t1);}

C_noret_decl(trf_7408)
static void C_fcall trf_7408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7408(t0,t1);}

C_noret_decl(trf_7441)
static void C_fcall trf_7441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7441(t0,t1);}

C_noret_decl(trf_7411)
static void C_fcall trf_7411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7411(t0,t1);}

C_noret_decl(trf_7283)
static void C_fcall trf_7283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7283(t0,t1,t2,t3);}

C_noret_decl(trf_7663)
static void C_fcall trf_7663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7663(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7663(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7676)
static void C_fcall trf_7676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7676(t0,t1);}

C_noret_decl(trf_7685)
static void C_fcall trf_7685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7685(t0,t1);}

C_noret_decl(trf_7766)
static void C_fcall trf_7766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7766(t0,t1,t2,t3);}

C_noret_decl(trf_6842)
static void C_fcall trf_6842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6842(t0,t1,t2,t3);}

C_noret_decl(trf_6848)
static void C_fcall trf_6848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6848(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6848(t0,t1,t2,t3);}

C_noret_decl(trf_6826)
static void C_fcall trf_6826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6826(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6826(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6701)
static void C_fcall trf_6701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6701(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6701(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6327)
static void C_fcall trf_6327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6327(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6327(t0,t1,t2,t3);}

C_noret_decl(trf_6349)
static void C_fcall trf_6349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6349(t0,t1);}

C_noret_decl(trf_6615)
static void C_fcall trf_6615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6615(t0,t1);}

C_noret_decl(trf_6455)
static void C_fcall trf_6455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6455(t0,t1,t2,t3);}

C_noret_decl(trf_6283)
static void C_fcall trf_6283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6283(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6283(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6222(t0,t1,t2);}

C_noret_decl(trf_6193)
static void C_fcall trf_6193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6193(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6193(t0,t1,t2);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6199(t0,t1,t2);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6113(t0,t1);}

C_noret_decl(trf_6116)
static void C_fcall trf_6116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6116(t0,t1);}

C_noret_decl(trf_6119)
static void C_fcall trf_6119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6119(t0,t1);}

C_noret_decl(trf_5817)
static void C_fcall trf_5817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5817(t0,t1);}

C_noret_decl(trf_4744)
static void C_fcall trf_4744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4744(t0,t1);}

C_noret_decl(trf_5418)
static void C_fcall trf_5418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5418(t0,t1);}

C_noret_decl(trf_5112)
static void C_fcall trf_5112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5112(t0,t1);}

C_noret_decl(trf_4829)
static void C_fcall trf_4829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4829(t0,t1);}

C_noret_decl(trf_4693)
static void C_fcall trf_4693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4693(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4693(t0,t1,t2,t3);}

C_noret_decl(trf_4706)
static void C_fcall trf_4706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4706(t0,t1);}

C_noret_decl(trf_4635)
static void C_fcall trf_4635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4635(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4635(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2113)
static void C_fcall trf_2113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2113(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2113(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4511)
static void C_fcall trf_4511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4511(t0,t1);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4532(t0,t1);}

C_noret_decl(trf_2338)
static void C_fcall trf_2338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2338(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2338(t0,t1);}

C_noret_decl(trf_4269)
static void C_fcall trf_4269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4269(t0,t1);}

C_noret_decl(trf_4218)
static void C_fcall trf_4218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4218(t0,t1);}

C_noret_decl(trf_4168)
static void C_fcall trf_4168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4168(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4168(t0,t1,t2,t3);}

C_noret_decl(trf_4012)
static void C_fcall trf_4012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4012(t0,t1);}

C_noret_decl(trf_3560)
static void C_fcall trf_3560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3560(t0,t1);}

C_noret_decl(trf_3457)
static void C_fcall trf_3457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3457(t0,t1);}

C_noret_decl(trf_3189)
static void C_fcall trf_3189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3189(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3189(t0,t1,t2);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2985(t0,t1);}

C_noret_decl(trf_2754)
static void C_fcall trf_2754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2754(t0,t1);}

C_noret_decl(trf_2638)
static void C_fcall trf_2638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2638(t0,t1);}

C_noret_decl(trf_2671)
static void C_fcall trf_2671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2671(t0,t1);}

C_noret_decl(trf_2628)
static void C_fcall trf_2628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2628(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2628(t0,t1,t2);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2385(t0,t1,t2);}

C_noret_decl(trf_2433)
static void C_fcall trf_2433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2433(t0,t1);}

C_noret_decl(trf_2022)
static void C_fcall trf_2022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2022(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2022(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1987)
static void C_fcall trf_1987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1987(t0,t1);}

C_noret_decl(trf_1956)
static void C_fcall trf_1956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1956(t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr17)
static void C_fcall tr17(C_proc17 k) C_regparm C_noret;
C_regparm static void C_fcall tr17(C_proc17 k){
C_word t16=C_pick(0);
C_word t15=C_pick(1);
C_word t14=C_pick(2);
C_word t13=C_pick(3);
C_word t12=C_pick(4);
C_word t11=C_pick(5);
C_word t10=C_pick(6);
C_word t9=C_pick(7);
C_word t8=C_pick(8);
C_word t7=C_pick(9);
C_word t6=C_pick(10);
C_word t5=C_pick(11);
C_word t4=C_pick(12);
C_word t3=C_pick(13);
C_word t2=C_pick(14);
C_word t1=C_pick(15);
C_word t0=C_pick(16);
C_adjust_stack(-17);
(k)(17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5622)){
C_save(t1);
C_rereclaim2(5622*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,582);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[3]=C_h_intern(&lf[3],17,"user-options-pass");
lf[4]=C_h_intern(&lf[4],14,"user-read-pass");
lf[5]=C_h_intern(&lf[5],22,"user-preprocessor-pass");
lf[6]=C_h_intern(&lf[6],9,"user-pass");
lf[7]=C_h_intern(&lf[7],11,"user-pass-2");
lf[8]=C_h_intern(&lf[8],23,"user-post-analysis-pass");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunit-name");
lf[10]=C_h_intern(&lf[10],11,"number-type");
lf[11]=C_h_intern(&lf[11],7,"generic");
lf[12]=C_h_intern(&lf[12],17,"standard-bindings");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],28,"\010compilerinsert-timer-checks");
lf[15]=C_h_intern(&lf[15],19,"\010compilerused-units");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],12,"always-bound");
lf[18]=C_h_intern(&lf[18],34,"\010compileralways-bound-to-procedure");
lf[19]=C_h_intern(&lf[19],29,"\010compilerforeign-declarations");
lf[20]=C_h_intern(&lf[20],24,"\010compileremit-trace-info");
lf[21]=C_h_intern(&lf[21],26,"\010compilerblock-compilation");
lf[22]=C_h_intern(&lf[22],34,"\010compilerline-number-database-size");
lf[23]=C_h_intern(&lf[23],25,"\010compilertarget-heap-size");
lf[24]=C_h_intern(&lf[24],33,"\010compilertarget-initial-heap-size");
lf[25]=C_h_intern(&lf[25],26,"\010compilertarget-stack-size");
lf[26]=C_h_intern(&lf[26],22,"optimize-leaf-routines");
lf[27]=C_h_intern(&lf[27],21,"\010compileremit-profile");
lf[28]=C_h_intern(&lf[28],15,"no-bound-checks");
lf[29]=C_h_intern(&lf[29],14,"no-argc-checks");
lf[30]=C_h_intern(&lf[30],19,"no-procedure-checks");
lf[31]=C_h_intern(&lf[31],22,"\010compilerblock-globals");
lf[32]=C_h_intern(&lf[32],24,"\010compilersource-filename");
lf[33]=C_h_intern(&lf[33],20,"\010compilerexport-list");
lf[34]=C_h_intern(&lf[34],26,"\010compilersafe-globals-flag");
lf[35]=C_h_intern(&lf[35],26,"\010compilerexplicit-use-flag");
lf[36]=C_h_intern(&lf[36],40,"\010compilerdisable-stack-overflow-checking");
lf[37]=C_h_intern(&lf[37],29,"\010compilerrequire-imports-flag");
lf[38]=C_h_intern(&lf[38],27,"\010compileremit-unsafe-marker");
lf[39]=C_h_intern(&lf[39],30,"\010compilerexternal-protos-first");
lf[40]=C_h_intern(&lf[40],26,"\010compilerdo-lambda-lifting");
lf[41]=C_h_intern(&lf[41],24,"\010compilerinline-max-size");
lf[42]=C_h_intern(&lf[42],26,"\010compileremit-closure-info");
lf[43]=C_h_intern(&lf[43],25,"\010compilerexport-file-name");
lf[44]=C_h_intern(&lf[44],21,"\010compilerimport-table");
lf[45]=C_h_intern(&lf[45],25,"\010compileruse-import-table");
lf[46]=C_h_intern(&lf[46],33,"\010compilerundefine-shadowed-macros");
lf[47]=C_h_intern(&lf[47],30,"\010compilerconstant-declarations");
lf[48]=C_h_intern(&lf[48],41,"\010compilerdefault-default-target-heap-size");
lf[49]=C_h_intern(&lf[49],42,"\010compilerdefault-default-target-stack-size");
lf[50]=C_h_intern(&lf[50],21,"\010compilerverbose-mode");
lf[51]=C_h_intern(&lf[51],30,"\010compileroriginal-program-size");
lf[52]=C_h_intern(&lf[52],29,"\010compilercurrent-program-size");
lf[53]=C_h_intern(&lf[53],31,"\010compilerline-number-database-2");
lf[54]=C_h_intern(&lf[54],28,"\010compilerimmutable-constants");
lf[55]=C_h_intern(&lf[55],43,"\010compilerrest-parameters-promoted-to-vector");
lf[56]=C_h_intern(&lf[56],21,"\010compilerinline-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerinline-table-used");
lf[58]=C_h_intern(&lf[58],23,"\010compilerconstant-table");
lf[59]=C_h_intern(&lf[59],23,"\010compilerconstants-used");
lf[60]=C_h_intern(&lf[60],26,"\010compilermutable-constants");
lf[61]=C_h_intern(&lf[61],30,"\010compilerbroken-constant-nodes");
lf[62]=C_h_intern(&lf[62],37,"\010compilerinline-substitutions-enabled");
lf[63]=C_h_intern(&lf[63],24,"\010compilerdirect-call-ids");
lf[64]=C_h_intern(&lf[64],23,"\010compilerfirst-analysis");
lf[65]=C_h_intern(&lf[65],27,"\010compilerforeign-type-table");
lf[66]=C_h_intern(&lf[66],26,"\010compilerforeign-variables");
lf[67]=C_h_intern(&lf[67],29,"\010compilerforeign-lambda-stubs");
lf[68]=C_h_intern(&lf[68],22,"foreign-callback-stubs");
lf[69]=C_h_intern(&lf[69],27,"\010compilerexternal-variables");
lf[70]=C_h_intern(&lf[70],26,"\010compilerloop-lambda-names");
lf[71]=C_h_intern(&lf[71],28,"\010compilerprofile-lambda-list");
lf[72]=C_h_intern(&lf[72],29,"\010compilerprofile-lambda-index");
lf[73]=C_h_intern(&lf[73],33,"\010compilerprofile-info-vector-name");
lf[74]=C_h_intern(&lf[74],28,"\010compilerexternal-to-pointer");
lf[75]=C_h_intern(&lf[75],34,"\010compilererror-is-extended-binding");
lf[76]=C_h_intern(&lf[76],24,"\010compilerreal-name-table");
lf[77]=C_h_intern(&lf[77],29,"\010compilerlocation-pointer-map");
lf[78]=C_h_intern(&lf[78],34,"\010compilerpending-canonicalizations");
lf[79]=C_h_intern(&lf[79],29,"\010compilerdefconstant-bindings");
lf[80]=C_h_intern(&lf[80],23,"\010compilercallback-names");
lf[81]=C_h_intern(&lf[81],23,"\010compilertoplevel-scope");
lf[82]=C_h_intern(&lf[82],27,"\010compilertoplevel-lambda-id");
lf[83]=C_h_intern(&lf[83],29,"\010compilercustom-declare-alist");
lf[84]=C_h_intern(&lf[84],25,"\010compilercsc-control-file");
lf[85]=C_h_intern(&lf[85],26,"\010compilerdata-declarations");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilernot-inline-list");
lf[88]=C_h_intern(&lf[88],26,"\010compilerfile-requirements");
lf[89]=C_h_intern(&lf[89],28,"\010compilerpostponed-initforms");
lf[90]=C_h_intern(&lf[90],25,"\010compilerunused-variables");
lf[91]=C_h_intern(&lf[91],29,"\010compilercompiler-macro-table");
lf[92]=C_h_intern(&lf[92],32,"\010compilercompiler-macros-enabled");
lf[93]=C_h_intern(&lf[93],28,"\010compilerinitialize-compiler");
lf[94]=C_h_intern(&lf[94],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],11,"make-vector");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],25,"\010compilermake-random-name");
lf[99]=C_h_intern(&lf[99],12,"profile-info");
lf[100]=C_h_intern(&lf[100],32,"\010compilercanonicalize-expression");
lf[101]=C_h_intern(&lf[101],23,"\010compilerset-real-name!");
lf[102]=C_h_intern(&lf[102],8,"for-each");
lf[103]=C_h_intern(&lf[103],5,"quote");
lf[104]=C_h_intern(&lf[104],15,"\004coreinline_ref");
lf[105]=C_h_intern(&lf[105],36,"\010compilerforeign-type-convert-result");
lf[106]=C_h_intern(&lf[106],30,"\010compilerfinish-foreign-result");
lf[107]=C_h_intern(&lf[107],27,"\010compilerfinal-foreign-type");
lf[108]=C_h_intern(&lf[108],19,"\004coreinline_loc_ref");
lf[109]=C_h_intern(&lf[109],18,"\003syshash-table-ref");
lf[110]=C_h_intern(&lf[110],21,"\003sysalias-global-hook");
lf[111]=C_h_intern(&lf[111],12,"syntax-error");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal atomic form");
lf[113]=C_h_intern(&lf[113],24,"\003syssyntax-error-culprit");
lf[114]=C_h_intern(&lf[114],2,"if");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],16,"\003syscheck-syntax");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[119]=C_h_intern(&lf[119],10,"\004corecheck");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\006\001\376\377\016");
lf[121]=C_h_intern(&lf[121],14,"\004coreimmutable");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],6,"gensym");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],6,"cadadr");
lf[126]=C_h_intern(&lf[126],14,"\004coreundefined");
lf[127]=C_h_intern(&lf[127],23,"\004corerequire-for-syntax");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[129]=C_h_intern(&lf[129],10,"lset-union");
lf[130]=C_h_intern(&lf[130],18,"hash-table-update!");
lf[131]=C_h_intern(&lf[131],19,"syntax-requirements");
lf[132]=C_h_intern(&lf[132],11,"\003sysrequire");
lf[133]=C_h_intern(&lf[133],7,"\003sysmap");
lf[134]=C_h_intern(&lf[134],4,"eval");
lf[135]=C_h_intern(&lf[135],22,"\004corerequire-extension");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[137]=C_h_intern(&lf[137],22,"\003sysdo-the-right-thing");
lf[138]=C_h_intern(&lf[138],5,"begin");
lf[139]=C_h_intern(&lf[139],28,"\010compilerlookup-exports-file");
lf[140]=C_h_intern(&lf[140],7,"exports");
lf[141]=C_h_intern(&lf[141],19,"\003syshash-table-set!");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_h_intern(&lf[143],25,"\003sysextension-information");
lf[144]=C_h_intern(&lf[144],25,"\010compilercompiler-warning");
lf[145]=C_h_intern(&lf[145],3,"ext");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)extension `~A\047 is currently not installed");
lf[147]=C_h_intern(&lf[147],18,"\003sysfind-extension");
lf[148]=C_h_intern(&lf[148],31,"\003syscanonicalize-extension-path");
lf[149]=C_h_intern(&lf[149],17,"require-extension");
lf[150]=C_h_intern(&lf[150],8,"feature\077");
lf[151]=C_h_intern(&lf[151],5,"cadar");
lf[152]=C_h_intern(&lf[152],3,"let");
lf[153]=C_h_intern(&lf[153],21,"\003syscanonicalize-body");
lf[154]=C_h_intern(&lf[154],3,"map");
lf[155]=C_h_intern(&lf[155],6,"append");
lf[156]=C_h_intern(&lf[156],4,"cons");
lf[157]=C_h_intern(&lf[157],6,"unzip1");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],6,"lambda");
lf[160]=C_h_intern(&lf[160],20,"\004coreinternal-lambda");
lf[161]=C_h_intern(&lf[161],30,"\010compilerexpand-profile-lambda");
lf[162]=C_h_intern(&lf[162],37,"\010compilerprocess-lambda-documentation");
lf[163]=C_h_intern(&lf[163],6,"cddadr");
lf[164]=C_h_intern(&lf[164],5,"cdadr");
lf[165]=C_h_intern(&lf[165],5,"caadr");
lf[166]=C_h_intern(&lf[166],26,"\010compilerbuild-lambda-list");
lf[167]=C_h_intern(&lf[167],13,"\010compilerposq");
lf[168]=C_h_intern(&lf[168],30,"\010compilerdecompose-lambda-list");
lf[169]=C_h_intern(&lf[169],31,"\003sysexpand-extended-lambda-list");
lf[170]=C_h_intern(&lf[170],9,"\003syserror");
lf[171]=C_h_intern(&lf[171],25,"\003sysextended-lambda-list\077");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[173]=C_h_intern(&lf[173],17,"\004corenamed-lambda");
lf[174]=C_h_intern(&lf[174],16,"\004coreloop-lambda");
lf[175]=C_h_intern(&lf[175],4,"set!");
lf[176]=C_h_intern(&lf[176],9,"\004coreset!");
lf[177]=C_h_intern(&lf[177],18,"\004coreinline_update");
lf[178]=C_h_intern(&lf[178],27,"\010compilerforeign-type-check");
lf[179]=C_h_intern(&lf[179],38,"\010compilerforeign-type-convert-argument");
lf[180]=C_h_intern(&lf[180],22,"\004coreinline_loc_update");
lf[181]=C_h_intern(&lf[181],6,"syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\032assignment to keyword `~S\047");
lf[183]=C_h_intern(&lf[183],8,"keyword\077");
lf[184]=C_h_intern(&lf[184],15,"undefine-macro!");
lf[185]=C_h_intern(&lf[185],3,"var");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000+assigned global variable `~S\047 is a macro ~A");
lf[187]=C_h_intern(&lf[187],7,"sprintf");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\012in line ~S");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_h_intern(&lf[190],6,"macro\077");
lf[191]=C_h_intern(&lf[191],11,"lset-adjoin");
lf[192]=C_h_intern(&lf[192],17,"\010compilerget-line");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[194]=C_h_intern(&lf[194],11,"\004coreinline");
lf[195]=C_h_intern(&lf[195],20,"\004coreinline_allocate");
lf[196]=C_h_intern(&lf[196],19,"\004corecompiletimetoo");
lf[197]=C_h_intern(&lf[197],23,"\004coreelaborationtimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_h_intern(&lf[199],24,"\004coreelaborationtimeonly");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_h_intern(&lf[201],32,"\010compilercanonicalize-begin-body");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],19,"\004coreforeign-lambda");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexpand-foreign-lambda");
lf[206]=C_h_intern(&lf[206],28,"\004coreforeign-callback-lambda");
lf[207]=C_h_intern(&lf[207],39,"\010compilerexpand-foreign-callback-lambda");
lf[208]=C_h_intern(&lf[208],20,"\004coreforeign-lambda*");
lf[209]=C_h_intern(&lf[209],31,"\010compilerexpand-foreign-lambda*");
lf[210]=C_h_intern(&lf[210],29,"\004coreforeign-callback-lambda*");
lf[211]=C_h_intern(&lf[211],40,"\010compilerexpand-foreign-callback-lambda*");
lf[212]=C_h_intern(&lf[212],22,"\004coreforeign-primitive");
lf[213]=C_h_intern(&lf[213],33,"\010compilerexpand-foreign-primitive");
lf[214]=C_h_intern(&lf[214],28,"\004coredefine-foreign-variable");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[216]=C_h_intern(&lf[216],14,"symbol->string");
lf[217]=C_h_intern(&lf[217],24,"\004coredefine-foreign-type");
lf[218]=C_h_intern(&lf[218],10,"\003sysvalues");
lf[219]=C_h_intern(&lf[219],5,"cons*");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[221]=C_h_intern(&lf[221],29,"\004coredefine-external-variable");
lf[222]=C_h_intern(&lf[222],9,"c-pointer");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[224]=C_h_intern(&lf[224],13,"string-append");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[226]=C_h_intern(&lf[226],5,"fifth");
lf[227]=C_h_intern(&lf[227],17,"\004corelet-location");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_h_intern(&lf[230],14,"\010compilerwords");
lf[231]=C_h_intern(&lf[231],46,"\010compilerestimate-foreign-result-location-size");
lf[232]=C_h_intern(&lf[232],18,"\004coredefine-inline");
lf[233]=C_h_intern(&lf[233],34,"\010compilerextract-mutable-constants");
lf[234]=C_h_intern(&lf[234],20,"\004coredefine-constant");
lf[235]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010constant");
lf[237]=C_h_intern(&lf[237],5,"const");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000@value for constant binding appears not to be a valid literal: ~s");
lf[239]=C_h_intern(&lf[239],23,"\010compilerbasic-literal\077");
lf[240]=C_h_intern(&lf[240],29,"\010compilercollapsable-literal\077");
lf[241]=C_h_intern(&lf[241],4,"quit");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\0008error in constant evaluation of ~S for named constant ~S");
lf[243]=C_h_intern(&lf[243],22,"with-exception-handler");
lf[244]=C_h_intern(&lf[244],30,"call-with-current-continuation");
lf[245]=C_h_intern(&lf[245],12,"\004coredeclare");
lf[246]=C_h_intern(&lf[246],28,"\010compilerprocess-declaration");
lf[247]=C_h_intern(&lf[247],29,"\004coreforeign-callback-wrapper");
lf[248]=C_h_intern(&lf[248],8,"split-at");
lf[249]=C_h_intern(&lf[249],1,"r");
lf[250]=C_h_intern(&lf[250],17,"\003sysmake-c-string");
lf[251]=C_h_intern(&lf[251],3,"and");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000/not a valid result type for callback procedures");
lf[253]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\377\016");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\031nonnull-unsigned-c-string\376\377\016");
lf[255]=C_h_intern(&lf[255],25,"nonnull-unsigned-c-string");
lf[256]=C_h_intern(&lf[256],16,"nonnull-c-string");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\011c-string*\376\377\016");
lf[258]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\022unsigned-c-string*\376\377\016");
lf[259]=C_h_intern(&lf[259],18,"unsigned-c-string*");
lf[260]=C_h_intern(&lf[260],9,"c-string*");
lf[261]=C_h_intern(&lf[261],13,"c-string-list");
lf[262]=C_h_intern(&lf[262],14,"c-string-list*");
lf[263]=C_h_intern(&lf[263],8,"c-string");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\377\016");
lf[265]=C_h_intern(&lf[265],17,"unsigned-c-string");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005const\376\003\000\000\002\376\001\000\000\010c-string\376\377\016");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000Anon-matching or invalid argument list to foreign callback-wrapper");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000<name `~S\047 of external definition is not a valid C identifier");
lf[269]=C_h_intern(&lf[269],28,"\010compilervalid-c-identifier\077");
lf[270]=C_h_intern(&lf[270],8,"location");
lf[271]=C_h_intern(&lf[271],17,"\003sysmake-locative");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[273]=C_h_intern(&lf[273],13,"\004corecallunit");
lf[274]=C_h_intern(&lf[274],14,"\004coreprimitive");
lf[275]=C_h_intern(&lf[275],37,"\010compilerupdate-line-number-database!");
lf[276]=C_h_intern(&lf[276],23,"\003sysmacroexpand-1-local");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000#(in line ~s) - malformed expression");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[279]=C_h_intern(&lf[279],31,"\010compileremit-syntax-trace-info");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000 literal in operator position: ~S");
lf[281]=C_h_intern(&lf[281],4,"list");
lf[282]=C_h_intern(&lf[282],1,"t");
lf[283]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[284]=C_h_intern(&lf[284],4,"caar");
lf[285]=C_h_intern(&lf[285],18,"\010compilerconstant\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[287]=C_h_intern(&lf[287],26,"\010compilerinternal-bindings");
lf[288]=C_h_intern(&lf[288],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[289]=C_h_intern(&lf[289],7,"reverse");
lf[290]=C_h_intern(&lf[290],22,"\003sysclear-trace-buffer");
lf[291]=C_h_intern(&lf[291],26,"\010compilerdebugging-chicken");
lf[292]=C_h_intern(&lf[292],12,"pretty-print");
lf[293]=C_h_intern(&lf[293],7,"newline");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[296]=C_h_intern(&lf[296],4,"uses");
lf[297]=C_h_intern(&lf[297],29,"\010compilerstring->c-identifier");
lf[298]=C_h_intern(&lf[298],18,"\010compilerstringify");
lf[299]=C_h_intern(&lf[299],17,"register-feature!");
lf[300]=C_h_intern(&lf[300],4,"unit");
lf[301]=C_h_intern(&lf[301],5,"usage");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\0003unit was already given a name (new name is ignored)");
lf[303]=C_h_intern(&lf[303],15,"hash-table-set!");
lf[304]=C_h_intern(&lf[304],34,"\010compilerdefault-standard-bindings");
lf[305]=C_h_intern(&lf[305],34,"\010compilerdefault-extended-bindings");
lf[306]=C_h_intern(&lf[306],18,"usual-integrations");
lf[307]=C_h_intern(&lf[307],17,"lset-intersection");
lf[308]=C_h_intern(&lf[308],6,"fixnum");
lf[309]=C_h_intern(&lf[309],17,"fixnum-arithmetic");
lf[310]=C_h_intern(&lf[310],23,"\005matchset-error-control");
lf[311]=C_h_intern(&lf[311],12,"\000unspecified");
lf[312]=C_h_intern(&lf[312],4,"safe");
lf[313]=C_h_intern(&lf[313],18,"interrupts-enabled");
lf[314]=C_h_intern(&lf[314],18,"disable-interrupts");
lf[315]=C_h_intern(&lf[315],15,"disable-warning");
lf[316]=C_h_intern(&lf[316],26,"\010compilerdisabled-warnings");
lf[317]=C_h_intern(&lf[317],12,"safe-globals");
lf[318]=C_h_intern(&lf[318],38,"no-procedure-checks-for-usual-bindings");
lf[319]=C_h_intern(&lf[319],18,"bound-to-procedure");
lf[320]=C_h_intern(&lf[320],15,"foreign-declare");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[322]=C_h_intern(&lf[322],5,"every");
lf[323]=C_h_intern(&lf[323],7,"string\077");
lf[324]=C_h_intern(&lf[324],14,"custom-declare");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid declaration");
lf[326]=C_h_intern(&lf[326],35,"\010compilerprocess-custom-declaration");
lf[327]=C_h_intern(&lf[327],9,"c-options");
lf[328]=C_h_intern(&lf[328],31,"\010compileremit-control-file-item");
lf[329]=C_h_intern(&lf[329],12,"link-options");
lf[330]=C_h_intern(&lf[330],12,"post-process");
lf[331]=C_h_intern(&lf[331],17,"string-substitute");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\003\134$@");
lf[333]=C_h_intern(&lf[333],24,"pathname-strip-extension");
lf[334]=C_h_intern(&lf[334],5,"block");
lf[335]=C_h_intern(&lf[335],8,"separate");
lf[336]=C_h_intern(&lf[336],20,"keep-shadowed-macros");
lf[337]=C_h_intern(&lf[337],6,"unused");
lf[338]=C_h_intern(&lf[338],3,"not");
lf[339]=C_h_intern(&lf[339],15,"lset-difference");
lf[340]=C_h_intern(&lf[340],6,"inline");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[342]=C_h_intern(&lf[342],15,"run-time-macros");
lf[343]=C_h_intern(&lf[343],25,"\003sysenable-runtime-macros");
lf[344]=C_h_intern(&lf[344],12,"block-global");
lf[345]=C_h_intern(&lf[345],4,"hide");
lf[346]=C_h_intern(&lf[346],6,"export");
lf[347]=C_h_intern(&lf[347],12,"emit-exports");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid `emit-exports\047 declaration");
lf[349]=C_h_intern(&lf[349],30,"emit-external-prototypes-first");
lf[350]=C_h_intern(&lf[350],11,"lambda-lift");
lf[351]=C_h_intern(&lf[351],12,"inline-limit");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000.invalid argument to `inline-limit\047 declaration");
lf[353]=C_h_intern(&lf[353],8,"constant");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000/invalid arguments to `constant\047 declaration: ~S");
lf[355]=C_h_intern(&lf[355],7,"symbol\077");
lf[356]=C_h_intern(&lf[356],6,"import");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000:argument to `import\047 declaration is not a string or symbol");
lf[358]=C_h_intern(&lf[358],9,"partition");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\006<here>");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal declaration specifier `~s\047");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000!invalid declaration specification");
lf[362]=C_h_intern(&lf[362],17,"make-foreign-stub");
lf[363]=C_h_intern(&lf[363],12,"foreign-stub");
lf[364]=C_h_intern(&lf[364],13,"foreign-stub\077");
lf[365]=C_h_intern(&lf[365],20,"foreign-stub-id-set!");
lf[366]=C_h_intern(&lf[366],14,"\003sysblock-set!");
lf[367]=C_h_intern(&lf[367],15,"foreign-stub-id");
lf[368]=C_h_intern(&lf[368],29,"foreign-stub-return-type-set!");
lf[369]=C_h_intern(&lf[369],24,"foreign-stub-return-type");
lf[370]=C_h_intern(&lf[370],22,"foreign-stub-name-set!");
lf[371]=C_h_intern(&lf[371],17,"foreign-stub-name");
lf[372]=C_h_intern(&lf[372],32,"foreign-stub-argument-types-set!");
lf[373]=C_h_intern(&lf[373],27,"foreign-stub-argument-types");
lf[374]=C_h_intern(&lf[374],32,"foreign-stub-argument-names-set!");
lf[375]=C_h_intern(&lf[375],27,"foreign-stub-argument-names");
lf[376]=C_h_intern(&lf[376],22,"foreign-stub-body-set!");
lf[377]=C_h_intern(&lf[377],17,"foreign-stub-body");
lf[378]=C_h_intern(&lf[378],21,"foreign-stub-cps-set!");
lf[379]=C_h_intern(&lf[379],16,"foreign-stub-cps");
lf[380]=C_h_intern(&lf[380],26,"foreign-stub-callback-set!");
lf[381]=C_h_intern(&lf[381],21,"foreign-stub-callback");
lf[382]=C_h_intern(&lf[382],28,"\010compilercreate-foreign-stub");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006\003sysgc\376\003\000\000\002\376\377\006\000\376\377\016\376\377\016");
lf[384]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_bytevector");
lf[386]=C_h_intern(&lf[386],37,"\010compilerestimate-foreign-result-size");
lf[387]=C_h_intern(&lf[387],4,"stub");
lf[388]=C_h_intern(&lf[388],1,"a");
lf[389]=C_h_intern(&lf[389],13,"list-tabulate");
lf[390]=C_h_intern(&lf[390],6,"second");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000-name `~s\047 of foreign procedure has wrong type");
lf[393]=C_h_intern(&lf[393],4,"cadr");
lf[394]=C_h_intern(&lf[394],3,"car");
lf[395]=C_h_intern(&lf[395],4,"void");
lf[396]=C_h_intern(&lf[396],24,"\003sysline-number-database");
lf[397]=C_h_intern(&lf[397],31,"\010compilerperform-cps-conversion");
lf[398]=C_h_intern(&lf[398],4,"node");
lf[399]=C_h_intern(&lf[399],11,"\004corelambda");
lf[400]=C_h_intern(&lf[400],9,"\004corecall");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[402]=C_h_intern(&lf[402],16,"\010compilervarnode");
lf[403]=C_h_intern(&lf[403],1,"k");
lf[404]=C_h_intern(&lf[404],13,"\004corevariable");
lf[405]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[406]=C_h_intern(&lf[406],2,"f_");
lf[407]=C_h_intern(&lf[407],26,"make-foreign-callback-stub");
lf[408]=C_h_intern(&lf[408],13,"\010compilerbomb");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\016bad node (cps)");
lf[410]=C_h_intern(&lf[410],15,"\004coreglobal-ref");
lf[411]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\015\004corevariable\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\003\000\000\002\376\001\000\000\017\004coreglo"
"bal-ref\376\377\016");
lf[412]=C_h_intern(&lf[412],6,"values");
lf[413]=C_h_intern(&lf[413],21,"foreign-callback-stub");
lf[414]=C_h_intern(&lf[414],22,"foreign-callback-stub\077");
lf[415]=C_h_intern(&lf[415],29,"foreign-callback-stub-id-set!");
lf[416]=C_h_intern(&lf[416],24,"foreign-callback-stub-id");
lf[417]=C_h_intern(&lf[417],31,"foreign-callback-stub-name-set!");
lf[418]=C_h_intern(&lf[418],26,"foreign-callback-stub-name");
lf[419]=C_h_intern(&lf[419],37,"foreign-callback-stub-qualifiers-set!");
lf[420]=C_h_intern(&lf[420],32,"foreign-callback-stub-qualifiers");
lf[421]=C_h_intern(&lf[421],38,"foreign-callback-stub-return-type-set!");
lf[422]=C_h_intern(&lf[422],33,"foreign-callback-stub-return-type");
lf[423]=C_h_intern(&lf[423],41,"foreign-callback-stub-argument-types-set!");
lf[424]=C_h_intern(&lf[424],36,"foreign-callback-stub-argument-types");
lf[425]=C_h_intern(&lf[425],27,"\010compileranalyze-expression");
lf[426]=C_h_intern(&lf[426],17,"\010compilercollect!");
lf[427]=C_h_intern(&lf[427],10,"references");
lf[428]=C_h_intern(&lf[428],13,"\010compilerput!");
lf[429]=C_h_intern(&lf[429],9,"undefined");
lf[430]=C_h_intern(&lf[430],7,"unknown");
lf[431]=C_h_intern(&lf[431],5,"value");
lf[432]=C_h_intern(&lf[432],12,"\010compilerget");
lf[433]=C_h_intern(&lf[433],4,"home");
lf[434]=C_h_intern(&lf[434],16,"\010compilerget-all");
lf[435]=C_h_intern(&lf[435],8,"captured");
lf[436]=C_h_intern(&lf[436],6,"global");
lf[437]=C_h_intern(&lf[437],12,"\004corerecurse");
lf[438]=C_h_intern(&lf[438],44,"\010compileroptimizable-rest-argument-operators");
lf[439]=C_h_intern(&lf[439],15,"\010compilercount!");
lf[440]=C_h_intern(&lf[440],16,"o-r/access-count");
lf[441]=C_h_intern(&lf[441],14,"rest-parameter");
lf[442]=C_h_intern(&lf[442],16,"standard-binding");
lf[443]=C_h_intern(&lf[443],10,"call-sites");
lf[444]=C_h_intern(&lf[444],18,"\004coredirect_lambda");
lf[445]=C_h_intern(&lf[445],6,"simple");
lf[446]=C_h_intern(&lf[446],28,"\010compilersimple-lambda-node\077");
lf[447]=C_h_intern(&lf[447],6,"vector");
lf[448]=C_h_intern(&lf[448],12,"contained-in");
lf[449]=C_h_intern(&lf[449],8,"contains");
lf[450]=C_h_intern(&lf[450],8,"assigned");
lf[451]=C_h_intern(&lf[451],16,"assigned-locally");
lf[452]=C_h_intern(&lf[452],15,"potential-value");
lf[453]=C_h_intern(&lf[453],5,"redef");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of standard binding `~S\047");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000%redefinition of extended binding `~S\047");
lf[456]=C_h_intern(&lf[456],16,"extended-binding");
lf[457]=C_h_intern(&lf[457],9,"\004coreproc");
lf[458]=C_h_intern(&lf[458],3,"any");
lf[459]=C_h_intern(&lf[459],9,"replacing");
lf[460]=C_h_intern(&lf[460],10,"replacable");
lf[461]=C_h_intern(&lf[461],9,"removable");
lf[462]=C_h_intern(&lf[462],37,"\010compilerexpression-has-side-effects\077");
lf[463]=C_h_intern(&lf[463],21,"has-unused-parameters");
lf[464]=C_h_intern(&lf[464],13,"explicit-rest");
lf[465]=C_h_intern(&lf[465],11,"collapsable");
lf[466]=C_h_intern(&lf[466],12,"contractable");
lf[467]=C_h_intern(&lf[467],9,"inlinable");
lf[468]=C_h_intern(&lf[468],28,"\010compilerscan-free-variables");
lf[469]=C_h_intern(&lf[469],5,"boxed");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\042global variable `~S\047 is never used");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000:local assignment to unused variable `~S\047 may be unintended");
lf[472]=C_h_intern(&lf[472],23,"\003syshash-table-for-each");
lf[473]=C_h_intern(&lf[473],18,"\010compilerdebugging");
lf[474]=C_h_intern(&lf[474],1,"p");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis gathering phase...");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\033analysis traversal phase...");
lf[477]=C_h_intern(&lf[477],37,"\010compilerinitialize-analysis-database");
lf[478]=C_h_intern(&lf[478],35,"\010compilerperform-closure-conversion");
lf[479]=C_h_intern(&lf[479],12,"customizable");
lf[480]=C_h_intern(&lf[480],20,"node-parameters-set!");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\0009known procedure called with wrong number of arguments: ~A");
lf[482]=C_h_intern(&lf[482],28,"\010compilersource-info->string");
lf[483]=C_h_intern(&lf[483],8,"toplevel");
lf[484]=C_h_intern(&lf[484],18,"captured-variables");
lf[485]=C_h_intern(&lf[485],12,"closure-size");
lf[486]=C_h_intern(&lf[486],8,"\004coreref");
lf[487]=C_h_intern(&lf[487],10,"\004coreunbox");
lf[488]=C_h_intern(&lf[488],8,"\004corebox");
lf[489]=C_h_intern(&lf[489],12,"\004coreclosure");
lf[490]=C_h_intern(&lf[490],14,"\010compilerqnode");
lf[491]=C_h_intern(&lf[491],20,"\003sysmake-lambda-info");
lf[492]=C_h_intern(&lf[492],1,"\077");
lf[493]=C_h_intern(&lf[493],8,"->string");
lf[494]=C_h_intern(&lf[494],18,"\010compilerreal-name");
lf[495]=C_h_intern(&lf[495],10,"fold-right");
lf[496]=C_h_intern(&lf[496],10,"boxed-rest");
lf[497]=C_h_intern(&lf[497],6,"filter");
lf[498]=C_h_intern(&lf[498],16,"\004coreupdatebox_i");
lf[499]=C_h_intern(&lf[499],14,"\004coreupdatebox");
lf[500]=C_h_intern(&lf[500],13,"\004coreupdate_i");
lf[501]=C_h_intern(&lf[501],11,"\004coreupdate");
lf[502]=C_h_intern(&lf[502],19,"\010compilerimmediate\077");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\023bad node (closure2)");
lf[504]=C_h_intern(&lf[504],11,"\004coreswitch");
lf[505]=C_h_intern(&lf[505],9,"\004corecond");
lf[506]=C_h_intern(&lf[506],16,"\004coredirect_call");
lf[507]=C_h_intern(&lf[507],11,"\004corereturn");
lf[508]=C_h_intern(&lf[508],1,"o");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\026calls to known targets");
lf[510]=C_h_intern(&lf[510],16,"\003sysmake-promise");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000*closure conversion transformation phase...");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\027customizable procedures");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000%closure conversion gathering phase...");
lf[514]=C_h_intern(&lf[514],19,"make-lambda-literal");
lf[515]=C_h_intern(&lf[515],14,"lambda-literal");
lf[516]=C_h_intern(&lf[516],15,"lambda-literal\077");
lf[517]=C_h_intern(&lf[517],22,"lambda-literal-id-set!");
lf[518]=C_h_intern(&lf[518],17,"lambda-literal-id");
lf[519]=C_h_intern(&lf[519],28,"lambda-literal-external-set!");
lf[520]=C_h_intern(&lf[520],23,"lambda-literal-external");
lf[521]=C_h_intern(&lf[521],29,"lambda-literal-arguments-set!");
lf[522]=C_h_intern(&lf[522],24,"lambda-literal-arguments");
lf[523]=C_h_intern(&lf[523],34,"lambda-literal-argument-count-set!");
lf[524]=C_h_intern(&lf[524],29,"lambda-literal-argument-count");
lf[525]=C_h_intern(&lf[525],33,"lambda-literal-rest-argument-set!");
lf[526]=C_h_intern(&lf[526],28,"lambda-literal-rest-argument");
lf[527]=C_h_intern(&lf[527],31,"lambda-literal-temporaries-set!");
lf[528]=C_h_intern(&lf[528],26,"lambda-literal-temporaries");
lf[529]=C_h_intern(&lf[529],37,"lambda-literal-callee-signatures-set!");
lf[530]=C_h_intern(&lf[530],32,"lambda-literal-callee-signatures");
lf[531]=C_h_intern(&lf[531],29,"lambda-literal-allocated-set!");
lf[532]=C_h_intern(&lf[532],24,"lambda-literal-allocated");
lf[533]=C_h_intern(&lf[533],35,"lambda-literal-directly-called-set!");
lf[534]=C_h_intern(&lf[534],30,"lambda-literal-directly-called");
lf[535]=C_h_intern(&lf[535],32,"lambda-literal-closure-size-set!");
lf[536]=C_h_intern(&lf[536],27,"lambda-literal-closure-size");
lf[537]=C_h_intern(&lf[537],27,"lambda-literal-looping-set!");
lf[538]=C_h_intern(&lf[538],22,"lambda-literal-looping");
lf[539]=C_h_intern(&lf[539],32,"lambda-literal-customizable-set!");
lf[540]=C_h_intern(&lf[540],27,"lambda-literal-customizable");
lf[541]=C_h_intern(&lf[541],38,"lambda-literal-rest-argument-mode-set!");
lf[542]=C_h_intern(&lf[542],33,"lambda-literal-rest-argument-mode");
lf[543]=C_h_intern(&lf[543],24,"lambda-literal-body-set!");
lf[544]=C_h_intern(&lf[544],19,"lambda-literal-body");
lf[545]=C_h_intern(&lf[545],26,"lambda-literal-direct-set!");
lf[546]=C_h_intern(&lf[546],21,"lambda-literal-direct");
lf[547]=C_h_intern(&lf[547],36,"\010compilerprepare-for-code-generation");
lf[548]=C_h_intern(&lf[548],14,"\004coreimmediate");
lf[549]=C_h_intern(&lf[549],3,"fix");
lf[550]=C_h_intern(&lf[550],4,"bool");
lf[551]=C_h_intern(&lf[551],4,"char");
lf[552]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003nil\376\377\016");
lf[553]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003eof\376\377\016");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\027bad immediate (prepare)");
lf[555]=C_h_intern(&lf[555],36,"\010compilermake-block-variable-literal");
lf[556]=C_h_intern(&lf[556],36,"\010compilerblock-variable-literal-name");
lf[557]=C_h_intern(&lf[557],32,"\010compilerblock-variable-literal\077");
lf[558]=C_h_intern(&lf[558],10,"list-index");
lf[559]=C_h_intern(&lf[559],11,"\004coreglobal");
lf[560]=C_h_intern(&lf[560],10,"\004corelocal");
lf[561]=C_h_intern(&lf[561],12,"\004coreliteral");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000!identified direct recursive calls");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\021bad direct lambda");
lf[564]=C_h_intern(&lf[564],4,"none");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\024unused rest argument");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000 rest argument accessed as vector");
lf[567]=C_h_intern(&lf[567],7,"butlast");
lf[568]=C_h_intern(&lf[568],9,"\004corebind");
lf[569]=C_h_intern(&lf[569],13,"\004coresetlocal");
lf[570]=C_h_intern(&lf[570],16,"\004coresetglobal_i");
lf[571]=C_h_intern(&lf[571],14,"\004coresetglobal");
lf[572]=C_h_intern(&lf[572],1,"=");
lf[573]=C_h_intern(&lf[573],4,"type");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\0000coerced inexact literal number `~S\047 to fixnum ~S");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000-can not coerce inexact literal `~S\047 to fixnum");
lf[576]=C_h_intern(&lf[576],20,"\010compilerbig-fixnum\077");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\027fast global assignments");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\026fast global references");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\030fast box initializations");
lf[580]=C_decode_literal(C_heaptop,"\376B\000\000\024preparation phase...");
lf[581]=C_h_intern(&lf[581],14,"make-parameter");
C_register_lf2(lf,582,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1758,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1756 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1759 in k1756 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1762 in k1759 in k1756 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 318  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 319  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 320  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 321  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 322  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 323  make-parameter */
t4=C_retrieve(lf[581]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word ab[152],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_set_block_item(lf[9],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[10]+1,lf[11]);
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t8=C_set_block_item(lf[15],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t10=C_set_block_item(lf[17],0,C_SCHEME_END_OF_LIST);
t11=C_set_block_item(lf[18],0,C_SCHEME_END_OF_LIST);
t12=C_set_block_item(lf[19],0,C_SCHEME_END_OF_LIST);
t13=C_set_block_item(lf[20],0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t15=C_set_block_item(lf[22],0,C_fix(997));
t16=C_set_block_item(lf[23],0,C_SCHEME_FALSE);
t17=C_set_block_item(lf[24],0,C_SCHEME_FALSE);
t18=C_set_block_item(lf[25],0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[26],0,C_SCHEME_FALSE);
t20=C_set_block_item(lf[27],0,C_SCHEME_FALSE);
t21=C_set_block_item(lf[28],0,C_SCHEME_FALSE);
t22=C_set_block_item(lf[29],0,C_SCHEME_FALSE);
t23=C_set_block_item(lf[30],0,C_SCHEME_FALSE);
t24=C_set_block_item(lf[31],0,C_SCHEME_END_OF_LIST);
t25=C_set_block_item(lf[32],0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[33],0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[34],0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[35],0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[36],0,C_SCHEME_FALSE);
t30=C_set_block_item(lf[37],0,C_SCHEME_FALSE);
t31=C_set_block_item(lf[38],0,C_SCHEME_FALSE);
t32=C_set_block_item(lf[39],0,C_SCHEME_FALSE);
t33=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t34=C_set_block_item(lf[41],0,C_fix(-1));
t35=C_set_block_item(lf[42],0,C_SCHEME_TRUE);
t36=C_set_block_item(lf[43],0,C_SCHEME_FALSE);
t37=C_set_block_item(lf[44],0,C_SCHEME_FALSE);
t38=C_set_block_item(lf[45],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[46],0,C_SCHEME_TRUE);
t40=C_set_block_item(lf[47],0,C_SCHEME_END_OF_LIST);
t41=C_mutate((C_word*)lf[48]+1,C_fix((C_word)C_DEFAULT_TARGET_HEAP_SIZE));
t42=C_mutate((C_word*)lf[49]+1,C_fix((C_word)C_DEFAULT_TARGET_STACK_SIZE));
t43=C_set_block_item(lf[50],0,C_SCHEME_FALSE);
t44=C_set_block_item(lf[51],0,C_SCHEME_FALSE);
t45=C_set_block_item(lf[52],0,C_fix(0));
t46=C_set_block_item(lf[53],0,C_SCHEME_FALSE);
t47=C_set_block_item(lf[54],0,C_SCHEME_END_OF_LIST);
t48=C_set_block_item(lf[55],0,C_SCHEME_END_OF_LIST);
t49=C_set_block_item(lf[56],0,C_SCHEME_FALSE);
t50=C_set_block_item(lf[57],0,C_SCHEME_FALSE);
t51=C_set_block_item(lf[58],0,C_SCHEME_FALSE);
t52=C_set_block_item(lf[59],0,C_SCHEME_FALSE);
t53=C_set_block_item(lf[60],0,C_SCHEME_END_OF_LIST);
t54=C_set_block_item(lf[61],0,C_SCHEME_END_OF_LIST);
t55=C_set_block_item(lf[62],0,C_SCHEME_FALSE);
t56=C_set_block_item(lf[63],0,C_SCHEME_END_OF_LIST);
t57=C_set_block_item(lf[64],0,C_SCHEME_TRUE);
t58=C_set_block_item(lf[65],0,C_SCHEME_FALSE);
t59=C_set_block_item(lf[66],0,C_SCHEME_END_OF_LIST);
t60=C_set_block_item(lf[67],0,C_SCHEME_END_OF_LIST);
t61=C_set_block_item(lf[68],0,C_SCHEME_END_OF_LIST);
t62=C_set_block_item(lf[69],0,C_SCHEME_END_OF_LIST);
t63=C_set_block_item(lf[70],0,C_SCHEME_END_OF_LIST);
t64=C_set_block_item(lf[71],0,C_SCHEME_END_OF_LIST);
t65=C_set_block_item(lf[72],0,C_fix(0));
t66=C_set_block_item(lf[73],0,C_SCHEME_FALSE);
t67=C_set_block_item(lf[74],0,C_SCHEME_END_OF_LIST);
t68=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t69=C_set_block_item(lf[76],0,C_SCHEME_FALSE);
t70=C_set_block_item(lf[77],0,C_SCHEME_END_OF_LIST);
t71=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t72=C_set_block_item(lf[79],0,C_SCHEME_END_OF_LIST);
t73=C_set_block_item(lf[80],0,C_SCHEME_END_OF_LIST);
t74=C_set_block_item(lf[81],0,C_SCHEME_TRUE);
t75=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t76=C_set_block_item(lf[83],0,C_SCHEME_END_OF_LIST);
t77=C_set_block_item(lf[84],0,C_SCHEME_FALSE);
t78=C_set_block_item(lf[85],0,C_SCHEME_END_OF_LIST);
t79=C_set_block_item(lf[86],0,C_SCHEME_END_OF_LIST);
t80=C_set_block_item(lf[87],0,C_SCHEME_END_OF_LIST);
t81=C_set_block_item(lf[88],0,C_SCHEME_FALSE);
t82=C_set_block_item(lf[89],0,C_SCHEME_END_OF_LIST);
t83=C_set_block_item(lf[90],0,C_SCHEME_END_OF_LIST);
t84=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t85=C_set_block_item(lf[92],0,C_SCHEME_TRUE);
t86=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1876,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1941,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5635,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5641,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5647,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5656,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5665,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5674,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5683,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5692,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5701,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5710,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[374]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5719,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5728,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5737,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5746,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5755,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5764,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5773,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5782,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[382]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[205]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5945,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5990,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6035,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6072,tmp=(C_word)a,a+=2,tmp));
t112=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6109,tmp=(C_word)a,a+=2,tmp));
t113=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6190,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[397]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6280,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[407]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6955,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6961,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6967,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6976,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6985,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6994,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7003,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7012,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7021,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7030,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7039,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7048,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7057,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8582,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[514]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9816,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[516]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9822,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[517]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9828,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[518]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9837,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[519]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9846,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[520]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9855,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[521]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9864,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[522]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9873,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[523]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9882,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[524]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9891,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[525]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9900,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[526]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9909,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[527]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9918,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[528]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9927,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[529]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9936,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[530]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9945,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9954,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[532]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9963,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[533]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9972,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[534]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9981,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[535]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9990,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[536]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9999,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[537]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10008,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[538]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10017,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[539]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10026,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[540]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10035,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[541]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10044,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[542]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10053,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10062,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[544]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10071,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[545]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10080,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[546]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10089,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[547]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10098,tmp=(C_word)a,a+=2,tmp));
t162=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t162+1)))(2,t162,C_SCHEME_UNDEFINED);}

/* ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[80],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10098,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_fix(0);
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_fix(0);
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_fix(0);
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_fix(0);
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11093,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11047,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11061,a[2]=t5,a[3]=t25,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10967,a[2]=t5,a[3]=t25,a[4]=t7,a[5]=t24,tmp=(C_word)a,a+=6,tmp);
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10135,a[2]=t3,a[3]=t21,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10101,a[2]=t28,a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10188,a[2]=t24,a[3]=t23,a[4]=t27,a[5]=t26,a[6]=t3,a[7]=t9,a[8]=t15,a[9]=t17,a[10]=t11,a[11]=t19,a[12]=t31,a[13]=t33,a[14]=t13,a[15]=t28,a[16]=t29,tmp=(C_word)a,a+=17,tmp));
t35=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10955,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11155,a[2]=t2,a[3]=t31,a[4]=t19,a[5]=t21,a[6]=t23,a[7]=t9,a[8]=t7,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2311 debugging */
t37=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t37))(4,t37,t36,lf[474],lf[580]);}

/* k11153 in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11158,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2312 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10188(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k11156 in k11153 in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 2313 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[579],((C_word*)((C_word*)t0)[2])[1]);}

/* k11159 in k11156 in k11153 in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2314 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[578],((C_word*)((C_word*)t0)[2])[1]);}

/* k11162 in k11159 in k11156 in k11153 in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2315 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[577],((C_word*)((C_word*)t0)[2])[1]);}

/* k11165 in k11162 in k11159 in k11156 in k11153 in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2316 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* mapwalk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10955,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10961,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a10960 in mapwalk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10961,3,t0,t1,t2);}
/* compiler.scm: 2270 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10188(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word *a;
loop:
a=C_alloc(131);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10188,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[126]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t11,lf[457]));
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t2);}
else{
t14=(C_word)C_eqp(t11,lf[404]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t9);
/* compiler.scm: 2104 walk-var */
t16=((C_word*)t0)[16];
f_10101(t16,t1,t15,t3,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(t11,lf[410]);
if(C_truep(t15)){
t16=(C_word)C_i_car(t9);
/* compiler.scm: 2107 walk-global */
t17=((C_word*)t0)[15];
f_10135(t17,t1,t16,C_SCHEME_TRUE);}
else{
t16=(C_word)C_eqp(t11,lf[506]);
if(C_truep(t16)){
t17=(C_word)C_i_cadddr(t9);
t18=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t17);
t19=C_mutate(((C_word *)((C_word*)t0)[14])+1,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10246,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2111 mapwalk */
t21=((C_word*)((C_word*)t0)[13])[1];
f_10955(t21,t20,t7,t3,t4,t5);}
else{
t17=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t9);
t19=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t18);
t20=C_mutate(((C_word *)((C_word*)t0)[14])+1,t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10266,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2115 mapwalk */
t22=((C_word*)((C_word*)t0)[13])[1];
f_10955(t22,t21,t7,t3,t4,t5);}
else{
t18=(C_word)C_eqp(t11,lf[104]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10290,a[2]=t9,a[3]=t11,a[4]=t1,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10294,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
t21=(C_word)C_i_cadr(t9);
/* compiler.scm: 2118 estimate-foreign-result-size */
t22=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t20,t21);}
else{
t19=(C_word)C_eqp(t11,lf[108]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10318,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10322,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_car(t9);
/* compiler.scm: 2122 estimate-foreign-result-size */
t23=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}
else{
t20=(C_word)C_eqp(t11,lf[489]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_fixnum_plus((C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],t21),C_fix(1));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10339,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2127 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10955(t25,t24,t7,t3,t4,t5);}
else{
t21=(C_word)C_eqp(t11,lf[488]);
if(C_truep(t21)){
t22=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[14])[1],C_fix(2));
t23=C_mutate(((C_word *)((C_word*)t0)[14])+1,t22);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10366,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_car(t7);
/* compiler.scm: 2131 walk */
t90=t24;
t91=t25;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t22=(C_word)C_eqp(t11,lf[499]);
if(C_truep(t22)){
t23=(C_word)C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10382,a[2]=t5,a[3]=t23,a[4]=t11,a[5]=((C_word*)t0)[11],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2135 mapwalk */
t25=((C_word*)((C_word*)t0)[13])[1];
f_10955(t25,t24,t7,t3,t4,t5);}
else{
t23=(C_word)C_eqp(t11,lf[399]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[444]));
if(C_truep(t24)){
t25=((C_word*)((C_word*)t0)[10])[1];
t26=((C_word*)((C_word*)t0)[9])[1];
t27=((C_word*)((C_word*)t0)[8])[1];
t28=((C_word*)((C_word*)t0)[14])[1];
t29=(C_word)C_eqp(t11,lf[444]);
t30=C_set_block_item(((C_word*)t0)[10],0,C_fix(0));
t31=C_set_block_item(((C_word*)t0)[14],0,C_fix(0));
t32=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_END_OF_LIST);
t33=C_set_block_item(((C_word*)t0)[8],0,C_fix(0));
t34=(C_word)C_i_caddr(t9);
t35=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10438,a[2]=((C_word*)t0)[12],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=t29,a[6]=t26,a[7]=((C_word*)t0)[9],a[8]=t28,a[9]=((C_word*)t0)[14],a[10]=t25,a[11]=((C_word*)t0)[10],a[12]=t27,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[7],a[15]=t9,tmp=(C_word)a,a+=16,tmp);
/* compiler.scm: 2155 decompose-lambda-list */
t36=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t1,t34,t35);}
else{
t25=(C_word)C_eqp(t11,lf[152]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t9);
t27=(C_word)C_i_car(t7);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[488],t28);
t30=(C_truep(t29)?(C_word)C_a_i_list(&a,1,t26):C_SCHEME_END_OF_LIST);
t31=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[10])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[10])+1,t31);
t33=(C_word)C_a_i_list(&a,1,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10622,a[2]=t9,a[3]=t3,a[4]=t5,a[5]=t30,a[6]=t4,a[7]=((C_word*)t0)[12],a[8]=t7,a[9]=t33,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 2212 walk */
t90=t34;
t91=t27;
t92=t3;
t93=t4;
t94=t5;
t1=t90;
t2=t91;
t3=t92;
t4=t93;
t5=t94;
goto loop;}
else{
t26=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t9);
t28=(C_word)C_i_car(t7);
t29=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10663,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,a[7]=t27,a[8]=t5,a[9]=t4,a[10]=t3,a[11]=t28,a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 2218 posq */
t30=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t30))(4,t30,t29,t27,t3);}
else{
t27=(C_word)C_eqp(t11,lf[400]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(t7);
t29=(C_word)C_i_length(t28);
t30=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10783,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=((C_word*)t0)[13],a[8]=t9,a[9]=t11,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 2242 lset-adjoin */
t31=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t31))(5,t31,t30,*((C_word*)lf[572]+1),((C_word*)((C_word*)t0)[9])[1],t29);}
else{
t28=(C_word)C_eqp(t11,lf[437]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10826,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[13],a[7]=t9,a[8]=t11,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_car(t9))){
t30=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[8])[1]);
t31=C_mutate(((C_word *)((C_word*)t0)[8])+1,t30);
t32=t29;
f_10826(t32,t31);}
else{
t30=t29;
f_10826(t30,C_SCHEME_UNDEFINED);}}
else{
t29=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t29)){
t30=(C_word)C_i_car(t9);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10854,a[2]=((C_word*)t0)[4],a[3]=t30,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t30))){
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10941,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2253 big-fixnum? */
t33=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t33))(3,t33,t32,t30);}
else{
t32=t31;
f_10854(t32,C_SCHEME_FALSE);}}
else{
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10944,a[2]=t9,a[3]=t11,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2267 mapwalk */
t31=((C_word*)((C_word*)t0)[13])[1];
f_10955(t31,t30,t7,t3,t4,t5);}}}}}}}}}}}}}}}}}

/* k10942 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10944,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10939 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10854(t2,(C_word)C_i_not(t1));}

/* k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10854,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2254 immediate-literal */
f_11093(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=(C_word)C_eqp(lf[308],C_retrieve(lf[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10875,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_integerp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10902,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2257 big-fixnum? */
t5=C_retrieve(lf[576]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t4=t3;
f_10875(t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10912,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2263 literal */
t4=((C_word*)t0)[2];
f_10967(t4,t3,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2264 immediate? */
t3=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}}

/* k10916 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10918,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2264 immediate-literal */
f_11093(((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10931,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2265 literal */
t3=((C_word*)t0)[2];
f_10967(t3,t2,((C_word*)t0)[3]);}}

/* k10929 in k10916 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10931,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* k10910 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10912,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* k10900 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10875(t2,(C_word)C_i_not(t1));}

/* k10873 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10875,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2258 compiler-warning */
t4=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[573],lf[574],((C_word*)t0)[4],t3);}
else{
/* compiler.scm: 2262 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[575],((C_word*)t0)[4]);}}

/* k10876 in k10873 in k10852 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
/* compiler.scm: 2261 immediate-literal */
f_11093(((C_word*)t0)[2],t2);}

/* k10824 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10826,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10829,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2249 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10955(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10827 in k10824 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10829,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10781 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10783,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10795,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=t4;
f_10795(t7,(C_word)C_eqp(((C_word*)t0)[4],t6));}
else{
t6=t4;
f_10795(t6,C_SCHEME_FALSE);}}

/* k10793 in k10781 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10795(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10786(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10786(t2,C_SCHEME_UNDEFINED);}}

/* k10784 in k10781 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10786,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2245 mapwalk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_10955(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10787 in k10784 in k10781 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10789,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10663,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10679,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2220 walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_10188(t4,t3,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10752,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_10752(2,t5,t3);}
else{
t5=C_retrieve(lf[16]);
if(C_truep(t5)){
t6=t4;
f_10752(2,t6,t5);}
else{
t6=(C_word)C_i_memq(((C_word*)t0)[7],C_retrieve(lf[17]));
if(C_truep(t6)){
t7=t4;
f_10752(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10764,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2226 get */
t8=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],((C_word*)t0)[7],lf[442]);}}}}}

/* k10762 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10752(2,t2,t1);}
else{
/* compiler.scm: 2227 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456]);}}

/* k10750 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(C_word)C_i_memq(((C_word*)t0)[13],C_retrieve(lf[31]));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[103]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t7=(C_word)C_i_car(t6);
/* compiler.scm: 2229 immediate? */
t8=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t4,t7);}
else{
t6=t4;
f_10691(2,t6,C_SCHEME_FALSE);}}

/* k10689 in k10750 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10691,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[13]));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10697(t6,t5);}
else{
t4=t3;
f_10697(t4,C_SCHEME_UNDEFINED);}}

/* k10695 in k10689 in k10750 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10697,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[12])?lf[570]:lf[571]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10721,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* compiler.scm: 2235 blockvar-literal */
t4=((C_word*)t0)[4];
f_11061(t4,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2236 literal */
t4=((C_word*)t0)[2];
f_10967(t4,t3,((C_word*)t0)[3]);}}

/* k10719 in k10695 in k10689 in k10750 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10721,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10713,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 2238 walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_10188(t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10711 in k10719 in k10695 in k10689 in k10750 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k10677 in k10661 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[569],((C_word*)t0)[2],t2));}

/* k10620 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10626,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10634,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2213 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10632 in k10620 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10638,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2213 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10636 in k10632 in k10620 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2213 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_10188(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10624 in k10620 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10626,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[568],((C_word*)t0)[2],t2));}

/* a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10438,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=((C_word*)t0)[5],a[10]=t1,a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[13],a[20]=((C_word*)t0)[14],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t4)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10559,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2161 get */
t8=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,lf[427]);}
else{
t7=t6;
f_10445(2,t7,C_SCHEME_FALSE);}}

/* k10557 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10565,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2162 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}

/* k10563 in k10557 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10565,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10445(2,t2,lf[281]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10590,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2163 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[496]);}}

/* k10588 in k10563 in k10557 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_10571(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_not(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10571(t3,(C_truep(t2)?t2:(C_word)C_i_nullp(((C_word*)t0)[2])));}}

/* k10569 in k10563 in k10557 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10445(2,t2,lf[564]);}
else{
/* compiler.scm: 2164 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441]);}}

/* k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10550,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(lf[564],t1);
if(C_truep(t5)){
/* compiler.scm: 2168 butlast */
t6=C_retrieve(lf[567]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[7]);}
else{
t6=t4;
f_10550(2,t6,((C_word*)t0)[7]);}}

/* k10548 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2165 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_10188(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10451,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[564]);
if(C_truep(t3)){
/* compiler.scm: 2173 debugging */
t4=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[508],lf[565],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[447]);
if(C_truep(t4)){
/* compiler.scm: 2174 debugging */
t5=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[508],lf[566],((C_word*)t0)[4],((C_word*)t0)[7]);}
else{
t5=t2;
f_10451(2,t5,C_SCHEME_UNDEFINED);}}}

/* k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 2176 bomb */
t4=C_retrieve(lf[408]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[563],((C_word*)t0)[8],((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[5]);}
else{
t4=t2;
f_10454(2,t4,C_SCHEME_UNDEFINED);}}

/* k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10476,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[20],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[17])[1]);
t5=(C_truep(((C_word*)t0)[9])?((C_word*)t0)[9]:(C_word)C_i_memq(((C_word*)t0)[8],C_retrieve(lf[63])));
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10492,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[13],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=t3,a[15]=((C_word*)t0)[8],a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* compiler.scm: 2188 get */
t7=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[8],lf[485]);}

/* k10490 in k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10492,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t4=((C_word*)t0)[11];
if(C_truep(t4)){
t5=t3;
f_10499(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10518,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2192 debugging */
t7=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,lf[508],lf[562],((C_word*)t0)[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t6=t3;
f_10499(t6,C_SCHEME_FALSE);}}}

/* k10516 in k10490 in k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10499(t2,C_SCHEME_TRUE);}

/* k10497 in k10490 in k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10499,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_10503(2,t3,((C_word*)t0)[3]);}
else{
/* compiler.scm: 2194 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[15],lf[479]);}}

/* k10501 in k10497 in k10490 in k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2178 make-lambda-literal */
t2=C_retrieve(lf[514]);
((C_proc17)C_retrieve_proc(t2))(17,t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10474 in k10452 in k10449 in k10446 in k10443 in a10437 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10476,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[12])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[11])+1,((C_word*)t0)[10]);
t5=C_mutate(((C_word *)((C_word*)t0)[9])+1,((C_word*)t0)[8]);
t6=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[398],lf[457],t9,C_SCHEME_END_OF_LIST));}

/* k10380 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10385,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10391,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=(C_word)C_eqp(lf[404],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t7=(C_word)C_i_car(t6);
t8=t3;
f_10391(t8,(C_word)C_i_memq(t7,((C_word*)t0)[2]));}
else{
t6=t3;
f_10391(t6,C_SCHEME_FALSE);}}

/* k10389 in k10380 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_10385(t4,lf[498]);}
else{
t2=((C_word*)t0)[3];
f_10385(t2,((C_word*)t0)[2]);}}

/* k10383 in k10380 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10385,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]));}

/* k10364 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10366,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[488],((C_word*)t0)[2],t2));}

/* k10337 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10339,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t1));}

/* k10320 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2122 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10316 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10318,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10311,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2123 mapwalk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_10955(t5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10309 in k10316 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10311,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10292 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2118 words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10288 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10290,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* k10264 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10266,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10244 in walk in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10246,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* walk-var in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10101(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10101,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10105,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2072 posq */
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k10103 in walk-var in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10105,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[560],t2,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2073 keyword? */
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10118 in k10103 in walk-var in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10120,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10130,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2073 literal */
t3=((C_word*)t0)[5];
f_10967(t3,t2,((C_word*)t0)[4]);}
else{
/* compiler.scm: 2074 walk-global */
t2=((C_word*)t0)[3];
f_10135(t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10128 in k10118 in k10103 in walk-var in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10130,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[561],t2,C_SCHEME_END_OF_LIST));}

/* walk-global in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10135,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10139(2,t5,t3);}
else{
t5=C_retrieve(lf[28]);
if(C_truep(t5)){
t6=t4;
f_10139(2,t6,t5);}
else{
t6=C_retrieve(lf[16]);
if(C_truep(t6)){
t7=t4;
f_10139(2,t7,t6);}
else{
t7=(C_word)C_i_memq(t2,C_retrieve(lf[17]));
if(C_truep(t7)){
t8=t4;
f_10139(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10180,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2081 get */
t9=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[2],t2,lf[442]);}}}}}

/* k10178 in walk-global in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10139(2,t2,t1);}
else{
/* compiler.scm: 2082 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[456]);}}

/* k10137 in walk-global in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10139,2,t0,t1);}
t2=(C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[31]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t3;
f_10145(t6,t5);}
else{
t4=t3;
f_10145(t4,C_SCHEME_UNDEFINED);}}

/* k10143 in k10137 in walk-global in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10145,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
/* compiler.scm: 2088 blockvar-literal */
t3=((C_word*)t0)[3];
f_11061(t3,t2,((C_word*)t0)[5]);}
else{
/* compiler.scm: 2089 literal */
t3=((C_word*)t0)[2];
f_10967(t3,t2,((C_word*)t0)[5]);}}

/* k10153 in k10143 in k10137 in walk-global in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10155,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[559],t2,C_SCHEME_END_OF_LIST));}

/* literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_10967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10967,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2273 immediate? */
t4=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k10972 in literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10974,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 2273 immediate-literal */
f_11093(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[5]))){
if(C_truep((C_word)C_i_inexactp(((C_word*)t0)[5]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11029,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2275 list-index */
t4=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_10980(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10980(2,t3,C_SCHEME_FALSE);}}}

/* a11028 in k10972 in literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11029,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_inexactp(t2))){
t3=((C_word*)t0)[2];
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10978 in k10972 in literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10980,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[5]))){
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10996,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* compiler.scm: 2281 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2283 posq */
t3=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k11004 in k10978 in k10972 in literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 2284 new-literal */
t2=((C_word*)t0)[3];
f_11047(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k10994 in k10978 in k10972 in literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10996,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_vector(&a,1,((C_word*)t0)[2]));}

/* blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_11061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11061,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11065,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 2292 list-index */
t5=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a11076 in blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11084,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2294 block-variable-literal? */
t4=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k11082 in a11076 in blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11084,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2295 block-variable-literal-name */
t3=C_retrieve(lf[556]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11089 in k11082 in a11076 in blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k11063 in blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11065,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11075,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2297 make-block-variable-literal */
t3=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k11073 in k11063 in blockvar-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2297 new-literal */
t2=((C_word*)t0)[3];
f_11047(t2,((C_word*)t0)[2],t1);}

/* new-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_11047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11047,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11055,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,t2);
/* compiler.scm: 2288 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k11053 in new-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* immediate-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_11093(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11093,NULL,2,t1,t2);}
t3=C_retrieve(lf[2]);
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[398],lf[126],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11106,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_11106(2,t6,(C_word)C_a_i_list(&a,2,lf[549],t2));}
else{
if(C_truep((C_word)C_booleanp(t2))){
t6=t5;
f_11106(2,t6,(C_word)C_a_i_list(&a,2,lf[550],t2));}
else{
if(C_truep((C_word)C_charp(t2))){
t6=t5;
f_11106(2,t6,(C_word)C_a_i_list(&a,2,lf[551],t2));}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t6=t5;
f_11106(2,t6,lf[552]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t6=t5;
f_11106(2,t6,lf[553]);}
else{
/* compiler.scm: 2308 bomb */
t6=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[554]);}}}}}}}

/* k11104 in immediate-literal in ##compiler#prepare-for-code-generation in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_11106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11106,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[548],t1,C_SCHEME_END_OF_LIST));}

/* lambda-literal-direct in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10089,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(15)));}

/* lambda-literal-direct-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10080,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(15),t3);}

/* lambda-literal-body in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10071,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(14)));}

/* lambda-literal-body-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10062,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(14),t3);}

/* lambda-literal-rest-argument-mode in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10053,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(13)));}

/* lambda-literal-rest-argument-mode-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10044,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(13),t3);}

/* lambda-literal-customizable in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10035,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(12)));}

/* lambda-literal-customizable-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10026,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(12),t3);}

/* lambda-literal-looping in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10017,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(11)));}

/* lambda-literal-looping-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_10008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10008,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(11),t3);}

/* lambda-literal-closure-size in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9999,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(10)));}

/* lambda-literal-closure-size-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9990,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(10),t3);}

/* lambda-literal-directly-called in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9981,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(9)));}

/* lambda-literal-directly-called-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9972,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(9),t3);}

/* lambda-literal-allocated in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9963,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* lambda-literal-allocated-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9954,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* lambda-literal-callee-signatures in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9945,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* lambda-literal-callee-signatures-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9936,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* lambda-literal-temporaries in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9927,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* lambda-literal-temporaries-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9918,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* lambda-literal-rest-argument in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9909,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* lambda-literal-rest-argument-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9900,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* lambda-literal-argument-count in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9891,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* lambda-literal-argument-count-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9882,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* lambda-literal-arguments in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9873,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* lambda-literal-arguments-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9864,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* lambda-literal-external in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9855,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* lambda-literal-external-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9846,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* lambda-literal-id in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9837,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[515]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* lambda-literal-id-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9828,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[515]);
/* compiler.scm: 2042 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* lambda-literal? in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9822,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[515]));}

/* make-lambda-literal in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13,C_word t14,C_word t15,C_word t16){
C_word tmp;
C_word t17;
C_word ab[17],*a=ab;
if(c!=17) C_bad_argc_2(c,17,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr17,(void*)f_9816,17,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);}
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_record(&a,16,lf[515],t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16));}

/* ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[47],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8582,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8585,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8591,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8601,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8612,a[2]=t3,a[3]=t8,a[4]=t10,a[5]=t9,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9647,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8946,a[2]=t3,a[3]=t16,a[4]=t18,a[5]=t14,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9635,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9783,a[2]=t12,a[3]=t7,a[4]=t2,a[5]=t16,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 2030 debugging */
t22=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[474],lf[513]);}

/* k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 2031 gather */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8612(t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);}

/* k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2032 debugging */
t3=C_retrieve(lf[473]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[508],lf[512],((C_word*)((C_word*)t0)[2])[1]);}

/* k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 2033 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[511]);}

/* k9790 in k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9795,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2034 transform */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8946(t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k9793 in k9790 in k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9798,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_9798(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9808,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9810,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 2036 ##sys#make-promise */
t6=*((C_word*)lf[510]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* a9809 in k9793 in k9790 in k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9810,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_length(C_retrieve(lf[63])));}

/* k9806 in k9793 in k9790 in k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 2036 debugging */
t2=C_retrieve(lf[473]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[508],lf[509],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k9796 in k9793 in k9790 in k9787 in k9784 in k9781 in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* maptransform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9635,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9641,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a9640 in maptransform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9641,3,t0,t1,t2);}
/* compiler.scm: 2002 transform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8946(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8946(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8946,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t8,a[11]=t10,a[12]=t2,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8965(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t13)){
t14=t12;
f_8965(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[457]);
t15=t12;
f_8965(t15,(C_truep(t14)?t14:(C_word)C_eqp(t10,lf[410])));}}}

/* k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8965,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[404]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8977,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1877 ref-var */
f_9647(t4,((C_word*)t0)[12],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[114]);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t3)){
t5=t4;
f_8998(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[400]);
if(C_truep(t5)){
t6=t4;
f_8998(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t6)){
t7=t4;
f_8998(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t7)){
t8=t4;
f_8998(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[273]);
if(C_truep(t8)){
t9=t4;
f_8998(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[104]);
if(C_truep(t9)){
t10=t4;
f_8998(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t10)){
t11=t4;
f_8998(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[504]);
if(C_truep(t11)){
t12=t4;
f_8998(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[505]);
if(C_truep(t12)){
t13=t4;
f_8998(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[506]);
if(C_truep(t13)){
t14=t4;
f_8998(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[437]);
if(C_truep(t14)){
t15=t4;
f_8998(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[507]);
if(C_truep(t15)){
t16=t4;
f_8998(t16,t15);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[11],lf[108]);
t17=t4;
f_8998(t17,(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[11],lf[180])));}}}}}}}}}}}}}}}

/* k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1885 maptransform */
t5=((C_word*)((C_word*)t0)[10])[1];
f_9635(t5,t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1889 test */
t5=((C_word*)t0)[4];
f_8585(t5,t4,t3,lf[469]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[399]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[6],lf[444]));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9094,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1905 decompose-lambda-list */
t7=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[12],t5,t6);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_i_car(((C_word*)t0)[9]);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9365,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(lf[103],t8);
if(C_truep(t10)){
t11=(C_word)C_slot(t7,C_fix(2));
t12=(C_word)C_i_car(t11);
/* compiler.scm: 1965 immediate? */
t13=C_retrieve(lf[502]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t9,t12);}
else{
t11=t9;
f_9365(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t6)){
t7=(C_truep(C_retrieve(lf[42]))?C_fix(2):C_fix(1));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(C_word)C_a_i_list(&a,2,t9,C_SCHEME_TRUE);
t11=(C_word)C_a_i_record(&a,4,lf[398],lf[457],t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9514,a[2]=t8,a[3]=((C_word*)t0)[12],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[42]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9521,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9525,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(C_word)C_i_car(((C_word*)t0)[11]);
/* compiler.scm: 1996 ##sys#make-lambda-info */
t16=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t14,t15);}
else{
t13=t12;
f_9514(t13,C_SCHEME_END_OF_LIST);}}
else{
/* compiler.scm: 1999 bomb */
t7=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[12],lf[503]);}}}}}}

/* k9523 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1996 qnode */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9519 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9521,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9514(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9512 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9514,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t2));}

/* k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9365,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_eqp(lf[126],((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1967 posq */
t4=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9371,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9380,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1969 test */
t3=((C_word*)t0)[3];
f_8585(t3,t2,((C_word*)t0)[2],lf[469]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1981 test */
t3=((C_word*)t0)[3];
f_8585(t3,t2,((C_word*)t0)[2],lf[469]);}}

/* k9439 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9441,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1985 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9471,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1989 transform */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8946(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k9469 in k9439 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9471,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[175],((C_word*)t0)[2],t2));}

/* k9452 in k9439 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9458,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1986 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8946(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9456 in k9452 in k9439 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9458,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* k9378 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9380,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[8])?lf[498]:lf[499]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1973 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_truep(((C_word*)t0)[8])?lf[500]:lf[501]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1979 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k9425 in k9378 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9431,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1980 transform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8946(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9429 in k9425 in k9378 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9431,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k9405 in k9378 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9407,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[486],((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9403,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1974 transform */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8946(t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9401 in k9405 in k9378 in k9369 in k9363 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9403,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t2));}

/* a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9094,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t1,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],tmp=(C_word)a,a+=16,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1908 filter */
t7=C_retrieve(lf[497]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t2);}

/* a9342 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9343,3,t0,t1,t2);}
/* compiler.scm: 1908 test */
t3=((C_word*)t0)[2];
f_8585(t3,t1,t2,lf[469]);}

/* k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9341,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[123]),t1);}

/* k9339 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1909 map */
t2=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_9104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* compiler.scm: 1910 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[124]);}

/* k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9104,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_car(((C_word*)t0)[16]):lf[483]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,a[18]=t1,a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* compiler.scm: 1912 test */
t4=((C_word*)t0)[2];
f_8585(t4,t3,t2,lf[484]);}

/* k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* compiler.scm: 1913 test */
t4=((C_word*)t0)[2];
f_8585(t4,t3,((C_word*)t0)[17],lf[485]);}

/* k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9116,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=t2,tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[42]))){
t4=(C_word)C_i_cadr(((C_word*)t0)[20]);
t5=t3;
f_9122(t5,(C_truep(t4)?(C_word)C_i_pairp(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t4=t3;
f_9122(t4,C_SCHEME_FALSE);}}

/* k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9122,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=t1,tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1919 test */
t4=((C_word*)t0)[2];
f_8585(t4,t3,((C_word*)t0)[6],lf[469]);}
else{
t3=t2;
f_9125(2,t3,C_SCHEME_FALSE);}}

/* k9306 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9308,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1920 test */
t3=((C_word*)t0)[2];
f_8585(t3,t2,((C_word*)t0)[6],lf[441]);}
else{
t2=((C_word*)t0)[4];
f_9125(2,t2,C_SCHEME_FALSE);}}

/* k9309 in k9306 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t2);
/* compiler.scm: 1921 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3,lf[496],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_9125(2,t2,C_SCHEME_FALSE);}}

/* k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[20])?C_fix(2):C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[19],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_9265,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[20],a[12]=t4,a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t5,a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9269,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9284,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a9283 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9284,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9267 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdr(t2):((C_word*)t0)[5]);
/* compiler.scm: 1931 build-lambda-list */
t4=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t3);}

/* k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],t1);
t3=(C_word)C_i_cadddr(((C_word*)t0)[17]);
t4=(C_word)C_a_i_list(&a,4,((C_word*)t0)[16],((C_word*)t0)[15],t2,t3);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* compiler.scm: 1940 transform */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8946(t7,t5,t6,((C_word*)t0)[18],((C_word*)t0)[6]);}

/* k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9202,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9210,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9224,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1945 unzip1 */
t5=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_9202(2,t3,t1);}}

/* k9222 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9228,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9230,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9229 in k9222 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9241,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(t2);
/* compiler.scm: 1946 varnode */
t5=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k9239 in a9229 in k9222 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9241,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[488],C_SCHEME_END_OF_LIST,t2));}

/* k9226 in k9222 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1942 fold-right */
t2=C_retrieve(lf[495]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9209 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9210,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[398],lf[152],t5,t6));}

/* k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[12],((C_word*)t0)[11],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9148,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9186 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9187,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1949 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9193 in a9186 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1949 ref-var */
f_9647(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9162,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9170,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9178,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1957 real-name */
t7=C_retrieve(lf[494]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=t2;
f_9151(2,t3,t1);}}

/* k9176 in k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9178,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[492]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* compiler.scm: 1957 ->string */
t5=C_retrieve(lf[493]);
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k9168 in k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1956 ##sys#make-lambda-info */
t2=C_retrieve(lf[491]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9164 in k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1955 qnode */
t2=C_retrieve(lf[490]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9160 in k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 1952 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9149 in k9146 in k9200 in k9197 in k9263 in k9123 in k9120 in k9114 in k9108 in k9102 in k9099 in k9096 in a9093 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9151,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[489],((C_word*)t0)[2],t2));}

/* k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1890 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k9020 in k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9022,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9038,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1894 transform */
t5=((C_word*)((C_word*)t0)[6])[1];
f_8946(t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1901 maptransform */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9635(t3,t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k9072 in k9020 in k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t1));}

/* k9036 in k9020 in k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1897 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k9065 in k9036 in k9020 in k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9067,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[488],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9059,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 1898 transform */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8946(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9057 in k9065 in k9036 in k9020 in k9017 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t4));}

/* k9002 in k8996 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9004,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k8975 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1878 test */
t3=((C_word*)t0)[3];
f_8585(t3,t2,((C_word*)t0)[2],lf[469]);}

/* k8981 in k8975 in k8963 in transform in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[487],C_SCHEME_END_OF_LIST,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ref-var in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9647(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9647,NULL,4,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9654,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 2006 posq */
t9=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t7,t4);}

/* k9652 in ref-var in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9654,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9670,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2009 varnode */
t5=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9668 in k9652 in ref-var in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9670,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[486],((C_word*)t0)[2],t2));}

/* gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8612(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8612,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[103]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t6,a[11]=t8,a[12]=t10,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_8631(t13,t11);}
else{
t13=(C_word)C_eqp(t10,lf[404]);
if(C_truep(t13)){
t14=t12;
f_8631(t14,t13);}
else{
t14=(C_word)C_eqp(t10,lf[126]);
if(C_truep(t14)){
t15=t12;
f_8631(t15,t14);}
else{
t15=(C_word)C_eqp(t10,lf[457]);
if(C_truep(t15)){
t16=t12;
f_8631(t16,t15);}
else{
t16=(C_word)C_eqp(t10,lf[274]);
t17=t12;
f_8631(t17,(C_truep(t16)?t16:(C_word)C_eqp(t10,lf[410])));}}}}}

/* k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[12],lf[152]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8642,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8652,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1814 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[400]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_cdr(((C_word*)t0)[11]);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_i_cadr(((C_word*)t0)[11]):C_SCHEME_FALSE);
t9=(C_word)C_slot(t4,C_fix(1));
t10=(C_word)C_eqp(lf[404],t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8694,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[6],a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t13=(C_truep(t8)?t8:t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8721,a[2]=t8,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t15=(C_word)C_slot(t4,C_fix(2));
t16=(C_word)C_i_car(t15);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t16,a[7]=((C_word*)t0)[5],a[8]=t14,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8835,a[2]=t16,a[3]=((C_word*)t0)[3],a[4]=t17,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1830 test */
t19=((C_word*)t0)[3];
f_8585(t19,t18,t16,lf[430]);}
else{
t15=t14;
f_8721(t15,C_SCHEME_END_OF_LIST);}}
else{
t14=t12;
f_8711(t14,C_SCHEME_END_OF_LIST);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[399]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[12],lf[444]));
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[11]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1854 decompose-lambda-list */
t8=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[13],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[13],t6,((C_word*)t0)[10]);}}}}}

/* a8909 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8910,3,t0,t1,t2);}
/* compiler.scm: 1864 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8612(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8871,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_i_car(((C_word*)t0)[6]):lf[483]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=((C_word*)t0)[4];
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9686,a[2]=t12,a[3]=t9,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9686(3,t14,t10,t6);}

/* walk in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9686,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[404]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t10,((C_word*)t0)[4]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9715,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2021 lset-adjoin */
t12=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[103]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9724(t12,t10);}
else{
t12=(C_word)C_eqp(t8,lf[126]);
if(C_truep(t12)){
t13=t11;
f_9724(t13,t12);}
else{
t13=(C_word)C_eqp(t8,lf[274]);
if(C_truep(t13)){
t14=t11;
f_9724(t14,t13);}
else{
t14=(C_word)C_eqp(t8,lf[457]);
if(C_truep(t14)){
t15=t11;
f_9724(t15,t14);}
else{
t15=(C_word)C_eqp(t8,lf[104]);
t16=t11;
f_9724(t16,(C_truep(t15)?t15:(C_word)C_eqp(t8,lf[410])));}}}}}}

/* k9722 in walk in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9724,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9736,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9750,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 2025 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[2])[1],t3);}
else{
t5=t4;
f_9736(t5,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}}

/* k9748 in k9722 in walk in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9736(t3,t2);}

/* k9734 in k9722 in walk in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_9736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* compiler.scm: 2026 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9686(3,t3,((C_word*)t0)[2],t2);}

/* k9713 in walk in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9682 in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9684,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8884,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1860 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[485],t3);}

/* k8882 in k9682 in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1861 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6],lf[484],((C_word*)t0)[2]);}

/* k8885 in k8882 in k9682 in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8887,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8898,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1862 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8896 in k8885 in k8882 in k9682 in a8870 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1862 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8612(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8833 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8727(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1830 test */
t2=((C_word*)t0)[3];
f_8585(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[431]);}}

/* k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=t2;
f_8733(t4,(C_word)C_eqp(lf[399],t3));}
else{
t3=t2;
f_8733(t3,C_SCHEME_FALSE);}}

/* k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8733,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1835 test */
t6=((C_word*)t0)[2];
f_8585(t6,t5,((C_word*)t0)[6],lf[427]);}
else{
t2=((C_word*)t0)[8];
f_8721(t2,C_SCHEME_END_OF_LIST);}}

/* k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8748,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1836 test */
t3=((C_word*)t0)[2];
f_8585(t3,t2,((C_word*)t0)[7],lf[443]);}

/* k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
t6=t2;
f_8751(t6,(C_truep(t5)?(C_word)C_i_listp(((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_8751(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_8751(t3,C_SCHEME_FALSE);}}

/* k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8751,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8769,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t1)){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(t4,t6);
t8=t3;
f_8769(t8,(C_word)C_i_not(t7));}
else{
t4=t3;
f_8769(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8769(t4,C_SCHEME_FALSE);}}

/* k8767 in k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8769,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8776,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1844 source-info->string */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8754(2,t2,C_SCHEME_UNDEFINED);}}

/* k8774 in k8767 in k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1842 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[481],t1);}

/* k8752 in k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1845 register-direct-call! */
t3=((C_word*)t0)[2];
f_8601(t3,t2,((C_word*)t0)[6]);}

/* k8755 in k8752 in k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* compiler.scm: 1846 register-customizable! */
t3=((C_word*)t0)[3];
f_8591(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=t2;
f_8760(2,t3,C_SCHEME_UNDEFINED);}}

/* k8758 in k8755 in k8752 in k8749 in k8746 in k8743 in k8731 in k8725 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
t2=((C_word*)t0)[4];
f_8721(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k8719 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8721,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8711(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8709 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8711,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 1823 node-parameters-set! */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8692 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8698 in k8692 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8699,3,t0,t1,t2);}
/* compiler.scm: 1851 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8612(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8651 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8652,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a8668 in a8651 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8669,3,t0,t1,t2);}
/* compiler.scm: 1815 gather */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8612(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8654 in a8651 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8656,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1816 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8665 in k8654 in a8651 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1816 gather */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8612(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8641 in k8629 in gather in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8642,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
/* compiler.scm: 1814 split-at */
t3=C_retrieve(lf[248]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* register-direct-call! in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8601,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8610,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1801 lset-adjoin */
t6=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[97]+1),C_retrieve(lf[63]),t2);}

/* k8608 in register-direct-call! in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* register-customizable! in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8591,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8596,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1796 lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),((C_word*)((C_word*)t0)[3])[1],t2);}

/* k8594 in register-customizable! in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* compiler.scm: 1797 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[479],C_SCHEME_TRUE);}

/* test in ##compiler#perform-closure-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8585,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1793 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1414 make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(3001),C_SCHEME_END_OF_LIST);}

/* k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7063,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7766,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7663,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7070,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7651,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7772,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7786,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t13,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1584 initialize-analysis-database */
t18=C_retrieve(lf[477]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,t1);}

/* k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1587 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[476]);}

/* k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7814,2,t0,t1);}
t2=C_set_block_item(lf[52],0,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1589 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7070(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1592 debugging */
t3=C_retrieve(lf[473]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[474],lf[475]);}

/* k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1593 ##sys#hash-table-for-each */
t4=C_retrieve(lf[472]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[65],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7834,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_fix(0);
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_fix(0);
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_fix(0);
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_7838,a[2]=t9,a[3]=t19,a[4]=t13,a[5]=t31,a[6]=((C_word*)t0)[2],a[7]=t21,a[8]=t11,a[9]=t23,a[10]=t3,a[11]=((C_word*)t0)[3],a[12]=t25,a[13]=t29,a[14]=t17,a[15]=t27,a[16]=t2,a[17]=((C_word*)t0)[4],a[18]=t1,a[19]=t7,a[20]=t5,tmp=(C_word)a,a+=21,tmp);
t33=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8469,a[2]=t27,a[3]=t25,a[4]=t7,a[5]=t23,a[6]=t21,a[7]=t19,a[8]=t17,a[9]=t31,a[10]=t15,a[11]=t9,a[12]=t13,a[13]=t29,a[14]=t11,a[15]=t5,tmp=(C_word)a,a+=16,tmp);
/* for-each */
t34=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,t3);}

/* a8468 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8469,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[430]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_TRUE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,lf[427]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=C_mutate(((C_word *)((C_word*)t0)[14])+1,t6);
t8=(C_word)C_i_length(((C_word*)((C_word*)t0)[14])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t6=(C_word)C_eqp(t3,lf[435]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[452]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=C_mutate(((C_word *)((C_word*)t0)[11])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=(C_word)C_eqp(t3,lf[443]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=C_mutate(((C_word *)((C_word*)t0)[10])+1,t9);
t11=(C_word)C_i_length(((C_word*)((C_word*)t0)[10])[1]);
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=(C_word)C_eqp(t3,lf[450]);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=(C_word)C_eqp(t3,lf[451]);
if(C_truep(t10)){
t11=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t3,lf[429]);
if(C_truep(t11)){
t12=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_eqp(t3,lf[436]);
if(C_truep(t12)){
t13=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t3,lf[431]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t2);
t15=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t14=(C_word)C_eqp(t3,lf[440]);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t2);
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t15=(C_word)C_eqp(t3,lf[441]);
if(C_truep(t15)){
t16=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}

/* k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[19])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[19])+1,t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8434,a[2]=((C_word*)t0)[16],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[64]))){
t7=((C_word*)((C_word*)t0)[19])[1];
t8=(C_truep(t7)?t7:(C_truep(((C_word*)((C_word*)t0)[9])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));
t9=(C_truep(t8)?(C_word)C_slot(t8,C_fix(1)):C_SCHEME_FALSE);
t10=t6;
f_8434(t10,(C_word)C_eqp(lf[399],t9));}
else{
t7=t6;
f_8434(t7,C_SCHEME_FALSE);}}

/* k8432 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
/* compiler.scm: 1639 set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7845(2,t2,C_SCHEME_UNDEFINED);}}

/* k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[7])[1]))){
t4=(C_word)C_i_memq(((C_word*)t0)[16],C_retrieve(lf[90]));
t5=t3;
f_8380(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_8380(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8380(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8380(t4,C_SCHEME_FALSE);}}

/* k8378 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* compiler.scm: 1648 compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[185],lf[471],((C_word*)t0)[3]);}
else{
t3=t2;
f_8383(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7848(2,t2,C_SCHEME_UNDEFINED);}}

/* k8381 in k8378 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve(lf[21]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8395,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_8395(t5,t3);}
else{
if(C_truep(C_retrieve(lf[33]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t6=t4;
f_8395(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8395(t5,C_SCHEME_FALSE);}}}

/* k8393 in k8381 in k8378 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[60]));
t3=((C_word*)t0)[2];
f_8389(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_8389(t2,C_SCHEME_FALSE);}}

/* k8387 in k8381 in k8378 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1652 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[185],lf[470],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7848(2,t2,C_SCHEME_UNDEFINED);}}

/* k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[13])[1])?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* compiler.scm: 1656 quick-put! */
f_7772(t2,((C_word*)t0)[8],lf[469],C_SCHEME_TRUE);}
else{
t4=t2;
f_7851(2,t4,C_SCHEME_UNDEFINED);}}

/* k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[399],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t4);
t10=(C_word)C_i_not(t9);
if(C_truep(t10)){
t11=t5;
f_8323(2,t11,t10);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8355,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8363,a[2]=t11,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1665 scan-free-variables */
t13=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)((C_word*)t0)[9])[1]);}}
else{
t9=t5;
f_8323(2,t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7854(2,t3,C_SCHEME_UNDEFINED);}}

/* k8361 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1665 every */
t2=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8354 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8355,3,t0,t1,t2);}
/* compiler.scm: 1665 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,((C_word*)t0)[2],t2,lf[436]);}

/* k8321 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8323,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_8329(t6,(C_word)C_eqp(C_fix(1),t5));}
else{
t5=t2;
f_8329(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_7854(2,t2,C_SCHEME_UNDEFINED);}}

/* k8327 in k8321 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1667 quick-put! */
f_7772(((C_word*)t0)[3],((C_word*)t0)[2],lf[466],C_SCHEME_TRUE);}
else{
/* compiler.scm: 1668 quick-put! */
f_7772(((C_word*)t0)[3],((C_word*)t0)[2],lf[467],C_SCHEME_TRUE);}}

/* k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8285,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t4=((C_word*)((C_word*)t0)[9])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_8285(t6,(C_word)C_eqp(lf[103],t5));}
else{
t4=t3;
f_8285(t4,C_SCHEME_FALSE);}}

/* k8283 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8285,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1676 collapsable-literal? */
t6=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t2=((C_word*)t0)[4];
f_7857(2,t2,C_SCHEME_UNDEFINED);}}

/* k8292 in k8283 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_8297(t3,t1);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t2;
f_8297(t4,(C_word)C_eqp(C_fix(1),t3));}}

/* k8295 in k8292 in k8283 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1678 quick-put! */
f_7772(((C_word*)t0)[3],((C_word*)t0)[2],lf[465],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7857(2,t2,C_SCHEME_UNDEFINED);}}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8186,a[2]=t2,a[3]=((C_word*)t0)[14],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[9])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[399],t7);
if(C_truep(t8)){
t9=((C_word*)((C_word*)t0)[11])[1];
t10=((C_word*)((C_word*)t0)[2])[1];
t11=t5;
f_8186(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t5;
f_8186(t9,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7860(2,t3,C_SCHEME_UNDEFINED);}}

/* k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8186,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[7])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1692 decompose-lambda-list */
t6=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
t4=((C_word*)t0)[2];
f_7860(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_7860(2,t2,C_SCHEME_UNDEFINED);}}

/* a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8204,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_8208(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a8246 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8254,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8272,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1698 get */
t5=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t2,lf[427]);}

/* k8270 in a8246 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8272,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8254(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8268,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1699 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}}

/* k8266 in k8270 in a8246 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8254(t2,(C_word)C_i_not(t1));}

/* k8252 in a8246 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8254,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1700 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[337],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8255 in k8252 in a8246 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* k8206 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[80]));
t4=t2;
f_8214(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_8214(t3,C_SCHEME_FALSE);}}

/* k8212 in k8206 in a8203 in k8184 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8214,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1706 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,lf[463],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1709 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,((C_word*)t0)[5],((C_word*)t0)[4],t4,lf[464],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8123,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[10])[1];
if(C_truep(t4)){
t5=t3;
f_8123(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t6=((C_word*)((C_word*)t0)[7])[1];
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[404],t7);
t9=(C_word)C_i_not(t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8150,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[7],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_8150(t11,t9);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8164,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)((C_word*)t0)[7])[1];
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
/* compiler.scm: 1717 get */
t15=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t11,((C_word*)t0)[13],t14,lf[436]);}}
else{
t6=t5;
f_8138(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8123(t5,C_SCHEME_FALSE);}}}

/* k8162 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8150(t2,(C_word)C_i_not(t1));}

/* k8148 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8150,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1718 expression-has-side-effects? */
t3=C_retrieve(lf[462]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8138(t2,C_SCHEME_FALSE);}}

/* k8155 in k8148 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8138(t2,(C_word)C_i_not(t1));}

/* k8136 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8123(t2,(C_truep(t1)?t1:((C_word*)((C_word*)t0)[2])[1]));}

/* k8121 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8123(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1720 quick-put! */
f_7772(((C_word*)t0)[3],((C_word*)t0)[2],lf[461],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7863(2,t2,C_SCHEME_UNDEFINED);}}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_eqp(lf[404],t5);
if(C_truep(t6)){
t7=((C_word*)((C_word*)t0)[5])[1];
t8=(C_word)C_slot(t7,C_fix(2));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8035,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[11],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1732 get */
t11=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,((C_word*)t0)[11],t9,lf[427]);}
else{
t7=t2;
f_7866(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_7866(2,t4,C_SCHEME_UNDEFINED);}}

/* k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8109,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1733 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[5],lf[430]);}

/* k8107 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8041(2,t2,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1733 get */
t2=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[431]);}}

/* k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_8044(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1734 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[6],lf[435]);}}

/* k8097 in k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8099,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8044(t2,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=((C_word*)t0)[6];
f_8044(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1738 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[450]);}}
else{
t4=((C_word*)t0)[6];
f_8044(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_8044(t2,C_SCHEME_FALSE);}}}

/* k8089 in k8097 in k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8091,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8044(t2,C_SCHEME_FALSE);}
else{
t2=C_retrieve(lf[21]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_8044(t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1739 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[436]);}}}

/* k8085 in k8089 in k8097 in k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8044(t2,(C_word)C_i_not(t1));}

/* k8042 in k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_8044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8044,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1740 quick-put! */
f_7772(t2,((C_word*)t0)[2],lf[460],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[6];
f_7866(2,t2,C_SCHEME_UNDEFINED);}}

/* k8045 in k8042 in k8039 in k8033 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_8047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1741 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_7894(t6,(C_word)C_eqp(lf[399],t5));}
else{
t4=t3;
f_7894(t4,C_SCHEME_FALSE);}}

/* k7892 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7894,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_cadr(t3))){
t4=((C_word*)t0)[5];
f_7869(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_caddr(t3);
t5=((C_word*)((C_word*)t0)[6])[1];
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7915,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
t10=(C_word)C_slot(t7,C_fix(1));
t11=t8;
f_7915(t11,(C_word)C_eqp(lf[400],t10));}
else{
t10=t8;
f_7915(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_7915(t9,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[5];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k7913 in k7892 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7915,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(2),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_slot(t5,C_fix(1));
t9=(C_word)C_eqp(lf[404],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t6,C_fix(1));
t11=(C_word)C_eqp(lf[404],t10);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=(C_word)C_slot(t6,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=t7;
f_7936(t15,(C_word)C_eqp(t12,t14));}
else{
t12=t7;
f_7936(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_7936(t10,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[6];
f_7869(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[6];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k7934 in k7913 in k7892 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7942,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1761 quick-put! */
f_7772(t4,((C_word*)t0)[2],lf[460],t3);}
else{
t2=((C_word*)t0)[5];
f_7869(2,t2,C_SCHEME_UNDEFINED);}}

/* k7940 in k7934 in k7913 in k7892 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1762 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[459],C_SCHEME_TRUE);}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t3)){
t4=t2;
f_7875(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
t5=((C_word*)((C_word*)t0)[2])[1];
t6=t2;
f_7875(t6,(C_word)C_eqp(t4,t5));}}
else{
t3=t2;
f_7875(t3,C_SCHEME_FALSE);}}

/* k7873 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7875,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1772 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7877 in k7873 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7836 in a7833 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[55]+1,t1);
/* compiler.scm: 1773 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[441],lf[447]);}

/* k7822 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1779 lset-difference */
t3=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[55]),((C_word*)((C_word*)t0)[2])[1]);}

/* k7826 in k7822 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[51]))){
t4=t3;
f_7831(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[51]+1,C_retrieve(lf[52]));
t5=t3;
f_7831(t5,t4);}}

/* k7829 in k7826 in k7822 in k7819 in k7816 in k7812 in k7809 in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* contains? in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7786,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7796,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1579 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,lf[449]);}}

/* k7794 in contains? in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1581 any */
t3=C_retrieve(lf[458]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7803 in k7794 in contains? in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7804,3,t0,t1,t2);}
/* compiler.scm: 1581 contains? */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7786(t3,t1,t2,((C_word*)t0)[2]);}

/* quick-put! in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7772(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7772,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7780,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler.scm: 1574 alist-cons */
t7=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t3,t4,t6);}

/* k7778 in quick-put! in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* walkeach in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7651,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7657,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t2);}

/* a7656 in walkeach in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7657,3,t0,t1,t2);}
/* compiler.scm: 1548 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7070(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7070(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7070,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=f_7063(C_fix(1));
t13=(C_word)C_eqp(t11,lf[103]);
t14=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t4,a[13]=t9,a[14]=t11,a[15]=t1,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t13)){
t15=t14;
f_7092(t15,t13);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
t16=t14;
f_7092(t16,(C_truep(t15)?t15:(C_word)C_eqp(t11,lf[457])));}}

/* k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[97],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7092,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[404]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[12],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1430 ref */
t5=((C_word*)t0)[8];
f_7766(t5,t4,t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[410]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7147,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1438 ref */
t6=((C_word*)t0)[8];
f_7766(t6,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[273]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[14],lf[437]));
if(C_truep(t5)){
t6=f_7063(C_fix(1));
/* compiler.scm: 1444 walkeach */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7651(t7,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[400]);
if(C_truep(t6)){
t7=f_7063(C_fix(1));
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_slot(t8,C_fix(1));
t11=(C_word)C_eqp(lf[404],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t8,C_fix(2));
t13=(C_word)C_i_car(t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7206,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[7]);
/* compiler.scm: 1451 collect! */
t16=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t16))(6,t16,t14,((C_word*)t0)[9],t13,lf[443],t15);}
else{
t12=t9;
f_7183(2,t12,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[152]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1465 append */
t9=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[159]);
if(C_truep(t8)){
t9=f_7063(C_fix(1));
t10=(C_word)C_i_car(((C_word*)t0)[13]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7345,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1478 decompose-lambda-list */
t12=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[15],t10,t11);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[399]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[14],lf[444]));
if(C_truep(t10)){
t11=f_7063(C_fix(1));
t12=(C_word)C_i_caddr(((C_word*)t0)[13]);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7389,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1491 decompose-lambda-list */
t14=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[15],t12,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[13]);
t13=(C_word)C_i_car(((C_word*)t0)[5]);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7499,a[2]=((C_word*)t0)[11],a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t12,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[5],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[64]))){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7574,a[2]=t13,a[3]=t12,a[4]=((C_word*)t0)[9],a[5]=t14,tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7580,a[2]=((C_word*)t0)[9],a[3]=t12,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1522 get */
t17=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,((C_word*)t0)[9],t12,lf[442]);}
else{
t15=t14;
f_7499(2,t15,C_SCHEME_UNDEFINED);}}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[274]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[14],lf[194]));
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[13]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[4],a[3]=t14,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_i_symbolp(t14))){
/* compiler.scm: 1541 ##sys#hash-table-ref */
t17=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t16,C_retrieve(lf[76]),t14);}
else{
t17=t16;
f_7613(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7613(2,t17,C_SCHEME_FALSE);}}
else{
t17=t16;
f_7613(2,t17,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 1545 walkeach */
t14=((C_word*)((C_word*)t0)[6])[1];
f_7651(t14,((C_word*)t0)[15],((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[4]);}}}}}}}}}}}

/* k7611 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1542 set-real-name! */
t2=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7607(2,t2,C_SCHEME_UNDEFINED);}}

/* k7605 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1543 walkeach */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7651(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7578 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1523 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[453],lf[454],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1524 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[456]);}}

/* k7587 in k7578 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1525 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[453],lf[455],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7574(2,t2,C_SCHEME_UNDEFINED);}}

/* k7572 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1526 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[452],((C_word*)t0)[2]);}

/* k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[8]))){
t4=t3;
f_7528(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[9]);
t5=t3;
f_7528(t5,(C_word)C_i_not(t4));}}

/* k7526 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7528,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_7063(C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
t4=C_retrieve(lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7543(t6,t4);}
else{
if(C_truep(C_retrieve(lf[33]))){
t6=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[33]));
t7=t5;
f_7543(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_7543(t6,C_SCHEME_FALSE);}}}
else{
t4=t3;
f_7534(t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_7502(2,t2,C_SCHEME_UNDEFINED);}}

/* k7541 in k7526 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1532 lset-adjoin */
t3=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7534(t2,C_SCHEME_UNDEFINED);}}

/* k7545 in k7541 in k7526 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_7534(t3,t2);}

/* k7532 in k7526 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1533 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}

/* k7500 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7525,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1534 append */
t4=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k7523 in k7500 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1534 assign */
t2=((C_word*)t0)[6];
f_7663(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7503 in k7500 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve(lf[81]))){
t3=t2;
f_7508(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1535 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[451],C_SCHEME_TRUE);}}

/* k7506 in k7503 in k7500 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1536 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[450],C_SCHEME_TRUE);}

/* k7509 in k7506 in k7503 in k7500 in k7497 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
/* compiler.scm: 1537 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7070(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7389,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[9]);
t6=C_retrieve(lf[52]);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t6,a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7481,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1497 collect! */
t9=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,((C_word*)t0)[3],((C_word*)t0)[2],lf[449],t5);}
else{
t8=t7;
f_7396(2,t8,C_SCHEME_UNDEFINED);}}

/* k7479 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1498 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[448],((C_word*)t0)[2]);}

/* k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[9]);}

/* a7470 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7475,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1501 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[3],t2,lf[433],((C_word*)t0)[2]);}

/* k7473 in a7470 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1502 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[430],C_SCHEME_TRUE);}

/* k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[55]));
t4=(C_truep(t3)?lf[447]:lf[281]);
/* compiler.scm: 1505 put! */
t5=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[441],t4);}
else{
t3=t2;
f_7402(2,t3,C_SCHEME_UNDEFINED);}}

/* k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7456,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1509 simple-lambda-node? */
t4=C_retrieve(lf[446]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}

/* k7454 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1509 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[445],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
f_7405(2,t2,C_SCHEME_UNDEFINED);}}

/* k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[82]))){
t4=t3;
f_7408(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_mutate((C_word*)lf[82]+1,((C_word*)t0)[5]);
t5=t3;
f_7408(t5,t4);}}

/* k7406 in k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[2]))){
t4=(C_word)C_eqp(C_retrieve(lf[82]),((C_word*)t0)[5]);
t5=t3;
f_7441(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_7441(t4,C_SCHEME_FALSE);}}

/* k7439 in k7406 in k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_7411(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_7411(t2,C_SCHEME_UNDEFINED);}}

/* k7409 in k7406 in k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7411,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7438,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1514 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7436 in k7409 in k7406 in k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1514 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7070(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7412 in k7409 in k7406 in k7403 in k7400 in k7397 in k7394 in a7388 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_cdddr(t4);
t6=(C_word)C_fixnum_difference(C_retrieve(lf[52]),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_car(t5,t6));}

/* a7344 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7345,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7363 in a7344 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7364,3,t0,t1,t2);}
/* compiler.scm: 1482 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t1,((C_word*)t0)[2],t2,lf[430],C_SCHEME_TRUE);}

/* k7347 in a7344 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7349,2,t0,t1);}
t2=C_retrieve(lf[81]);
t3=C_set_block_item(lf[81],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7353,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1486 append */
t7=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7360 in k7347 in a7344 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1486 walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7070(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7351 in k7347 in a7344 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[81]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7283,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7283(t5,((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* loop in k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7283,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7301,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1468 append */
t6=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7310,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[5],a[12]=t3,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1471 put! */
t7=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,((C_word*)t0)[2],t4,lf[433],((C_word*)t0)[8]);}}

/* k7308 in loop in k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1472 assign */
t3=((C_word*)t0)[4];
f_7663(t3,t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k7311 in k7308 in loop in k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7316,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1473 walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7070(t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7314 in k7311 in k7308 in loop in k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1474 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7283(t4,((C_word*)t0)[2],t2,t3);}

/* k7299 in loop in k7276 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1468 walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_7070(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7204 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1453 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5],lf[442]);}

/* k7252 in k7204 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7254,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_memq(((C_word*)t0)[5],C_retrieve(lf[438])):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
t3=((C_word*)t0)[2];
f_7183(2,t3,C_SCHEME_UNDEFINED);}}

/* a7216 in k7252 in k7204 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7217,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[404],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7236,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1459 get */
t10=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],t8,lf[441]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7234 in a7216 in k7252 in k7204 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1459 count! */
t2=C_retrieve(lf[439]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[440]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7181 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* compiler.scm: 1461 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7070(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7184 in k7181 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* compiler.scm: 1462 walkeach */
t3=((C_word*)((C_word*)t0)[6])[1];
f_7651(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7145 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_7063(C_fix(1));
/* compiler.scm: 1440 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}

/* k7102 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7104,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=f_7063(C_fix(1));
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[3]))){
/* compiler.scm: 1433 put! */
t3=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],lf[435],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1434 get */
t4=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],lf[436]);}}}

/* k7133 in k7102 in k7090 in walk in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1434 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[436],C_SCHEME_TRUE);}}

/* assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7663(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7663,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t3;
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[126],t7);
if(C_truep(t8)){
/* compiler.scm: 1552 put! */
t9=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t1,((C_word*)t0)[2],t2,lf[429],C_SCHEME_TRUE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7676,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=t3;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[404],t11);
if(C_truep(t12)){
t13=t3;
t14=(C_word)C_slot(t13,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=t9;
f_7676(t16,(C_word)C_eqp(t2,t15));}
else{
t13=t9;
f_7676(t13,C_SCHEME_FALSE);}}}

/* k7674 in assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7676,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[21]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7685(t4,t2);}
else{
t4=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_7685(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7736,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1557 get */
t6=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[6],((C_word*)t0)[5],lf[353]);}}}}

/* k7734 in k7674 in assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_7685(t2,(C_truep(t1)?t1:(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[31]))));}

/* k7683 in k7674 in assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7685,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1560 get-all */
t3=C_retrieve(lf[434]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[430],lf[431]);}
else{
/* compiler.scm: 1568 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}}

/* k7686 in k7683 in k7674 in assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1561 get */
t3=C_retrieve(lf[432]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[433]);}

/* k7689 in k7686 in k7683 in k7674 in assign in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_assq(lf[430],((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep((C_word)C_i_assq(lf[431],((C_word*)t0)[7]))){
/* compiler.scm: 1564 put! */
t2=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_not(t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t3)){
/* compiler.scm: 1566 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[431],((C_word*)t0)[2]);}
else{
/* compiler.scm: 1567 put! */
t4=C_retrieve(lf[428]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[430],C_SCHEME_TRUE);}}}}

/* ref in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_7766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7766,NULL,4,t0,t1,t2,t3);}
/* compiler.scm: 1571 collect! */
t4=C_retrieve(lf[426]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[427],t3);}

/* grow in k7059 in ##compiler#analyze-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static C_word C_fcall f_7063(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_fixnum_plus(C_retrieve(lf[52]),t1);
t3=C_mutate((C_word*)lf[52]+1,t2);
return(t3);}

/* foreign-callback-stub-argument-types in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7048,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-callback-stub-argument-types-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7039,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-callback-stub-return-type in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7030,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-callback-stub-return-type-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7021,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-callback-stub-qualifiers in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7012,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-callback-stub-qualifiers-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7003,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-callback-stub-name in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6994,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-callback-stub-name-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6985,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-callback-stub-id in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6976,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[413]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-callback-stub-id-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6967,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[413]);
/* compiler.scm: 1403 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-callback-stub? in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6961,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[413]));}

/* make-foreign-callback-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6955,7,t0,t1,t2,t3,t4,t5,t6);}
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,6,lf[413],t2,t3,t4,t5,t6));}

/* ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6280,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6283,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6327,a[2]=t8,a[3]=t10,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6701,a[2]=t12,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t18=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6826,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6842,a[2]=t14,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6927,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
/* compiler.scm: 1398 walk */
t21=((C_word*)t6)[1];
f_6327(t21,t1,t2,*((C_word*)lf[412]+1));}

/* atomic? in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6927,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_i_memq(t4,lf[411]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_truep((C_word)C_eqp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[104]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[177]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[108]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[180]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
/* compiler.scm: 1396 every */
t8=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,((C_word*)((C_word*)t0)[2])[1],t7);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6842(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6842,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6848(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6848(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6848,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6862,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1379 reverse */
t5=*((C_word*)lf[289]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t2);
/* compiler.scm: 1380 atomic? */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6927(3,t6,t4,t5);}}

/* k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6868,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* compiler.scm: 1381 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6848(t5,((C_word*)t0)[3],t2,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1383 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[388]);}}

/* k6884 in k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1384 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6327(t4,((C_word*)t0)[2],t2,t3);}

/* a6894 in k6884 in k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6895,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6909,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6921,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1389 varnode */
t7=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6919 in a6894 in k6884 in k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* compiler.scm: 1388 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6848(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6907 in a6894 in k6884 in k6866 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6909,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6860 in loop in walk-arguments in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1379 wk */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* walk-inline-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6826(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6826,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6832,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1372 walk-arguments */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6842(t7,t1,t4,t6);}

/* a6831 in walk-inline-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6832,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[398],t3,t4,t2);
/* compiler.scm: 1375 k */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t5);}

/* walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6701,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6705,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 1348 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[403]);}

/* k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 1349 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6708,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[406]);}

/* k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[11]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6758,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1353 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[11]);}

/* k6756 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1353 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6754,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6731,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6733,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1354 walk-arguments */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6842(t6,t4,((C_word*)t0)[2],t5);}

/* a6732 in k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6733,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6739,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1357 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6327(t4,t1,((C_word*)t0)[2],t3);}

/* a6738 in a6732 in k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6739,3,t0,t1,t2);}
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6743,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6750,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1359 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6748 in a6738 in a6732 in k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1359 cons* */
t2=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6741 in a6738 in a6732 in k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6743,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[398],lf[400],((C_word*)t0)[2],t1));}

/* k6729 in k6752 in k6760 in k6706 in k6703 in walk-call in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6731,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6327,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[404]);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t11,a[10]=t2,a[11]=t1,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t12)){
t14=t13;
f_6349(t14,t12);}
else{
t14=(C_word)C_eqp(t11,lf[103]);
if(C_truep(t14)){
t15=t13;
f_6349(t15,t14);}
else{
t15=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t15)){
t16=t13;
f_6349(t16,t15);}
else{
t16=(C_word)C_eqp(t11,lf[274]);
t17=t13;
f_6349(t17,(C_truep(t16)?t16:(C_word)C_eqp(t11,lf[410])));}}}}

/* k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6349,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1305 k */
t2=((C_word*)t0)[12];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1306 gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[403]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[152]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6455,a[2]=t5,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6455(t7,((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[8]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t6=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[406]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6530,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1328 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[282]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[247]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[406]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[194]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t9=t8;
f_6615(t9,t7);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[195]);
if(C_truep(t9)){
t10=t8;
f_6615(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t10)){
t11=t8;
f_6615(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[177]);
if(C_truep(t11)){
t12=t8;
f_6615(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[108]);
t13=t8;
f_6615(t13,(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[9],lf[180])));}}}}}}}}}}}

/* k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6615,NULL,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 1342 walk-inline-call */
t2=((C_word*)((C_word*)t0)[9])[1];
f_6826(t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* compiler.scm: 1343 walk-call */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6701(t5,((C_word*)t0)[8],t3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[273]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=((C_word*)t0)[8];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6772,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1362 gensym */
t8=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[403]);}
else{
/* compiler.scm: 1345 bomb */
t4=C_retrieve(lf[408]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[8],lf[409]);}}}}

/* k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1363 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6773 in k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6775,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[406]);}

/* k6818 in k6773 in k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6816,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1367 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}

/* k6814 in k6818 in k6773 in k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1367 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6810 in k6818 in k6773 in k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6812,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 1369 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k6806 in k6810 in k6818 in k6773 in k6770 in k6613 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[273],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t4));}

/* k6578 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6606,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_apply(5,0,t3,C_retrieve(lf[407]),t1,((C_word*)t0)[2]);}

/* k6604 in k6578 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6606,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* compiler.scm: 1339 cps-lambda */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6283(t7,((C_word*)t0)[4],((C_word*)t0)[3],t5,t6,((C_word*)t0)[2]);}

/* k6528 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6530,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1329 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6327(t4,((C_word*)t0)[2],t2,t3);}

/* a6538 in k6528 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6539,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,1,t2);
t7=(C_word)C_a_i_record(&a,4,lf[398],lf[175],t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6563,a[2]=t3,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1333 varnode */
t10=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[4]);}

/* k6565 in a6538 in k6528 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1333 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6561 in a6538 in k6528 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6515 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* compiler.scm: 1327 cps-lambda */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6283(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6455(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6455,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
/* compiler.scm: 1321 walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6327(t5,t1,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1322 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6327(t6,t1,t4,t5);}}

/* a6477 in loop in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6478,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6492,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 1326 loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_6455(t8,t5,t6,t7);}

/* k6490 in a6477 in loop in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1307 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}

/* k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* gensym */
t5=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[406]);}

/* k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6440,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6436,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1312 varnode */
t6=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[8]);}

/* k6434 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1312 k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6430 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6432,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1313 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6327(t7,t4,t5,t6);}

/* a6404 in k6430 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6405,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* compiler.scm: 1317 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6327(t5,t3,t4,((C_word*)t0)[2]);}

/* k6414 in a6404 in k6430 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* compiler.scm: 1318 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6327(t4,t2,t3,((C_word*)t0)[2]);}

/* k6418 in k6414 in a6404 in k6430 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[114],C_SCHEME_END_OF_LIST,t2));}

/* k6397 in k6430 in k6438 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[152],((C_word*)t0)[2],t2));}

/* k1 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6376,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1308 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6374 in k1 in k6362 in k6359 in k6347 in walk in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[400],lf[405],t2));}

/* cps-lambda in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6283,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6287,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1293 gensym */
t7=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[403]);}

/* k6285 in cps-lambda in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],C_SCHEME_TRUE,t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6310,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1296 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6327(t7,t4,t5,t6);}

/* a6309 in k6285 in cps-lambda in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6321,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1298 varnode */
t4=C_retrieve(lf[402]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6319 in a6309 in k6285 in cps-lambda in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[398],lf[400],lf[401],t2));}

/* k6302 in k6285 in cps-lambda in ##compiler#perform-cps-conversion in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[398],lf[399],((C_word*)t0)[4],t2);
/* compiler.scm: 1294 k */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6190,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6193,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6222,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
/* compiler.scm: 1285 walk */
t10=((C_word*)t7)[1];
f_6222(t10,t1,t2);}

/* walk in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_not_pair_p(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6241,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 1280 ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[396]),t5);}
else{
/* compiler.scm: 1284 mapupdate */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6193(t5,t1,t2);}}}

/* k6239 in walk in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6241,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[6],t2))){
t4=t3;
f_6247(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6264,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1282 alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k6262 in k6239 in walk in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1282 ##sys#hash-table-set! */
t2=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[396]),((C_word*)t0)[2],t1);}

/* k6245 in k6239 in walk in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1283 mapupdate */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6193(t3,((C_word*)t0)[2],t2);}

/* mapupdate in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6193(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6193,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6199(t6,t1,t2);}

/* loop in mapupdate in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6199,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6209,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* compiler.scm: 1274 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6222(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6207 in loop in mapupdate in ##compiler#update-line-number-database! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1275 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6199(t3,((C_word*)t0)[2],t2);}

/* ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6113,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_i_stringp(t6);
t8=t3;
f_6113(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_6113(t5,C_SCHEME_FALSE);}}

/* k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6113,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6116(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_6116(t3,lf[395]);}}

/* k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6116,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
t4=t2;
f_6119(t4,(C_word)C_i_cadr(t3));}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=t2;
f_6119(t4,(C_word)C_i_cadr(t3));}}

/* k6117 in k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_6119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6119,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6122,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[393]+1),t4);}

/* k6133 in k6117 in k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6120 in k6117 in k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6123 in k6120 in k6117 in k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in ##compiler#expand-foreign-primitive in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1264 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-callback-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6072,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6082,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6095,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[393]+1),t9);}

/* k6093 in ##compiler#expand-foreign-callback-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6080 in ##compiler#expand-foreign-callback-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6083 in k6080 in ##compiler#expand-foreign-callback-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6086 in k6083 in k6080 in ##compiler#expand-foreign-callback-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1255 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6035,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t2);
t6=(C_word)C_i_cadr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6045,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6058,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdddr(t2);
/* map */
t10=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,*((C_word*)lf[393]+1),t9);}

/* k6056 in ##compiler#expand-foreign-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[224]+1),t1);}

/* k6043 in ##compiler#expand-foreign-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[394]+1),((C_word*)t0)[2]);}

/* k6046 in k6043 in ##compiler#expand-foreign-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6051,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[2]);}

/* k6049 in k6046 in k6043 in ##compiler#expand-foreign-lambda* in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1247 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#expand-foreign-callback-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5990,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1234 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5997(2,t6,t4);}
else{
/* compiler.scm: 1236 quit */
t6=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[392],t4);}}}

/* k5995 in ##compiler#expand-foreign-callback-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6003,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[390]+1),t5);}

/* k6001 in k5995 in ##compiler#expand-foreign-callback-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1239 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* ##compiler#expand-foreign-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5945,3,t0,t1,t2);}
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_i_cadr(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5952,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t4))){
/* compiler.scm: 1225 symbol->string */
t6=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_stringp(t4))){
t6=t5;
f_5952(2,t6,t4);}
else{
/* compiler.scm: 1227 quit */
t6=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[391],t4);}}}

/* k5950 in ##compiler#expand-foreign-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5958,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[390]+1),t5);}

/* k5956 in k5950 in ##compiler#expand-foreign-lambda in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1230 create-foreign-stub */
t2=C_retrieve(lf[382]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5791,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5795,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t8,a[6]=t4,a[7]=t2,a[8]=t1,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_i_length(t4);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5939,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1198 list-tabulate */
t12=C_retrieve(lf[389]);
((C_proc4)C_retrieve_proc(t12))(4,t12,t9,t10,t11);}

/* a5938 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5939,3,t0,t1,t2);}
/* compiler.scm: 1198 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,lf[388]);}

/* k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1199 gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[387]);}

/* k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler.scm: 1200 gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 1201 estimate-foreign-result-size */
t3=C_retrieve(lf[386]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}

/* k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 1202 set-real-name! */
t3=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 1204 make-foreign-stub */
t3=C_retrieve(lf[362]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[13]);}

/* k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1,t2);
t4=(C_truep(((C_word*)t0)[10])?(C_word)C_fixnum_plus(((C_word*)t0)[9],C_fix(24)):((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_a_i_list(&a,2,lf[274],((C_word*)t0)[2]);
t7=t5;
f_5817(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t5;
f_5817(t6,(C_word)C_a_i_list(&a,2,lf[194],((C_word*)t0)[2]));}}

/* k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_5817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5817,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5908,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1210 map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* a5907 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5908,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5916,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1210 foreign-type-convert-argument */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k5914 in a5907 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1210 foreign-type-check */
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5831,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[6])?lf[383]:C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5843,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[5],C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[384],t1);
/* compiler.scm: 1215 append */
t8=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1216 final-foreign-type */
t7=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[4]);}}

/* k5858 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 1217 words */
t3=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5861 in k5858 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[385],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5874,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[3]);
/* compiler.scm: 1220 append */
t12=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,((C_word*)t0)[2],t11);}

/* k5880 in k5861 in k5858 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1220 finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5876 in k5861 in k5858 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1219 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5872 in k5861 in k5858 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5874,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5843(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k5851 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1215 foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5841 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5829 in k5818 in k5815 in k5931 in k5805 in k5802 in k5799 in k5796 in k5793 in ##compiler#create-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5831,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[159],t2));}

/* foreign-stub-callback in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5782,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(8)));}

/* foreign-stub-callback-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5773,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(8),t3);}

/* foreign-stub-cps in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5764,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(7)));}

/* foreign-stub-cps-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5755,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(7),t3);}

/* foreign-stub-body in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5746,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* foreign-stub-body-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5737,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* foreign-stub-argument-names in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5728,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(5)));}

/* foreign-stub-argument-names-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5719,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(5),t3);}

/* foreign-stub-argument-types in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5710,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(4)));}

/* foreign-stub-argument-types-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5701,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(4),t3);}

/* foreign-stub-name in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5692,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* foreign-stub-name-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5683,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* foreign-stub-return-type in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5674,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* foreign-stub-return-type-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5665,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* foreign-stub-id in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5656,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[363]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* foreign-stub-id-set! in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5647,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[363]);
/* compiler.scm: 1187 ##sys#block-set! */
t5=*((C_word*)lf[366]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* foreign-stub? in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5641,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[363]));}

/* make-foreign-stub in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word ab[10],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_5635,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,9,lf[363],t2,t3,t4,t5,t6,t7,t8,t9));}

/* ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4690,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4693,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=t4;
f_4744(t5,t1);}

/* a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4744,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=t2;
f_4748(2,t3,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 1023 syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[361],((C_word*)t0)[3]);}}

/* k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(t2,lf[296]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,C_retrieve(lf[299]),t5);}
else{
t5=(C_word)C_eqp(t2,lf[300]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1035 check-decl */
f_4693(t6,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t6=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[304]));
t9=t3;
f_4754(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4860,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1045 append */
t10=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t9,C_retrieve(lf[12]));}}
else{
t7=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t8))){
t9=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[305]));
t10=t3;
f_4754(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1049 append */
t11=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t10,C_retrieve(lf[13]));}}
else{
t8=(C_word)C_eqp(t2,lf[306]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t9))){
t10=C_mutate((C_word*)lf[12]+1,C_retrieve(lf[304]));
t11=C_mutate((C_word*)lf[13]+1,C_retrieve(lf[305]));
t12=t3;
f_4754(2,t12,t11);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4914,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1056 lset-intersection */
t12=C_retrieve(lf[307]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,*((C_word*)lf[97]+1),t10,C_retrieve(lf[304]));}}
else{
t9=(C_word)C_eqp(t2,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1059 check-decl */
f_4693(t10,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t10=(C_word)C_eqp(t2,lf[308]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[309]));
if(C_truep(t11)){
t12=C_mutate((C_word*)lf[10]+1,lf[308]);
t13=t3;
f_4754(2,t13,t12);}
else{
t12=(C_word)C_eqp(t2,lf[11]);
if(C_truep(t12)){
t13=C_mutate((C_word*)lf[10]+1,lf[11]);
t14=t3;
f_4754(2,t14,t13);}
else{
t13=(C_word)C_eqp(t2,lf[16]);
if(C_truep(t13)){
t14=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1065 ##match#set-error-control */
t15=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t3,lf[311]);}
else{
t14=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t14)){
t15=C_set_block_item(lf[16],0,C_SCHEME_FALSE);
t16=t3;
f_4754(2,t16,t15);}
else{
t15=(C_word)C_eqp(t2,lf[28]);
if(C_truep(t15)){
t16=C_set_block_item(lf[28],0,C_SCHEME_TRUE);
t17=t3;
f_4754(2,t17,t16);}
else{
t16=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t16)){
t17=C_set_block_item(lf[29],0,C_SCHEME_TRUE);
t18=t3;
f_4754(2,t18,t17);}
else{
t17=(C_word)C_eqp(t2,lf[30]);
if(C_truep(t17)){
t18=C_set_block_item(lf[30],0,C_SCHEME_TRUE);
t19=t3;
f_4754(2,t19,t18);}
else{
t18=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t18)){
t19=C_set_block_item(lf[14],0,C_SCHEME_TRUE);
t20=t3;
f_4754(2,t20,t19);}
else{
t19=(C_word)C_eqp(t2,lf[314]);
if(C_truep(t19)){
t20=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t21=t3;
f_4754(2,t21,t20);}
else{
t20=(C_word)C_eqp(t2,lf[315]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1072 append */
t23=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t23))(4,t23,t21,t22,C_retrieve(lf[316]));}
else{
t21=(C_word)C_eqp(t2,lf[17]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5028,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1073 append */
t24=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t24))(4,t24,t22,t23,C_retrieve(lf[17]));}
else{
t22=(C_word)C_eqp(t2,lf[317]);
if(C_truep(t22)){
t23=C_set_block_item(lf[34],0,C_SCHEME_TRUE);
t24=t3;
f_4754(2,t24,t23);}
else{
t23=(C_word)C_eqp(t2,lf[318]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1077 append */
t25=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t25))(5,t25,t24,C_retrieve(lf[304]),C_retrieve(lf[305]),C_retrieve(lf[18]));}
else{
t24=(C_word)C_eqp(t2,lf[319]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1081 append */
t27=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t25,t26,C_retrieve(lf[18]));}
else{
t25=(C_word)C_eqp(t2,lf[320]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
t27=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[4],a[3]=t26,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1085 every */
t28=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t28))(4,t28,t27,*((C_word*)lf[323]+1),t26);}
else{
t26=(C_word)C_eqp(t2,lf[324]);
if(C_truep(t26)){
t27=(C_word)C_i_listp(((C_word*)t0)[4]);
t28=(C_word)C_i_not(t27);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t28)){
t30=t29;
f_5112(t30,t28);}
else{
t30=(C_word)C_i_cadr(((C_word*)t0)[4]);
t31=(C_word)C_i_listp(t30);
t32=(C_word)C_i_not(t31);
if(C_truep(t32)){
t33=t29;
f_5112(t33,t32);}
else{
t33=(C_word)C_i_cadr(((C_word*)t0)[4]);
t34=(C_word)C_i_length(t33);
t35=t29;
f_5112(t35,(C_word)C_fixnum_lessp(t34,C_fix(3)));}}}
else{
t27=(C_word)C_eqp(t2,lf[327]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
t29=(C_word)C_a_i_cons(&a,2,lf[327],t28);
/* compiler.scm: 1093 emit-control-file-item */
t30=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t3,t29);}
else{
t28=(C_word)C_eqp(t2,lf[329]);
if(C_truep(t28)){
t29=(C_word)C_i_cdr(((C_word*)t0)[4]);
t30=(C_word)C_a_i_cons(&a,2,lf[329],t29);
/* compiler.scm: 1095 emit-control-file-item */
t31=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t3,t30);}
else{
t29=(C_word)C_eqp(t2,lf[330]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1098 pathname-strip-extension */
t31=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,C_retrieve(lf[32]));}
else{
t30=(C_word)C_eqp(t2,lf[334]);
if(C_truep(t30)){
t31=C_set_block_item(lf[21],0,C_SCHEME_TRUE);
t32=t3;
f_4754(2,t32,t31);}
else{
t31=(C_word)C_eqp(t2,lf[335]);
if(C_truep(t31)){
t32=C_set_block_item(lf[21],0,C_SCHEME_FALSE);
t33=t3;
f_4754(2,t33,t32);}
else{
t32=(C_word)C_eqp(t2,lf[336]);
if(C_truep(t32)){
t33=C_set_block_item(lf[46],0,C_SCHEME_FALSE);
t34=t3;
f_4754(2,t34,t33);}
else{
t33=(C_word)C_eqp(t2,lf[337]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5250,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t35=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1104 append */
t36=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t36))(4,t36,t34,t35,C_retrieve(lf[90]));}
else{
t34=(C_word)C_eqp(t2,lf[338]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1106 check-decl */
f_4693(t35,((C_word*)t0)[4],C_fix(1),C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t35)){
t36=C_set_block_item(lf[343],0,C_SCHEME_TRUE);
t37=t3;
f_4754(2,t37,t36);}
else{
t36=(C_word)C_eqp(t2,lf[344]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t2,lf[345]));
if(C_truep(t37)){
t38=(C_word)C_i_cdr(((C_word*)t0)[4]);
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5418,a[2]=t38,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[33]))){
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5426,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1140 lset-difference */
t41=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[33]),t38);}
else{
t40=t39;
f_5418(t40,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t38)){
t39=(C_word)C_i_cdr(((C_word*)t0)[4]);
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5439,a[2]=t39,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1144 lset-difference */
t41=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t41))(5,t41,t40,*((C_word*)lf[97]+1),C_retrieve(lf[31]),t39);}
else{
t39=(C_word)C_eqp(t2,lf[347]);
if(C_truep(t39)){
t40=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t40))){
/* compiler.scm: 1148 quit */
t41=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t41))(4,t41,t3,lf[348],((C_word*)t0)[4]);}
else{
t41=C_retrieve(lf[43]);
if(C_truep(t41)){
t42=t3;
f_4754(2,t42,C_SCHEME_UNDEFINED);}
else{
t42=(C_word)C_i_cadr(((C_word*)t0)[4]);
t43=C_mutate((C_word*)lf[43]+1,t42);
t44=t3;
f_4754(2,t44,t43);}}}
else{
t40=(C_word)C_eqp(t2,lf[349]);
if(C_truep(t40)){
t41=C_set_block_item(lf[39],0,C_SCHEME_TRUE);
t42=t3;
f_4754(2,t42,t41);}
else{
t41=(C_word)C_eqp(t2,lf[350]);
if(C_truep(t41)){
t42=C_set_block_item(lf[40],0,C_SCHEME_TRUE);
t43=t3;
f_4754(2,t43,t42);}
else{
t42=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t42)){
t43=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t43))){
t44=C_retrieve(lf[41]);
if(C_truep((C_word)C_fixnum_greaterp(t44,C_fix(-1)))){
t45=t3;
f_4754(2,t45,C_SCHEME_UNDEFINED);}
else{
t45=C_set_block_item(lf[41],0,C_fix(10));
t46=t3;
f_4754(2,t46,t45);}}
else{
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5513,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* compiler.scm: 1157 lset-union */
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t44,*((C_word*)lf[97]+1),C_retrieve(lf[86]),t45);}}
else{
t43=(C_word)C_eqp(t2,lf[351]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5530,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1159 check-decl */
f_4693(t44,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}
else{
t44=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t44)){
t45=(C_word)C_i_cdr(((C_word*)t0)[4]);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[4],a[3]=t45,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1167 every */
t47=C_retrieve(lf[322]);
((C_proc4)C_retrieve_proc(t47))(4,t47,t46,*((C_word*)lf[355]+1),t45);}
else{
t45=(C_word)C_eqp(t2,lf[356]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5604,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 1171 ##sys#call-with-values */
C_call_with_values(4,0,t3,t46,t47);}
else{
/* compiler.scm: 1181 compiler-warning */
t46=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t3,lf[181],lf[360],((C_word*)t0)[4]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* a5603 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5604,4,t0,t1,t2,t3);}
t4=C_set_block_item(lf[45],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5609,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5614,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5613 in a5603 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5614,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,lf[359]);}

/* k5607 in a5603 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[139]),((C_word*)t0)[2]);}

/* a5575 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5582,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1172 partition */
t4=C_retrieve(lf[358]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* a5581 in a5575 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5582,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
/* compiler.scm: 1176 quit */
t3=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[357],t2);}}}

/* k5556 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1168 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],C_retrieve(lf[47]));}
else{
/* compiler.scm: 1169 quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[354],((C_word*)t0)[2]);}}

/* k5560 in k5556 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5528 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t4=t3;
f_5537(2,t4,t2);}
else{
/* compiler.scm: 1164 quit */
t4=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[352],((C_word*)t0)[3]);}}

/* k5535 in k5528 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5511 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5437 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[33]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
/* compiler.scm: 1145 lset-union */
t6=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],t5);}

/* k5441 in k5437 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5424 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1,t1);
t3=((C_word*)t0)[2];
f_5418(t3,t2);}

/* k5416 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_5418(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5418,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1141 lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[31]));}

/* k5420 in k5416 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
f_4754(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1111 lset-difference */
t7=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[97]+1),C_retrieve(lf[304]),t6);}}
else{
t4=(C_word)C_eqp(t2,lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t5))){
t6=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[3];
f_4754(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1115 lset-difference */
t8=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,*((C_word*)lf[97]+1),C_retrieve(lf[305]),t7);}}
else{
t5=(C_word)C_eqp(t2,lf[340]);
if(C_truep(t5)){
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t6))){
t7=C_set_block_item(lf[41],0,C_fix(-1));
t8=((C_word*)t0)[3];
f_4754(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* compiler.scm: 1119 lset-union */
t9=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[97]+1),C_retrieve(lf[87]),t8);}}
else{
t6=(C_word)C_eqp(t2,lf[306]);
if(C_truep(t6)){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t7))){
t8=C_set_block_item(lf[12],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(lf[13],0,C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[3];
f_4754(2,t10,t9);}
else{
t8=(C_word)C_i_cddr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1126 lset-difference */
t10=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,*((C_word*)lf[97]+1),C_retrieve(lf[304]),t8);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1129 check-decl */
f_4693(t7,((C_word*)t0)[4],C_fix(1),(C_word)C_a_i_list(&a,1,C_fix(1)));}}}}}

/* k5371 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[313]);
if(C_truep(t3)){
t4=C_set_block_item(lf[14],0,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
f_4754(2,t5,t4);}
else{
t4=(C_word)C_eqp(t2,lf[312]);
if(C_truep(t4)){
t5=C_set_block_item(lf[16],0,C_SCHEME_TRUE);
/* compiler.scm: 1134 ##match#set-error-control */
t6=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],lf[311]);}
else{
/* compiler.scm: 1135 compiler-warning */
t5=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],lf[181],lf[341],((C_word*)t0)[3]);}}}

/* k5360 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5366,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1127 lset-difference */
t4=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[305]),((C_word*)t0)[2]);}

/* k5364 in k5360 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5331 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5306 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5281 in k5261 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5248 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5200 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5210 in k5200 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5211,3,t0,t1,t2);}
/* string-substitute */
t3=C_retrieve(lf[331]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[332],((C_word*)t0)[2],t2);}

/* k5207 in k5200 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5209,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[330],t1);
/* compiler.scm: 1097 emit-control-file-item */
t3=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5110 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_5112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1090 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[325],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* compiler.scm: 1091 process-custom-declaration */
t4=C_retrieve(lf[326]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t2,t3);}}

/* k5088 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1086 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[19]),((C_word*)t0)[3]);}
else{
/* compiler.scm: 1087 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[321],((C_word*)t0)[2]);}}

/* k5092 in k5088 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[19]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5061 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 1082 append */
t5=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve(lf[17]));}

/* k5065 in k5061 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5047 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1079 append */
t4=*((C_word*)lf[155]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve(lf[304]),C_retrieve(lf[305]),C_retrieve(lf[17]));}

/* k5051 in k5047 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5026 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k5012 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[316]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4929 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=((C_word*)t0)[2];
f_4754(2,t4,t3);}

/* k4912 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1057 lset-intersection */
t4=C_retrieve(lf[307]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),((C_word*)t0)[2],C_retrieve(lf[305]));}

/* k4916 in k4912 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4883 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4858 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4819,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4843,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1037 stringify */
t5=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4841 in k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1037 string->c-identifier */
t2=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4817 in k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1038 hash-table-set! */
t3=C_retrieve(lf[303]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_retrieve(lf[88]),lf[300],((C_word*)t0)[2]);}

/* k4820 in k4817 in k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t4=(C_word)C_i_string_equal_p(C_retrieve(lf[9]),((C_word*)t0)[3]);
t5=t3;
f_4829(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4829(t4,C_SCHEME_FALSE);}}

/* k4827 in k4820 in k4817 in k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1040 compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[301],lf[302]);}
else{
t2=((C_word*)t0)[2];
f_4825(2,t2,C_SCHEME_UNDEFINED);}}

/* k4823 in k4820 in k4817 in k4811 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[9]+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
/* for-each */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[139]),((C_word*)t0)[3]);}
else{
t3=t2;
f_4766(2,t3,C_SCHEME_UNDEFINED);}}

/* k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1031 hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[296],t3,t4);}
else{
t2=((C_word*)t0)[2];
f_4754(2,t2,C_SCHEME_UNDEFINED);}}

/* a4799 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4793 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4794,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),((C_word*)t0)[2],t2);}

/* k4773 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4784,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4783 in k4773 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4792,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1032 stringify */
t4=C_retrieve(lf[298]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4790 in a4783 in k4773 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1032 string->c-identifier */
t2=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4776 in k4773 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 1033 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[15]),t1);}

/* k4780 in k4776 in k4773 in k4764 in k4761 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[15]+1,t1);
t3=((C_word*)t0)[2];
f_4754(2,t3,t2);}

/* k4752 in k4746 in a4743 in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[295]);}

/* check-decl in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4693(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4693,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_fixnum_lessp(t6,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4706,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=t8;
f_4706(t9,t7);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4716,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t10=t9;
f_4716(2,t10,C_fix(99999));}
else{
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4716(2,t11,(C_word)C_i_car(t4));}
else{
/* compiler.scm: 1018 ##sys#error */
t11=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[1],t4);}}}}

/* k4714 in check-decl in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4706(t2,(C_word)C_fixnum_greaterp(((C_word*)t0)[2],t1));}

/* k4704 in check-decl in ##compiler#process-declaration in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 1019 syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[294],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1941,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1944,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1956,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1980,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2113,a[2]=t5,a[3]=t11,a[4]=t4,a[5]=t9,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp));
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4635,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=t2,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(lf[124],C_retrieve(lf[291])))){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4685,a[2]=t2,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1001 newline */
t17=*((C_word*)lf[293]+1);
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t16=t15;
f_4648(2,t16,C_SCHEME_UNDEFINED);}}

/* k4683 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 1001 pretty-print */
t2=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1002 ##sys#clear-trace-buffer */
t3=C_retrieve(lf[290]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4649 in k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1006 reverse */
t4=*((C_word*)lf[289]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[78]));}

/* k4664 in k4649 in k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=C_set_block_item(lf[78],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 1009 ##sys#compiler-toplevel-macroexpand-hook */
t4=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4673 in k4664 in k4649 in k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 1010 append */
t3=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[287]),C_retrieve(lf[13]));}

/* k4677 in k4673 in k4664 in k4649 in k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* compiler.scm: 455  ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4660 in k4649 in k4646 in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 1004 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2113(t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* mapwalk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4635,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t2);}

/* a4640 in mapwalk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4641,3,t0,t1,t2);}
/* compiler.scm: 999  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2113(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2113,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(C_word)C_i_assq(t2,t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 503  resolve-atom */
t9=((C_word*)((C_word*)t0)[7])[1];
f_2022(t9,t8,t7,t3,t4,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2138,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 505  resolve-atom */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2022(t8,t7,t2,t3,t4,t5);}}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* compiler.scm: 507  constant? */
t7=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t7=t6;
f_2150(2,t7,C_SCHEME_FALSE);}}}

/* k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[10]));}
else{
if(C_truep((C_word)C_i_not_pair_p(((C_word*)t0)[10]))){
/* compiler.scm: 508  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[112],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* compiler.scm: 512  get-line */
t6=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* compiler.scm: 975  constant? */
t5=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
/* compiler.scm: 973  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[11],lf[286],((C_word*)t0)[10]);}}}}}

/* k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 976  emit-syntax-trace-info */
t3=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 980  caar */
t5=*((C_word*)lf[284]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_4511(t4,C_SCHEME_FALSE);}}}

/* k4609 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4511(t2,(C_word)C_eqp(lf[159],t1));}

/* k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4511,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 983  emit-syntax-trace-info */
t5=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 995  emit-syntax-trace-info */
t3=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4596 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 996  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4635(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4518 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 984  ##sys#check-syntax */
t3=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[159],((C_word*)t0)[9],lf[283]);}

/* k4521 in k4518 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t3;
f_4532(t6,(C_word)C_eqp(t4,t5));}
else{
t4=t3;
f_4532(t4,C_SCHEME_FALSE);}}

/* k4530 in k4521 in k4518 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 987  map */
t3=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[281]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 988  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[282]);}}

/* k4552 in k4530 in k4521 in k4518 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[152],t4,t6);
/* compiler.scm: 989  walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_2113(t8,((C_word*)t0)[5],t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4545 in k4530 in k4521 in k4518 in k4509 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[152],t3);
/* compiler.scm: 987  walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2113(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4497 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 977  compiler-warning */
t3=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[181],lf[280],((C_word*)t0)[4]);}

/* k4500 in k4497 in k4494 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 978  mapwalk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4635(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=f_1944(((C_word*)t0)[12],((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t2,a[14]=((C_word*)t0)[10],tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 514  emit-syntax-trace-info */
t4=C_retrieve(lf[279]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[10],C_SCHEME_FALSE);}

/* k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[14]))){
t3=t2;
f_2186(2,t3,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 517  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[277],((C_word*)t0)[2]);}
else{
/* compiler.scm: 518  syntax-error */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[278],((C_word*)t0)[14]);}}}

/* k4476 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 517  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,((C_word*)t0)[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* compiler.scm: 521  ##sys#macroexpand-1-local */
t5=C_retrieve(lf[276]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,((C_word*)t0)[8]);}

/* k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[14],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 525  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[56]),((C_word*)t0)[7]);}
else{
t4=t3;
f_2211(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t1,a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 523  update-line-number-database! */
t4=C_retrieve(lf[275]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t4=t3;
f_2202(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2200 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 524  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2113(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[13]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* compiler.scm: 527  walk */
t4=((C_word*)((C_word*)t0)[12])[1];
f_2113(t4,((C_word*)t0)[11],t3,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[114]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 532  ##sys#check-syntax */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[114],((C_word*)t0)[13],lf[117]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[103]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 540  ##sys#check-syntax */
t5=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[103],((C_word*)t0)[13],lf[118]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[119]);
if(C_truep(t4)){
if(C_truep(C_retrieve(lf[16]))){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[120]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* compiler.scm: 546  walk */
t6=((C_word*)((C_word*)t0)[12])[1];
f_2113(t6,((C_word*)t0)[11],t5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[121]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 549  cadadr */
t7=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[13]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[126]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t6)){
t8=t7;
f_2338(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[273]);
if(C_truep(t8)){
t9=t7;
f_2338(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[274]);
if(C_truep(t9)){
t10=t7;
f_2338(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[104]);
t11=t7;
f_2338(t11,(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[7],lf[108])));}}}}}}}}}

/* k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2338(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[236],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2338,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[11],lf[127]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[134]),t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[12]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2385(t9,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[152]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 597  ##sys#check-syntax */
t6=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[152],((C_word*)t0)[12],lf[158]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[159]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[11],lf[160]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 611  ##sys#check-syntax */
t8=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,lf[159],((C_word*)t0)[12],lf[172]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[173]);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(((C_word*)t0)[12]);
t9=(C_word)C_a_i_cons(&a,2,lf[159],t8);
t10=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 642  walk */
t11=((C_word*)((C_word*)t0)[10])[1];
f_2113(t11,((C_word*)t0)[13],t9,((C_word*)t0)[9],((C_word*)t0)[8],t10);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[174]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(((C_word*)t0)[12]);
t10=(C_word)C_i_cddr(((C_word*)t0)[12]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t10,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* map */
t12=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_retrieve(lf[123]),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[175]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],lf[176]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 658  ##sys#check-syntax */
t12=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[175],((C_word*)t0)[12],lf[193]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[11],lf[194]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 697  unquotify */
t14=((C_word*)t0)[3];
f_1980(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[11],lf[195]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* map */
t15=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,((C_word*)t0)[3],t14);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[11],lf[177]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[12]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3094,a[2]=t14,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 705  walk */
t17=((C_word*)((C_word*)t0)[10])[1];
f_2113(t17,t15,t16,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[11],lf[180]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(((C_word*)t0)[12]);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=t15,a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t17=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* compiler.scm: 710  walk */
t18=((C_word*)((C_word*)t0)[10])[1];
f_2113(t18,t16,t17,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[11],lf[196]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[11],lf[197]));
if(C_truep(t16)){
t17=(C_word)C_i_cadr(((C_word*)t0)[12]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t17,a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 715  eval */
t19=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t17);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[11],lf[198]);
t18=(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[11],lf[199]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t20=(C_word)C_i_cadr(((C_word*)t0)[12]);
/* compiler.scm: 719  eval */
t21=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t19,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[11],lf[138]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3170,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 723  ##sys#check-syntax */
t21=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t20,lf[138],((C_word*)t0)[12],lf[203]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[11],lf[204]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 735  expand-foreign-lambda */
t22=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[11],lf[206]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 738  expand-foreign-callback-lambda */
t23=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t23))(3,t23,t22,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[11],lf[208]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 741  expand-foreign-lambda* */
t24=C_retrieve(lf[209]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[11],lf[210]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 744  expand-foreign-callback-lambda* */
t25=C_retrieve(lf[211]);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[11],lf[212]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 747  expand-foreign-primitive */
t26=C_retrieve(lf[213]);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,((C_word*)t0)[12]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[11],lf[214]);
if(C_truep(t25)){
t26=(C_word)C_i_cadr(((C_word*)t0)[12]);
t27=(C_word)C_i_cadr(t26);
t28=(C_word)C_i_caddr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[13],a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cadddr(((C_word*)t0)[12]);
t33=t30;
f_3304(2,t33,(C_word)C_i_cadr(t32));}
else{
/* compiler.scm: 754  symbol->string */
t32=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t32))(3,t32,t30,t27);}}
else{
t26=(C_word)C_eqp(((C_word*)t0)[11],lf[217]);
if(C_truep(t26)){
t27=(C_word)C_i_cadr(((C_word*)t0)[12]);
t28=(C_word)C_i_cadr(t27);
t29=(C_word)C_i_caddr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_cdddr(((C_word*)t0)[12]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3371,a[2]=t28,a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=t31,tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 765  gensym */
t33=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t33))(2,t33,t32);}
else{
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 778  ##sys#hash-table-set! */
t33=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t33))(5,t33,t32,C_retrieve(lf[65]),t28,t30);}}
else{
t27=(C_word)C_eqp(((C_word*)t0)[11],lf[221]);
if(C_truep(t27)){
t28=(C_word)C_i_cadr(((C_word*)t0)[12]);
t29=(C_word)C_i_cadr(t28);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3445,a[2]=t29,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 783  symbol->string */
t31=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t30,t29);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[11],lf[227]);
if(C_truep(t28)){
t29=(C_word)C_i_cadr(((C_word*)t0)[12]);
t30=(C_word)C_i_cadr(t29);
t31=(C_word)C_i_caddr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[9],a[3]=t30,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],a[8]=t32,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 798  gensym */
t34=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t34))(2,t34,t33);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[11],lf[232]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[12]);
t31=(C_word)C_i_cadr(t30);
t32=(C_word)C_i_caddr(((C_word*)t0)[12]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3647,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=t31,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[11],lf[234]);
if(C_truep(t30)){
t31=(C_word)C_i_cadr(((C_word*)t0)[12]);
t32=(C_word)C_i_cadr(t31);
t33=(C_word)C_i_caddr(((C_word*)t0)[12]);
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=t32,tmp=(C_word)a,a+=7,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3797,a[2]=t34,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3799,a[2]=t32,a[3]=t33,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  call-with-current-continuation */
t37=*((C_word*)lf[244]+1);
((C_proc3)C_retrieve_proc(t37))(3,t37,t35,t36);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[11],lf[245]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3872,tmp=(C_word)a,a+=2,tmp);
t34=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* map */
t35=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t32,t33,t34);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[11],lf[247]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 870  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t33,t34);}
else{
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4269,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_eqp(lf[270],((C_word*)t0)[11]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 945  ##sys#check-syntax */
t36=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t36))(5,t36,t35,lf[270],((C_word*)t0)[12],lf[272]);}
else{
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=t33,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve(lf[92]))){
if(C_truep(C_retrieve(lf[91]))){
/* compiler.scm: 963  ##sys#hash-table-ref */
t36=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t36))(4,t36,t35,C_retrieve(lf[91]),((C_word*)t0)[11]);}
else{
t36=t35;
f_4398(2,t36,C_SCHEME_FALSE);}}
else{
t36=t35;
f_4398(2,t36,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4396 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 965  cm */
t3=t1;
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
/* compiler.scm: 970  handle-call */
t2=((C_word*)t0)[7];
f_4269(t2,((C_word*)t0)[6]);}}

/* k4402 in k4396 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[8]))){
/* compiler.scm: 967  handle-call */
t2=((C_word*)t0)[7];
f_4269(t2,((C_word*)t0)[6]);}
else{
/* compiler.scm: 968  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2113(t2,((C_word*)t0)[6],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4307 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_1944(t2,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(t3,C_retrieve(lf[77]));
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t7=(C_word)C_a_i_list(&a,5,lf[271],t5,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 950  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2113(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_assq(t2,C_retrieve(lf[74]));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
/* compiler.scm: 954  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2113(t7,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[80])))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 956  symbol->string */
t7=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t7=(C_word)C_a_i_list(&a,5,lf[271],t2,C_fix(0),C_SCHEME_FALSE,t6);
/* compiler.scm: 958  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2113(t8,((C_word*)t0)[3],t7,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}}}
else{
t3=(C_word)C_a_i_list(&a,2,lf[103],lf[270]);
t4=(C_word)C_a_i_list(&a,5,lf[271],t2,C_fix(0),C_SCHEME_FALSE,t3);
/* compiler.scm: 959  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2113(t5,((C_word*)t0)[3],t4,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4367 in k4307 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[104],t2));}

/* handle-call in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4269,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 934  mapwalk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4635(t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4271 in handle-call in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4279,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 936  ##sys#hash-table-ref */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[53]),t2);}

/* k4277 in k4271 in handle-call in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cdr(t1):C_SCHEME_END_OF_LIST);
/* compiler.scm: 941  alist-cons */
t5=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t4);}
else{
t3=t2;
f_4282(2,t3,C_SCHEME_UNDEFINED);}}

/* k4291 in k4277 in k4271 in handle-call in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* compiler.scm: 938  ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],C_retrieve(lf[53]),((C_word*)t0)[2],t2);}

/* k4280 in k4277 in k4271 in handle-call in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3905,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_cadddr(t2);
t9=(C_word)C_i_cadr(t8);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3927,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4253,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 877  valid-c-identifier? */
t14=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,t11);}

/* k4251 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[80]));
t3=C_mutate((C_word*)lf[80]+1,t2);
t4=((C_word*)t0)[2];
f_3927(2,t4,t3);}
else{
/* compiler.scm: 879  quit */
t2=C_retrieve(lf[241]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[268],((C_word*)t0)[3]);}}

/* k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[11]);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4218(t6,t4);}
else{
t6=(C_word)C_i_listp(((C_word*)t0)[4]);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t5;
f_4218(t8,t7);}
else{
t8=(C_word)C_i_length(((C_word*)t0)[11]);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t8,t9);
t11=t5;
f_4218(t11,(C_word)C_i_not(t10));}}}

/* k4216 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 884  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[267],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3930(2,t2,C_SCHEME_UNDEFINED);}}

/* k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 888  mapwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4635(t4,t3,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3949,a[2]=t1,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4168,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4168(t7,t3,((C_word*)t0)[9],((C_word*)t0)[2]);}

/* loop in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4168(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4168,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4208,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4212,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 900  final-foreign-type */
t9=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t5);}}

/* k4210 in loop in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 900  finish-foreign-result */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4206 in loop in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 899  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4202 in loop in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4192,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 902  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4168(t6,t3,t4,t5);}

/* k4190 in k4202 in loop in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[250],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[253]))){
/* compiler.scm: 905  g292 */
t7=t6;
f_4040(2,t7,f_4017(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[254]))){
/* compiler.scm: 905  g292 */
t7=t6;
f_4040(2,t7,f_4017(C_a_i(&a,15),t5));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[255]);
if(C_truep(t7)){
/* compiler.scm: 905  g292 */
t8=t6;
f_4040(2,t8,f_4017(C_a_i(&a,15),t5));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[256]);
if(C_truep(t8)){
/* compiler.scm: 905  g292 */
t9=t6;
f_4040(2,t9,f_4017(C_a_i(&a,15),t5));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[257]))){
/* compiler.scm: 905  g293 */
t9=t4;
f_4012(t9,t6);}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[258]))){
/* compiler.scm: 905  g293 */
t9=t4;
f_4012(t9,t6);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],lf[259]);
if(C_truep(t9)){
/* compiler.scm: 905  g293 */
t10=t4;
f_4012(t10,t6);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[3],lf[260]);
if(C_truep(t10)){
/* compiler.scm: 905  g293 */
t11=t4;
f_4012(t11,t6);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[3],lf[261]);
if(C_truep(t11)){
/* compiler.scm: 905  g293 */
t12=t4;
f_4012(t12,t6);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[3],lf[262]);
if(C_truep(t12)){
/* compiler.scm: 905  g293 */
t13=t4;
f_4012(t13,t6);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[3],lf[263]);
if(C_truep(t13)){
/* compiler.scm: 905  g294 */
t14=t6;
f_4040(2,t14,f_3975(C_a_i(&a,42),t3));}
else{
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[264]))){
/* compiler.scm: 905  g294 */
t14=t6;
f_4040(2,t14,f_3975(C_a_i(&a,42),t3));}
else{
t14=(C_word)C_eqp(((C_word*)t0)[3],lf[265]);
/* compiler.scm: 905  g294 */
t15=t6;
f_4040(2,t15,(C_truep(t14)?f_3975(C_a_i(&a,42),t3):(C_truep((C_word)C_i_equalp(((C_word*)t0)[3],lf[266]))?f_3975(C_a_i(&a,42),t3):(C_word)C_i_cddr(((C_word*)t0)[4]))));}}}}}}}}}}}}}

/* k4038 in k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
/* compiler.scm: 903  foreign-type-convert-argument */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* g292 in k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static C_word C_fcall f_4017(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[250],t3);
return((C_word)C_a_i_list(&a,1,t4));}

/* g293 in k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_4012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4012,NULL,2,t0,t1);}
/* compiler.scm: 917  syntax-error */
t2=C_retrieve(lf[111]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[252],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g294 in k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static C_word C_fcall f_3975(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t1=(C_word)C_i_cddr(((C_word*)t0)[2]);
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[152],t2);
t4=(C_word)C_a_i_list(&a,2,lf[249],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[250],lf[249]);
t7=(C_word)C_a_i_list(&a,3,lf[251],lf[249],t6);
t8=(C_word)C_a_i_list(&a,3,lf[152],t5,t7);
return((C_word)C_a_i_list(&a,1,t8));}

/* k3963 in k3959 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[160],((C_word*)t0)[6],t2);
/* compiler.scm: 889  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2113(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3947 in k3939 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3949,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 455  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3935 in k3928 in k3925 in a3904 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[247],t1));}

/* a3894 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler.scm: 870  split-at */
t3=C_retrieve(lf[248]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_fix(4));}

/* a3871 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3872,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* compiler.scm: 865  process-declaration */
t4=C_retrieve(lf[246]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3868 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 863  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2113(t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3799,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3805,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3817,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  with-exception-handler */
t5=C_retrieve(lf[243]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3816 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3838 in a3816 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3839r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3839r(t0,t1,t2);}}

static void C_ccall f_3839r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 837  g254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3844 in a3838 in a3816 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3822 in a3816 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 841  collapsable-literal? */
t3=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3828 in a3822 in a3816 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3830,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_a_i_list(&a,3,lf[152],C_retrieve(lf[79]),((C_word*)t0)[2]);
/* compiler.scm: 843  eval */
t3=C_retrieve(lf[134]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}

/* a3804 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 837  g254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3810 in a3804 in a3798 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
/* compiler.scm: 839  quit */
t2=C_retrieve(lf[241]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,lf[242],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3795 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=C_set_block_item(lf[59],0,C_SCHEME_TRUE);
t3=(C_word)C_a_i_list(&a,2,lf[103],t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[79]));
t6=C_mutate((C_word*)lf[79]+1,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 846  collapsable-literal? */
t8=C_retrieve(lf[240]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}

/* k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* compiler.scm: 847  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 850  basic-literal? */
t4=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k3781 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3747(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 851  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[237],lf[238],((C_word*)t0)[2]);}}

/* k3745 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 855  gensym */
t3=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}

/* k3748 in k3745 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 856  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[58]),((C_word*)t0)[2],t3);}

/* k3751 in k3748 in k3745 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 857  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_retrieve(lf[60]));}

/* k3755 in k3751 in k3748 in k3745 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[31]));
t4=C_mutate((C_word*)lf[31]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_retrieve(lf[17]));
t6=C_mutate((C_word*)lf[17]+1,t5);
t7=(C_word)C_a_i_list(&a,2,lf[103],((C_word*)t0)[6]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
/* compiler.scm: 860  walk */
t9=((C_word*)((C_word*)t0)[5])[1];
f_2113(t9,((C_word*)t0)[4],t8,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3738 in k3735 in k3724 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}

/* a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3665,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3669,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 827  ##sys#hash-table-set! */
t5=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,C_retrieve(lf[56]),((C_word*)t0)[2],t2);}

/* k3667 in a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 828  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3705 in k3667 in a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 828  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve(lf[17]));}

/* k3671 in k3667 in a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=C_set_block_item(lf[57],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3687,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a3686 in k3671 in k3667 in a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3687,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_a_i_list(&a,2,lf[103],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[176],t3,t5));}

/* k3683 in k3671 in k3667 in a3664 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* compiler.scm: 830  walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2113(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* a3646 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,lf[160],t3);
/* compiler.scm: 826  walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2113(t5,t2,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3653 in a3646 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 825  extract-mutable-constants */
t2=C_retrieve(lf[233]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 799  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=(C_word)C_i_cddddr(((C_word*)t0)[10]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_cadddr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* compiler.scm: 801  set-real-name! */
t6=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[77]));
t4=C_mutate((C_word*)lf[77]+1,t3);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3608,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 804  estimate-foreign-result-location-size */
t7=C_retrieve(lf[231]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[10]);}

/* k3606 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 804  words */
t2=C_retrieve(lf[230]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(C_word)C_fixnum_plus(C_fix(2),t1);
t3=(C_word)C_a_i_list(&a,2,lf[228],t2);
t4=(C_word)C_a_i_list(&a,2,lf[103],t1);
t5=(C_word)C_a_i_list(&a,3,lf[195],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t7,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t8,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t11=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[5],((C_word*)t0)[3]);
t12=t10;
f_3560(t12,(C_word)C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_3560(t11,C_SCHEME_END_OF_LIST);}}

/* k3558 in k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_3560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3560,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* compiler.scm: 817  fifth */
t3=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3568(2,t3,(C_word)C_i_cadddr(((C_word*)t0)[2]));}}

/* k3566 in k3558 in k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* compiler.scm: 455  ##sys#append */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3554 in k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 818  alist-cons */
t4=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3550 in k3554 in k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 812  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3542 in k3583 in k3527 in k3521 in k3518 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* compiler.scm: 786  make-random-name */
t9=C_retrieve(lf[98]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}

/* k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3457(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3485,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3493,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 787  fifth */
t5=C_retrieve(lf[226]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3491 in k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(t1);
/* compiler.scm: 787  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3483 in k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3457(t3,t2);}

/* k3455 in k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_3457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3457,NULL,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[69]));
t4=C_mutate((C_word*)lf[69]+1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 790  string-append */
t6=*((C_word*)lf[224]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[225],((C_word*)((C_word*)t0)[7])[1]);}

/* k3475 in k3455 in k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],lf[222],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 792  alist-cons */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[4],C_retrieve(lf[74]));}

/* k3467 in k3475 in k3455 in k3452 in k3443 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[223]);}

/* k3423 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[220]);}

/* k3369 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 766  gensym */
t3=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3372 in k3369 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[3],((C_word*)t0)[9],t1);
/* compiler.scm: 767  ##sys#hash-table-set! */
t4=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_retrieve(lf[65]),((C_word*)t0)[2],t3);}

/* k3375 in k3372 in k3369 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 768  cons* */
t3=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[17]));}

/* k3379 in k3375 in k3372 in k3369 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 769  cons* */
t4=C_retrieve(lf[219]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[7],C_retrieve(lf[31]));}

/* k3383 in k3379 in k3375 in k3372 in k3369 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3385,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[8],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[9]):lf[218]);
t8=(C_word)C_a_i_list(&a,3,lf[176],((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_list(&a,3,lf[138],t4,t8);
/* compiler.scm: 770  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_2113(t10,((C_word*)t0)[5],t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3302 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t1))){
t3=t2;
f_3316(2,t3,t1);}
else{
/* compiler.scm: 756  symbol->string */
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k3314 in k3302 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[66]));
t4=C_mutate((C_word*)lf[66]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[215]);}

/* k3287 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 747  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3274 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 744  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3261 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 741  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3248 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 738  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3235 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 735  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3189,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3189(t8,t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[202]);}}

/* fold in k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3189,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 730  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2113(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3216,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 731  walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2113(t6,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k3214 in fold in k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3220,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 731  fold */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3189(t3,t2,((C_word*)t0)[2]);}

/* k3218 in k3214 in fold in k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3207 in fold in k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3181 in k3168 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 725  canonicalize-begin-body */
t2=C_retrieve(lf[201]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3155 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[200]);}

/* k3140 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 716  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2113(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3113 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3119,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 711  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2113(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3117 in k3113 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k3092 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[2],t1));}

/* k3063 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 702  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4635(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3067 in k3063 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[195],t2));}

/* k3034 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* compiler.scm: 697  mapwalk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4635(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3038 in k3034 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[194],t2));}

/* k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=f_1944(t2,((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 661  get-line */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}

/* k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2874,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 662  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2113(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2877,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 664  ##sys#alias-global-hook */
t5=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=t2;
f_2877(2,t4,C_SCHEME_UNDEFINED);}}

/* k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[34]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 667  lset-adjoin */
t5=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[97]+1),C_retrieve(lf[18]),((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t3;
f_2985(t4,C_SCHEME_UNDEFINED);}}

/* k3009 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 668  lset-adjoin */
t4=C_retrieve(lf[191]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[97]+1),C_retrieve(lf[17]),((C_word*)((C_word*)t0)[2])[1]);}

/* k3013 in k3009 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[17]+1,t1);
t3=((C_word*)t0)[2];
f_2985(t3,t2);}

/* k2983 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 669  macro? */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2989 in k2983 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* compiler.scm: 673  sprintf */
t4=C_retrieve(lf[187]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[188],((C_word*)t0)[2]);}
else{
t4=t3;
f_3004(2,t4,lf[189]);}}
else{
t2=((C_word*)t0)[4];
f_2877(2,t2,C_SCHEME_UNDEFINED);}}

/* k3002 in k2989 in k2983 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 670  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[185],lf[186],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2992 in k2989 in k2983 in k2980 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[46]))){
/* compiler.scm: 674  undefine-macro! */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2877(2,t2,C_SCHEME_UNDEFINED);}}

/* k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 675  keyword? */
t4=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2970 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* compiler.scm: 676  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[181],lf[182],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_2880(2,t2,C_SCHEME_UNDEFINED);}}

/* k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 680  gensym */
t5=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_i_assq(((C_word*)((C_word*)t0)[4])[1],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 688  gensym */
t6=C_retrieve(lf[123]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[175],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]));}}}

/* k2933 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 689  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2964 in k2933 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2958,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 693  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2956 in k2964 in k2933 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[180],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2890 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler.scm: 681  foreign-type-convert-argument */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2921 in k2890 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2911,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 684  foreign-type-check */
t7=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k2909 in k2921 in k2890 in k2878 in k2875 in k2872 in k2869 in k2860 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[177],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t2));}

/* k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 648  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[7],t1);}

/* k2848 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 648  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2825 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 651  ##sys#canonicalize-body */
t5=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* a2841 in k2825 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2842,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2838 in k2825 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 650  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2113(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2828 in k2825 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2833,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 654  set-real-names! */
f_1956(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2831 in k2828 in k2825 in k2822 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2582,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2774,a[2]=t8,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 614  ##sys#extended-lambda-list? */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t4)[1]);}

/* k2772 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 615  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_2582(2,t2,C_SCHEME_UNDEFINED);}}

/* a2784 in k2772 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2785,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2778 in k2772 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
/* compiler.scm: 617  ##sys#expand-extended-lambda-list */
t2=C_retrieve(lf[169]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[170]+1));}

/* k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* compiler.scm: 620  decompose-lambda-list */
t3=C_retrieve(lf[168]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2587,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[123]),t2);}

/* k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 624  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[8],t1);}

/* k2769 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 624  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 625  ##sys#canonicalize-body */
t4=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3,((C_word*)t0)[3],((C_word*)t0)[12]);}

/* a2762 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2763,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 626  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2113(t3,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 630  posq */
t5=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t4=t3;
f_2754(t4,C_SCHEME_FALSE);}}

/* k2759 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2754(t2,(C_word)C_i_list_ref(((C_word*)t0)[2],t1));}

/* k2752 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 628  build-lambda-list */
t2=C_retrieve(lf[166]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=t4;
f_2638(t8,(C_word)C_i_pairp(t7));}
else{
t7=t4;
f_2638(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2638(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2606(2,t3,C_SCHEME_UNDEFINED);}}

/* k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 632  g159 */
t6=((C_word*)t0)[3];
f_2628(t6,((C_word*)t0)[2],t4);}
else{
t4=((C_word*)t0)[2];
f_2606(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2722,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  caadr */
t6=*((C_word*)lf[165]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t5=t3;
f_2671(t5,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
f_2606(2,t2,C_SCHEME_FALSE);}}

/* k2720 in k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cdadr */
t4=*((C_word*)lf[164]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_2671(t3,C_SCHEME_FALSE);}}

/* k2716 in k2720 in k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 632  cddadr */
t3=*((C_word*)lf[163]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_2671(t2,C_SCHEME_FALSE);}}

/* k2712 in k2716 in k2720 in k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2671(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_2671(t2,C_SCHEME_FALSE);}}

/* k2669 in k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2671,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 632  cadadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
f_2606(2,t2,C_SCHEME_FALSE);}}

/* k2676 in k2669 in k2636 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* compiler.scm: 632  g159 */
t3=((C_word*)t0)[3];
f_2628(t3,((C_word*)t0)[2],t1);}

/* g159 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2628,NULL,3,t0,t1,t2);}
/* compiler.scm: 634  process-lambda-documentation */
t3=C_retrieve(lf[162]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k2604 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* compiler.scm: 636  set-real-names! */
f_1956(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2607 in k2604 in k2601 in k2598 in k2595 in k2592 in k2589 in a2586 in k2580 in k2571 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_truep(C_retrieve(lf[27]))?(C_word)C_eqp(lf[159],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t2)){
/* compiler.scm: 638  expand-profile-lambda */
t3=C_retrieve(lf[161]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[159],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* compiler.scm: 599  unzip1 */
t4=C_retrieve(lf[157]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2508,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[123]),t1);}

/* k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 601  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k2559 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 601  append */
t2=*((C_word*)lf[155]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* compiler.scm: 602  set-real-names! */
f_1956(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 603  map */
t4=*((C_word*)lf[154]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2540 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2541,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2549,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_car(t3);
/* compiler.scm: 604  walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2113(t7,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k2547 in a2540 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2519 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2525,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 606  ##sys#canonicalize-body */
t6=C_retrieve(lf[153]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,t4,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* a2534 in k2519 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2535,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k2527 in k2519 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 606  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2523 in k2519 in k2512 in k2509 in k2506 in k2503 in k2497 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[152],((C_word*)t0)[2],t1));}

/* loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[136]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 574  cadar */
t4=*((C_word*)lf[151]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2406,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2406,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=t5;
f_2471(2,t6,t3);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 578  feature? */
t7=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}
else{
t6=t5;
f_2471(2,t6,C_SCHEME_FALSE);}}}

/* k2478 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2471(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 580  ##sys#canonicalize-extension-path */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[149]);}}

/* k2488 in k2478 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 579  ##sys#find-extension */
t2=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2469 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[45]))){
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 586  ##sys#extension-information */
t4=C_retrieve(lf[143]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t3=t2;
f_2433(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2433(t3,C_SCHEME_FALSE);}}
else{
/* compiler.scm: 582  compiler-warning */
t2=C_retrieve(lf[144]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[145],lf[146],((C_word*)t0)[2]);}}

/* k2443 in k2469 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[140],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* for-each */
t6=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_2433(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_2433(t2,C_SCHEME_FALSE);}}

/* a2458 in k2443 in k2469 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
/* ##sys#hash-table-set! */
t3=C_retrieve(lf[141]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,C_retrieve(lf[44]),t2,((C_word*)t0)[2]);}

/* k2455 in k2443 in k2469 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2433(t2,C_SCHEME_TRUE);}

/* k2431 in k2469 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2410(2,t2,C_SCHEME_UNDEFINED);}
else{
/* compiler.scm: 592  lookup-exports-file */
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2408 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler.scm: 593  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2385(t4,t2,t3);}

/* k2415 in k2408 in a2405 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2417,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[138],((C_word*)t0)[2],t1));}

/* a2399 in k2393 in loop in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
/* compiler.scm: 575  ##sys#do-the-right-thing */
t2=C_retrieve(lf[137]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2377 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 570  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2113(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2345 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[132]),t1);}

/* k2348 in k2345 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 564  hash-table-update! */
t5=C_retrieve(lf[130]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_retrieve(lf[88]),lf[131],t3,t4);}

/* a2360 in k2348 in k2345 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2354 in k2348 in k2345 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2355,3,t0,t1,t2);}
/* lset-union */
t3=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2351 in k2348 in k2345 in k2336 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[128]);}

/* k2303 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(C_word)C_i_assoc(t1,C_retrieve(lf[54]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2317,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 552  gensym */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[124]);}}

/* k2315 in k2303 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 553  alist-cons */
t3=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],t1,C_retrieve(lf[54]));}

/* k2319 in k2315 in k2303 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[17]));
t4=C_mutate((C_word*)lf[17]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve(lf[31]));
t6=C_mutate((C_word*)lf[31]+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[3]);}

/* k2278 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2232 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* compiler.scm: 533  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2113(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2239 in k2232 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* compiler.scm: 534  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2113(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2243 in k2239 in k2232 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2249,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_2249(2,t4,lf[115]);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* compiler.scm: 537  walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2113(t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2247 in k2243 in k2239 in k2232 in k2209 in k2191 in k2184 in k2181 in k2175 in k2148 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[114],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2136 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* compiler.scm: 506  ##sys#alias-global-hook */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2130 in walk in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_2022(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2022,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2026,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[59]))){
/* compiler.scm: 475  ##sys#hash-table-ref */
t7=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_retrieve(lf[58]),t2);}
else{
t7=t6;
f_2026(2,t7,C_SCHEME_FALSE);}}

/* k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
/* compiler.scm: 476  walk */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2113(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[57]))){
/* compiler.scm: 477  ##sys#hash-table-ref */
t3=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),((C_word*)t0)[2]);}
else{
t3=t2;
f_2039(2,t3,C_SCHEME_FALSE);}}}

/* k2037 in k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
if(C_truep(t1)){
/* compiler.scm: 479  walk */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2113(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[66]));
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 483  final-foreign-type */
t5=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t3=(C_word)C_i_assq(((C_word*)t0)[2],C_retrieve(lf[77]));
if(C_truep(t3)){
t4=(C_word)C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* compiler.scm: 491  final-foreign-type */
t6=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k2085 in k2037 in k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[108],t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 494  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2095 in k2085 in k2037 in k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 493  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2055 in k2037 in k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[104],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* compiler.scm: 486  finish-foreign-result */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t1,t4);}

/* k2065 in k2055 in k2037 in k2024 in resolve-atom in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler.scm: 485  foreign-type-convert-result */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unquotify in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1980,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[103]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(t2);
t8=t3;
f_1987(t8,(C_word)C_i_nullp(t7));}
else{
t7=t3;
f_1987(t7,C_SCHEME_FALSE);}}
else{
t6=t3;
f_1987(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1987(t4,C_SCHEME_FALSE);}}

/* k1985 in unquotify in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_1987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cadr(((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-real-names! in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_fcall f_1956(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1956,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1962,tmp=(C_word)a,a+=2,tmp);
/* compiler.scm: 462  for-each */
t5=*((C_word*)lf[102]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,t4,t2,t3);}

/* a1961 in set-real-names! in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1962,4,t0,t1,t2,t3);}
/* compiler.scm: 462  set-real-name! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* resolve in ##compiler#canonicalize-expression in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static C_word C_fcall f_1944(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
return((C_truep(t3)?(C_word)C_i_cdr(t3):t1));}

/* ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[53]))){
/* compiler.scm: 434  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[53]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 435  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[22]),C_SCHEME_END_OF_LIST);}}

/* k1937 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[53]+1,t1);
t3=((C_word*)t0)[2];
f_1880(2,t3,t2);}

/* k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* compiler.scm: 437  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[56]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 438  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1930 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[56]+1,t1);
t3=((C_word*)t0)[2];
f_1883(2,t3,t2);}

/* k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[58]))){
/* compiler.scm: 440  vector-fill! */
t3=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[58]),C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 441  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1923 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[58]+1,t1);
t3=((C_word*)t0)[2];
f_1886(2,t3,t2);}

/* k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 442  make-random-name */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[99]);}

/* k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 443  make-vector */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k1892 in k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 444  make-hash-table */
t4=C_retrieve(lf[96]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k1896 in k1892 in k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[44]))){
/* compiler.scm: 446  vector-fill! */
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[44]),C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 447  make-vector */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(997),C_SCHEME_END_OF_LIST);}}

/* k1916 in k1896 in k1892 in k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=((C_word*)t0)[2];
f_1901(2,t3,t2);}

/* k1899 in k1896 in k1892 in k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
if(C_truep(C_retrieve(lf[65]))){
/* compiler.scm: 449  vector-fill! */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[65]),C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler.scm: 450  make-vector */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}}

/* k1909 in k1899 in k1896 in k1892 in k1888 in k1884 in k1881 in k1878 in ##compiler#initialize-compiler in k1789 in k1785 in k1781 in k1777 in k1773 in k1769 in k1762 in k1759 in k1756 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[65]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[816] = {
{"toplevelcompiler.scm",(void*)C_compiler_toplevel},
{"f_1758compiler.scm",(void*)f_1758},
{"f_1761compiler.scm",(void*)f_1761},
{"f_1764compiler.scm",(void*)f_1764},
{"f_1771compiler.scm",(void*)f_1771},
{"f_1775compiler.scm",(void*)f_1775},
{"f_1779compiler.scm",(void*)f_1779},
{"f_1783compiler.scm",(void*)f_1783},
{"f_1787compiler.scm",(void*)f_1787},
{"f_1791compiler.scm",(void*)f_1791},
{"f_10098compiler.scm",(void*)f_10098},
{"f_11155compiler.scm",(void*)f_11155},
{"f_11158compiler.scm",(void*)f_11158},
{"f_11161compiler.scm",(void*)f_11161},
{"f_11164compiler.scm",(void*)f_11164},
{"f_11167compiler.scm",(void*)f_11167},
{"f_10955compiler.scm",(void*)f_10955},
{"f_10961compiler.scm",(void*)f_10961},
{"f_10188compiler.scm",(void*)f_10188},
{"f_10944compiler.scm",(void*)f_10944},
{"f_10941compiler.scm",(void*)f_10941},
{"f_10854compiler.scm",(void*)f_10854},
{"f_10918compiler.scm",(void*)f_10918},
{"f_10931compiler.scm",(void*)f_10931},
{"f_10912compiler.scm",(void*)f_10912},
{"f_10902compiler.scm",(void*)f_10902},
{"f_10875compiler.scm",(void*)f_10875},
{"f_10878compiler.scm",(void*)f_10878},
{"f_10826compiler.scm",(void*)f_10826},
{"f_10829compiler.scm",(void*)f_10829},
{"f_10783compiler.scm",(void*)f_10783},
{"f_10795compiler.scm",(void*)f_10795},
{"f_10786compiler.scm",(void*)f_10786},
{"f_10789compiler.scm",(void*)f_10789},
{"f_10663compiler.scm",(void*)f_10663},
{"f_10764compiler.scm",(void*)f_10764},
{"f_10752compiler.scm",(void*)f_10752},
{"f_10691compiler.scm",(void*)f_10691},
{"f_10697compiler.scm",(void*)f_10697},
{"f_10721compiler.scm",(void*)f_10721},
{"f_10713compiler.scm",(void*)f_10713},
{"f_10679compiler.scm",(void*)f_10679},
{"f_10622compiler.scm",(void*)f_10622},
{"f_10634compiler.scm",(void*)f_10634},
{"f_10638compiler.scm",(void*)f_10638},
{"f_10626compiler.scm",(void*)f_10626},
{"f_10438compiler.scm",(void*)f_10438},
{"f_10559compiler.scm",(void*)f_10559},
{"f_10565compiler.scm",(void*)f_10565},
{"f_10590compiler.scm",(void*)f_10590},
{"f_10571compiler.scm",(void*)f_10571},
{"f_10445compiler.scm",(void*)f_10445},
{"f_10550compiler.scm",(void*)f_10550},
{"f_10448compiler.scm",(void*)f_10448},
{"f_10451compiler.scm",(void*)f_10451},
{"f_10454compiler.scm",(void*)f_10454},
{"f_10492compiler.scm",(void*)f_10492},
{"f_10518compiler.scm",(void*)f_10518},
{"f_10499compiler.scm",(void*)f_10499},
{"f_10503compiler.scm",(void*)f_10503},
{"f_10476compiler.scm",(void*)f_10476},
{"f_10382compiler.scm",(void*)f_10382},
{"f_10391compiler.scm",(void*)f_10391},
{"f_10385compiler.scm",(void*)f_10385},
{"f_10366compiler.scm",(void*)f_10366},
{"f_10339compiler.scm",(void*)f_10339},
{"f_10322compiler.scm",(void*)f_10322},
{"f_10318compiler.scm",(void*)f_10318},
{"f_10311compiler.scm",(void*)f_10311},
{"f_10294compiler.scm",(void*)f_10294},
{"f_10290compiler.scm",(void*)f_10290},
{"f_10266compiler.scm",(void*)f_10266},
{"f_10246compiler.scm",(void*)f_10246},
{"f_10101compiler.scm",(void*)f_10101},
{"f_10105compiler.scm",(void*)f_10105},
{"f_10120compiler.scm",(void*)f_10120},
{"f_10130compiler.scm",(void*)f_10130},
{"f_10135compiler.scm",(void*)f_10135},
{"f_10180compiler.scm",(void*)f_10180},
{"f_10139compiler.scm",(void*)f_10139},
{"f_10145compiler.scm",(void*)f_10145},
{"f_10155compiler.scm",(void*)f_10155},
{"f_10967compiler.scm",(void*)f_10967},
{"f_10974compiler.scm",(void*)f_10974},
{"f_11029compiler.scm",(void*)f_11029},
{"f_10980compiler.scm",(void*)f_10980},
{"f_11006compiler.scm",(void*)f_11006},
{"f_10996compiler.scm",(void*)f_10996},
{"f_11061compiler.scm",(void*)f_11061},
{"f_11077compiler.scm",(void*)f_11077},
{"f_11084compiler.scm",(void*)f_11084},
{"f_11091compiler.scm",(void*)f_11091},
{"f_11065compiler.scm",(void*)f_11065},
{"f_11075compiler.scm",(void*)f_11075},
{"f_11047compiler.scm",(void*)f_11047},
{"f_11055compiler.scm",(void*)f_11055},
{"f_11093compiler.scm",(void*)f_11093},
{"f_11106compiler.scm",(void*)f_11106},
{"f_10089compiler.scm",(void*)f_10089},
{"f_10080compiler.scm",(void*)f_10080},
{"f_10071compiler.scm",(void*)f_10071},
{"f_10062compiler.scm",(void*)f_10062},
{"f_10053compiler.scm",(void*)f_10053},
{"f_10044compiler.scm",(void*)f_10044},
{"f_10035compiler.scm",(void*)f_10035},
{"f_10026compiler.scm",(void*)f_10026},
{"f_10017compiler.scm",(void*)f_10017},
{"f_10008compiler.scm",(void*)f_10008},
{"f_9999compiler.scm",(void*)f_9999},
{"f_9990compiler.scm",(void*)f_9990},
{"f_9981compiler.scm",(void*)f_9981},
{"f_9972compiler.scm",(void*)f_9972},
{"f_9963compiler.scm",(void*)f_9963},
{"f_9954compiler.scm",(void*)f_9954},
{"f_9945compiler.scm",(void*)f_9945},
{"f_9936compiler.scm",(void*)f_9936},
{"f_9927compiler.scm",(void*)f_9927},
{"f_9918compiler.scm",(void*)f_9918},
{"f_9909compiler.scm",(void*)f_9909},
{"f_9900compiler.scm",(void*)f_9900},
{"f_9891compiler.scm",(void*)f_9891},
{"f_9882compiler.scm",(void*)f_9882},
{"f_9873compiler.scm",(void*)f_9873},
{"f_9864compiler.scm",(void*)f_9864},
{"f_9855compiler.scm",(void*)f_9855},
{"f_9846compiler.scm",(void*)f_9846},
{"f_9837compiler.scm",(void*)f_9837},
{"f_9828compiler.scm",(void*)f_9828},
{"f_9822compiler.scm",(void*)f_9822},
{"f_9816compiler.scm",(void*)f_9816},
{"f_8582compiler.scm",(void*)f_8582},
{"f_9783compiler.scm",(void*)f_9783},
{"f_9786compiler.scm",(void*)f_9786},
{"f_9789compiler.scm",(void*)f_9789},
{"f_9792compiler.scm",(void*)f_9792},
{"f_9795compiler.scm",(void*)f_9795},
{"f_9810compiler.scm",(void*)f_9810},
{"f_9808compiler.scm",(void*)f_9808},
{"f_9798compiler.scm",(void*)f_9798},
{"f_9635compiler.scm",(void*)f_9635},
{"f_9641compiler.scm",(void*)f_9641},
{"f_8946compiler.scm",(void*)f_8946},
{"f_8965compiler.scm",(void*)f_8965},
{"f_8998compiler.scm",(void*)f_8998},
{"f_9525compiler.scm",(void*)f_9525},
{"f_9521compiler.scm",(void*)f_9521},
{"f_9514compiler.scm",(void*)f_9514},
{"f_9365compiler.scm",(void*)f_9365},
{"f_9371compiler.scm",(void*)f_9371},
{"f_9441compiler.scm",(void*)f_9441},
{"f_9471compiler.scm",(void*)f_9471},
{"f_9454compiler.scm",(void*)f_9454},
{"f_9458compiler.scm",(void*)f_9458},
{"f_9380compiler.scm",(void*)f_9380},
{"f_9427compiler.scm",(void*)f_9427},
{"f_9431compiler.scm",(void*)f_9431},
{"f_9407compiler.scm",(void*)f_9407},
{"f_9403compiler.scm",(void*)f_9403},
{"f_9094compiler.scm",(void*)f_9094},
{"f_9343compiler.scm",(void*)f_9343},
{"f_9098compiler.scm",(void*)f_9098},
{"f_9341compiler.scm",(void*)f_9341},
{"f_9101compiler.scm",(void*)f_9101},
{"f_9104compiler.scm",(void*)f_9104},
{"f_9110compiler.scm",(void*)f_9110},
{"f_9116compiler.scm",(void*)f_9116},
{"f_9122compiler.scm",(void*)f_9122},
{"f_9308compiler.scm",(void*)f_9308},
{"f_9311compiler.scm",(void*)f_9311},
{"f_9125compiler.scm",(void*)f_9125},
{"f_9284compiler.scm",(void*)f_9284},
{"f_9269compiler.scm",(void*)f_9269},
{"f_9265compiler.scm",(void*)f_9265},
{"f_9199compiler.scm",(void*)f_9199},
{"f_9224compiler.scm",(void*)f_9224},
{"f_9230compiler.scm",(void*)f_9230},
{"f_9241compiler.scm",(void*)f_9241},
{"f_9228compiler.scm",(void*)f_9228},
{"f_9210compiler.scm",(void*)f_9210},
{"f_9202compiler.scm",(void*)f_9202},
{"f_9187compiler.scm",(void*)f_9187},
{"f_9195compiler.scm",(void*)f_9195},
{"f_9148compiler.scm",(void*)f_9148},
{"f_9178compiler.scm",(void*)f_9178},
{"f_9170compiler.scm",(void*)f_9170},
{"f_9166compiler.scm",(void*)f_9166},
{"f_9162compiler.scm",(void*)f_9162},
{"f_9151compiler.scm",(void*)f_9151},
{"f_9019compiler.scm",(void*)f_9019},
{"f_9022compiler.scm",(void*)f_9022},
{"f_9074compiler.scm",(void*)f_9074},
{"f_9038compiler.scm",(void*)f_9038},
{"f_9067compiler.scm",(void*)f_9067},
{"f_9059compiler.scm",(void*)f_9059},
{"f_9004compiler.scm",(void*)f_9004},
{"f_8977compiler.scm",(void*)f_8977},
{"f_8983compiler.scm",(void*)f_8983},
{"f_9647compiler.scm",(void*)f_9647},
{"f_9654compiler.scm",(void*)f_9654},
{"f_9670compiler.scm",(void*)f_9670},
{"f_8612compiler.scm",(void*)f_8612},
{"f_8631compiler.scm",(void*)f_8631},
{"f_8910compiler.scm",(void*)f_8910},
{"f_8871compiler.scm",(void*)f_8871},
{"f_9686compiler.scm",(void*)f_9686},
{"f_9724compiler.scm",(void*)f_9724},
{"f_9750compiler.scm",(void*)f_9750},
{"f_9736compiler.scm",(void*)f_9736},
{"f_9715compiler.scm",(void*)f_9715},
{"f_9684compiler.scm",(void*)f_9684},
{"f_8884compiler.scm",(void*)f_8884},
{"f_8887compiler.scm",(void*)f_8887},
{"f_8898compiler.scm",(void*)f_8898},
{"f_8835compiler.scm",(void*)f_8835},
{"f_8727compiler.scm",(void*)f_8727},
{"f_8733compiler.scm",(void*)f_8733},
{"f_8745compiler.scm",(void*)f_8745},
{"f_8748compiler.scm",(void*)f_8748},
{"f_8751compiler.scm",(void*)f_8751},
{"f_8769compiler.scm",(void*)f_8769},
{"f_8776compiler.scm",(void*)f_8776},
{"f_8754compiler.scm",(void*)f_8754},
{"f_8757compiler.scm",(void*)f_8757},
{"f_8760compiler.scm",(void*)f_8760},
{"f_8721compiler.scm",(void*)f_8721},
{"f_8711compiler.scm",(void*)f_8711},
{"f_8694compiler.scm",(void*)f_8694},
{"f_8699compiler.scm",(void*)f_8699},
{"f_8652compiler.scm",(void*)f_8652},
{"f_8669compiler.scm",(void*)f_8669},
{"f_8656compiler.scm",(void*)f_8656},
{"f_8667compiler.scm",(void*)f_8667},
{"f_8642compiler.scm",(void*)f_8642},
{"f_8601compiler.scm",(void*)f_8601},
{"f_8610compiler.scm",(void*)f_8610},
{"f_8591compiler.scm",(void*)f_8591},
{"f_8596compiler.scm",(void*)f_8596},
{"f_8585compiler.scm",(void*)f_8585},
{"f_7057compiler.scm",(void*)f_7057},
{"f_7061compiler.scm",(void*)f_7061},
{"f_7811compiler.scm",(void*)f_7811},
{"f_7814compiler.scm",(void*)f_7814},
{"f_7818compiler.scm",(void*)f_7818},
{"f_7821compiler.scm",(void*)f_7821},
{"f_7834compiler.scm",(void*)f_7834},
{"f_8469compiler.scm",(void*)f_8469},
{"f_7838compiler.scm",(void*)f_7838},
{"f_8434compiler.scm",(void*)f_8434},
{"f_7845compiler.scm",(void*)f_7845},
{"f_8380compiler.scm",(void*)f_8380},
{"f_8383compiler.scm",(void*)f_8383},
{"f_8395compiler.scm",(void*)f_8395},
{"f_8389compiler.scm",(void*)f_8389},
{"f_7848compiler.scm",(void*)f_7848},
{"f_7851compiler.scm",(void*)f_7851},
{"f_8363compiler.scm",(void*)f_8363},
{"f_8355compiler.scm",(void*)f_8355},
{"f_8323compiler.scm",(void*)f_8323},
{"f_8329compiler.scm",(void*)f_8329},
{"f_7854compiler.scm",(void*)f_7854},
{"f_8285compiler.scm",(void*)f_8285},
{"f_8294compiler.scm",(void*)f_8294},
{"f_8297compiler.scm",(void*)f_8297},
{"f_7857compiler.scm",(void*)f_7857},
{"f_8186compiler.scm",(void*)f_8186},
{"f_8204compiler.scm",(void*)f_8204},
{"f_8247compiler.scm",(void*)f_8247},
{"f_8272compiler.scm",(void*)f_8272},
{"f_8268compiler.scm",(void*)f_8268},
{"f_8254compiler.scm",(void*)f_8254},
{"f_8257compiler.scm",(void*)f_8257},
{"f_8208compiler.scm",(void*)f_8208},
{"f_8214compiler.scm",(void*)f_8214},
{"f_7860compiler.scm",(void*)f_7860},
{"f_8164compiler.scm",(void*)f_8164},
{"f_8150compiler.scm",(void*)f_8150},
{"f_8157compiler.scm",(void*)f_8157},
{"f_8138compiler.scm",(void*)f_8138},
{"f_8123compiler.scm",(void*)f_8123},
{"f_7863compiler.scm",(void*)f_7863},
{"f_8035compiler.scm",(void*)f_8035},
{"f_8109compiler.scm",(void*)f_8109},
{"f_8041compiler.scm",(void*)f_8041},
{"f_8099compiler.scm",(void*)f_8099},
{"f_8091compiler.scm",(void*)f_8091},
{"f_8087compiler.scm",(void*)f_8087},
{"f_8044compiler.scm",(void*)f_8044},
{"f_8047compiler.scm",(void*)f_8047},
{"f_7866compiler.scm",(void*)f_7866},
{"f_7894compiler.scm",(void*)f_7894},
{"f_7915compiler.scm",(void*)f_7915},
{"f_7936compiler.scm",(void*)f_7936},
{"f_7942compiler.scm",(void*)f_7942},
{"f_7869compiler.scm",(void*)f_7869},
{"f_7875compiler.scm",(void*)f_7875},
{"f_7879compiler.scm",(void*)f_7879},
{"f_7824compiler.scm",(void*)f_7824},
{"f_7828compiler.scm",(void*)f_7828},
{"f_7831compiler.scm",(void*)f_7831},
{"f_7786compiler.scm",(void*)f_7786},
{"f_7796compiler.scm",(void*)f_7796},
{"f_7804compiler.scm",(void*)f_7804},
{"f_7772compiler.scm",(void*)f_7772},
{"f_7780compiler.scm",(void*)f_7780},
{"f_7651compiler.scm",(void*)f_7651},
{"f_7657compiler.scm",(void*)f_7657},
{"f_7070compiler.scm",(void*)f_7070},
{"f_7092compiler.scm",(void*)f_7092},
{"f_7613compiler.scm",(void*)f_7613},
{"f_7607compiler.scm",(void*)f_7607},
{"f_7580compiler.scm",(void*)f_7580},
{"f_7589compiler.scm",(void*)f_7589},
{"f_7574compiler.scm",(void*)f_7574},
{"f_7499compiler.scm",(void*)f_7499},
{"f_7528compiler.scm",(void*)f_7528},
{"f_7543compiler.scm",(void*)f_7543},
{"f_7547compiler.scm",(void*)f_7547},
{"f_7534compiler.scm",(void*)f_7534},
{"f_7502compiler.scm",(void*)f_7502},
{"f_7525compiler.scm",(void*)f_7525},
{"f_7505compiler.scm",(void*)f_7505},
{"f_7508compiler.scm",(void*)f_7508},
{"f_7511compiler.scm",(void*)f_7511},
{"f_7389compiler.scm",(void*)f_7389},
{"f_7481compiler.scm",(void*)f_7481},
{"f_7396compiler.scm",(void*)f_7396},
{"f_7471compiler.scm",(void*)f_7471},
{"f_7475compiler.scm",(void*)f_7475},
{"f_7399compiler.scm",(void*)f_7399},
{"f_7402compiler.scm",(void*)f_7402},
{"f_7456compiler.scm",(void*)f_7456},
{"f_7405compiler.scm",(void*)f_7405},
{"f_7408compiler.scm",(void*)f_7408},
{"f_7441compiler.scm",(void*)f_7441},
{"f_7411compiler.scm",(void*)f_7411},
{"f_7438compiler.scm",(void*)f_7438},
{"f_7414compiler.scm",(void*)f_7414},
{"f_7345compiler.scm",(void*)f_7345},
{"f_7364compiler.scm",(void*)f_7364},
{"f_7349compiler.scm",(void*)f_7349},
{"f_7362compiler.scm",(void*)f_7362},
{"f_7353compiler.scm",(void*)f_7353},
{"f_7278compiler.scm",(void*)f_7278},
{"f_7283compiler.scm",(void*)f_7283},
{"f_7310compiler.scm",(void*)f_7310},
{"f_7313compiler.scm",(void*)f_7313},
{"f_7316compiler.scm",(void*)f_7316},
{"f_7301compiler.scm",(void*)f_7301},
{"f_7206compiler.scm",(void*)f_7206},
{"f_7254compiler.scm",(void*)f_7254},
{"f_7217compiler.scm",(void*)f_7217},
{"f_7236compiler.scm",(void*)f_7236},
{"f_7183compiler.scm",(void*)f_7183},
{"f_7186compiler.scm",(void*)f_7186},
{"f_7147compiler.scm",(void*)f_7147},
{"f_7104compiler.scm",(void*)f_7104},
{"f_7135compiler.scm",(void*)f_7135},
{"f_7663compiler.scm",(void*)f_7663},
{"f_7676compiler.scm",(void*)f_7676},
{"f_7736compiler.scm",(void*)f_7736},
{"f_7685compiler.scm",(void*)f_7685},
{"f_7688compiler.scm",(void*)f_7688},
{"f_7691compiler.scm",(void*)f_7691},
{"f_7766compiler.scm",(void*)f_7766},
{"f_7063compiler.scm",(void*)f_7063},
{"f_7048compiler.scm",(void*)f_7048},
{"f_7039compiler.scm",(void*)f_7039},
{"f_7030compiler.scm",(void*)f_7030},
{"f_7021compiler.scm",(void*)f_7021},
{"f_7012compiler.scm",(void*)f_7012},
{"f_7003compiler.scm",(void*)f_7003},
{"f_6994compiler.scm",(void*)f_6994},
{"f_6985compiler.scm",(void*)f_6985},
{"f_6976compiler.scm",(void*)f_6976},
{"f_6967compiler.scm",(void*)f_6967},
{"f_6961compiler.scm",(void*)f_6961},
{"f_6955compiler.scm",(void*)f_6955},
{"f_6280compiler.scm",(void*)f_6280},
{"f_6927compiler.scm",(void*)f_6927},
{"f_6842compiler.scm",(void*)f_6842},
{"f_6848compiler.scm",(void*)f_6848},
{"f_6868compiler.scm",(void*)f_6868},
{"f_6886compiler.scm",(void*)f_6886},
{"f_6895compiler.scm",(void*)f_6895},
{"f_6921compiler.scm",(void*)f_6921},
{"f_6909compiler.scm",(void*)f_6909},
{"f_6862compiler.scm",(void*)f_6862},
{"f_6826compiler.scm",(void*)f_6826},
{"f_6832compiler.scm",(void*)f_6832},
{"f_6701compiler.scm",(void*)f_6701},
{"f_6705compiler.scm",(void*)f_6705},
{"f_6708compiler.scm",(void*)f_6708},
{"f_6762compiler.scm",(void*)f_6762},
{"f_6758compiler.scm",(void*)f_6758},
{"f_6754compiler.scm",(void*)f_6754},
{"f_6733compiler.scm",(void*)f_6733},
{"f_6739compiler.scm",(void*)f_6739},
{"f_6750compiler.scm",(void*)f_6750},
{"f_6743compiler.scm",(void*)f_6743},
{"f_6731compiler.scm",(void*)f_6731},
{"f_6327compiler.scm",(void*)f_6327},
{"f_6349compiler.scm",(void*)f_6349},
{"f_6615compiler.scm",(void*)f_6615},
{"f_6772compiler.scm",(void*)f_6772},
{"f_6775compiler.scm",(void*)f_6775},
{"f_6820compiler.scm",(void*)f_6820},
{"f_6816compiler.scm",(void*)f_6816},
{"f_6812compiler.scm",(void*)f_6812},
{"f_6808compiler.scm",(void*)f_6808},
{"f_6580compiler.scm",(void*)f_6580},
{"f_6606compiler.scm",(void*)f_6606},
{"f_6530compiler.scm",(void*)f_6530},
{"f_6539compiler.scm",(void*)f_6539},
{"f_6567compiler.scm",(void*)f_6567},
{"f_6563compiler.scm",(void*)f_6563},
{"f_6517compiler.scm",(void*)f_6517},
{"f_6455compiler.scm",(void*)f_6455},
{"f_6478compiler.scm",(void*)f_6478},
{"f_6492compiler.scm",(void*)f_6492},
{"f_6361compiler.scm",(void*)f_6361},
{"f_6364compiler.scm",(void*)f_6364},
{"f_6440compiler.scm",(void*)f_6440},
{"f_6436compiler.scm",(void*)f_6436},
{"f_6432compiler.scm",(void*)f_6432},
{"f_6405compiler.scm",(void*)f_6405},
{"f_6416compiler.scm",(void*)f_6416},
{"f_6420compiler.scm",(void*)f_6420},
{"f_6399compiler.scm",(void*)f_6399},
{"f_6365compiler.scm",(void*)f_6365},
{"f_6376compiler.scm",(void*)f_6376},
{"f_6283compiler.scm",(void*)f_6283},
{"f_6287compiler.scm",(void*)f_6287},
{"f_6310compiler.scm",(void*)f_6310},
{"f_6321compiler.scm",(void*)f_6321},
{"f_6304compiler.scm",(void*)f_6304},
{"f_6190compiler.scm",(void*)f_6190},
{"f_6222compiler.scm",(void*)f_6222},
{"f_6241compiler.scm",(void*)f_6241},
{"f_6264compiler.scm",(void*)f_6264},
{"f_6247compiler.scm",(void*)f_6247},
{"f_6193compiler.scm",(void*)f_6193},
{"f_6199compiler.scm",(void*)f_6199},
{"f_6209compiler.scm",(void*)f_6209},
{"f_6109compiler.scm",(void*)f_6109},
{"f_6113compiler.scm",(void*)f_6113},
{"f_6116compiler.scm",(void*)f_6116},
{"f_6119compiler.scm",(void*)f_6119},
{"f_6135compiler.scm",(void*)f_6135},
{"f_6122compiler.scm",(void*)f_6122},
{"f_6125compiler.scm",(void*)f_6125},
{"f_6128compiler.scm",(void*)f_6128},
{"f_6072compiler.scm",(void*)f_6072},
{"f_6095compiler.scm",(void*)f_6095},
{"f_6082compiler.scm",(void*)f_6082},
{"f_6085compiler.scm",(void*)f_6085},
{"f_6088compiler.scm",(void*)f_6088},
{"f_6035compiler.scm",(void*)f_6035},
{"f_6058compiler.scm",(void*)f_6058},
{"f_6045compiler.scm",(void*)f_6045},
{"f_6048compiler.scm",(void*)f_6048},
{"f_6051compiler.scm",(void*)f_6051},
{"f_5990compiler.scm",(void*)f_5990},
{"f_5997compiler.scm",(void*)f_5997},
{"f_6003compiler.scm",(void*)f_6003},
{"f_5945compiler.scm",(void*)f_5945},
{"f_5952compiler.scm",(void*)f_5952},
{"f_5958compiler.scm",(void*)f_5958},
{"f_5791compiler.scm",(void*)f_5791},
{"f_5939compiler.scm",(void*)f_5939},
{"f_5795compiler.scm",(void*)f_5795},
{"f_5798compiler.scm",(void*)f_5798},
{"f_5801compiler.scm",(void*)f_5801},
{"f_5804compiler.scm",(void*)f_5804},
{"f_5807compiler.scm",(void*)f_5807},
{"f_5933compiler.scm",(void*)f_5933},
{"f_5817compiler.scm",(void*)f_5817},
{"f_5908compiler.scm",(void*)f_5908},
{"f_5916compiler.scm",(void*)f_5916},
{"f_5820compiler.scm",(void*)f_5820},
{"f_5860compiler.scm",(void*)f_5860},
{"f_5863compiler.scm",(void*)f_5863},
{"f_5882compiler.scm",(void*)f_5882},
{"f_5878compiler.scm",(void*)f_5878},
{"f_5874compiler.scm",(void*)f_5874},
{"f_5853compiler.scm",(void*)f_5853},
{"f_5843compiler.scm",(void*)f_5843},
{"f_5831compiler.scm",(void*)f_5831},
{"f_5782compiler.scm",(void*)f_5782},
{"f_5773compiler.scm",(void*)f_5773},
{"f_5764compiler.scm",(void*)f_5764},
{"f_5755compiler.scm",(void*)f_5755},
{"f_5746compiler.scm",(void*)f_5746},
{"f_5737compiler.scm",(void*)f_5737},
{"f_5728compiler.scm",(void*)f_5728},
{"f_5719compiler.scm",(void*)f_5719},
{"f_5710compiler.scm",(void*)f_5710},
{"f_5701compiler.scm",(void*)f_5701},
{"f_5692compiler.scm",(void*)f_5692},
{"f_5683compiler.scm",(void*)f_5683},
{"f_5674compiler.scm",(void*)f_5674},
{"f_5665compiler.scm",(void*)f_5665},
{"f_5656compiler.scm",(void*)f_5656},
{"f_5647compiler.scm",(void*)f_5647},
{"f_5641compiler.scm",(void*)f_5641},
{"f_5635compiler.scm",(void*)f_5635},
{"f_4690compiler.scm",(void*)f_4690},
{"f_4744compiler.scm",(void*)f_4744},
{"f_4748compiler.scm",(void*)f_4748},
{"f_5604compiler.scm",(void*)f_5604},
{"f_5614compiler.scm",(void*)f_5614},
{"f_5609compiler.scm",(void*)f_5609},
{"f_5576compiler.scm",(void*)f_5576},
{"f_5582compiler.scm",(void*)f_5582},
{"f_5558compiler.scm",(void*)f_5558},
{"f_5562compiler.scm",(void*)f_5562},
{"f_5530compiler.scm",(void*)f_5530},
{"f_5537compiler.scm",(void*)f_5537},
{"f_5513compiler.scm",(void*)f_5513},
{"f_5439compiler.scm",(void*)f_5439},
{"f_5443compiler.scm",(void*)f_5443},
{"f_5426compiler.scm",(void*)f_5426},
{"f_5418compiler.scm",(void*)f_5418},
{"f_5422compiler.scm",(void*)f_5422},
{"f_5263compiler.scm",(void*)f_5263},
{"f_5373compiler.scm",(void*)f_5373},
{"f_5362compiler.scm",(void*)f_5362},
{"f_5366compiler.scm",(void*)f_5366},
{"f_5333compiler.scm",(void*)f_5333},
{"f_5308compiler.scm",(void*)f_5308},
{"f_5283compiler.scm",(void*)f_5283},
{"f_5250compiler.scm",(void*)f_5250},
{"f_5202compiler.scm",(void*)f_5202},
{"f_5211compiler.scm",(void*)f_5211},
{"f_5209compiler.scm",(void*)f_5209},
{"f_5112compiler.scm",(void*)f_5112},
{"f_5090compiler.scm",(void*)f_5090},
{"f_5094compiler.scm",(void*)f_5094},
{"f_5063compiler.scm",(void*)f_5063},
{"f_5067compiler.scm",(void*)f_5067},
{"f_5049compiler.scm",(void*)f_5049},
{"f_5053compiler.scm",(void*)f_5053},
{"f_5028compiler.scm",(void*)f_5028},
{"f_5014compiler.scm",(void*)f_5014},
{"f_4931compiler.scm",(void*)f_4931},
{"f_4914compiler.scm",(void*)f_4914},
{"f_4918compiler.scm",(void*)f_4918},
{"f_4885compiler.scm",(void*)f_4885},
{"f_4860compiler.scm",(void*)f_4860},
{"f_4813compiler.scm",(void*)f_4813},
{"f_4843compiler.scm",(void*)f_4843},
{"f_4819compiler.scm",(void*)f_4819},
{"f_4822compiler.scm",(void*)f_4822},
{"f_4829compiler.scm",(void*)f_4829},
{"f_4825compiler.scm",(void*)f_4825},
{"f_4763compiler.scm",(void*)f_4763},
{"f_4766compiler.scm",(void*)f_4766},
{"f_4800compiler.scm",(void*)f_4800},
{"f_4794compiler.scm",(void*)f_4794},
{"f_4775compiler.scm",(void*)f_4775},
{"f_4784compiler.scm",(void*)f_4784},
{"f_4792compiler.scm",(void*)f_4792},
{"f_4778compiler.scm",(void*)f_4778},
{"f_4782compiler.scm",(void*)f_4782},
{"f_4754compiler.scm",(void*)f_4754},
{"f_4693compiler.scm",(void*)f_4693},
{"f_4716compiler.scm",(void*)f_4716},
{"f_4706compiler.scm",(void*)f_4706},
{"f_1941compiler.scm",(void*)f_1941},
{"f_4685compiler.scm",(void*)f_4685},
{"f_4648compiler.scm",(void*)f_4648},
{"f_4651compiler.scm",(void*)f_4651},
{"f_4666compiler.scm",(void*)f_4666},
{"f_4675compiler.scm",(void*)f_4675},
{"f_4679compiler.scm",(void*)f_4679},
{"f_4662compiler.scm",(void*)f_4662},
{"f_4635compiler.scm",(void*)f_4635},
{"f_4641compiler.scm",(void*)f_4641},
{"f_2113compiler.scm",(void*)f_2113},
{"f_2150compiler.scm",(void*)f_2150},
{"f_4496compiler.scm",(void*)f_4496},
{"f_4611compiler.scm",(void*)f_4611},
{"f_4511compiler.scm",(void*)f_4511},
{"f_4598compiler.scm",(void*)f_4598},
{"f_4520compiler.scm",(void*)f_4520},
{"f_4523compiler.scm",(void*)f_4523},
{"f_4532compiler.scm",(void*)f_4532},
{"f_4554compiler.scm",(void*)f_4554},
{"f_4547compiler.scm",(void*)f_4547},
{"f_4499compiler.scm",(void*)f_4499},
{"f_4502compiler.scm",(void*)f_4502},
{"f_2177compiler.scm",(void*)f_2177},
{"f_2183compiler.scm",(void*)f_2183},
{"f_4478compiler.scm",(void*)f_4478},
{"f_2186compiler.scm",(void*)f_2186},
{"f_2193compiler.scm",(void*)f_2193},
{"f_2202compiler.scm",(void*)f_2202},
{"f_2211compiler.scm",(void*)f_2211},
{"f_2338compiler.scm",(void*)f_2338},
{"f_4398compiler.scm",(void*)f_4398},
{"f_4404compiler.scm",(void*)f_4404},
{"f_4309compiler.scm",(void*)f_4309},
{"f_4369compiler.scm",(void*)f_4369},
{"f_4269compiler.scm",(void*)f_4269},
{"f_4273compiler.scm",(void*)f_4273},
{"f_4279compiler.scm",(void*)f_4279},
{"f_4293compiler.scm",(void*)f_4293},
{"f_4282compiler.scm",(void*)f_4282},
{"f_3905compiler.scm",(void*)f_3905},
{"f_4253compiler.scm",(void*)f_4253},
{"f_3927compiler.scm",(void*)f_3927},
{"f_4218compiler.scm",(void*)f_4218},
{"f_3930compiler.scm",(void*)f_3930},
{"f_3941compiler.scm",(void*)f_3941},
{"f_4168compiler.scm",(void*)f_4168},
{"f_4212compiler.scm",(void*)f_4212},
{"f_4208compiler.scm",(void*)f_4208},
{"f_4204compiler.scm",(void*)f_4204},
{"f_4192compiler.scm",(void*)f_4192},
{"f_3961compiler.scm",(void*)f_3961},
{"f_4040compiler.scm",(void*)f_4040},
{"f_4017compiler.scm",(void*)f_4017},
{"f_4012compiler.scm",(void*)f_4012},
{"f_3975compiler.scm",(void*)f_3975},
{"f_3965compiler.scm",(void*)f_3965},
{"f_3949compiler.scm",(void*)f_3949},
{"f_3937compiler.scm",(void*)f_3937},
{"f_3895compiler.scm",(void*)f_3895},
{"f_3872compiler.scm",(void*)f_3872},
{"f_3870compiler.scm",(void*)f_3870},
{"f_3799compiler.scm",(void*)f_3799},
{"f_3817compiler.scm",(void*)f_3817},
{"f_3839compiler.scm",(void*)f_3839},
{"f_3845compiler.scm",(void*)f_3845},
{"f_3823compiler.scm",(void*)f_3823},
{"f_3830compiler.scm",(void*)f_3830},
{"f_3805compiler.scm",(void*)f_3805},
{"f_3811compiler.scm",(void*)f_3811},
{"f_3797compiler.scm",(void*)f_3797},
{"f_3726compiler.scm",(void*)f_3726},
{"f_3737compiler.scm",(void*)f_3737},
{"f_3783compiler.scm",(void*)f_3783},
{"f_3747compiler.scm",(void*)f_3747},
{"f_3750compiler.scm",(void*)f_3750},
{"f_3753compiler.scm",(void*)f_3753},
{"f_3757compiler.scm",(void*)f_3757},
{"f_3740compiler.scm",(void*)f_3740},
{"f_3665compiler.scm",(void*)f_3665},
{"f_3669compiler.scm",(void*)f_3669},
{"f_3707compiler.scm",(void*)f_3707},
{"f_3673compiler.scm",(void*)f_3673},
{"f_3687compiler.scm",(void*)f_3687},
{"f_3685compiler.scm",(void*)f_3685},
{"f_3647compiler.scm",(void*)f_3647},
{"f_3655compiler.scm",(void*)f_3655},
{"f_3520compiler.scm",(void*)f_3520},
{"f_3523compiler.scm",(void*)f_3523},
{"f_3529compiler.scm",(void*)f_3529},
{"f_3608compiler.scm",(void*)f_3608},
{"f_3585compiler.scm",(void*)f_3585},
{"f_3560compiler.scm",(void*)f_3560},
{"f_3568compiler.scm",(void*)f_3568},
{"f_3556compiler.scm",(void*)f_3556},
{"f_3552compiler.scm",(void*)f_3552},
{"f_3544compiler.scm",(void*)f_3544},
{"f_3445compiler.scm",(void*)f_3445},
{"f_3454compiler.scm",(void*)f_3454},
{"f_3493compiler.scm",(void*)f_3493},
{"f_3485compiler.scm",(void*)f_3485},
{"f_3457compiler.scm",(void*)f_3457},
{"f_3477compiler.scm",(void*)f_3477},
{"f_3469compiler.scm",(void*)f_3469},
{"f_3425compiler.scm",(void*)f_3425},
{"f_3371compiler.scm",(void*)f_3371},
{"f_3374compiler.scm",(void*)f_3374},
{"f_3377compiler.scm",(void*)f_3377},
{"f_3381compiler.scm",(void*)f_3381},
{"f_3385compiler.scm",(void*)f_3385},
{"f_3304compiler.scm",(void*)f_3304},
{"f_3316compiler.scm",(void*)f_3316},
{"f_3289compiler.scm",(void*)f_3289},
{"f_3276compiler.scm",(void*)f_3276},
{"f_3263compiler.scm",(void*)f_3263},
{"f_3250compiler.scm",(void*)f_3250},
{"f_3237compiler.scm",(void*)f_3237},
{"f_3170compiler.scm",(void*)f_3170},
{"f_3189compiler.scm",(void*)f_3189},
{"f_3216compiler.scm",(void*)f_3216},
{"f_3220compiler.scm",(void*)f_3220},
{"f_3209compiler.scm",(void*)f_3209},
{"f_3183compiler.scm",(void*)f_3183},
{"f_3157compiler.scm",(void*)f_3157},
{"f_3142compiler.scm",(void*)f_3142},
{"f_3115compiler.scm",(void*)f_3115},
{"f_3119compiler.scm",(void*)f_3119},
{"f_3094compiler.scm",(void*)f_3094},
{"f_3065compiler.scm",(void*)f_3065},
{"f_3069compiler.scm",(void*)f_3069},
{"f_3036compiler.scm",(void*)f_3036},
{"f_3040compiler.scm",(void*)f_3040},
{"f_2862compiler.scm",(void*)f_2862},
{"f_2871compiler.scm",(void*)f_2871},
{"f_2874compiler.scm",(void*)f_2874},
{"f_2982compiler.scm",(void*)f_2982},
{"f_3011compiler.scm",(void*)f_3011},
{"f_3015compiler.scm",(void*)f_3015},
{"f_2985compiler.scm",(void*)f_2985},
{"f_2991compiler.scm",(void*)f_2991},
{"f_3004compiler.scm",(void*)f_3004},
{"f_2994compiler.scm",(void*)f_2994},
{"f_2877compiler.scm",(void*)f_2877},
{"f_2972compiler.scm",(void*)f_2972},
{"f_2880compiler.scm",(void*)f_2880},
{"f_2935compiler.scm",(void*)f_2935},
{"f_2966compiler.scm",(void*)f_2966},
{"f_2958compiler.scm",(void*)f_2958},
{"f_2892compiler.scm",(void*)f_2892},
{"f_2923compiler.scm",(void*)f_2923},
{"f_2911compiler.scm",(void*)f_2911},
{"f_2824compiler.scm",(void*)f_2824},
{"f_2850compiler.scm",(void*)f_2850},
{"f_2827compiler.scm",(void*)f_2827},
{"f_2842compiler.scm",(void*)f_2842},
{"f_2840compiler.scm",(void*)f_2840},
{"f_2830compiler.scm",(void*)f_2830},
{"f_2833compiler.scm",(void*)f_2833},
{"f_2573compiler.scm",(void*)f_2573},
{"f_2774compiler.scm",(void*)f_2774},
{"f_2785compiler.scm",(void*)f_2785},
{"f_2779compiler.scm",(void*)f_2779},
{"f_2582compiler.scm",(void*)f_2582},
{"f_2587compiler.scm",(void*)f_2587},
{"f_2591compiler.scm",(void*)f_2591},
{"f_2771compiler.scm",(void*)f_2771},
{"f_2594compiler.scm",(void*)f_2594},
{"f_2763compiler.scm",(void*)f_2763},
{"f_2597compiler.scm",(void*)f_2597},
{"f_2600compiler.scm",(void*)f_2600},
{"f_2761compiler.scm",(void*)f_2761},
{"f_2754compiler.scm",(void*)f_2754},
{"f_2603compiler.scm",(void*)f_2603},
{"f_2638compiler.scm",(void*)f_2638},
{"f_2722compiler.scm",(void*)f_2722},
{"f_2718compiler.scm",(void*)f_2718},
{"f_2714compiler.scm",(void*)f_2714},
{"f_2671compiler.scm",(void*)f_2671},
{"f_2678compiler.scm",(void*)f_2678},
{"f_2628compiler.scm",(void*)f_2628},
{"f_2606compiler.scm",(void*)f_2606},
{"f_2609compiler.scm",(void*)f_2609},
{"f_2499compiler.scm",(void*)f_2499},
{"f_2505compiler.scm",(void*)f_2505},
{"f_2508compiler.scm",(void*)f_2508},
{"f_2561compiler.scm",(void*)f_2561},
{"f_2511compiler.scm",(void*)f_2511},
{"f_2514compiler.scm",(void*)f_2514},
{"f_2541compiler.scm",(void*)f_2541},
{"f_2549compiler.scm",(void*)f_2549},
{"f_2521compiler.scm",(void*)f_2521},
{"f_2535compiler.scm",(void*)f_2535},
{"f_2529compiler.scm",(void*)f_2529},
{"f_2525compiler.scm",(void*)f_2525},
{"f_2385compiler.scm",(void*)f_2385},
{"f_2395compiler.scm",(void*)f_2395},
{"f_2406compiler.scm",(void*)f_2406},
{"f_2480compiler.scm",(void*)f_2480},
{"f_2490compiler.scm",(void*)f_2490},
{"f_2471compiler.scm",(void*)f_2471},
{"f_2445compiler.scm",(void*)f_2445},
{"f_2459compiler.scm",(void*)f_2459},
{"f_2457compiler.scm",(void*)f_2457},
{"f_2433compiler.scm",(void*)f_2433},
{"f_2410compiler.scm",(void*)f_2410},
{"f_2417compiler.scm",(void*)f_2417},
{"f_2400compiler.scm",(void*)f_2400},
{"f_2379compiler.scm",(void*)f_2379},
{"f_2347compiler.scm",(void*)f_2347},
{"f_2350compiler.scm",(void*)f_2350},
{"f_2361compiler.scm",(void*)f_2361},
{"f_2355compiler.scm",(void*)f_2355},
{"f_2353compiler.scm",(void*)f_2353},
{"f_2305compiler.scm",(void*)f_2305},
{"f_2317compiler.scm",(void*)f_2317},
{"f_2321compiler.scm",(void*)f_2321},
{"f_2280compiler.scm",(void*)f_2280},
{"f_2234compiler.scm",(void*)f_2234},
{"f_2241compiler.scm",(void*)f_2241},
{"f_2245compiler.scm",(void*)f_2245},
{"f_2249compiler.scm",(void*)f_2249},
{"f_2138compiler.scm",(void*)f_2138},
{"f_2132compiler.scm",(void*)f_2132},
{"f_2022compiler.scm",(void*)f_2022},
{"f_2026compiler.scm",(void*)f_2026},
{"f_2039compiler.scm",(void*)f_2039},
{"f_2087compiler.scm",(void*)f_2087},
{"f_2097compiler.scm",(void*)f_2097},
{"f_2057compiler.scm",(void*)f_2057},
{"f_2067compiler.scm",(void*)f_2067},
{"f_1980compiler.scm",(void*)f_1980},
{"f_1987compiler.scm",(void*)f_1987},
{"f_1956compiler.scm",(void*)f_1956},
{"f_1962compiler.scm",(void*)f_1962},
{"f_1944compiler.scm",(void*)f_1944},
{"f_1876compiler.scm",(void*)f_1876},
{"f_1939compiler.scm",(void*)f_1939},
{"f_1880compiler.scm",(void*)f_1880},
{"f_1932compiler.scm",(void*)f_1932},
{"f_1883compiler.scm",(void*)f_1883},
{"f_1925compiler.scm",(void*)f_1925},
{"f_1886compiler.scm",(void*)f_1886},
{"f_1890compiler.scm",(void*)f_1890},
{"f_1894compiler.scm",(void*)f_1894},
{"f_1898compiler.scm",(void*)f_1898},
{"f_1918compiler.scm",(void*)f_1918},
{"f_1901compiler.scm",(void*)f_1901},
{"f_1911compiler.scm",(void*)f_1911},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
