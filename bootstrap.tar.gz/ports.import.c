/* Generated from ports.import.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:23
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: ports.import.scm -optimize-level 2 -include-path . -include-path . -feature chicken-compile-shared -dynamic -output-file ports.import.c
   used units: library eval data_structures ports extras srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[3];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15)
static void C_ccall f_15(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18)
static void C_ccall f_18(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21)
static void C_ccall f_21(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_24)
static void C_ccall f_24(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_27)
static void C_ccall f_27(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_30)
static void C_ccall f_30(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_33)
static void C_ccall f_33(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(215)){
C_save(t1);
C_rereclaim2(215*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,3);
lf[0]=C_h_intern(&lf[0],29,"\003sysregister-primitive-module");
lf[1]=C_h_intern(&lf[1],5,"ports");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026call-with-input-string\376\003\000\000\002\376\001\000\000\027call-with-output-string\376\003\000\000\002\376\001\000\000\017make-"
"input-port\376\003\000\000\002\376\001\000\000\020make-output-port\376\003\000\000\002\376\001\000\000\015port-for-each\376\003\000\000\002\376\001\000\000\010port-map\376\003\000"
"\000\002\376\001\000\000\011port-fold\376\003\000\000\002\376\001\000\000\023make-broadcast-port\376\003\000\000\002\376\001\000\000\026make-concatenated-port\376\003\000"
"\000\002\376\001\000\000\031with-error-output-to-port\376\003\000\000\002\376\001\000\000\024with-input-from-port\376\003\000\000\002\376\001\000\000\026with-inp"
"ut-from-string\376\003\000\000\002\376\001\000\000\023with-output-to-port\376\003\000\000\002\376\001\000\000\025with-output-to-string\376\003\000\000\002\376"
"\001\000\000\031with-error-output-to-port\376\377\016");
C_register_lf2(lf,3,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k13 */
static void C_ccall f_15(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k16 in k13 */
static void C_ccall f_18(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k19 in k16 in k13 */
static void C_ccall f_21(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_24,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k22 in k19 in k16 in k13 */
static void C_ccall f_24(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_24,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_27,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k25 in k22 in k19 in k16 in k13 */
static void C_ccall f_27(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_27,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_30,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k28 in k25 in k22 in k19 in k16 in k13 */
static void C_ccall f_30(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_30,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_33,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("ports.import.scm: 27   ##sys#register-primitive-module");
t3=C_retrieve(lf[0]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[1],lf[2]);}

/* k31 in k28 in k25 in k22 in k19 in k16 in k13 */
static void C_ccall f_33(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[9] = {
{"toplevelports.import.scm",(void*)C_toplevel},
{"f_15ports.import.scm",(void*)f_15},
{"f_18ports.import.scm",(void*)f_18},
{"f_21ports.import.scm",(void*)f_21},
{"f_24ports.import.scm",(void*)f_24},
{"f_27ports.import.scm",(void*)f_27},
{"f_30ports.import.scm",(void*)f_30},
{"f_33ports.import.scm",(void*)f_33},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
