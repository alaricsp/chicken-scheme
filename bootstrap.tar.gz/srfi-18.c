/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-29 11:59
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: srfi-18.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file srfi-18.c
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,99,111,109,112,117,116,101,45,116,105,109,101,45,108,105,109,105,116,32,116,109,54,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,99,117,114,114,101,110,116,45,116,105,109,101,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,20),40,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,50,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,116,105,109,101,45,62,109,105,108,108,105,115,101,99,111,110,100,115,32,116,109,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,49,48,50,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,109,105,108,108,105,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,109,115,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,12),40,116,105,109,101,63,32,120,49,50,50,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,106,111,105,110,45,116,105,109,101,111,117,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,50,56,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,33),40,97,98,97,110,100,111,110,101,100,45,109,117,116,101,120,45,101,120,99,101,112,116,105,111,110,63,32,120,49,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,35),40,116,101,114,109,105,110,97,116,101,100,45,116,104,114,101,97,100,45,101,120,99,101,112,116,105,111,110,63,32,120,49,52,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,26),40,117,110,99,97,117,103,104,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,97,57,54,56,32,46,32,114,101,115,117,108,116,115,49,54,48,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,57,54,50,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,116,104,114,101,97,100,32,116,104,117,110,107,49,53,52,32,46,32,110,97,109,101,49,53,53,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,14),40,116,104,114,101,97,100,63,32,120,49,54,55,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,99,117,114,114,101,110,116,45,116,104,114,101,97,100,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,24),40,116,104,114,101,97,100,45,115,116,97,116,101,32,116,104,114,101,97,100,49,55,52,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,32,116,104,114,101,97,100,49,55,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,116,104,114,101,97,100,49,56,52,32,120,49,56,53,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,32,116,104,114,101,97,100,49,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,36),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,45,115,101,116,33,32,116,104,114,101,97,100,49,57,53,32,113,49,57,54,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,116,104,114,101,97,100,45,110,97,109,101,32,120,50,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,116,104,114,101,97,100,45,115,116,97,114,116,33,32,116,104,114,101,97,100,50,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,49,49,51,57,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,17),40,97,49,49,50,52,32,114,101,116,117,114,110,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,106,111,105,110,33,32,116,104,114,101,97,100,50,49,56,32,46,32,116,105,109,101,111,117,116,50,49,57,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,29),40,116,104,114,101,97,100,45,116,101,114,109,105,110,97,116,101,33,32,116,104,114,101,97,100,50,54,50,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,50,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,97,49,50,57,51,32,114,101,116,117,114,110,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,117,115,112,101,110,100,33,32,116,104,114,101,97,100,50,55,53,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,114,101,115,117,109,101,33,32,116,104,114,101,97,100,50,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,51,53,49,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,17),40,97,49,51,51,57,32,114,101,116,117,114,110,51,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,21),40,116,104,114,101,97,100,45,115,108,101,101,112,33,32,116,109,50,57,53,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,109,117,116,101,120,63,32,120,51,49,52,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,20),40,109,97,107,101,45,109,117,116,101,120,32,46,32,105,100,51,49,57,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,109,117,116,101,120,45,110,97,109,101,32,120,51,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,25),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,32,109,117,116,101,120,51,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,35),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,109,117,116,101,120,51,51,57,32,120,51,52,48,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,109,117,116,101,120,45,115,116,97,116,101,32,109,117,116,101,120,51,52,53,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,8),40,115,119,105,116,99,104,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,99,104,101,99,107,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,53,57,51,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,54,52,50,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,49,52,55,50,32,114,101,116,117,114,110,51,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,36),40,109,117,116,101,120,45,108,111,99,107,33,32,109,117,116,101,120,51,54,50,32,46,32,109,115,45,97,110,100,45,116,51,54,51,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,52,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,55,56,51,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,17),40,97,49,54,56,55,32,114,101,116,117,114,110,52,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,41),40,109,117,116,101,120,45,117,110,108,111,99,107,33,32,109,117,116,101,120,52,52,52,32,46,32,99,118,97,114,45,97,110,100,45,116,111,52,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,32,46,32,110,97,109,101,53,49,53,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,26),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,63,32,120,53,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,35),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,32,99,118,53,50,51,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,45),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,99,118,53,50,56,32,120,53,50,57,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,36),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,105,103,110,97,108,33,32,99,118,97,114,53,51,52,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,49,57,53,56,32,116,105,53,54,48,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,39),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,98,114,111,97,100,99,97,115,116,33,32,99,118,97,114,53,53,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,50,48,48,55,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,33),40,116,104,114,101,97,100,45,115,105,103,110,97,108,33,32,116,104,114,101,97,100,53,55,54,32,101,120,110,53,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,40),40,116,104,114,101,97,100,45,119,97,105,116,45,102,111,114,45,105,47,111,33,32,102,100,54,49,48,32,46,32,116,109,112,54,48,57,54,49,49,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,114,101,97,100,45,112,114,111,109,112,116,45,104,111,111,107,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_18_toplevel)
C_externexport void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_fcall f_1072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_808)
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_fcall f_688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2018(t0,t1);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1521(t0,t1);}

C_noret_decl(trf_1497)
static void C_fcall trf_1497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1497(t0,t1);}

C_noret_decl(trf_1476)
static void C_fcall trf_1476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1476(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1476(t0,t1);}

C_noret_decl(trf_1072)
static void C_fcall trf_1072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1072(t0,t1);}

C_noret_decl(trf_688)
static void C_fcall trf_688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_688(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1095)){
C_save(t1);
C_rereclaim2(1095*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[0]=C_h_intern(&lf[0],8,"truncate");
lf[2]=C_h_intern(&lf[2],4,"time");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[6]=C_h_intern(&lf[6],12,"current-time");
lf[7]=C_h_intern(&lf[7],20,"srfi-18:current-time");
lf[8]=C_h_intern(&lf[8],13,"time->seconds");
lf[9]=C_h_intern(&lf[9],18,"time->milliseconds");
lf[10]=C_h_intern(&lf[10],13,"seconds->time");
lf[11]=C_h_intern(&lf[11],19,"\003sysflonum-fraction");
lf[12]=C_h_intern(&lf[12],18,"\003sysexact->inexact");
lf[13]=C_h_intern(&lf[13],3,"max");
lf[14]=C_h_intern(&lf[14],18,"milliseconds->time");
lf[15]=C_h_intern(&lf[15],5,"time\077");
lf[16]=C_h_intern(&lf[16],13,"srfi-18:time\077");
lf[17]=C_h_intern(&lf[17],5,"raise");
lf[18]=C_h_intern(&lf[18],10,"\003syssignal");
lf[19]=C_h_intern(&lf[19],23,"join-timeout-exception\077");
lf[20]=C_h_intern(&lf[20],9,"condition");
lf[21]=C_h_intern(&lf[21],22,"join-timeout-exception");
lf[22]=C_h_intern(&lf[22],26,"abandoned-mutex-exception\077");
lf[23]=C_h_intern(&lf[23],25,"abandoned-mutex-exception");
lf[24]=C_h_intern(&lf[24],28,"terminated-thread-exception\077");
lf[25]=C_h_intern(&lf[25],27,"terminated-thread-exception");
lf[26]=C_h_intern(&lf[26],19,"uncaught-exception\077");
lf[27]=C_h_intern(&lf[27],18,"uncaught-exception");
lf[28]=C_h_intern(&lf[28],25,"uncaught-exception-reason");
lf[29]=C_h_intern(&lf[29],6,"gensym");
lf[30]=C_h_intern(&lf[30],11,"make-thread");
lf[31]=C_h_intern(&lf[31],12,"\003sysschedule");
lf[32]=C_h_intern(&lf[32],16,"\003systhread-kill!");
lf[33]=C_h_intern(&lf[33],4,"dead");
lf[34]=C_h_intern(&lf[34],18,"\003syscurrent-thread");
lf[35]=C_h_intern(&lf[35],15,"\003sysmake-thread");
lf[36]=C_h_intern(&lf[36],7,"created");
lf[37]=C_h_intern(&lf[37],6,"thread");
lf[38]=C_h_intern(&lf[38],7,"thread\077");
lf[39]=C_h_intern(&lf[39],14,"current-thread");
lf[40]=C_h_intern(&lf[40],12,"thread-state");
lf[41]=C_h_intern(&lf[41],15,"thread-specific");
lf[42]=C_h_intern(&lf[42],20,"thread-specific-set!");
lf[43]=C_h_intern(&lf[43],14,"thread-quantum");
lf[44]=C_h_intern(&lf[44],19,"thread-quantum-set!");
lf[45]=C_h_intern(&lf[45],11,"thread-name");
lf[46]=C_h_intern(&lf[46],13,"thread-start!");
lf[47]=C_h_intern(&lf[47],5,"ready");
lf[48]=C_h_intern(&lf[48],22,"\003sysadd-to-ready-queue");
lf[49]=C_h_intern(&lf[49],9,"\003syserror");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\047thread can not be started a second time");
lf[51]=C_h_intern(&lf[51],13,"thread-yield!");
lf[52]=C_h_intern(&lf[52],17,"\003systhread-yield!");
lf[53]=C_h_intern(&lf[53],12,"thread-join!");
lf[54]=C_h_intern(&lf[54],28,"\003sysremove-from-timeout-list");
lf[55]=C_h_intern(&lf[55],10,"terminated");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[59]=C_h_intern(&lf[59],33,"\003systhread-block-for-termination!");
lf[60]=C_h_intern(&lf[60],29,"\003systhread-block-for-timeout!");
lf[61]=C_h_intern(&lf[61],17,"thread-terminate!");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[63]=C_h_intern(&lf[63],21,"\003sysprimordial-thread");
lf[64]=C_h_intern(&lf[64],16,"\003sysexit-handler");
lf[65]=C_h_intern(&lf[65],15,"thread-suspend!");
lf[66]=C_h_intern(&lf[66],9,"suspended");
lf[67]=C_h_intern(&lf[67],14,"thread-resume!");
lf[68]=C_h_intern(&lf[68],13,"thread-sleep!");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[70]=C_h_intern(&lf[70],6,"mutex\077");
lf[71]=C_h_intern(&lf[71],5,"mutex");
lf[72]=C_h_intern(&lf[72],10,"make-mutex");
lf[73]=C_h_intern(&lf[73],14,"\003sysmake-mutex");
lf[74]=C_h_intern(&lf[74],10,"mutex-name");
lf[75]=C_h_intern(&lf[75],14,"mutex-specific");
lf[76]=C_h_intern(&lf[76],19,"mutex-specific-set!");
lf[77]=C_h_intern(&lf[77],11,"mutex-state");
lf[78]=C_h_intern(&lf[78],9,"not-owned");
lf[79]=C_h_intern(&lf[79],9,"abandoned");
lf[80]=C_h_intern(&lf[80],13,"not-abandoned");
lf[81]=C_h_intern(&lf[81],11,"mutex-lock!");
lf[82]=C_h_intern(&lf[82],10,"\003sysappend");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[84]=C_h_intern(&lf[84],8,"\003sysdelq");
lf[85]=C_h_intern(&lf[85],8,"sleeping");
lf[86]=C_h_intern(&lf[86],13,"mutex-unlock!");
lf[87]=C_h_intern(&lf[87],18,"condition-variable");
lf[88]=C_h_intern(&lf[88],7,"blocked");
lf[89]=C_h_intern(&lf[89],23,"make-condition-variable");
lf[90]=C_h_intern(&lf[90],19,"condition-variable\077");
lf[91]=C_h_intern(&lf[91],27,"condition-variable-specific");
lf[92]=C_h_intern(&lf[92],32,"condition-variable-specific-set!");
lf[93]=C_h_intern(&lf[93],26,"condition-variable-signal!");
lf[94]=C_h_intern(&lf[94],25,"\003systhread-basic-unblock!");
lf[95]=C_h_intern(&lf[95],29,"condition-variable-broadcast!");
lf[96]=C_h_intern(&lf[96],12,"\003sysfor-each");
lf[97]=C_h_intern(&lf[97],14,"thread-signal!");
lf[98]=C_h_intern(&lf[98],19,"\003systhread-unblock!");
lf[99]=C_h_intern(&lf[99],20,"thread-wait-for-i/o!");
lf[100]=C_h_intern(&lf[100],25,"\003systhread-block-for-i/o!");
lf[101]=C_h_intern(&lf[101],4,"\000all");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[103]=C_h_intern(&lf[103],4,"msvc");
lf[104]=C_h_intern(&lf[104],20,"\003sysread-prompt-hook");
lf[105]=C_h_intern(&lf[105],13,"\003systty-port\077");
lf[106]=C_h_intern(&lf[106],18,"\003sysstandard-input");
lf[107]=C_h_intern(&lf[107],14,"build-platform");
lf[108]=C_h_intern(&lf[108],27,"condition-property-accessor");
lf[109]=C_h_intern(&lf[109],6,"reason");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],7,"srfi-18");
C_register_lf2(lf,112,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_683,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k681 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 55   register-feature! */
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[111]);}

/* k684 in k681 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_686,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! compute-time-limit ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_688,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! current-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! srfi-18:current-time ...) */,*((C_word*)lf[6]+1));
t6=C_mutate((C_word*)lf[8]+1 /* (set! time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! time->milliseconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[10]+1 /* (set! seconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_808,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! milliseconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_862,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[15]+1 /* (set! time? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_878,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[16]+1 /* (set! srfi-18:time? ...) */,*((C_word*)lf[15]+1));
t12=C_mutate((C_word*)lf[17]+1 /* (set! raise ...) */,*((C_word*)lf[18]+1));
t13=C_mutate((C_word*)lf[19]+1 /* (set! join-timeout-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[22]+1 /* (set! abandoned-mutex-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[24]+1 /* (set! terminated-thread-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[26]+1 /* (set! uncaught-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 151  condition-property-accessor */
t18=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,lf[27],lf[109]);}

/* k950 in k684 in k681 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[100],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! uncaught-exception-reason ...) */,t1);
t3=*((C_word*)lf[29]+1);
t4=C_mutate((C_word*)lf[30]+1 /* (set! make-thread ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_954,a[2]=t3,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[38]+1 /* (set! thread? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[39]+1 /* (set! current-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[40]+1 /* (set! thread-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[41]+1 /* (set! thread-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[42]+1 /* (set! thread-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[43]+1 /* (set! thread-quantum ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[44]+1 /* (set! thread-quantum-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[45]+1 /* (set! thread-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[30]+1);
t14=C_mutate((C_word*)lf[46]+1 /* (set! thread-start! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t13,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[51]+1 /* (set! thread-yield! ...) */,*((C_word*)lf[52]+1));
t16=C_mutate((C_word*)lf[53]+1 /* (set! thread-join! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[61]+1 /* (set! thread-terminate! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[65]+1 /* (set! thread-suspend! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[67]+1 /* (set! thread-resume! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[68]+1 /* (set! thread-sleep! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[70]+1 /* (set! mutex? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1371,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t22=*((C_word*)lf[29]+1);
t23=C_mutate((C_word*)lf[72]+1 /* (set! make-mutex ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1377,a[2]=t22,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[74]+1 /* (set! mutex-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! mutex-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1404,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[76]+1 /* (set! mutex-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[77]+1 /* (set! mutex-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! mutex-lock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[86]+1 /* (set! mutex-unlock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[29]+1);
t31=C_mutate((C_word*)lf[89]+1 /* (set! make-condition-variable ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=t30,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t32=C_mutate((C_word*)lf[90]+1 /* (set! condition-variable? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[91]+1 /* (set! condition-variable-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[92]+1 /* (set! condition-variable-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[93]+1 /* (set! condition-variable-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[95]+1 /* (set! condition-variable-broadcast! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1947,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[97]+1 /* (set! thread-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2083,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 475  build-platform */
t40=*((C_word*)lf[107]+1);
((C_proc2)C_retrieve_proc(t40))(2,t40,t39);}

/* k2081 in k950 in k684 in k681 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_2018(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[104]+1);
t4=*((C_word*)lf[51]+1);
t5=C_mutate((C_word*)lf[104]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2057,a[2]=t3,a[3]=t4,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t0)[2];
f_2018(t6,t5);}}

/* ##sys#read-prompt-hook in k2081 in k950 in k684 in k681 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2067(2,t4,t2);}
else{
/* srfi-18.scm: 480  ##sys#tty-port? */
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[106]+1));}}

/* k2065 in ##sys#read-prompt-hook in k2081 in k950 in k684 in k681 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 481  old */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2068 in k2065 in ##sys#read-prompt-hook in k2081 in k950 in k684 in k681 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 482  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[34]+1),C_fix(0),C_SCHEME_TRUE);}

/* k2071 in k2068 in k2065 in ##sys#read-prompt-hook in k2081 in k950 in k684 in k681 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 483  thread-yield! */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2016 in k950 in k684 in k681 */
static void C_fcall f_2018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2018,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[99]+1 /* (set! thread-wait-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2020,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* thread-wait-for-i/o! in k2016 in k950 in k684 in k681 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2020r(t0,t1,t2,t3);}}

static void C_ccall f_2020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2024(2,t5,lf[101]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2024(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[102],t3);}}}

/* k2022 in thread-wait-for-i/o! in k2016 in k950 in k684 in k681 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[99]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 490  ##sys#thread-block-for-i/o! */
t4=*((C_word*)lf[100]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[34]+1),((C_word*)t0)[3],t1);}

/* k2028 in k2022 in thread-wait-for-i/o! in k2016 in k950 in k684 in k681 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 491  thread-yield! */
t2=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* thread-signal! in k950 in k684 in k681 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1984,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[97]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[34]+1));
if(C_truep(t5)){
/* srfi-18.scm: 463  ##sys#signal */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2008,a[2]=t3,a[3]=t6,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t2,C_fix(1),t7);
/* srfi-18.scm: 470  ##sys#thread-unblock! */
t9=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t2);}}

/* a2007 in thread-signal! in k950 in k684 in k681 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 468  ##sys#signal */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2010 in a2007 in thread-signal! in k950 in k684 in k681 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 469  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k950 in k684 in k681 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1947,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(2));
/* srfi-18.scm: 449  ##sys#for-each */
t7=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a1958 in condition-variable-broadcast! in k950 in k684 in k681 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1959,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[88]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[85]));
if(C_truep(t5)){
/* srfi-18.scm: 453  ##sys#thread-basic-unblock! */
t6=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1952 in condition-variable-broadcast! in k950 in k684 in k681 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k950 in k684 in k681 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1904,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[93]);
t4=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_i_setslot(t2,C_fix(2),t7);
t9=(C_word)C_eqp(t6,lf[88]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[85]));
if(C_truep(t10)){
/* srfi-18.scm: 444  ##sys#thread-basic-unblock! */
t11=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k950 in k684 in k681 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1895,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[87],lf[92]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k950 in k684 in k681 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1886,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k950 in k684 in k681 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1880,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[87]));}

/* make-condition-variable in k950 in k684 in k681 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1861r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1861r(t0,t1,t2);}}

static void C_ccall f_1861r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1869(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* srfi-18.scm: 420  gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[87]);}}

/* k1867 in make-condition-variable in k950 in k684 in k681 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[87],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1670r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1670r(t0,t1,t2,t3);}}

static void C_ccall f_1670r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[86]);
t5=*((C_word*)lf[34]+1);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t3);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t11=(C_truep(t7)?(C_word)C_i_check_structure_2(t7,lf[87],lf[86]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1688,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm: 377  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t12);}

/* a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1688,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 380  ##sys#compute-time-limit */
t5=lf[1];
f_688(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1695(2,t5,C_SCHEME_FALSE);}}

/* k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1833,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
/* srfi-18.scm: 384  ##sys#delq */
t6=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[7],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1815,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* srfi-18.scm: 387  ##sys#append */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1710(2,t6,C_SCHEME_UNDEFINED);}}

/* k1813 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
/* srfi-18.scm: 396  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1710(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[85]));}}

/* a1783 in k1813 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-18.scm: 392  ##sys#delq */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1802 in a1783 in k1813 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(13)))){
t4=t3;
f_1791(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 394  ##sys#remove-from-timeout-list */
t4=*((C_word*)lf[54]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k1789 in k1802 in a1783 in k1813 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 395  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1708 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1713(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_TRUE);
t8=(C_word)C_eqp(t4,lf[88]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[85]));
if(C_truep(t9)){
t10=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t11=(C_word)C_slot(t3,C_fix(8));
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11);
t13=(C_word)C_i_setslot(t3,C_fix(8),t12);
t14=(C_word)C_eqp(t4,lf[85]);
if(C_truep(t14)){
/* srfi-18.scm: 407  ##sys#add-to-ready-queue */
t15=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t2,t3);}
else{
t15=t2;
f_1713(2,t15,C_SCHEME_UNDEFINED);}}
else{
t10=t2;
f_1713(2,t10,C_SCHEME_UNDEFINED);}}}

/* k1711 in k1708 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 408  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1824 in k1831 in k1693 in a1687 in mutex-unlock! in k950 in k684 in k681 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
/* srfi-18.scm: 385  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1446r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1446r(t0,t1,t2,t3);}}

static void C_ccall f_1446r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[81]);
t5=(C_word)C_notvemptyp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_vector_ref(t3,C_fix(0));
/* srfi-18.scm: 321  ##sys#compute-time-limit */
t8=lf[1];
f_688(t8,t6,t7);}
else{
t7=t6;
f_1456(2,t7,C_SCHEME_FALSE);}}

/* k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?(C_word)C_i_check_structure_2(t4,lf[37],lf[81]):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1473,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word)li44),tmp=(C_word)a,a+=8,tmp);
/* srfi-18.scm: 326  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[31],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1473,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1476,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1497,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* srfi-18.scm: 352  check */
t7=t5;
f_1497(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[85]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1643,a[2]=t2,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
/* srfi-18.scm: 367  switch */
t9=t4;
f_1476(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_1521(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[55],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[33],t9));
if(C_truep(t11)){
t12=t6;
f_1521(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_1521(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k1519 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_fcall f_1521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 349  check */
t3=((C_word*)t0)[2];
f_1497(t3,t2);}

/* k1522 in k1519 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 350  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1642 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
/* srfi-18.scm: 366  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* k1581 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word)li42),tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 362  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k1587 in k1581 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 363  switch */
t2=((C_word*)t0)[3];
f_1476(t2,((C_word*)t0)[2]);}

/* a1593 in k1581 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1628,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
/* srfi-18.scm: 356  ##sys#delq */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[4],t3);}

/* k1626 in a1593 in k1581 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(3),t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(13)))){
t4=t3;
f_1601(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 358  ##sys#remove-from-timeout-list */
t4=*((C_word*)lf[54]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}}

/* k1599 in k1626 in a1593 in k1581 in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(8),t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]);
/* srfi-18.scm: 361  return */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* check in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_fcall f_1497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1497,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1508,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[20],lf[83],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 334  ##sys#signal */
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1506 in check in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 334  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_fcall f_1476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1476,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm: 330  ##sys#append */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1485 in switch in a1472 in k1454 in mutex-lock! in k950 in k684 in k681 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
/* srfi-18.scm: 331  ##sys#schedule */
t3=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k950 in k684 in k681 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1422,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[77]);
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[78]));}
else{
t4=(C_word)C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[79]:lf[80]));}}

/* mutex-specific-set! in k950 in k684 in k681 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1413,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[76]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k950 in k684 in k681 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1404,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k950 in k684 in k681 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1395,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k950 in k684 in k681 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1377r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1377r(t0,t1,t2);}}

static void C_ccall f_1377r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1381(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* srfi-18.scm: 295  gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[71]);}}

/* k1379 in make-mutex in k950 in k684 in k681 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 296  ##sys#make-mutex */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* mutex? in k950 in k684 in k681 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1371,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1331,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1359,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_1359(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 284  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[4],lf[68],lf[69],t2);}}

/* k1357 in thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 285  ##sys#compute-time-limit */
t3=lf[1];
f_688(t3,t2,((C_word*)t0)[2]);}

/* k1364 in k1357 in thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1340,a[2]=t1,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 278  ##sys#call-with-current-continuation */
C_call_cc(3,0,t2,t3);}

/* a1339 in k1364 in k1357 in thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1340,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1352,a[2]=t2,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 282  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,((C_word*)t0)[2]);}

/* k1345 in a1339 in k1364 in k1357 in thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 283  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1351 in a1339 in k1364 in k1357 in thread-sleep! in k950 in k684 in k681 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
/* srfi-18.scm: 281  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k950 in k684 in k681 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1309,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[67]);
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_eqp(t4,lf[66]);
if(C_truep(t5)){
t6=(C_word)C_i_setslot(t2,C_fix(3),lf[47]);
/* srfi-18.scm: 274  ##sys#add-to-ready-queue */
t7=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k950 in k684 in k681 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1276,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[65]);
t4=(C_word)C_i_setslot(t2,C_fix(3),lf[66]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[34]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 265  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1293 in thread-suspend! in k950 in k684 in k681 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=t2,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
/* srfi-18.scm: 268  ##sys#schedule */
t5=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a1302 in a1293 in thread-suspend! in k950 in k684 in k681 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
/* srfi-18.scm: 267  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k950 in k684 in k681 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1232,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[61]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[63]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 255  ##sys#exit-handler */
t7=*((C_word*)lf[64]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=t4;
f_1239(2,t6,C_SCHEME_UNDEFINED);}}

/* k1272 in thread-terminate! in k950 in k684 in k681 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1237 in thread-terminate! in k950 in k684 in k681 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_SCHEME_UNDEFINED);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t2);
t4=(C_word)C_a_i_record(&a,3,lf[20],lf[62],C_SCHEME_END_OF_LIST);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 258  ##sys#thread-kill! */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],lf[55]);}

/* k1246 in k1237 in thread-terminate! in k950 in k684 in k681 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[34]+1));
if(C_truep(t2)){
/* srfi-18.scm: 259  ##sys#schedule */
t3=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k950 in k684 in k681 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1104r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1104r(t0,t1,t2,t3);}}

static void C_ccall f_1104r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[53]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1111,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
/* srfi-18.scm: 221  ##sys#compute-time-limit */
t7=lf[1];
f_688(t7,t5,t6);}
else{
t6=t5;
f_1111(2,t6,C_SCHEME_FALSE);}}

/* k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1125,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm: 225  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1125,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1129,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 228  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_1129(2,t5,C_SCHEME_UNDEFINED);}}

/* k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 249  ##sys#thread-block-for-termination! */
t5=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}

/* k1133 in k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 250  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1139 in k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_eqp(t2,lf[33]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(13)))){
t5=t4;
f_1153(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 235  ##sys#remove-from-timeout-list */
t5=*((C_word*)lf[54]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}
else{
t4=(C_word)C_eqp(t2,lf[55]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1179,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[56],t6);
t8=(C_word)C_a_i_record(&a,3,lf[20],lf[57],t7);
/* srfi-18.scm: 239  ##sys#signal */
t9=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_1198(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[20],lf[58],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 247  ##sys#signal */
t7=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k1196 in a1139 in k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 244  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1177 in a1139 in k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 238  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1151 in a1139 in k1127 in a1124 in k1109 in thread-join! in k950 in k684 in k681 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* thread-start! in k950 in k684 in k681 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1068,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1072,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1098,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 208  make-thread */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_1072(t5,(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[37],lf[46]));}}

/* k1096 in thread-start! in k950 in k684 in k681 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1072(t3,t2);}

/* k1070 in thread-start! in k950 in k684 in k681 */
static void C_fcall f_1072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1072,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[36],t3);
if(C_truep(t4)){
t5=t2;
f_1075(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 211  ##sys#error */
t5=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[46],lf[50],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1073 in k1070 in thread-start! in k950 in k684 in k681 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[47]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 213  ##sys#add-to-ready-queue */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k1079 in k1073 in k1070 in thread-start! in k950 in k684 in k681 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k950 in k684 in k681 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1059,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[45]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k950 in k684 in k681 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1043,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[44]);
t5=(C_word)C_i_check_exact_2(t3,lf[44]);
t6=(C_word)C_i_fixnum_max(t3,C_fix(10));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_i_slot(t2,C_fix(9),t6));}

/* thread-quantum in k950 in k684 in k681 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1034,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[43]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k950 in k684 in k681 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1025,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[42]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k950 in k684 in k681 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1016,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[41]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k950 in k684 in k681 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1007,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[40]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k950 in k684 in k681 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[34]+1));}

/* thread? in k950 in k684 in k681 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_998,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[37]));}

/* make-thread in k950 in k684 in k681 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_954r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_954r(t0,t1,t2,t3);}}

static void C_ccall f_954r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_958,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_983(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
/* srfi-18.scm: 163  gensym */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[37]);}}

/* k981 in make-thread in k950 in k684 in k681 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[34]+1),C_fix(9));
/* srfi-18.scm: 160  ##sys#make-thread */
t3=*((C_word*)lf[35]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[36],t1,t2);}

/* k956 in make-thread in k950 in k684 in k681 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a962 in k956 in make-thread in k950 in k684 in k681 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 168  ##sys#call-with-values */
C_call_with_values(4,0,t1,((C_word*)t0)[2],t2);}

/* a968 in a962 in k956 in make-thread in k950 in k684 in k681 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_969r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_969r(t0,t1,t2);}}

static void C_ccall f_969r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 172  ##sys#thread-kill! */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[33]);}

/* k974 in a968 in a962 in k956 in make-thread in k950 in k684 in k681 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 173  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k684 in k681 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_934,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k684 in k681 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_918,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k684 in k681 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_902,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k684 in k681 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_886,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[21],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k684 in k681 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_878,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[2]));}

/* milliseconds->time in k684 in k681 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_862,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[14]);
t4=(C_word)C_a_i_divide(&a,2,t2,C_fix(1000));
t5=(C_word)C_a_i_plus(&a,2,C_flonum(&a,C_startup_time_seconds),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[2],t2,t5,C_fix(0)));}

/* seconds->time in k684 in k681 */
static void C_ccall f_808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_808,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[10]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_815,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
/* srfi-18.scm: 115  max */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_fix(0),t5);}

/* k813 in seconds->time in k684 in k681 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_818,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_856,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 116  ##sys#exact->inexact */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k854 in k813 in seconds->time in k684 in k681 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 116  ##sys#flonum-fraction */
t2=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k850 in k813 in seconds->time in k684 in k681 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
/* srfi-18.scm: 116  truncate */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k816 in k813 in seconds->time in k684 in k681 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
/* srfi-18.scm: 117  truncate */
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k834 in k816 in k813 in seconds->time in k684 in k681 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_828,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-18.scm: 118  truncate */
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k826 in k834 in k816 in k813 in seconds->time in k684 in k681 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],((C_word*)t0)[2],t1,t2));}

/* time->milliseconds in k684 in k681 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_779,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[2],lf[9]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_flonum(&a,C_startup_time_seconds));
t6=(C_word)C_a_i_times(&a,2,t5,C_fix(1000));
t7=(C_word)C_i_inexact_to_exact(t6);
t8=(C_word)C_slot(t2,C_fix(3));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_plus(&a,2,t7,t8));}

/* time->seconds in k684 in k681 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_758,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[2],lf[8]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_a_i_divide(&a,2,t5,C_fix(1000));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_plus(&a,2,t4,t6));}

/* current-time in k684 in k681 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
/* srfi-18.scm: 98   truncate */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}

/* k741 in current-time in k684 in k681 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k684 in k681 */
static void C_fcall f_688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_688,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_722,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
/* srfi-18.scm: 75   truncate */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* srfi-18.scm: 76   ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[4],lf[5],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k720 in ##sys#compute-time-limit in k684 in k681 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[120] = {
{"toplevelsrfi-18.scm",(void*)C_srfi_18_toplevel},
{"f_683srfi-18.scm",(void*)f_683},
{"f_686srfi-18.scm",(void*)f_686},
{"f_952srfi-18.scm",(void*)f_952},
{"f_2083srfi-18.scm",(void*)f_2083},
{"f_2057srfi-18.scm",(void*)f_2057},
{"f_2067srfi-18.scm",(void*)f_2067},
{"f_2070srfi-18.scm",(void*)f_2070},
{"f_2073srfi-18.scm",(void*)f_2073},
{"f_2018srfi-18.scm",(void*)f_2018},
{"f_2020srfi-18.scm",(void*)f_2020},
{"f_2024srfi-18.scm",(void*)f_2024},
{"f_2030srfi-18.scm",(void*)f_2030},
{"f_1984srfi-18.scm",(void*)f_1984},
{"f_2008srfi-18.scm",(void*)f_2008},
{"f_2012srfi-18.scm",(void*)f_2012},
{"f_1947srfi-18.scm",(void*)f_1947},
{"f_1959srfi-18.scm",(void*)f_1959},
{"f_1954srfi-18.scm",(void*)f_1954},
{"f_1904srfi-18.scm",(void*)f_1904},
{"f_1895srfi-18.scm",(void*)f_1895},
{"f_1886srfi-18.scm",(void*)f_1886},
{"f_1880srfi-18.scm",(void*)f_1880},
{"f_1861srfi-18.scm",(void*)f_1861},
{"f_1869srfi-18.scm",(void*)f_1869},
{"f_1670srfi-18.scm",(void*)f_1670},
{"f_1688srfi-18.scm",(void*)f_1688},
{"f_1695srfi-18.scm",(void*)f_1695},
{"f_1833srfi-18.scm",(void*)f_1833},
{"f_1815srfi-18.scm",(void*)f_1815},
{"f_1784srfi-18.scm",(void*)f_1784},
{"f_1804srfi-18.scm",(void*)f_1804},
{"f_1791srfi-18.scm",(void*)f_1791},
{"f_1710srfi-18.scm",(void*)f_1710},
{"f_1713srfi-18.scm",(void*)f_1713},
{"f_1825srfi-18.scm",(void*)f_1825},
{"f_1446srfi-18.scm",(void*)f_1446},
{"f_1456srfi-18.scm",(void*)f_1456},
{"f_1473srfi-18.scm",(void*)f_1473},
{"f_1521srfi-18.scm",(void*)f_1521},
{"f_1524srfi-18.scm",(void*)f_1524},
{"f_1643srfi-18.scm",(void*)f_1643},
{"f_1583srfi-18.scm",(void*)f_1583},
{"f_1589srfi-18.scm",(void*)f_1589},
{"f_1594srfi-18.scm",(void*)f_1594},
{"f_1628srfi-18.scm",(void*)f_1628},
{"f_1601srfi-18.scm",(void*)f_1601},
{"f_1497srfi-18.scm",(void*)f_1497},
{"f_1508srfi-18.scm",(void*)f_1508},
{"f_1476srfi-18.scm",(void*)f_1476},
{"f_1487srfi-18.scm",(void*)f_1487},
{"f_1422srfi-18.scm",(void*)f_1422},
{"f_1413srfi-18.scm",(void*)f_1413},
{"f_1404srfi-18.scm",(void*)f_1404},
{"f_1395srfi-18.scm",(void*)f_1395},
{"f_1377srfi-18.scm",(void*)f_1377},
{"f_1381srfi-18.scm",(void*)f_1381},
{"f_1371srfi-18.scm",(void*)f_1371},
{"f_1331srfi-18.scm",(void*)f_1331},
{"f_1359srfi-18.scm",(void*)f_1359},
{"f_1366srfi-18.scm",(void*)f_1366},
{"f_1340srfi-18.scm",(void*)f_1340},
{"f_1347srfi-18.scm",(void*)f_1347},
{"f_1352srfi-18.scm",(void*)f_1352},
{"f_1309srfi-18.scm",(void*)f_1309},
{"f_1276srfi-18.scm",(void*)f_1276},
{"f_1294srfi-18.scm",(void*)f_1294},
{"f_1303srfi-18.scm",(void*)f_1303},
{"f_1232srfi-18.scm",(void*)f_1232},
{"f_1274srfi-18.scm",(void*)f_1274},
{"f_1239srfi-18.scm",(void*)f_1239},
{"f_1248srfi-18.scm",(void*)f_1248},
{"f_1104srfi-18.scm",(void*)f_1104},
{"f_1111srfi-18.scm",(void*)f_1111},
{"f_1125srfi-18.scm",(void*)f_1125},
{"f_1129srfi-18.scm",(void*)f_1129},
{"f_1135srfi-18.scm",(void*)f_1135},
{"f_1140srfi-18.scm",(void*)f_1140},
{"f_1198srfi-18.scm",(void*)f_1198},
{"f_1179srfi-18.scm",(void*)f_1179},
{"f_1153srfi-18.scm",(void*)f_1153},
{"f_1068srfi-18.scm",(void*)f_1068},
{"f_1098srfi-18.scm",(void*)f_1098},
{"f_1072srfi-18.scm",(void*)f_1072},
{"f_1075srfi-18.scm",(void*)f_1075},
{"f_1081srfi-18.scm",(void*)f_1081},
{"f_1059srfi-18.scm",(void*)f_1059},
{"f_1043srfi-18.scm",(void*)f_1043},
{"f_1034srfi-18.scm",(void*)f_1034},
{"f_1025srfi-18.scm",(void*)f_1025},
{"f_1016srfi-18.scm",(void*)f_1016},
{"f_1007srfi-18.scm",(void*)f_1007},
{"f_1004srfi-18.scm",(void*)f_1004},
{"f_998srfi-18.scm",(void*)f_998},
{"f_954srfi-18.scm",(void*)f_954},
{"f_983srfi-18.scm",(void*)f_983},
{"f_958srfi-18.scm",(void*)f_958},
{"f_963srfi-18.scm",(void*)f_963},
{"f_969srfi-18.scm",(void*)f_969},
{"f_976srfi-18.scm",(void*)f_976},
{"f_934srfi-18.scm",(void*)f_934},
{"f_918srfi-18.scm",(void*)f_918},
{"f_902srfi-18.scm",(void*)f_902},
{"f_886srfi-18.scm",(void*)f_886},
{"f_878srfi-18.scm",(void*)f_878},
{"f_862srfi-18.scm",(void*)f_862},
{"f_808srfi-18.scm",(void*)f_808},
{"f_815srfi-18.scm",(void*)f_815},
{"f_856srfi-18.scm",(void*)f_856},
{"f_852srfi-18.scm",(void*)f_852},
{"f_818srfi-18.scm",(void*)f_818},
{"f_836srfi-18.scm",(void*)f_836},
{"f_828srfi-18.scm",(void*)f_828},
{"f_779srfi-18.scm",(void*)f_779},
{"f_758srfi-18.scm",(void*)f_758},
{"f_731srfi-18.scm",(void*)f_731},
{"f_743srfi-18.scm",(void*)f_743},
{"f_688srfi-18.scm",(void*)f_688},
{"f_722srfi-18.scm",(void*)f_722},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
