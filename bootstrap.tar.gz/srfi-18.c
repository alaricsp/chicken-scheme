/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: srfi-18.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file srfi-18.c
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,99,111,109,112,117,116,101,45,116,105,109,101,45,108,105,109,105,116,32,116,109,56,49,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,99,117,114,114,101,110,116,45,116,105,109,101,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,21),40,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,49,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,26),40,116,105,109,101,45,62,109,105,108,108,105,115,101,99,111,110,100,115,32,116,109,49,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,49,50,49,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,109,105,108,108,105,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,109,115,49,51,52,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,12),40,116,105,109,101,63,32,120,49,52,49,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,106,111,105,110,45,116,105,109,101,111,117,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,52,55,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,33),40,97,98,97,110,100,111,110,101,100,45,109,117,116,101,120,45,101,120,99,101,112,116,105,111,110,63,32,120,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,35),40,116,101,114,109,105,110,97,116,101,100,45,116,104,114,101,97,100,45,101,120,99,101,112,116,105,111,110,63,32,120,49,53,57,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,26),40,117,110,99,97,117,103,104,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,97,57,55,57,32,46,32,114,101,115,117,108,116,115,49,55,57,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,57,55,51,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,116,104,114,101,97,100,32,116,104,117,110,107,49,55,51,32,46,32,110,97,109,101,49,55,52,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,14),40,116,104,114,101,97,100,63,32,120,49,56,54,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,99,117,114,114,101,110,116,45,116,104,114,101,97,100,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,24),40,116,104,114,101,97,100,45,115,116,97,116,101,32,116,104,114,101,97,100,49,57,51,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,32,116,104,114,101,97,100,49,57,56,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,116,104,114,101,97,100,50,48,51,32,120,50,48,52,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,32,116,104,114,101,97,100,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,36),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,45,115,101,116,33,32,116,104,114,101,97,100,50,49,52,32,113,50,49,53,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,116,104,114,101,97,100,45,110,97,109,101,32,120,50,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,116,104,114,101,97,100,45,115,116,97,114,116,33,32,116,104,114,101,97,100,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,49,49,53,48,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,17),40,97,49,49,51,53,32,114,101,116,117,114,110,50,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,106,111,105,110,33,32,116,104,114,101,97,100,50,51,55,32,46,32,116,105,109,101,111,117,116,50,51,56,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,29),40,116,104,114,101,97,100,45,116,101,114,109,105,110,97,116,101,33,32,116,104,114,101,97,100,50,55,57,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,52,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,97,49,50,57,53,32,114,101,116,117,114,110,50,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,117,115,112,101,110,100,33,32,116,104,114,101,97,100,50,57,50,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,114,101,115,117,109,101,33,32,116,104,114,101,97,100,51,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,51,53,51,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,17),40,97,49,51,52,49,32,114,101,116,117,114,110,51,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,21),40,116,104,114,101,97,100,45,115,108,101,101,112,33,32,116,109,51,49,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,109,117,116,101,120,63,32,120,51,51,49,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,20),40,109,97,107,101,45,109,117,116,101,120,32,46,32,105,100,51,51,54,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,109,117,116,101,120,45,110,97,109,101,32,120,51,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,25),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,32,109,117,116,101,120,51,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,35),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,109,117,116,101,120,51,53,54,32,120,51,53,55,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,109,117,116,101,120,45,115,116,97,116,101,32,109,117,116,101,120,51,54,50,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,8),40,115,119,105,116,99,104,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,99,104,101,99,107,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,53,57,53,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,54,51,50,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,49,52,55,52,32,114,101,116,117,114,110,52,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,36),40,109,117,116,101,120,45,108,111,99,107,33,32,109,117,116,101,120,51,55,57,32,46,32,109,115,45,97,110,100,45,116,51,56,48,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,56,48,53,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,55,55,51,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,17),40,97,49,54,55,55,32,114,101,116,117,114,110,52,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,41),40,109,117,116,101,120,45,117,110,108,111,99,107,33,32,109,117,116,101,120,52,53,56,32,46,32,99,118,97,114,45,97,110,100,45,116,111,52,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,32,46,32,110,97,109,101,53,50,54,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,26),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,63,32,120,53,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,35),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,32,99,118,53,51,52,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,45),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,99,118,53,51,57,32,120,53,52,48,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,36),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,105,103,110,97,108,33,32,99,118,97,114,53,52,53,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,49,57,51,57,32,116,105,53,55,49,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,39),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,98,114,111,97,100,99,97,115,116,33,32,99,118,97,114,53,54,57,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,49,57,56,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,33),40,116,104,114,101,97,100,45,115,105,103,110,97,108,33,32,116,104,114,101,97,100,53,56,55,32,101,120,110,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,40),40,116,104,114,101,97,100,45,119,97,105,116,45,102,111,114,45,105,47,111,33,32,102,100,54,50,49,32,46,32,116,109,112,54,50,48,54,50,50,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,114,101,97,100,45,112,114,111,109,112,116,45,104,111,111,107,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_18_toplevel)
C_externexport void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_694)
static void C_ccall f_694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_fcall f_1999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_fcall f_1499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_fcall f_1478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_fcall f_1083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_769)
static void C_ccall f_769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_fcall f_699(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1999)
static void C_fcall trf_1999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1999(t0,t1);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1523(t0,t1);}

C_noret_decl(trf_1499)
static void C_fcall trf_1499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1499(t0,t1);}

C_noret_decl(trf_1478)
static void C_fcall trf_1478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1478(t0,t1);}

C_noret_decl(trf_1083)
static void C_fcall trf_1083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1083(t0,t1);}

C_noret_decl(trf_699)
static void C_fcall trf_699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_699(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_699(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1085)){
C_save(t1);
C_rereclaim2(1085*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],8,"truncate");
lf[4]=C_h_intern(&lf[4],4,"time");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[8]=C_h_intern(&lf[8],12,"current-time");
lf[9]=C_h_intern(&lf[9],20,"srfi-18:current-time");
lf[10]=C_h_intern(&lf[10],13,"time->seconds");
lf[11]=C_h_intern(&lf[11],18,"time->milliseconds");
lf[12]=C_h_intern(&lf[12],13,"seconds->time");
lf[13]=C_h_intern(&lf[13],19,"\003sysflonum-fraction");
lf[14]=C_h_intern(&lf[14],18,"\003sysexact->inexact");
lf[15]=C_h_intern(&lf[15],3,"max");
lf[16]=C_h_intern(&lf[16],18,"milliseconds->time");
lf[17]=C_h_intern(&lf[17],5,"time\077");
lf[18]=C_h_intern(&lf[18],13,"srfi-18:time\077");
lf[19]=C_h_intern(&lf[19],5,"raise");
lf[20]=C_h_intern(&lf[20],10,"\003syssignal");
lf[21]=C_h_intern(&lf[21],23,"join-timeout-exception\077");
lf[22]=C_h_intern(&lf[22],9,"condition");
lf[23]=C_h_intern(&lf[23],22,"join-timeout-exception");
lf[24]=C_h_intern(&lf[24],26,"abandoned-mutex-exception\077");
lf[25]=C_h_intern(&lf[25],25,"abandoned-mutex-exception");
lf[26]=C_h_intern(&lf[26],28,"terminated-thread-exception\077");
lf[27]=C_h_intern(&lf[27],27,"terminated-thread-exception");
lf[28]=C_h_intern(&lf[28],19,"uncaught-exception\077");
lf[29]=C_h_intern(&lf[29],18,"uncaught-exception");
lf[30]=C_h_intern(&lf[30],25,"uncaught-exception-reason");
lf[31]=C_h_intern(&lf[31],6,"gensym");
lf[32]=C_h_intern(&lf[32],11,"make-thread");
lf[33]=C_h_intern(&lf[33],12,"\003sysschedule");
lf[34]=C_h_intern(&lf[34],16,"\003systhread-kill!");
lf[35]=C_h_intern(&lf[35],4,"dead");
lf[36]=C_h_intern(&lf[36],18,"\003syscurrent-thread");
lf[37]=C_h_intern(&lf[37],15,"\003sysmake-thread");
lf[38]=C_h_intern(&lf[38],7,"created");
lf[39]=C_h_intern(&lf[39],6,"thread");
lf[40]=C_h_intern(&lf[40],7,"thread\077");
lf[41]=C_h_intern(&lf[41],14,"current-thread");
lf[42]=C_h_intern(&lf[42],12,"thread-state");
lf[43]=C_h_intern(&lf[43],15,"thread-specific");
lf[44]=C_h_intern(&lf[44],20,"thread-specific-set!");
lf[45]=C_h_intern(&lf[45],14,"thread-quantum");
lf[46]=C_h_intern(&lf[46],19,"thread-quantum-set!");
lf[47]=C_h_intern(&lf[47],11,"thread-name");
lf[48]=C_h_intern(&lf[48],13,"thread-start!");
lf[49]=C_h_intern(&lf[49],5,"ready");
lf[50]=C_h_intern(&lf[50],22,"\003sysadd-to-ready-queue");
lf[51]=C_h_intern(&lf[51],9,"\003syserror");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\047thread can not be started a second time");
lf[53]=C_h_intern(&lf[53],13,"thread-yield!");
lf[54]=C_h_intern(&lf[54],17,"\003systhread-yield!");
lf[55]=C_h_intern(&lf[55],12,"thread-join!");
lf[56]=C_h_intern(&lf[56],10,"terminated");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[60]=C_h_intern(&lf[60],33,"\003systhread-block-for-termination!");
lf[61]=C_h_intern(&lf[61],29,"\003systhread-block-for-timeout!");
lf[62]=C_h_intern(&lf[62],17,"thread-terminate!");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[64]=C_h_intern(&lf[64],21,"\003sysprimordial-thread");
lf[65]=C_h_intern(&lf[65],16,"\003sysexit-handler");
lf[66]=C_h_intern(&lf[66],15,"thread-suspend!");
lf[67]=C_h_intern(&lf[67],9,"suspended");
lf[68]=C_h_intern(&lf[68],14,"thread-resume!");
lf[69]=C_h_intern(&lf[69],13,"thread-sleep!");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[71]=C_h_intern(&lf[71],6,"mutex\077");
lf[72]=C_h_intern(&lf[72],5,"mutex");
lf[73]=C_h_intern(&lf[73],10,"make-mutex");
lf[74]=C_h_intern(&lf[74],14,"\003sysmake-mutex");
lf[75]=C_h_intern(&lf[75],10,"mutex-name");
lf[76]=C_h_intern(&lf[76],14,"mutex-specific");
lf[77]=C_h_intern(&lf[77],19,"mutex-specific-set!");
lf[78]=C_h_intern(&lf[78],11,"mutex-state");
lf[79]=C_h_intern(&lf[79],9,"not-owned");
lf[80]=C_h_intern(&lf[80],9,"abandoned");
lf[81]=C_h_intern(&lf[81],13,"not-abandoned");
lf[82]=C_h_intern(&lf[82],11,"mutex-lock!");
lf[83]=C_h_intern(&lf[83],10,"\003sysappend");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[85]=C_h_intern(&lf[85],8,"\003sysdelq");
lf[86]=C_h_intern(&lf[86],8,"sleeping");
lf[87]=C_h_intern(&lf[87],13,"mutex-unlock!");
lf[88]=C_h_intern(&lf[88],18,"condition-variable");
lf[89]=C_h_intern(&lf[89],7,"blocked");
lf[90]=C_h_intern(&lf[90],23,"make-condition-variable");
lf[91]=C_h_intern(&lf[91],19,"condition-variable\077");
lf[92]=C_h_intern(&lf[92],27,"condition-variable-specific");
lf[93]=C_h_intern(&lf[93],32,"condition-variable-specific-set!");
lf[94]=C_h_intern(&lf[94],26,"condition-variable-signal!");
lf[95]=C_h_intern(&lf[95],25,"\003systhread-basic-unblock!");
lf[96]=C_h_intern(&lf[96],29,"condition-variable-broadcast!");
lf[97]=C_h_intern(&lf[97],12,"\003sysfor-each");
lf[98]=C_h_intern(&lf[98],14,"thread-signal!");
lf[99]=C_h_intern(&lf[99],19,"\003systhread-unblock!");
lf[100]=C_h_intern(&lf[100],20,"thread-wait-for-i/o!");
lf[101]=C_h_intern(&lf[101],25,"\003systhread-block-for-i/o!");
lf[102]=C_h_intern(&lf[102],4,"\000all");
lf[103]=C_h_intern(&lf[103],4,"msvc");
lf[104]=C_h_intern(&lf[104],20,"\003sysread-prompt-hook");
lf[105]=C_h_intern(&lf[105],13,"\003systty-port\077");
lf[106]=C_h_intern(&lf[106],18,"\003sysstandard-input");
lf[107]=C_h_intern(&lf[107],14,"build-platform");
lf[108]=C_h_intern(&lf[108],27,"condition-property-accessor");
lf[109]=C_h_intern(&lf[109],6,"reason");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],7,"srfi-18");
C_register_lf2(lf,112,create_ptable());
t2=C_mutate(&lf[0] /* c633 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_694,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k692 */
static void C_ccall f_694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 55   register-feature!");
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[111]);}

/* k695 in k692 */
static void C_ccall f_697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_697,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* compute-time-limit ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_699,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* current-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_742,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[9]+1 /* srfi-18:current-time ...) */,*((C_word*)lf[8]+1));
t6=C_mutate((C_word*)lf[10]+1 /* time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_769,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* time->milliseconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_790,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[12]+1 /* seconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_819,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* milliseconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* time? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* srfi-18:time? ...) */,*((C_word*)lf[17]+1));
t12=C_mutate((C_word*)lf[19]+1 /* raise ...) */,*((C_word*)lf[20]+1));
t13=C_mutate((C_word*)lf[21]+1 /* join-timeout-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[24]+1 /* abandoned-mutex-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* terminated-thread-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[28]+1 /* uncaught-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 151  condition-property-accessor");
t18=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,lf[29],lf[109]);}

/* k961 in k695 in k692 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[100],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* uncaught-exception-reason ...) */,t1);
t3=*((C_word*)lf[31]+1);
t4=C_mutate((C_word*)lf[32]+1 /* make-thread ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_965,a[2]=t3,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[40]+1 /* thread? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[41]+1 /* current-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[42]+1 /* thread-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[43]+1 /* thread-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[44]+1 /* thread-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[45]+1 /* thread-quantum ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[46]+1 /* thread-quantum-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[47]+1 /* thread-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[32]+1);
t14=C_mutate((C_word*)lf[48]+1 /* thread-start! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t13,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[53]+1 /* thread-yield! ...) */,*((C_word*)lf[54]+1));
t16=C_mutate((C_word*)lf[55]+1 /* thread-join! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[62]+1 /* thread-terminate! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[66]+1 /* thread-suspend! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1278,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[68]+1 /* thread-resume! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[69]+1 /* thread-sleep! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[71]+1 /* mutex? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t22=*((C_word*)lf[31]+1);
t23=C_mutate((C_word*)lf[73]+1 /* make-mutex ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1379,a[2]=t22,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[75]+1 /* mutex-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[76]+1 /* mutex-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* mutex-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* mutex-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[82]+1 /* mutex-lock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[87]+1 /* mutex-unlock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[31]+1);
t31=C_mutate((C_word*)lf[90]+1 /* make-condition-variable ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1842,a[2]=t30,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t32=C_mutate((C_word*)lf[91]+1 /* condition-variable? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[92]+1 /* condition-variable-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[93]+1 /* condition-variable-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[94]+1 /* condition-variable-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[96]+1 /* condition-variable-broadcast! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[98]+1 /* thread-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1965,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2064,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 468  build-platform");
t40=*((C_word*)lf[107]+1);
((C_proc2)C_retrieve_proc(t40))(2,t40,t39);}

/* k2062 in k961 in k695 in k692 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_1999(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[104]+1);
t4=*((C_word*)lf[53]+1);
t5=C_mutate((C_word*)lf[104]+1 /* read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t3,a[3]=t4,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t0)[2];
f_1999(t6,t5);}}

/* ##sys#read-prompt-hook in k2062 in k961 in k695 in k692 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2048(2,t4,t2);}
else{
C_trace("srfi-18.scm: 473  ##sys#tty-port?");
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[106]+1));}}

/* k2046 in ##sys#read-prompt-hook in k2062 in k961 in k695 in k692 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 474  old");
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2049 in k2046 in ##sys#read-prompt-hook in k2062 in k961 in k695 in k692 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 475  ##sys#thread-block-for-i/o!");
t3=*((C_word*)lf[101]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[36]+1),C_fix(0),C_SCHEME_TRUE);}

/* k2052 in k2049 in k2046 in ##sys#read-prompt-hook in k2062 in k961 in k695 in k692 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 476  thread-yield!");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1997 in k961 in k695 in k692 */
static void C_fcall f_1999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1999,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1 /* thread-wait-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2001,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* thread-wait-for-i/o! in k1997 in k961 in k695 in k692 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2001r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2001r(t0,t1,t2,t3);}}

static void C_ccall f_2001r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2005(2,t5,lf[102]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2005(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[1],t3);}}}

/* k2003 in thread-wait-for-i/o! in k1997 in k961 in k695 in k692 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[100]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 483  ##sys#thread-block-for-i/o!");
t4=*((C_word*)lf[101]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[36]+1),((C_word*)t0)[3],t1);}

/* k2009 in k2003 in thread-wait-for-i/o! in k1997 in k961 in k695 in k692 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 484  thread-yield!");
t2=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* thread-signal! in k961 in k695 in k692 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1965,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[98]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[36]+1));
if(C_truep(t5)){
C_trace("srfi-18.scm: 456  ##sys#signal");
t6=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=t3,a[3]=t6,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t2,C_fix(1),t7);
C_trace("srfi-18.scm: 463  ##sys#thread-unblock!");
t9=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t2);}}

/* a1988 in thread-signal! in k961 in k695 in k692 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 461  ##sys#signal");
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1991 in a1988 in thread-signal! in k961 in k695 in k692 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 462  old");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k961 in k695 in k692 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1928,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(2));
C_trace("srfi-18.scm: 442  ##sys#for-each");
t7=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a1939 in condition-variable-broadcast! in k961 in k695 in k692 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1940,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[86]));
if(C_truep(t5)){
C_trace("srfi-18.scm: 446  ##sys#thread-basic-unblock!");
t6=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1933 in condition-variable-broadcast! in k961 in k695 in k692 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k961 in k695 in k692 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1885,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[94]);
t4=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_i_setslot(t2,C_fix(2),t7);
t9=(C_word)C_eqp(t6,lf[89]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[86]));
if(C_truep(t10)){
C_trace("srfi-18.scm: 437  ##sys#thread-basic-unblock!");
t11=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k961 in k695 in k692 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1876,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[88],lf[93]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k961 in k695 in k692 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1867,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[88],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k961 in k695 in k692 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1861,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[88]));}

/* make-condition-variable in k961 in k695 in k692 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1842r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1842r(t0,t1,t2);}}

static void C_ccall f_1842r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1850(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
C_trace("srfi-18.scm: 413  gensym");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[88]);}}

/* k1848 in make-condition-variable in k961 in k695 in k692 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[88],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1660r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1660r(t0,t1,t2,t3);}}

static void C_ccall f_1660r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[87]);
t5=*((C_word*)lf[36]+1);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t3);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_SCHEME_FALSE);
t11=(C_truep(t7)?(C_word)C_i_check_structure_2(t7,lf[88],lf[87]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1678,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp);
C_trace("srfi-18.scm: 372  ##sys#call-with-current-continuation");
C_call_cc(3,0,t1,t12);}

/* a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1678,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("srfi-18.scm: 375  ##sys#compute-time-limit");
t5=lf[3];
f_699(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1685(2,t5,C_SCHEME_FALSE);}}

/* k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1814,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
C_trace("srfi-18.scm: 379  ##sys#delq");
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[7],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1796,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
C_trace("srfi-18.scm: 382  ##sys#append");
t9=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1700(2,t6,C_SCHEME_UNDEFINED);}}

/* k1794 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
C_trace("srfi-18.scm: 389  ##sys#thread-block-for-timeout!");
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1700(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[86]));}}

/* a1773 in k1794 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1785,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
C_trace("srfi-18.scm: 387  ##sys#delq");
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1783 in a1773 in k1794 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1);
C_trace("srfi-18.scm: 388  return");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1698 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1703(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_TRUE);
t8=(C_word)C_eqp(t4,lf[89]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[86]));
if(C_truep(t9)){
t10=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t11=(C_word)C_slot(t3,C_fix(8));
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11);
t13=(C_word)C_i_setslot(t3,C_fix(8),t12);
t14=(C_word)C_eqp(t4,lf[86]);
if(C_truep(t14)){
C_trace("srfi-18.scm: 400  ##sys#add-to-ready-queue");
t15=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t2,t3);}
else{
t15=t2;
f_1703(2,t15,C_SCHEME_UNDEFINED);}}
else{
t10=t2;
f_1703(2,t10,C_SCHEME_UNDEFINED);}}}

/* k1701 in k1698 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 401  ##sys#schedule");
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1805 in k1812 in k1683 in a1677 in mutex-unlock! in k961 in k695 in k692 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
C_trace("srfi-18.scm: 380  return");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1448r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1448r(t0,t1,t2,t3);}}

static void C_ccall f_1448r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[82]);
t5=(C_word)C_notvemptyp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1458,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_vector_ref(t3,C_fix(0));
C_trace("srfi-18.scm: 318  ##sys#compute-time-limit");
t8=lf[3];
f_699(t8,t6,t7);}
else{
t7=t6;
f_1458(2,t7,C_SCHEME_FALSE);}}

/* k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?(C_word)C_i_check_structure_2(t4,lf[39],lf[82]):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1475,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word)li44),tmp=(C_word)a,a+=8,tmp);
C_trace("srfi-18.scm: 323  ##sys#call-with-current-continuation");
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1475,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1478,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1499,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("srfi-18.scm: 349  check");
t7=t5;
f_1499(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[86]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t2,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
C_trace("srfi-18.scm: 362  switch");
t9=t4;
f_1478(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1523,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_1523(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[56],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[35],t9));
if(C_truep(t11)){
t12=t6;
f_1523(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_1523(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k1521 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_fcall f_1523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1523,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 346  check");
t3=((C_word*)t0)[2];
f_1499(t3,t2);}

/* k1524 in k1521 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 347  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1632 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
C_trace("srfi-18.scm: 361  return");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* k1583 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 357  ##sys#thread-block-for-timeout!");
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k1589 in k1583 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 358  switch");
t2=((C_word*)t0)[3];
f_1478(t2,((C_word*)t0)[2]);}

/* a1595 in k1583 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1618,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
C_trace("srfi-18.scm: 353  ##sys#delq");
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1616 in a1595 in k1583 in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=(C_word)C_slot(*((C_word*)lf[36]+1),C_fix(8));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_i_setslot(*((C_word*)lf[36]+1),C_fix(8),t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}

/* check in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_fcall f_1499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1499,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[22],lf[84],C_SCHEME_END_OF_LIST);
C_trace("srfi-18.scm: 331  ##sys#signal");
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1508 in check in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 331  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_fcall f_1478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1478,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("srfi-18.scm: 327  ##sys#append");
t5=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1487 in switch in a1474 in k1456 in mutex-lock! in k961 in k695 in k692 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
C_trace("srfi-18.scm: 328  ##sys#schedule");
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k961 in k695 in k692 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1424,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[78]);
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[79]));}
else{
t4=(C_word)C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[80]:lf[81]));}}

/* mutex-specific-set! in k961 in k695 in k692 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1415,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[72],lf[77]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k961 in k695 in k692 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1406,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k961 in k695 in k692 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1397,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k961 in k695 in k692 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1379r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1379r(t0,t1,t2);}}

static void C_ccall f_1379r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1383(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
C_trace("srfi-18.scm: 292  gensym");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[72]);}}

/* k1381 in make-mutex in k961 in k695 in k692 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 293  ##sys#make-mutex");
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* mutex? in k961 in k695 in k692 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1373,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[72]));}

/* thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1333,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1361,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_1361(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("srfi-18.scm: 281  ##sys#signal-hook");
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[6],lf[69],lf[70],t2);}}

/* k1359 in thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 282  ##sys#compute-time-limit");
t3=lf[3];
f_699(t3,t2,((C_word*)t0)[2]);}

/* k1366 in k1359 in thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1342,a[2]=t1,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 275  ##sys#call-with-current-continuation");
C_call_cc(3,0,t2,t3);}

/* a1341 in k1366 in k1359 in thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1342,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t2,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 279  ##sys#thread-block-for-timeout!");
t7=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,((C_word*)t0)[2]);}

/* k1347 in a1341 in k1366 in k1359 in thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 280  ##sys#schedule");
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1353 in a1341 in k1366 in k1359 in thread-sleep! in k961 in k695 in k692 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
C_trace("srfi-18.scm: 278  return");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k961 in k695 in k692 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1311,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[68]);
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_eqp(t4,lf[67]);
if(C_truep(t5)){
t6=(C_word)C_i_setslot(t2,C_fix(3),lf[49]);
C_trace("srfi-18.scm: 271  ##sys#add-to-ready-queue");
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k961 in k695 in k692 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1278,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[66]);
t4=(C_word)C_i_setslot(t2,C_fix(3),lf[67]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[36]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1296,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 262  ##sys#call-with-current-continuation");
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1295 in thread-suspend! in k961 in k695 in k692 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1296,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1305,a[2]=t2,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
C_trace("srfi-18.scm: 265  ##sys#schedule");
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a1304 in a1295 in thread-suspend! in k961 in k695 in k692 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
C_trace("srfi-18.scm: 264  return");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k961 in k695 in k692 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1234,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[64]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 252  ##sys#exit-handler");
t7=*((C_word*)lf[65]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=t4;
f_1241(2,t6,C_SCHEME_UNDEFINED);}}

/* k1274 in thread-terminate! in k961 in k695 in k692 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1239 in thread-terminate! in k961 in k695 in k692 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_SCHEME_UNDEFINED);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t2);
t4=(C_word)C_a_i_record(&a,3,lf[22],lf[63],C_SCHEME_END_OF_LIST);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 255  ##sys#thread-kill!");
t7=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],lf[56]);}

/* k1248 in k1239 in thread-terminate! in k961 in k695 in k692 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[36]+1));
if(C_truep(t2)){
C_trace("srfi-18.scm: 256  ##sys#schedule");
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k961 in k695 in k692 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1115r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1115r(t0,t1,t2,t3);}}

static void C_ccall f_1115r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[55]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1122,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
C_trace("srfi-18.scm: 221  ##sys#compute-time-limit");
t7=lf[3];
f_699(t7,t5,t6);}
else{
t6=t5;
f_1122(2,t6,C_SCHEME_FALSE);}}

/* k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1136,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp);
C_trace("srfi-18.scm: 225  ##sys#call-with-current-continuation");
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1136,3,t0,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1140,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("srfi-18.scm: 228  ##sys#thread-block-for-timeout!");
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_1140(2,t5,C_SCHEME_UNDEFINED);}}

/* k1138 in a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 246  ##sys#thread-block-for-termination!");
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k1144 in k1138 in a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 247  ##sys#schedule");
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1150 in k1138 in a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_eqp(t2,lf[35]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
C_apply(4,0,t1,((C_word*)t0)[4],t4);}
else{
t4=(C_word)C_eqp(t2,lf[56]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[57],t6);
t8=(C_word)C_a_i_record(&a,3,lf[22],lf[58],t7);
C_trace("srfi-18.scm: 236  ##sys#signal");
t9=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_1200(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[22],lf[59],C_SCHEME_END_OF_LIST);
C_trace("srfi-18.scm: 244  ##sys#signal");
t7=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k1198 in a1150 in k1138 in a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 241  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1179 in a1150 in k1138 in a1135 in k1120 in thread-join! in k961 in k695 in k692 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 235  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* thread-start! in k961 in k695 in k692 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1079,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1083,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 208  make-thread");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_1083(t5,(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[39],lf[48]));}}

/* k1107 in thread-start! in k961 in k695 in k692 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1083(t3,t2);}

/* k1081 in thread-start! in k961 in k695 in k692 */
static void C_fcall f_1083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1083,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[38],t3);
if(C_truep(t4)){
t5=t2;
f_1086(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("srfi-18.scm: 211  ##sys#error");
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[48],lf[52],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1084 in k1081 in thread-start! in k961 in k695 in k692 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[49]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 213  ##sys#add-to-ready-queue");
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k1090 in k1084 in k1081 in thread-start! in k961 in k695 in k692 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k961 in k695 in k692 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1070,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[47]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k961 in k695 in k692 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1054,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[46]);
t5=(C_word)C_i_check_exact_2(t3,lf[46]);
t6=(C_word)C_i_fixnum_max(t3,C_fix(10));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_i_slot(t2,C_fix(9),t6));}

/* thread-quantum in k961 in k695 in k692 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1045,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[45]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k961 in k695 in k692 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1036,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[39],lf[44]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k961 in k695 in k692 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1027,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[43]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k961 in k695 in k692 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1018,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[39],lf[42]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k961 in k695 in k692 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[36]+1));}

/* thread? in k961 in k695 in k692 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1009,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[39]));}

/* make-thread in k961 in k695 in k692 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_965r(t0,t1,t2,t3);}}

static void C_ccall f_965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_969,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_994(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
C_trace("srfi-18.scm: 163  gensym");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[39]);}}

/* k992 in make-thread in k961 in k695 in k692 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[36]+1),C_fix(9));
C_trace("srfi-18.scm: 160  ##sys#make-thread");
t3=*((C_word*)lf[37]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[38],t1,t2);}

/* k967 in make-thread in k961 in k695 in k692 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a973 in k967 in make-thread in k961 in k695 in k692 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
C_trace("srfi-18.scm: 168  ##sys#call-with-values");
C_call_with_values(4,0,t1,((C_word*)t0)[2],t2);}

/* a979 in a973 in k967 in make-thread in k961 in k695 in k692 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_980r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_980r(t0,t1,t2);}}

static void C_ccall f_980r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 172  ##sys#thread-kill!");
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[35]);}

/* k985 in a979 in a973 in k967 in make-thread in k961 in k695 in k692 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 173  ##sys#schedule");
t2=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k695 in k692 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_945,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[29],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k695 in k692 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_929,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k695 in k692 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_913,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k695 in k692 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_897,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[22]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k695 in k692 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_889,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[4]));}

/* milliseconds->time in k695 in k692 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_873,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[16]);
t4=(C_word)C_a_i_divide(&a,2,t2,C_fix(1000));
t5=(C_word)C_a_i_plus(&a,2,C_flonum(&a,C_startup_time_seconds),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[4],t2,t5,C_fix(0)));}

/* seconds->time in k695 in k692 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_819,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[12]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_826,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
C_trace("srfi-18.scm: 115  max");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_fix(0),t5);}

/* k824 in seconds->time in k695 in k692 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_829,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_863,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("srfi-18.scm: 116  ##sys#exact->inexact");
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k865 in k824 in seconds->time in k695 in k692 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("srfi-18.scm: 116  ##sys#flonum-fraction");
t2=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k861 in k824 in seconds->time in k695 in k692 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
C_trace("srfi-18.scm: 116  truncate");
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k827 in k824 in seconds->time in k695 in k692 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
C_trace("srfi-18.scm: 117  truncate");
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k845 in k827 in k824 in seconds->time in k695 in k692 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_839,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("srfi-18.scm: 118  truncate");
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k837 in k845 in k827 in k824 in seconds->time in k695 in k692 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_839,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[4],((C_word*)t0)[2],t1,t2));}

/* time->milliseconds in k695 in k692 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_790,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[4],lf[11]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_flonum(&a,C_startup_time_seconds));
t6=(C_word)C_a_i_times(&a,2,t5,C_fix(1000));
t7=(C_word)C_i_inexact_to_exact(t6);
t8=(C_word)C_slot(t2,C_fix(3));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_plus(&a,2,t7,t8));}

/* time->seconds in k695 in k692 */
static void C_ccall f_769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_769,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[4],lf[10]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_a_i_divide(&a,2,t5,C_fix(1000));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_plus(&a,2,t4,t6));}

/* current-time in k695 in k692 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_754,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
C_trace("srfi-18.scm: 98   truncate");
t9=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}

/* k752 in current-time in k695 in k692 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[4],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k695 in k692 */
static void C_fcall f_699(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_699,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_733,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
C_trace("srfi-18.scm: 75   truncate");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
C_trace("srfi-18.scm: 76   ##sys#signal-hook");
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[6],lf[7],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k731 in ##sys#compute-time-limit in k695 in k692 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[117] = {
{"toplevelsrfi-18.scm",(void*)C_srfi_18_toplevel},
{"f_694srfi-18.scm",(void*)f_694},
{"f_697srfi-18.scm",(void*)f_697},
{"f_963srfi-18.scm",(void*)f_963},
{"f_2064srfi-18.scm",(void*)f_2064},
{"f_2038srfi-18.scm",(void*)f_2038},
{"f_2048srfi-18.scm",(void*)f_2048},
{"f_2051srfi-18.scm",(void*)f_2051},
{"f_2054srfi-18.scm",(void*)f_2054},
{"f_1999srfi-18.scm",(void*)f_1999},
{"f_2001srfi-18.scm",(void*)f_2001},
{"f_2005srfi-18.scm",(void*)f_2005},
{"f_2011srfi-18.scm",(void*)f_2011},
{"f_1965srfi-18.scm",(void*)f_1965},
{"f_1989srfi-18.scm",(void*)f_1989},
{"f_1993srfi-18.scm",(void*)f_1993},
{"f_1928srfi-18.scm",(void*)f_1928},
{"f_1940srfi-18.scm",(void*)f_1940},
{"f_1935srfi-18.scm",(void*)f_1935},
{"f_1885srfi-18.scm",(void*)f_1885},
{"f_1876srfi-18.scm",(void*)f_1876},
{"f_1867srfi-18.scm",(void*)f_1867},
{"f_1861srfi-18.scm",(void*)f_1861},
{"f_1842srfi-18.scm",(void*)f_1842},
{"f_1850srfi-18.scm",(void*)f_1850},
{"f_1660srfi-18.scm",(void*)f_1660},
{"f_1678srfi-18.scm",(void*)f_1678},
{"f_1685srfi-18.scm",(void*)f_1685},
{"f_1814srfi-18.scm",(void*)f_1814},
{"f_1796srfi-18.scm",(void*)f_1796},
{"f_1774srfi-18.scm",(void*)f_1774},
{"f_1785srfi-18.scm",(void*)f_1785},
{"f_1700srfi-18.scm",(void*)f_1700},
{"f_1703srfi-18.scm",(void*)f_1703},
{"f_1806srfi-18.scm",(void*)f_1806},
{"f_1448srfi-18.scm",(void*)f_1448},
{"f_1458srfi-18.scm",(void*)f_1458},
{"f_1475srfi-18.scm",(void*)f_1475},
{"f_1523srfi-18.scm",(void*)f_1523},
{"f_1526srfi-18.scm",(void*)f_1526},
{"f_1633srfi-18.scm",(void*)f_1633},
{"f_1585srfi-18.scm",(void*)f_1585},
{"f_1591srfi-18.scm",(void*)f_1591},
{"f_1596srfi-18.scm",(void*)f_1596},
{"f_1618srfi-18.scm",(void*)f_1618},
{"f_1499srfi-18.scm",(void*)f_1499},
{"f_1510srfi-18.scm",(void*)f_1510},
{"f_1478srfi-18.scm",(void*)f_1478},
{"f_1489srfi-18.scm",(void*)f_1489},
{"f_1424srfi-18.scm",(void*)f_1424},
{"f_1415srfi-18.scm",(void*)f_1415},
{"f_1406srfi-18.scm",(void*)f_1406},
{"f_1397srfi-18.scm",(void*)f_1397},
{"f_1379srfi-18.scm",(void*)f_1379},
{"f_1383srfi-18.scm",(void*)f_1383},
{"f_1373srfi-18.scm",(void*)f_1373},
{"f_1333srfi-18.scm",(void*)f_1333},
{"f_1361srfi-18.scm",(void*)f_1361},
{"f_1368srfi-18.scm",(void*)f_1368},
{"f_1342srfi-18.scm",(void*)f_1342},
{"f_1349srfi-18.scm",(void*)f_1349},
{"f_1354srfi-18.scm",(void*)f_1354},
{"f_1311srfi-18.scm",(void*)f_1311},
{"f_1278srfi-18.scm",(void*)f_1278},
{"f_1296srfi-18.scm",(void*)f_1296},
{"f_1305srfi-18.scm",(void*)f_1305},
{"f_1234srfi-18.scm",(void*)f_1234},
{"f_1276srfi-18.scm",(void*)f_1276},
{"f_1241srfi-18.scm",(void*)f_1241},
{"f_1250srfi-18.scm",(void*)f_1250},
{"f_1115srfi-18.scm",(void*)f_1115},
{"f_1122srfi-18.scm",(void*)f_1122},
{"f_1136srfi-18.scm",(void*)f_1136},
{"f_1140srfi-18.scm",(void*)f_1140},
{"f_1146srfi-18.scm",(void*)f_1146},
{"f_1151srfi-18.scm",(void*)f_1151},
{"f_1200srfi-18.scm",(void*)f_1200},
{"f_1181srfi-18.scm",(void*)f_1181},
{"f_1079srfi-18.scm",(void*)f_1079},
{"f_1109srfi-18.scm",(void*)f_1109},
{"f_1083srfi-18.scm",(void*)f_1083},
{"f_1086srfi-18.scm",(void*)f_1086},
{"f_1092srfi-18.scm",(void*)f_1092},
{"f_1070srfi-18.scm",(void*)f_1070},
{"f_1054srfi-18.scm",(void*)f_1054},
{"f_1045srfi-18.scm",(void*)f_1045},
{"f_1036srfi-18.scm",(void*)f_1036},
{"f_1027srfi-18.scm",(void*)f_1027},
{"f_1018srfi-18.scm",(void*)f_1018},
{"f_1015srfi-18.scm",(void*)f_1015},
{"f_1009srfi-18.scm",(void*)f_1009},
{"f_965srfi-18.scm",(void*)f_965},
{"f_994srfi-18.scm",(void*)f_994},
{"f_969srfi-18.scm",(void*)f_969},
{"f_974srfi-18.scm",(void*)f_974},
{"f_980srfi-18.scm",(void*)f_980},
{"f_987srfi-18.scm",(void*)f_987},
{"f_945srfi-18.scm",(void*)f_945},
{"f_929srfi-18.scm",(void*)f_929},
{"f_913srfi-18.scm",(void*)f_913},
{"f_897srfi-18.scm",(void*)f_897},
{"f_889srfi-18.scm",(void*)f_889},
{"f_873srfi-18.scm",(void*)f_873},
{"f_819srfi-18.scm",(void*)f_819},
{"f_826srfi-18.scm",(void*)f_826},
{"f_867srfi-18.scm",(void*)f_867},
{"f_863srfi-18.scm",(void*)f_863},
{"f_829srfi-18.scm",(void*)f_829},
{"f_847srfi-18.scm",(void*)f_847},
{"f_839srfi-18.scm",(void*)f_839},
{"f_790srfi-18.scm",(void*)f_790},
{"f_769srfi-18.scm",(void*)f_769},
{"f_742srfi-18.scm",(void*)f_742},
{"f_754srfi-18.scm",(void*)f_754},
{"f_699srfi-18.scm",(void*)f_699},
{"f_733srfi-18.scm",(void*)f_733},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
