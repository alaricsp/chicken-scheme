/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: tcp.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[96];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,26),40,35,35,110,101,116,35,115,111,99,107,101,116,32,97,50,57,51,52,32,97,50,56,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,13),40,35,35,110,101,116,35,99,108,111,115,101,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,23),40,35,35,110,101,116,35,115,104,117,116,100,111,119,110,32,97,57,54,49,48,49,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,24),40,35,35,110,101,116,35,109,97,107,101,45,110,111,110,98,108,111,99,107,105,110,103,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,35,35,110,101,116,35,103,101,116,115,111,99,107,112,111,114,116,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,14),40,35,35,110,101,116,35,115,101,108,101,99,116,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,50,48,51,50,48,56,32,97,50,48,50,50,48,57,32,97,50,48,49,50,49,48,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,48,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,17),40,97,49,50,49,49,32,114,101,116,117,114,110,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,51,55,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,35),40,35,35,110,101,116,35,112,97,114,115,101,45,104,111,115,116,32,104,111,115,116,50,50,56,32,112,114,111,116,111,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,57,53,32,97,50,57,48,50,57,51,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,49,52,51,48,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,97,49,52,51,54,32,115,51,51,56,51,51,57,51,52,52,32,97,100,100,114,51,52,48,51,52,49,51,52,53,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,51,50,52,32,119,51,51,52,32,104,111,115,116,51,51,53,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,51,50,55,32,37,119,51,50,50,51,53,57,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,51,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,51,49,52,32,46,32,109,111,114,101,51,49,53,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,51,55,53,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,51,56,49,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,55,51,32,120,52,48,51,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,52,48,49,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,53,57,56,32,111,102,102,115,101,116,53,57,57,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,53,57,50,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,102,95,49,57,48,48,32,115,54,51,52,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,13),40,102,95,49,57,50,48,32,115,54,52,48,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,48,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,49,56,56,52,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,57,51,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,57,53,55,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,49,57,57,50,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,53,50,55,32,109,53,50,56,32,115,116,97,114,116,53,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,34),40,97,50,48,51,53,32,112,53,49,56,32,110,53,49,57,32,100,101,115,116,53,50,48,32,115,116,97,114,116,53,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,23),40,97,50,49,49,56,32,112,111,115,50,53,54,53,32,110,101,120,116,53,54,54,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,53,53,54,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,21),40,97,50,49,48,48,32,112,53,52,57,32,108,105,109,105,116,53,53,48,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,52,49,57,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,54,55,57,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,55,48,56,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,50,53,54,54,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,29),40,97,50,53,55,50,32,104,111,115,116,55,53,48,55,53,51,32,112,111,114,116,55,53,49,55,53,52,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,55,51,51,32,46,32,109,111,114,101,55,51,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,56,49,57,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,56,50,51,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,56,52,49,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,56,53,57,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,56,55,51,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,56,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2346 */
static C_word C_fcall stub725(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub725(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k2335 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub719(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub719(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from k1398 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub291(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub291(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k1306 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub256(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub256(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k1192 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from k1177 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1170 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub168(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from k1132 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1121 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1114 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1107 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub141(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1096 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1086 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k1060 */
static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k1045 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k1031 */
static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k1012 */
static C_word C_fcall stub76(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub76(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k999 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k984 */
static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k970 */
static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k955 */
static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_fcall f_2374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_fcall f_2225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_fcall f_1602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_fcall f_1618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2107)
static void C_fcall f_2107(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2042)
static void C_fcall f_2042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_fcall f_1829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_fcall f_1631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_fcall f_1571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1473)
static void C_fcall f_1473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_fcall f_1468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1425)
static void C_fcall f_1425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_fcall f_1227(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1236)
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_fcall f_1206(C_word t0) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_fcall f_1181(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static C_word C_fcall f_1167(C_word t0);
C_noret_decl(f_1111)
static C_word C_fcall f_1111(C_word t0);
C_noret_decl(f_1093)
static C_word C_fcall f_1093(C_word t0);
C_noret_decl(f_1038)
static C_word C_fcall f_1038(C_word t0,C_word t1);
C_noret_decl(f_1009)
static C_word C_fcall f_1009(C_word t0);
C_noret_decl(f_944)
static C_word C_fcall f_944(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2458(t0,t1);}

C_noret_decl(trf_2374)
static void C_fcall trf_2374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2374(t0,t1);}

C_noret_decl(trf_2225)
static void C_fcall trf_2225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2225(t0,t1);}

C_noret_decl(trf_1602)
static void C_fcall trf_1602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1602(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1602(t0,t1,t2);}

C_noret_decl(trf_1618)
static void C_fcall trf_1618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1618(t0,t1);}

C_noret_decl(trf_2107)
static void C_fcall trf_2107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2107(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2107(t0,t1,t2);}

C_noret_decl(trf_2042)
static void C_fcall trf_2042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2042(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2042(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2007(t0,t1);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1868(t0,t1);}

C_noret_decl(trf_1829)
static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1829(t0,t1);}

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1838(t0,t1);}

C_noret_decl(trf_1699)
static void C_fcall trf_1699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1699(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1699(t0,t1,t2);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1709(t0,t1,t2,t3);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1625(t0,t1);}

C_noret_decl(trf_1631)
static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1631(t0,t1);}

C_noret_decl(trf_1571)
static void C_fcall trf_1571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1571(t0,t1);}

C_noret_decl(trf_1473)
static void C_fcall trf_1473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1473(t0,t1);}

C_noret_decl(trf_1468)
static void C_fcall trf_1468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1468(t0,t1,t2);}

C_noret_decl(trf_1425)
static void C_fcall trf_1425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1425(t0,t1,t2,t3);}

C_noret_decl(trf_1227)
static void C_fcall trf_1227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1227(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1227(t0,t1,t2,t3);}

C_noret_decl(trf_1236)
static void C_fcall trf_1236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1236(t0,t1,t2);}

C_noret_decl(trf_1206)
static void C_fcall trf_1206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1206(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1206(t0);}

C_noret_decl(trf_1181)
static void C_fcall trf_1181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1181(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1181(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(430)){
C_save(t1);
C_rereclaim2(430*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,96);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[9]=C_h_intern(&lf[9],17,"\003sysmake-c-string");
lf[11]=C_h_intern(&lf[11],18,"\003syscurrent-thread");
lf[12]=C_h_intern(&lf[12],12,"\003sysschedule");
lf[13]=C_h_intern(&lf[13],9,"substring");
lf[15]=C_h_intern(&lf[15],15,"\003syssignal-hook");
lf[16]=C_h_intern(&lf[16],14,"\000network-error");
lf[17]=C_h_intern(&lf[17],11,"tcp-connect");
lf[18]=C_h_intern(&lf[18],17,"\003sysstring-append");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[20]=C_h_intern(&lf[20],17,"\003syspeek-c-string");
lf[21]=C_h_intern(&lf[21],16,"\003sysupdate-errno");
lf[22]=C_h_intern(&lf[22],10,"tcp-listen");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[25]=C_h_intern(&lf[25],11,"make-string");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[29]=C_h_intern(&lf[29],13,"\000domain-error");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[31]=C_h_intern(&lf[31],12,"tcp-listener");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[33]=C_h_intern(&lf[33],13,"tcp-listener\077");
lf[34]=C_h_intern(&lf[34],9,"tcp-close");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[36]=C_h_intern(&lf[36],15,"tcp-buffer-size");
lf[37]=C_h_intern(&lf[37],16,"tcp-read-timeout");
lf[38]=C_h_intern(&lf[38],17,"tcp-write-timeout");
lf[39]=C_h_intern(&lf[39],19,"tcp-connect-timeout");
lf[40]=C_h_intern(&lf[40],18,"tcp-accept-timeout");
lf[41]=C_h_intern(&lf[41],15,"make-input-port");
lf[42]=C_h_intern(&lf[42],16,"make-output-port");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[45]=C_h_intern(&lf[45],25,"\003systhread-block-for-i/o!");
lf[46]=C_h_intern(&lf[46],29,"\003systhread-block-for-timeout!");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[52]=C_h_intern(&lf[52],6,"socket");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[60]=C_h_intern(&lf[60],15,"\003sysmake-string");
lf[61]=C_h_intern(&lf[61],20,"\003sysscan-buffer-line");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[64]=C_h_intern(&lf[64],10,"tcp-accept");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[67]=C_h_intern(&lf[67],17,"tcp-accept-ready\077");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[73]=C_h_intern(&lf[73],4,"\000all");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[79]=C_h_intern(&lf[79],20,"\003systcp-port->fileno");
lf[80]=C_h_intern(&lf[80],13,"\003sysport-data");
lf[81]=C_h_intern(&lf[81],13,"tcp-addresses");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[84]=C_h_intern(&lf[84],16,"tcp-port-numbers");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[87]=C_h_intern(&lf[87],17,"tcp-listener-port");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[89]=C_h_intern(&lf[89],16,"tcp-abandon-port");
lf[90]=C_h_intern(&lf[90],14,"\003syscheck-port");
lf[91]=C_h_intern(&lf[91],19,"tcp-listener-fileno");
lf[92]=C_h_intern(&lf[92],14,"make-parameter");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[94]=C_h_intern(&lf[94],17,"register-feature!");
lf[95]=C_h_intern(&lf[95],3,"tcp");
C_register_lf2(lf,96,create_ptable());
t2=C_mutate(&lf[0] /* c372 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_936,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k934 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k937 in k934 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 91   register-feature!");
t3=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[95]);}

/* k940 in k937 in k934 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=C_mutate(&lf[2] /* socket ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[3] /* close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[4] /* shutdown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[5] /* make-nonblocking ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[6] /* getsockport ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub168(C_SCHEME_UNDEFINED))){
t8=t7;
f_1140(2,t8,C_SCHEME_UNDEFINED);}
else{
C_trace("tcp.scm: 176  ##sys#signal-hook");
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[16],lf[93]);}}

/* k1138 in k940 in k937 in k934 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate(&lf[7] /* select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[8] /* gethostaddr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[10] /* yield ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[13]+1);
t6=C_mutate(&lf[14] /* parse-host ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=t5,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[22]+1 /* tcp-listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[33]+1 /* tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[34]+1 /* tcp-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1530,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 310  make-parameter");
t11=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[37] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[38] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[39] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[40] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1571,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1588,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 321  check");
f_1571(t9,lf[37]);}

/* k2767 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 321  make-parameter");
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1 /* tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 322  check");
f_1571(t4,lf[38]);}

/* k2763 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 322  make-parameter");
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1 /* tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 323  check");
f_1571(t4,lf[39]);}

/* k2759 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 323  make-parameter");
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1 /* tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 324  check");
f_1571(t4,lf[40]);}

/* k2755 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 324  make-parameter");
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1 /* tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[41]+1);
t4=*((C_word*)lf[42]+1);
t5=*((C_word*)lf[36]+1);
t6=*((C_word*)lf[25]+1);
t7=C_mutate(&lf[43] /* io-ports ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1602,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[64]+1 /* tcp-accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[67]+1 /* tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* tcp-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[79]+1 /* tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2597,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[81]+1 /* tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2607,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[84]+1 /* tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[87]+1 /* tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[89]+1 /* tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[91]+1 /* tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2746,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2730,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 629  ##sys#check-port");
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[89]);}

/* k2728 in tcp-abandon-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 631  ##sys#port-data");
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2735 in k2728 in tcp-abandon-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2697,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[87]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1111(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2710,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2720,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t10=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2710(2,t8,C_SCHEME_UNDEFINED);}}

/* k2722 in tcp-listener-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 624  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[88],t1);}

/* k2718 in tcp-listener-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 623  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[87],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2708 in tcp-listener-port in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2652,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2656,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 611  ##sys#tcp-port->fileno");
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=f_1111(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2666(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2693 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 614  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2689 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 614  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[84],t1,((C_word*)t0)[2]);}

/* k2664 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=(C_word)stub155(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2673(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2682 in k2664 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 616  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2678 in k2664 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 616  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[84],t1,((C_word*)t0)[2]);}

/* k2671 in k2664 in k2654 in tcp-port-numbers in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 612  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2607,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 603  ##sys#tcp-port->fileno");
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2618,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub141(t4,t5);
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2621(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2648 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 606  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k2644 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 606  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[81],t1,((C_word*)t0)[2]);}

/* k2619 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub161(t4,t5);
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2623 in k2619 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2628(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2637 in k2623 in k2619 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 608  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2633 in k2623 in k2619 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 608  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[81],t1,((C_word*)t0)[2]);}

/* k2626 in k2623 in k2619 in k2616 in k2609 in tcp-addresses in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 604  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2597,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2605,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 600  ##sys#port-data");
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2603 in ##sys#tcp-port->fileno in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2350r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2350r(t0,t1,t2,t3);}}

static void C_ccall f_2350r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2354(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2354(2,t7,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 551  tcp-connect-timeout");
t5=*((C_word*)lf[39]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2363,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2363(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t4,t5,t6);}}

/* a2572 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2573,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2566 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
C_trace("tcp.scm: 554  ##net#parse-host");
t2=lf[14];
f_1227(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[78]);}

/* k2557 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_2363(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("tcp.scm: 555  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[77],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("tcp.scm: 557  make-string");
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=f_944(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 566  ##sys#update-errno");
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_2395(2,t6,C_SCHEME_UNDEFINED);}}

/* k2543 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2556,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2554 in k2543 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 567  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[76],t1);}

/* k2550 in k2543 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 567  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 568  ##net#gethostaddr");
f_1181(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2534 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2398(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("tcp.scm: 569  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[75],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_1093(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_2401(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 571  ##sys#update-errno");
t5=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2520 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2533,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2531 in k2520 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 572  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[74],t1);}

/* k2527 in k2520 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 572  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=(C_word)stub107(C_SCHEME_UNDEFINED,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t10)){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[6],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2458(t14,t2);}
else{
C_trace("tcp.scm: 591  fail");
t11=((C_word*)t0)[2];
f_2374(t11,t2);}}
else{
t10=t2;
f_2404(2,t10,C_SCHEME_UNDEFINED);}}

/* loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2458,NULL,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub196(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
C_trace("tcp.scm: 577  fail");
t6=((C_word*)t0)[2];
f_2374(t6,t4);}
else{
t6=t4;
f_2465(2,t6,C_SCHEME_UNDEFINED);}}

/* k2463 in loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
C_trace("tcp.scm: 580  ##sys#thread-block-for-timeout!");
t6=*((C_word*)lf[46]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[11]+1),t5);}
else{
t4=t3;
f_2474(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2472 in k2463 in loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 583  ##sys#thread-block-for-i/o!");
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[73]);}

/* k2475 in k2472 in k2463 in loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 584  yield");
f_1206(t2);}

/* k2478 in k2475 in k2472 in k2463 in loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
C_trace("tcp.scm: 586  ##sys#signal-hook");
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[17],lf[72],((C_word*)t0)[2]);}
else{
t3=t2;
f_2483(2,t3,C_SCHEME_UNDEFINED);}}

/* k2481 in k2478 in k2475 in k2472 in k2463 in loop in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 590  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2458(t2,((C_word*)t0)[2]);}

/* k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=(C_word)stub719(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)C_i_foreign_fixnum_argumentp(t3);
t10=(C_word)stub725(t8,t9);
C_trace("##sys#peek-c-string");
t11=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_fix(0));}
else{
t6=t4;
f_2410(2,t6,C_SCHEME_UNDEFINED);}}}

/* k2442 in k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 596  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k2438 in k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 596  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k2425 in k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 594  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[70],t1);}

/* k2421 in k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 594  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k2408 in k2402 in k2399 in k2396 in k2393 in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 597  ##net#io-ports");
t2=lf[43];
f_1602(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2374,NULL,2,t0,t1);}
t2=f_1009(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 561  ##sys#update-errno");
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2379 in fail in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2390 in k2379 in fail in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 563  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k2386 in k2379 in fail in k2367 in k2361 in k2355 in k2352 in tcp-connect in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 562  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2296,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[67]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1167(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 533  ##sys#update-errno");
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2306(2,t8,C_SCHEME_UNDEFINED);}}

/* k2313 in tcp-accept-ready? in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2324 in k2313 in tcp-accept-ready? in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 535  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k2320 in k2313 in tcp-accept-ready? in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 534  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[67],t1,((C_word*)t0)[2]);}

/* k2304 in tcp-accept-ready? in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2210,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2220,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 505  tcp-accept-timeout");
t6=*((C_word*)lf[40]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2225,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2225(t5,((C_word*)t0)[2]);}

/* loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2225,NULL,2,t0,t1);}
t2=f_1167(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t5=(C_word)stub62(C_SCHEME_UNDEFINED,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2238,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 510  ##sys#update-errno");
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2238(2,t8,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[2]);
C_trace("tcp.scm: 517  ##sys#thread-block-for-timeout!");
t7=*((C_word*)lf[46]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[11]+1),t6);}
else{
t5=t4;
f_2261(2,t5,C_SCHEME_UNDEFINED);}}}

/* k2259 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 520  ##sys#thread-block-for-i/o!");
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2262 in k2259 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 521  yield");
f_1206(t2);}

/* k2265 in k2262 in k2259 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
C_trace("tcp.scm: 523  ##sys#signal-hook");
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[64],lf[66],((C_word*)t0)[2]);}
else{
t3=t2;
f_2270(2,t3,C_SCHEME_UNDEFINED);}}

/* k2268 in k2265 in k2262 in k2259 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 527  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2225(t2,((C_word*)t0)[2]);}

/* k2245 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2256 in k2245 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 512  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k2252 in k2245 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 511  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[64],t1,((C_word*)t0)[2]);}

/* k2236 in loop in k2218 in tcp-accept in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 514  ##net#io-ports");
t2=lf[43];
f_1602(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1602(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1602,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_1093(t2);
if(C_truep(t4)){
t5=t3;
f_1606(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 333  ##sys#update-errno");
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k2195 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2206 in k2195 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 334  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k2202 in k2195 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 334  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[16],t1);}

/* k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("tcp.scm: 335  make-string");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
C_trace("tcp.scm: 341  tbs");
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1618(t4,(C_truep(t3)?lf[62]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1618(t3,C_SCHEME_FALSE);}}

/* k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1618,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("tcp.scm: 343  tcp-read-timeout");
t5=*((C_word*)lf[37]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("tcp.scm: 344  tcp-write-timeout");
t3=*((C_word*)lf[38]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word)li24),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1936,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2036,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2101,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li38),tmp=(C_word)a,a+=7,tmp);
C_trace("tcp.scm: 372  make-input-port");
t9=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t9))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2101,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2107,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_2107(t7,t1,C_SCHEME_FALSE);}

/* loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2107(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2107,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li36),tmp=(C_word)a,a+=10,tmp);
C_trace("tcp.scm: 419  ##sys#scan-buffer-line");
t4=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2176,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("tcp.scm: 436  read-input");
t4=((C_word*)t0)[3];
f_1625(t4,t3);}}

/* k2174 in loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
C_trace("tcp.scm: 438  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2107(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a2118 in loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2119,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
C_trace("tcp.scm: 424  ##sys#make-string");
t6=*((C_word*)lf[60]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k2121 in a2118 in loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2133,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
C_trace("tcp.scm: 428  read-input");
t6=((C_word*)t0)[3];
f_1625(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
C_trace("tcp.scm: 434  ##sys#string-append");
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k2131 in k2121 in a2118 in loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[59]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("tcp.scm: 431  ##sys#string-append");
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_2149(2,t3,((C_word*)t0)[2]);}}}

/* k2147 in k2131 in k2121 in a2118 in loop in a2100 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 431  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2107(t2,((C_word*)t0)[2],t1);}

/* a2035 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2036,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li34),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2042(t9,t1,t3,C_fix(0),t5);}

/* loop in a2035 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2042,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
C_trace("tcp.scm: 410  loop");
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2090,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("tcp.scm: 412  read-input");
t7=((C_word*)t0)[2];
f_1625(t7,t6);}}}

/* k2088 in loop in a2035 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
C_trace("tcp.scm: 415  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2042(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1992 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_1038(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_1009(((C_word*)t0)[3]);
t6=t4;
f_2007(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_2007(t5,C_SCHEME_FALSE);}}}

/* k2005 in a1992 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_2007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 396  ##sys#update-errno");
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2008 in k2005 in a1992 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2021,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2019 in k2008 in k2005 in a1992 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 399  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k2015 in k2008 in k2005 in a1992 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 397  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* a1957 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_1167(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 385  ##sys#update-errno");
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1971(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1978 in a1957 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1989 in k1978 in a1957 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 388  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[57],t1);}

/* k1985 in k1978 in a1957 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 386  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1969 in a1957 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1935 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
C_trace("tcp.scm: 375  read-input");
t3=((C_word*)t0)[2];
f_1625(t3,t2);}
else{
t3=t2;
f_1940(2,t3,C_SCHEME_UNDEFINED);}}

/* k1938 in a1935 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1900,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1821,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word)li29),tmp=(C_word)a,a+=9,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1884,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp):C_SCHEME_FALSE);
C_trace("tcp.scm: 468  make-output-port");
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}

/* f_1884 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 492  output");
t4=((C_word*)t0)[2];
f_1699(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1892 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[56]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1868(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1868(t5,C_SCHEME_FALSE);}}}

/* k1866 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 482  output");
t3=((C_word*)t0)[2];
f_1699(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1829(t2,C_SCHEME_UNDEFINED);}}

/* k1869 in k1866 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[55]);
t3=((C_word*)t0)[2];
f_1829(t3,t2);}

/* k1827 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_1038(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_1009(((C_word*)t0)[4]);
t5=t3;
f_1838(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1838(t4,C_SCHEME_FALSE);}}

/* k1836 in k1827 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 486  ##sys#update-errno");
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1839 in k1836 in k1827 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1850 in k1839 in k1836 in k1827 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 488  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k1846 in k1839 in k1836 in k1827 in a1820 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 487  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* f_1920 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1920,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("tcp.scm: 477  output");
t4=((C_word*)t0)[2];
f_1699(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1900 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("tcp.scm: 471  ##sys#string-append");
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1903 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 473  output");
t5=((C_word*)t0)[2];
f_1699(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1912 in k1903 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[53]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1792 in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[50]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[51]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[52]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[52]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
C_trace("tcp.scm: 500  values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1699,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li25),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1709(t7,t1,t3,C_fix(0));}

/* loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1709,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_word)C_i_foreign_fixnum_argumentp(t5);
t9=(C_truep(t6)?(C_word)C_i_foreign_block_argumentp(t6):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t7);
t11=(C_word)C_i_foreign_fixnum_argumentp(t4);
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t13=(C_word)stub122(C_SCHEME_UNDEFINED,t8,t9,t10,t11,t12);
t14=(C_word)C_eqp(C_fix(-1),t13);
if(C_truep(t14)){
t15=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t17=(C_word)C_fudge(C_fix(16));
t18=(C_word)C_fixnum_plus(t17,((C_word*)t0)[2]);
C_trace("tcp.scm: 449  ##sys#thread-block-for-timeout!");
t19=*((C_word*)lf[46]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t16,*((C_word*)lf[11]+1),t18);}
else{
t17=t16;
f_1731(2,t17,C_SCHEME_UNDEFINED);}}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 460  ##sys#update-errno");
t17=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t13,t2))){
t15=(C_word)C_fixnum_difference(t2,t13);
t16=(C_word)C_fixnum_plus(t3,t13);
C_trace("tcp.scm: 466  loop");
t23=t1;
t24=t15;
t25=t16;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}}}

/* k1761 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1772 in k1761 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 463  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k1768 in k1761 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 461  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1729 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("tcp.scm: 452  ##sys#thread-block-for-i/o!");
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1732 in k1729 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("tcp.scm: 453  yield");
f_1206(t2);}

/* k1735 in k1732 in k1729 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
C_trace("tcp.scm: 455  ##sys#signal-hook");
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[48],((C_word*)t0)[2]);}
else{
t3=t2;
f_1740(2,t3,C_SCHEME_UNDEFINED);}}

/* k1738 in k1735 in k1732 in k1729 in loop in output in k1696 in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 458  loop");
t2=((C_word*)((C_word*)t0)[5])[1];
f_1709(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li23),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1631(t5,t1);}

/* loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1631,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1024));
t7=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t8=(C_word)stub85(C_SCHEME_UNDEFINED,t4,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t12=(C_word)C_fudge(C_fix(16));
t13=(C_word)C_fixnum_plus(t12,((C_word*)t0)[4]);
C_trace("tcp.scm: 352  ##sys#thread-block-for-timeout!");
t14=*((C_word*)lf[46]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t11,*((C_word*)lf[11]+1),t13);}
else{
t12=t11;
f_1650(2,t12,C_SCHEME_UNDEFINED);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 363  ##sys#update-errno");
t12=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
t10=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t11=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}

/* k1680 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1691 in k1680 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 366  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[47],t1);}

/* k1687 in k1680 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 364  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1648 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 355  ##sys#thread-block-for-i/o!");
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1651 in k1648 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 356  yield");
f_1206(t2);}

/* k1654 in k1651 in k1648 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
C_trace("tcp.scm: 358  ##sys#signal-hook");
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[44],((C_word*)t0)[2]);}
else{
t3=t2;
f_1659(2,t3,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in k1651 in k1648 in loop in read-input in k1622 in k1619 in k1616 in k1613 in k1607 in k1604 in ##net#io-ports in k1598 in k1594 in k1590 in k1586 in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 361  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1631(t2,((C_word*)t0)[2]);}

/* check in k1563 in k1138 in k940 in k937 in k934 */
static void C_fcall f_1571(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1571,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=t2,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));}

/* f_1573 in check in k1563 in k1138 in k940 in k937 in k934 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1573,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k1138 in k940 in k937 in k934 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1530,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1009(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1546,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 304  ##sys#update-errno");
t8=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k1544 in tcp-close in k1138 in k940 in k937 in k934 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1555 in k1544 in tcp-close in k1138 in k940 in k937 in k934 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 305  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[35],t1);}

/* k1551 in k1544 in tcp-close in k1138 in k940 in k937 in k934 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 305  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[34],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k1138 in k940 in k937 in k934 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1521,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[31]):C_SCHEME_FALSE));}

/* tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1423r(t0,t1,t2,t3);}}

static void C_ccall f_1423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=t2,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1473,a[2]=t5,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-w326362");
t7=t6;
f_1473(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
C_trace("def-host327358");
t9=t5;
f_1468(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("body324333");
t11=t4;
f_1425(t11,t1,t7,t9);}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w326 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_fcall f_1473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1473,NULL,2,t0,t1);}
C_trace("def-host327358");
t2=((C_word*)t0)[2];
f_1468(t2,t1,C_fix(10));}

/* def-host327 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_fcall f_1468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1468,NULL,3,t0,t1,t2);}
C_trace("body324333");
t3=((C_word*)t0)[2];
f_1425(t3,t1,t2,C_SCHEME_FALSE);}

/* body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_fcall f_1425(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1425,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1431,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t4,t5);}

/* a1436 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1437,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_fixnum_argumentp(t6);
t9=(C_word)stub53(C_SCHEME_UNDEFINED,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 292  ##sys#update-errno");
t13=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=t10;
f_1447(2,t12,C_SCHEME_UNDEFINED);}}

/* k1454 in a1436 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1465 in k1454 in a1436 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 293  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[32],t1);}

/* k1461 in k1454 in a1436 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 293  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1445 in a1436 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[31],((C_word*)t0)[2]));}

/* a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
C_trace("tcp.scm: 261  ##sys#signal-hook");
t9=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[29],lf[22],lf[30],t2);}
else{
t9=t6;
f_1320(2,t9,C_SCHEME_UNDEFINED);}}

/* k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=f_944(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 264  ##sys#update-errno");
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1326(2,t5,C_SCHEME_UNDEFINED);}}

/* k1404 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 265  ##sys#error");
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[28]);}

/* k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_1395 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1395,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub291(C_SCHEME_UNDEFINED,t3));}

/* k1392 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 271  ##sys#update-errno");
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_1329(2,t3,C_SCHEME_UNDEFINED);}}

/* k1377 in k1392 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1388 in k1377 in k1392 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 272  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k1384 in k1377 in k1392 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 272  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[22],t1,((C_word*)t0)[2]);}

/* k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("tcp.scm: 273  make-string");
t3=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 275  ##net#gethostaddr");
f_1181(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t6=t2;
f_1335(2,t6,(C_word)stub256(C_SCHEME_UNDEFINED,t4,t5));}}

/* k1365 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1335(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("tcp.scm: 276  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],lf[24],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1333 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)stub41(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 280  ##sys#update-errno");
t11=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_1341(2,t10,C_SCHEME_UNDEFINED);}}

/* k1348 in k1333 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1359 in k1348 in k1333 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 281  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k1355 in k1348 in k1333 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 281  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1339 in k1333 in k1330 in k1327 in k1324 in k1318 in a1430 in body324 in tcp-listen in k1138 in k940 in k937 in k934 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 282  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_fcall f_1227(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1227,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1236,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li10),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1236(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1236,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
C_trace("tcp.scm: 232  values");
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1259,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
C_trace("tcp.scm: 236  substring");
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("tcp.scm: 245  loop");
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1263,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("tcp.scm: 237  substring");
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1147,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
C_trace("##sys#make-c-string");
t6=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t5=t4;
f_1147(2,t5,C_SCHEME_FALSE);}}

/* k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
C_trace("##sys#make-c-string");
t4=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_1151(2,t3,C_SCHEME_FALSE);}}

/* k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=(C_word)stub177(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1269,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("tcp.scm: 240  ##sys#update-errno");
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1269(2,t5,C_SCHEME_UNDEFINED);}}

/* k1273 in k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1284 in k1273 in k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 242  ##sys#string-append");
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[19],t1);}

/* k1280 in k1273 in k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 241  ##sys#signal-hook");
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],t1,((C_word*)t0)[2]);}

/* k1267 in k1149 in k1145 in k1261 in k1257 in loop in ##net#parse-host in k1138 in k940 in k937 in k934 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("tcp.scm: 235  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k1138 in k940 in k937 in k934 */
static void C_fcall f_1206(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1206,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
C_trace("tcp.scm: 220  ##sys#call-with-current-continuation");
C_call_cc(3,0,t1,t2);}

/* a1211 in yield in k1138 in k940 in k937 in k934 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1212,3,t0,t1,t2);}
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
C_trace("tcp.scm: 224  ##sys#schedule");
t6=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1220 in a1211 in yield in k1138 in k940 in k937 in k934 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
C_trace("tcp.scm: 223  return");
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k1138 in k940 in k937 in k934 */
static void C_fcall f_1181(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1181,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1190,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
C_trace("##sys#make-c-string");
t8=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=t6;
f_1190(2,t7,C_SCHEME_FALSE);}}

/* k1188 in ##net#gethostaddr in k1138 in k940 in k937 in k934 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub204(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select in k1138 in k940 in k937 in k934 */
static C_word C_fcall f_1167(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub190(C_SCHEME_UNDEFINED,t2));}

/* ##net#getsockport in k940 in k937 in k934 */
static C_word C_fcall f_1111(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub149(C_SCHEME_UNDEFINED,t2));}

/* ##net#make-nonblocking in k940 in k937 in k934 */
static C_word C_fcall f_1093(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub135(C_SCHEME_UNDEFINED,t2));}

/* ##net#shutdown in k940 in k937 in k934 */
static C_word C_fcall f_1038(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub98(C_SCHEME_UNDEFINED,t3,t4));}

/* ##net#close in k940 in k937 in k934 */
static C_word C_fcall f_1009(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub76(C_SCHEME_UNDEFINED,t2));}

/* ##net#socket in k940 in k937 in k934 */
static C_word C_fcall f_944(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub31(C_SCHEME_UNDEFINED,t4,t5,t6));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_936tcp.scm",(void*)f_936},
{"f_939tcp.scm",(void*)f_939},
{"f_942tcp.scm",(void*)f_942},
{"f_1140tcp.scm",(void*)f_1140},
{"f_1565tcp.scm",(void*)f_1565},
{"f_2769tcp.scm",(void*)f_2769},
{"f_1588tcp.scm",(void*)f_1588},
{"f_2765tcp.scm",(void*)f_2765},
{"f_1592tcp.scm",(void*)f_1592},
{"f_2761tcp.scm",(void*)f_2761},
{"f_1596tcp.scm",(void*)f_1596},
{"f_2757tcp.scm",(void*)f_2757},
{"f_1600tcp.scm",(void*)f_1600},
{"f_2746tcp.scm",(void*)f_2746},
{"f_2726tcp.scm",(void*)f_2726},
{"f_2730tcp.scm",(void*)f_2730},
{"f_2737tcp.scm",(void*)f_2737},
{"f_2697tcp.scm",(void*)f_2697},
{"f_2724tcp.scm",(void*)f_2724},
{"f_2720tcp.scm",(void*)f_2720},
{"f_2710tcp.scm",(void*)f_2710},
{"f_2652tcp.scm",(void*)f_2652},
{"f_2656tcp.scm",(void*)f_2656},
{"f_2695tcp.scm",(void*)f_2695},
{"f_2691tcp.scm",(void*)f_2691},
{"f_2666tcp.scm",(void*)f_2666},
{"f_2684tcp.scm",(void*)f_2684},
{"f_2680tcp.scm",(void*)f_2680},
{"f_2673tcp.scm",(void*)f_2673},
{"f_2607tcp.scm",(void*)f_2607},
{"f_2611tcp.scm",(void*)f_2611},
{"f_2618tcp.scm",(void*)f_2618},
{"f_2650tcp.scm",(void*)f_2650},
{"f_2646tcp.scm",(void*)f_2646},
{"f_2621tcp.scm",(void*)f_2621},
{"f_2625tcp.scm",(void*)f_2625},
{"f_2639tcp.scm",(void*)f_2639},
{"f_2635tcp.scm",(void*)f_2635},
{"f_2628tcp.scm",(void*)f_2628},
{"f_2597tcp.scm",(void*)f_2597},
{"f_2605tcp.scm",(void*)f_2605},
{"f_2350tcp.scm",(void*)f_2350},
{"f_2354tcp.scm",(void*)f_2354},
{"f_2357tcp.scm",(void*)f_2357},
{"f_2573tcp.scm",(void*)f_2573},
{"f_2567tcp.scm",(void*)f_2567},
{"f_2559tcp.scm",(void*)f_2559},
{"f_2363tcp.scm",(void*)f_2363},
{"f_2369tcp.scm",(void*)f_2369},
{"f_2545tcp.scm",(void*)f_2545},
{"f_2556tcp.scm",(void*)f_2556},
{"f_2552tcp.scm",(void*)f_2552},
{"f_2395tcp.scm",(void*)f_2395},
{"f_2536tcp.scm",(void*)f_2536},
{"f_2398tcp.scm",(void*)f_2398},
{"f_2522tcp.scm",(void*)f_2522},
{"f_2533tcp.scm",(void*)f_2533},
{"f_2529tcp.scm",(void*)f_2529},
{"f_2401tcp.scm",(void*)f_2401},
{"f_2458tcp.scm",(void*)f_2458},
{"f_2465tcp.scm",(void*)f_2465},
{"f_2474tcp.scm",(void*)f_2474},
{"f_2477tcp.scm",(void*)f_2477},
{"f_2480tcp.scm",(void*)f_2480},
{"f_2483tcp.scm",(void*)f_2483},
{"f_2404tcp.scm",(void*)f_2404},
{"f_2444tcp.scm",(void*)f_2444},
{"f_2440tcp.scm",(void*)f_2440},
{"f_2427tcp.scm",(void*)f_2427},
{"f_2423tcp.scm",(void*)f_2423},
{"f_2410tcp.scm",(void*)f_2410},
{"f_2374tcp.scm",(void*)f_2374},
{"f_2381tcp.scm",(void*)f_2381},
{"f_2392tcp.scm",(void*)f_2392},
{"f_2388tcp.scm",(void*)f_2388},
{"f_2296tcp.scm",(void*)f_2296},
{"f_2315tcp.scm",(void*)f_2315},
{"f_2326tcp.scm",(void*)f_2326},
{"f_2322tcp.scm",(void*)f_2322},
{"f_2306tcp.scm",(void*)f_2306},
{"f_2210tcp.scm",(void*)f_2210},
{"f_2220tcp.scm",(void*)f_2220},
{"f_2225tcp.scm",(void*)f_2225},
{"f_2261tcp.scm",(void*)f_2261},
{"f_2264tcp.scm",(void*)f_2264},
{"f_2267tcp.scm",(void*)f_2267},
{"f_2270tcp.scm",(void*)f_2270},
{"f_2247tcp.scm",(void*)f_2247},
{"f_2258tcp.scm",(void*)f_2258},
{"f_2254tcp.scm",(void*)f_2254},
{"f_2238tcp.scm",(void*)f_2238},
{"f_1602tcp.scm",(void*)f_1602},
{"f_2197tcp.scm",(void*)f_2197},
{"f_2208tcp.scm",(void*)f_2208},
{"f_2204tcp.scm",(void*)f_2204},
{"f_1606tcp.scm",(void*)f_1606},
{"f_1609tcp.scm",(void*)f_1609},
{"f_1615tcp.scm",(void*)f_1615},
{"f_1618tcp.scm",(void*)f_1618},
{"f_1621tcp.scm",(void*)f_1621},
{"f_1624tcp.scm",(void*)f_1624},
{"f_2101tcp.scm",(void*)f_2101},
{"f_2107tcp.scm",(void*)f_2107},
{"f_2176tcp.scm",(void*)f_2176},
{"f_2119tcp.scm",(void*)f_2119},
{"f_2123tcp.scm",(void*)f_2123},
{"f_2133tcp.scm",(void*)f_2133},
{"f_2149tcp.scm",(void*)f_2149},
{"f_2036tcp.scm",(void*)f_2036},
{"f_2042tcp.scm",(void*)f_2042},
{"f_2090tcp.scm",(void*)f_2090},
{"f_1993tcp.scm",(void*)f_1993},
{"f_2007tcp.scm",(void*)f_2007},
{"f_2010tcp.scm",(void*)f_2010},
{"f_2021tcp.scm",(void*)f_2021},
{"f_2017tcp.scm",(void*)f_2017},
{"f_1958tcp.scm",(void*)f_1958},
{"f_1980tcp.scm",(void*)f_1980},
{"f_1991tcp.scm",(void*)f_1991},
{"f_1987tcp.scm",(void*)f_1987},
{"f_1971tcp.scm",(void*)f_1971},
{"f_1936tcp.scm",(void*)f_1936},
{"f_1940tcp.scm",(void*)f_1940},
{"f_1698tcp.scm",(void*)f_1698},
{"f_1884tcp.scm",(void*)f_1884},
{"f_1894tcp.scm",(void*)f_1894},
{"f_1821tcp.scm",(void*)f_1821},
{"f_1868tcp.scm",(void*)f_1868},
{"f_1871tcp.scm",(void*)f_1871},
{"f_1829tcp.scm",(void*)f_1829},
{"f_1838tcp.scm",(void*)f_1838},
{"f_1841tcp.scm",(void*)f_1841},
{"f_1852tcp.scm",(void*)f_1852},
{"f_1848tcp.scm",(void*)f_1848},
{"f_1920tcp.scm",(void*)f_1920},
{"f_1900tcp.scm",(void*)f_1900},
{"f_1905tcp.scm",(void*)f_1905},
{"f_1914tcp.scm",(void*)f_1914},
{"f_1794tcp.scm",(void*)f_1794},
{"f_1699tcp.scm",(void*)f_1699},
{"f_1709tcp.scm",(void*)f_1709},
{"f_1763tcp.scm",(void*)f_1763},
{"f_1774tcp.scm",(void*)f_1774},
{"f_1770tcp.scm",(void*)f_1770},
{"f_1731tcp.scm",(void*)f_1731},
{"f_1734tcp.scm",(void*)f_1734},
{"f_1737tcp.scm",(void*)f_1737},
{"f_1740tcp.scm",(void*)f_1740},
{"f_1625tcp.scm",(void*)f_1625},
{"f_1631tcp.scm",(void*)f_1631},
{"f_1682tcp.scm",(void*)f_1682},
{"f_1693tcp.scm",(void*)f_1693},
{"f_1689tcp.scm",(void*)f_1689},
{"f_1650tcp.scm",(void*)f_1650},
{"f_1653tcp.scm",(void*)f_1653},
{"f_1656tcp.scm",(void*)f_1656},
{"f_1659tcp.scm",(void*)f_1659},
{"f_1571tcp.scm",(void*)f_1571},
{"f_1573tcp.scm",(void*)f_1573},
{"f_1530tcp.scm",(void*)f_1530},
{"f_1546tcp.scm",(void*)f_1546},
{"f_1557tcp.scm",(void*)f_1557},
{"f_1553tcp.scm",(void*)f_1553},
{"f_1521tcp.scm",(void*)f_1521},
{"f_1423tcp.scm",(void*)f_1423},
{"f_1473tcp.scm",(void*)f_1473},
{"f_1468tcp.scm",(void*)f_1468},
{"f_1425tcp.scm",(void*)f_1425},
{"f_1437tcp.scm",(void*)f_1437},
{"f_1456tcp.scm",(void*)f_1456},
{"f_1467tcp.scm",(void*)f_1467},
{"f_1463tcp.scm",(void*)f_1463},
{"f_1447tcp.scm",(void*)f_1447},
{"f_1431tcp.scm",(void*)f_1431},
{"f_1320tcp.scm",(void*)f_1320},
{"f_1406tcp.scm",(void*)f_1406},
{"f_1326tcp.scm",(void*)f_1326},
{"f_1395tcp.scm",(void*)f_1395},
{"f_1394tcp.scm",(void*)f_1394},
{"f_1379tcp.scm",(void*)f_1379},
{"f_1390tcp.scm",(void*)f_1390},
{"f_1386tcp.scm",(void*)f_1386},
{"f_1329tcp.scm",(void*)f_1329},
{"f_1332tcp.scm",(void*)f_1332},
{"f_1367tcp.scm",(void*)f_1367},
{"f_1335tcp.scm",(void*)f_1335},
{"f_1350tcp.scm",(void*)f_1350},
{"f_1361tcp.scm",(void*)f_1361},
{"f_1357tcp.scm",(void*)f_1357},
{"f_1341tcp.scm",(void*)f_1341},
{"f_1227tcp.scm",(void*)f_1227},
{"f_1236tcp.scm",(void*)f_1236},
{"f_1259tcp.scm",(void*)f_1259},
{"f_1263tcp.scm",(void*)f_1263},
{"f_1147tcp.scm",(void*)f_1147},
{"f_1151tcp.scm",(void*)f_1151},
{"f_1275tcp.scm",(void*)f_1275},
{"f_1286tcp.scm",(void*)f_1286},
{"f_1282tcp.scm",(void*)f_1282},
{"f_1269tcp.scm",(void*)f_1269},
{"f_1206tcp.scm",(void*)f_1206},
{"f_1212tcp.scm",(void*)f_1212},
{"f_1221tcp.scm",(void*)f_1221},
{"f_1181tcp.scm",(void*)f_1181},
{"f_1190tcp.scm",(void*)f_1190},
{"f_1167tcp.scm",(void*)f_1167},
{"f_1111tcp.scm",(void*)f_1111},
{"f_1093tcp.scm",(void*)f_1093},
{"f_1038tcp.scm",(void*)f_1038},
{"f_1009tcp.scm",(void*)f_1009},
{"f_944tcp.scm",(void*)f_944},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
