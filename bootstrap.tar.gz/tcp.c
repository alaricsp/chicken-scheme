/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-03 03:24
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -debug i -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,115,111,99,107,101,116,32,97,51,48,51,51,32,97,50,57,51,52,32,97,50,56,51,53,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,30),40,35,35,110,101,116,35,98,105,110,100,32,97,52,48,52,52,32,97,51,57,52,53,32,97,51,56,52,54,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,26),40,35,35,110,101,116,35,108,105,115,116,101,110,32,97,53,50,53,53,32,97,53,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,97,99,99,101,112,116,32,97,54,49,54,54,32,97,54,48,54,55,32,97,53,57,54,56,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,35,35,110,101,116,35,99,108,111,115,101,32,97,55,53,55,56,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,35,35,110,101,116,35,114,101,99,118,32,97,56,52,56,56,32,97,56,51,56,57,32,97,56,50,57,48,32,97,56,49,57,49,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,30),40,35,35,110,101,116,35,115,104,117,116,100,111,119,110,32,97,57,55,49,48,48,32,97,57,54,49,48,49,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,39),40,35,35,110,101,116,35,99,111,110,110,101,99,116,32,97,49,48,54,49,49,48,32,97,49,48,53,49,49,49,32,97,49,48,52,49,49,50,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,52),40,35,35,110,101,116,35,115,101,110,100,32,97,49,50,49,49,50,53,32,97,49,50,48,49,50,54,32,97,49,49,57,49,50,55,32,97,49,49,56,49,50,56,32,97,49,49,55,49,50,57,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,109,97,107,101,45,110,111,110,98,108,111,99,107,105,110,103,32,97,49,51,52,49,51,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,115,111,99,107,110,97,109,101,32,97,49,52,48,49,52,51,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,115,111,99,107,112,111,114,116,32,97,49,52,56,49,53,49,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,112,101,101,114,112,111,114,116,32,97,49,53,52,49,53,55,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,112,101,101,114,110,97,109,101,32,97,49,54,48,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,15),40,35,35,110,101,116,35,115,116,97,114,116,117,112,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,37),40,35,35,110,101,116,35,103,101,116,115,101,114,118,98,121,110,97,109,101,32,97,49,55,54,49,56,49,32,97,49,55,53,49,56,50,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,101,108,101,99,116,32,97,49,56,57,49,57,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,28),40,35,35,110,101,116,35,115,101,108,101,99,116,45,119,114,105,116,101,32,97,49,57,53,49,57,56,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,50,48,51,50,48,56,32,97,50,48,50,50,48,57,32,97,50,48,49,50,49,48,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,50,48,54,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,97,49,49,57,55,32,114,101,116,117,114,110,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,51,53,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,35),40,35,35,110,101,116,35,112,97,114,115,101,45,104,111,115,116,32,104,111,115,116,50,50,56,32,112,114,111,116,111,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,34),40,35,35,110,101,116,35,102,114,101,115,104,45,97,100,100,114,32,97,50,53,51,50,53,55,32,97,50,53,50,50,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,56,49,32,97,50,56,56,50,57,49,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,44),40,35,35,110,101,116,35,98,105,110,100,45,115,111,99,107,101,116,32,112,111,114,116,50,54,52,32,115,116,121,108,101,50,54,53,32,104,111,115,116,50,54,54,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,52,49,54,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,32),40,97,49,52,50,50,32,115,51,51,54,51,51,55,51,52,50,32,97,100,100,114,51,51,56,51,51,57,51,52,51,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,51,50,50,32,119,51,51,50,32,104,111,115,116,51,51,51,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,51,50,53,32,37,119,51,50,48,51,53,55,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,51,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,51,49,50,32,46,32,109,111,114,101,51,49,51,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,51,55,51,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,51,55,57,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,53,57,32,120,52,48,49,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,51,57,57,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,53,56,56,32,111,102,102,115,101,116,53,56,57,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,53,56,52,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,102,95,49,56,56,54,32,115,54,50,52,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,102,95,49,57,48,54,32,115,54,51,48,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,56,48,54,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,8),40,102,95,49,56,55,48,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,57,50,49,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,57,52,51,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,57,55,56,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,53,50,49,32,109,53,50,50,32,115,116,97,114,116,53,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,34),40,97,50,48,50,49,32,112,53,49,52,32,110,53,49,53,32,100,101,115,116,53,49,54,32,115,116,97,114,116,53,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,97,50,49,48,52,32,112,111,115,50,53,53,55,32,110,101,120,116,53,53,56,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,53,52,56,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,21),40,97,50,48,56,54,32,112,53,52,51,32,108,105,109,105,116,53,52,52,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,52,49,55,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,54,54,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,54,57,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,115,111,99,107,101,116,45,101,114,114,111,114,32,97,55,48,54,55,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,26),40,103,101,110,101,114,97,108,45,115,116,114,101,114,114,111,114,32,97,55,49,50,55,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,7),40,97,50,53,53,50,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,29),40,97,50,53,53,56,32,104,111,115,116,55,51,56,55,52,49,32,112,111,114,116,55,51,57,55,52,50,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,55,50,49,32,46,32,109,111,114,101,55,50,50,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,56,48,53,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,56,48,57,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,56,50,55,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,56,52,53,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,56,53,57,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,56,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2332 */
static C_word C_fcall stub713(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub713(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k2321 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub707(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub707(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from k1384 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k1292 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k1178 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from k1163 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1156 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1135 in k1131 in ##net#getservbyname in k1124 in k926 in k923 in k920 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup in k926 in k923 in k920 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub168(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from k1118 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1107 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1100 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1093 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub141(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1082 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1072 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k1046 */
static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k1031 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k1017 */
static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k998 */
static C_word C_fcall stub76(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub76(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k985 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k970 */
static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k956 */
static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k941 */
static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_fcall f_2444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_fcall f_2360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_fcall f_2211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_fcall f_1604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2093)
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2028)
static void C_fcall f_2028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_fcall f_1993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_fcall f_1854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_fcall f_1815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_fcall f_1824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1695)
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1459)
static void C_fcall f_1459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;

C_noret_decl(trf_2444)
static void C_fcall trf_2444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2444(t0,t1);}

C_noret_decl(trf_2360)
static void C_fcall trf_2360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2360(t0,t1);}

C_noret_decl(trf_2211)
static void C_fcall trf_2211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2211(t0,t1);}

C_noret_decl(trf_1604)
static void C_fcall trf_1604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1604(t0,t1);}

C_noret_decl(trf_2093)
static void C_fcall trf_2093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2093(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2093(t0,t1,t2);}

C_noret_decl(trf_2028)
static void C_fcall trf_2028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2028(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2028(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1993)
static void C_fcall trf_1993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1993(t0,t1);}

C_noret_decl(trf_1854)
static void C_fcall trf_1854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1854(t0,t1);}

C_noret_decl(trf_1815)
static void C_fcall trf_1815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1815(t0,t1);}

C_noret_decl(trf_1824)
static void C_fcall trf_1824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1824(t0,t1);}

C_noret_decl(trf_1685)
static void C_fcall trf_1685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1685(t0,t1,t2);}

C_noret_decl(trf_1695)
static void C_fcall trf_1695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1695(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1695(t0,t1,t2,t3);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1611(t0,t1);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1617(t0,t1);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1557(t0,t1);}

C_noret_decl(trf_1459)
static void C_fcall trf_1459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1459(t0,t1);}

C_noret_decl(trf_1454)
static void C_fcall trf_1454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1454(t0,t1,t2);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1411(t0,t1,t2,t3);}

C_noret_decl(trf_1222)
static void C_fcall trf_1222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1222(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(690)){
C_save(t1);
C_rereclaim2(690*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],10,"\003netsocket");
lf[3]=C_h_intern(&lf[3],8,"\003netbind");
lf[4]=C_h_intern(&lf[4],10,"\003netlisten");
lf[5]=C_h_intern(&lf[5],10,"\003netaccept");
lf[6]=C_h_intern(&lf[6],9,"\003netclose");
lf[7]=C_h_intern(&lf[7],8,"\003netrecv");
lf[8]=C_h_intern(&lf[8],12,"\003netshutdown");
lf[9]=C_h_intern(&lf[9],11,"\003netconnect");
lf[10]=C_h_intern(&lf[10],8,"\003netsend");
lf[11]=C_h_intern(&lf[11],20,"\003netmake-nonblocking");
lf[12]=C_h_intern(&lf[12],15,"\003netgetsockname");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_h_intern(&lf[14],15,"\003netgetsockport");
lf[15]=C_h_intern(&lf[15],15,"\003netgetpeerport");
lf[16]=C_h_intern(&lf[16],15,"\003netgetpeername");
lf[17]=C_h_intern(&lf[17],11,"\003netstartup");
lf[18]=C_h_intern(&lf[18],17,"\003netgetservbyname");
lf[19]=C_h_intern(&lf[19],17,"\003sysmake-c-string");
lf[20]=C_h_intern(&lf[20],10,"\003netselect");
lf[21]=C_h_intern(&lf[21],16,"\003netselect-write");
lf[22]=C_h_intern(&lf[22],15,"\003netgethostaddr");
lf[23]=C_h_intern(&lf[23],5,"yield");
lf[24]=C_h_intern(&lf[24],18,"\003syscurrent-thread");
lf[25]=C_h_intern(&lf[25],12,"\003sysschedule");
lf[26]=C_h_intern(&lf[26],9,"substring");
lf[27]=C_h_intern(&lf[27],14,"\003netparse-host");
lf[28]=C_h_intern(&lf[28],15,"\003syssignal-hook");
lf[29]=C_h_intern(&lf[29],14,"\000network-error");
lf[30]=C_h_intern(&lf[30],11,"tcp-connect");
lf[31]=C_h_intern(&lf[31],17,"\003sysstring-append");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[33]=C_h_intern(&lf[33],16,"\003sysupdate-errno");
lf[34]=C_h_intern(&lf[34],14,"\003netfresh-addr");
lf[35]=C_h_intern(&lf[35],15,"\003netbind-socket");
lf[36]=C_h_intern(&lf[36],10,"tcp-listen");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[39]=C_h_intern(&lf[39],11,"make-string");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[41]=C_h_intern(&lf[41],9,"\003syserror");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[43]=C_h_intern(&lf[43],13,"\000domain-error");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[45]=C_h_intern(&lf[45],12,"tcp-listener");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[47]=C_h_intern(&lf[47],13,"tcp-listener\077");
lf[48]=C_h_intern(&lf[48],9,"tcp-close");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[50]=C_h_intern(&lf[50],15,"tcp-buffer-size");
lf[51]=C_h_intern(&lf[51],16,"tcp-read-timeout");
lf[52]=C_h_intern(&lf[52],17,"tcp-write-timeout");
lf[53]=C_h_intern(&lf[53],19,"tcp-connect-timeout");
lf[54]=C_h_intern(&lf[54],18,"tcp-accept-timeout");
lf[55]=C_h_intern(&lf[55],15,"make-input-port");
lf[56]=C_h_intern(&lf[56],16,"make-output-port");
lf[57]=C_h_intern(&lf[57],12,"\003netio-ports");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[59]=C_h_intern(&lf[59],25,"\003systhread-block-for-i/o!");
lf[60]=C_h_intern(&lf[60],29,"\003systhread-block-for-timeout!");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[66]=C_h_intern(&lf[66],6,"socket");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],15,"\003sysmake-string");
lf[75]=C_h_intern(&lf[75],20,"\003sysscan-buffer-line");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[78]=C_h_intern(&lf[78],10,"tcp-accept");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[81]=C_h_intern(&lf[81],17,"tcp-accept-ready\077");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[83]=C_h_intern(&lf[83],16,"get-socket-error");
lf[84]=C_h_intern(&lf[84],16,"general-strerror");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[89]=C_h_intern(&lf[89],4,"\000all");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[95]=C_h_intern(&lf[95],20,"\003systcp-port->fileno");
lf[96]=C_h_intern(&lf[96],13,"\003sysport-data");
lf[97]=C_h_intern(&lf[97],13,"tcp-addresses");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[100]=C_h_intern(&lf[100],16,"tcp-port-numbers");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[103]=C_h_intern(&lf[103],17,"tcp-listener-port");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[105]=C_h_intern(&lf[105],16,"tcp-abandon-port");
lf[106]=C_h_intern(&lf[106],14,"\003syscheck-port");
lf[107]=C_h_intern(&lf[107],19,"tcp-listener-fileno");
lf[108]=C_h_intern(&lf[108],14,"make-parameter");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],3,"tcp");
C_register_lf2(lf,112,create_ptable());
t2=C_mutate(&lf[0] /* (set! c370 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k920 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k923 in k920 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 91   register-feature! */
t3=*((C_word*)lf[110]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[111]);}

/* k926 in k923 in k920 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[51],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_928,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! socket ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_930,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! bind ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[7]+1 /* (set! recv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[8]+1 /* (set! shutdown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[9]+1 /* (set! connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[10]+1 /* (set! send ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[11]+1 /* (set! make-nonblocking ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[12]+1 /* (set! getsockname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1086,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! getsockport ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! getpeerport ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! getpeername ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[17]+1 /* (set! startup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1122,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 175  ##net#startup */
t19=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}

/* k2756 in k926 in k923 in k920 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_1126(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 176  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],lf[109]);}}

/* k1124 in k926 in k923 in k920 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1 /* (set! getservbyname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1128,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[20]+1 /* (set! select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[21]+1 /* (set! select-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1160,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[22]+1 /* (set! gethostaddr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1167,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[23]+1 /* (set! yield ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[26]+1);
t8=C_mutate((C_word*)lf[27]+1 /* (set! parse-host ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1213,a[2]=t7,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[34]+1 /* (set! fresh-addr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! bind-socket ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[36]+1 /* (set! tcp-listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[47]+1 /* (set! tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1507,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[48]+1 /* (set! tcp-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1516,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 310  make-parameter */
t15=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,C_SCHEME_FALSE);}

/* k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[51] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[52] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[53] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[54] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1574,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 321  check */
f_1557(t9,lf[51]);}

/* k2753 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 321  make-parameter */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1 /* (set! tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 322  check */
f_1557(t4,lf[52]);}

/* k2749 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 322  make-parameter */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1 /* (set! tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 323  check */
f_1557(t4,lf[53]);}

/* k2745 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 323  make-parameter */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=C_mutate((C_word*)lf[53]+1 /* (set! tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  check */
f_1557(t4,lf[54]);}

/* k2741 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  make-parameter */
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1 /* (set! tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[55]+1);
t4=*((C_word*)lf[56]+1);
t5=*((C_word*)lf[50]+1);
t6=*((C_word*)lf[39]+1);
t7=C_mutate((C_word*)lf[57]+1 /* (set! io-ports ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1588,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word)li53),tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[78]+1 /* (set! tcp-accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[81]+1 /* (set! tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2282,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[83]+1 /* (set! get-socket-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! general-strerror ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[30]+1 /* (set! tcp-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[95]+1 /* (set! tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[97]+1 /* (set! tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[100]+1 /* (set! tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[103]+1 /* (set! tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[105]+1 /* (set! tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[107]+1 /* (set! tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2732,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[107]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 629  ##sys#check-port */
t4=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[105]);}

/* k2714 in tcp-abandon-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 631  ##sys#port-data */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2721 in k2714 in tcp-abandon-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2683,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[103]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2693,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 621  ##net#getsockport */
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2691 in tcp-listener-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2696,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t4=t2;
f_2696(2,t4,C_SCHEME_UNDEFINED);}}

/* k2708 in k2691 in tcp-listener-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 624  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[104],t1);}

/* k2704 in k2691 in tcp-listener-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 623  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[103],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2694 in k2691 in tcp-listener-port in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 611  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2649,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 613  ##net#getsockport */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2652(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2679 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 614  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[102],t1);}

/* k2675 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 614  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[100],t1,((C_word*)t0)[2]);}

/* k2650 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 615  ##net#getpeerport */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2654 in k2650 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2659(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2668 in k2654 in k2650 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 616  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[101],t1);}

/* k2664 in k2654 in k2650 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 616  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[100],t1,((C_word*)t0)[2]);}

/* k2657 in k2654 in k2650 in k2647 in k2640 in tcp-port-numbers in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 612  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2593,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2597,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 603  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2604,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 605  ##net#getsockname */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2607(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2634 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 606  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k2630 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 606  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[97],t1,((C_word*)t0)[2]);}

/* k2605 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 607  ##net#getpeername */
t3=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2609 in k2605 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2614(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2623 in k2609 in k2605 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[98],t1);}

/* k2619 in k2609 in k2605 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[97],t1,((C_word*)t0)[2]);}

/* k2612 in k2609 in k2605 in k2602 in k2595 in tcp-addresses in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 604  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2591,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 600  ##sys#port-data */
t4=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2589 in ##sys#tcp-port->fileno in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2336r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2336r(t0,t1,t2,t3);}}

static void C_ccall f_2336r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2340,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2340(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2340(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 551  tcp-connect-timeout */
t5=*((C_word*)lf[53]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2349,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2349(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[4],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}}

/* a2558 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2559,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2552 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
/* tcp.scm: 554  ##net#parse-host */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[94]);}

/* k2543 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_2349(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 555  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],lf[93],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 557  make-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2358,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 558  ##net#socket */
t3=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));}

/* k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2360,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 566  ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2381(2,t5,C_SCHEME_UNDEFINED);}}

/* k2529 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2540 in k2529 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[92],t1);}

/* k2536 in k2529 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[30],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 568  ##net#gethostaddr */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2520 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2384(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 569  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],lf[91],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 570  ##net#make-nonblocking */
t4=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}

/* k2503 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_2387(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 571  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2506 in k2503 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2517 in k2506 in k2503 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[90],t1);}

/* k2513 in k2506 in k2503 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2502,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 573  ##net#connect */
t4=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2],C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2444(t7,((C_word*)t0)[2]);}
else{
/* tcp.scm: 591  fail */
t4=((C_word*)t0)[3];
f_2360(t4,((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[2];
f_2390(2,t3,C_SCHEME_UNDEFINED);}}

/* loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_2444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2444,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 576  ##net#select-write */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(t1,C_fix(-1));
if(C_truep(t3)){
/* tcp.scm: 577  fail */
t4=((C_word*)t0)[2];
f_2360(t4,t2);}
else{
t4=t2;
f_2451(2,t4,C_SCHEME_UNDEFINED);}}

/* k2449 in k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 580  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[24]+1),t5);}
else{
t4=t3;
f_2460(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2458 in k2449 in k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 583  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[89]);}

/* k2461 in k2458 in k2449 in k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 584  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2464 in k2461 in k2458 in k2449 in k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 586  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[29],lf[30],lf[88],((C_word*)t0)[2]);}
else{
t3=t2;
f_2469(2,t3,C_SCHEME_UNDEFINED);}}

/* k2467 in k2464 in k2461 in k2458 in k2449 in k2446 in loop in k2500 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 590  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2444(t2,((C_word*)t0)[2]);}

/* k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 592  get-socket-error */
t3=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=t1;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2409,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t5=t1;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 596  general-strerror */
t8=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}
else{
t6=t2;
f_2396(2,t6,C_SCHEME_UNDEFINED);}}}

/* k2428 in k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 596  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k2424 in k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 596  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2411 in k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 594  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2407 in k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 594  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2394 in k2391 in k2388 in k2385 in k2382 in k2379 in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 597  ##net#io-ports */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_2360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2360,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 560  ##net#close */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2362 in fail in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 561  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2365 in k2362 in fail in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2376 in k2365 in k2362 in fail in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 563  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2372 in k2365 in k2362 in fail in k2356 in k2353 in k2347 in k2341 in k2338 in tcp-connect in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 562  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[30],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* general-strerror in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2325,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub713(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* get-socket-error in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2318,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub707(C_SCHEME_UNDEFINED,t3));}

/* tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2282,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[81]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2289,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* tcp.scm: 531  ##net#select */
t6=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2287 in tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 533  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2292(2,t4,C_SCHEME_UNDEFINED);}}

/* k2299 in k2287 in tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2310 in k2299 in k2287 in tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 535  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2306 in k2299 in k2287 in tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 534  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[81],t1,((C_word*)t0)[2]);}

/* k2290 in k2287 in tcp-accept-ready? in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2196,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[45]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2206,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 505  tcp-accept-timeout */
t6=*((C_word*)lf[54]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2211,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2211(t5,((C_word*)t0)[2]);}

/* loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_2211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2211,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 507  ##net#select */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 508  ##net#accept */
t4=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 517  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[24]+1),t5);}
else{
t4=t3;
f_2247(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2245 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 520  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2248 in k2245 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 521  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2251 in k2248 in k2245 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 523  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[29],lf[78],lf[80],((C_word*)t0)[2]);}
else{
t3=t2;
f_2256(2,t3,C_SCHEME_UNDEFINED);}}

/* k2254 in k2251 in k2248 in k2245 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 527  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2211(t2,((C_word*)t0)[2]);}

/* k2219 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 510  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2224(2,t4,C_SCHEME_UNDEFINED);}}

/* k2231 in k2219 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2242 in k2231 in k2219 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 512  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[79],t1);}

/* k2238 in k2231 in k2219 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 511  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[78],t1,((C_word*)t0)[2]);}

/* k2222 in k2219 in k2278 in loop in k2204 in tcp-accept in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 514  ##net#io-ports */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 332  ##net#make-nonblocking */
t5=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2178 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_1592(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 333  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2181 in k2178 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2192 in k2181 in k2178 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k2188 in k2181 in k2178 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],t1);}

/* k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 335  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=t4,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 341  tbs */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1604(t4,(C_truep(t3)?lf[76]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1604(t3,C_SCHEME_FALSE);}}

/* k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1604,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 343  tcp-read-timeout */
t5=*((C_word*)lf[51]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 344  tcp-write-timeout */
t3=*((C_word*)lf[52]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1922,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2022,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2087,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 372  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t9))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2087,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2093,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li51),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_2093(t7,t1,C_SCHEME_FALSE);}

/* loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2093,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li50),tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 419  ##sys#scan-buffer-line */
t4=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2162,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 436  read-input */
t4=((C_word*)t0)[3];
f_1611(t4,t3);}}

/* k2160 in loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 438  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2093(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a2104 in loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2105,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 424  ##sys#make-string */
t6=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k2107 in a2104 in loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2119,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 428  read-input */
t6=((C_word*)t0)[3];
f_1611(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 434  ##sys#string-append */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k2117 in k2107 in a2104 in loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[73]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 431  ##sys#string-append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_2135(2,t3,((C_word*)t0)[2]);}}}

/* k2133 in k2117 in k2107 in a2104 in loop in a2086 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 431  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2093(t2,((C_word*)t0)[2],t1);}

/* a2021 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2022,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li48),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2028(t9,t1,t3,C_fix(0),t5);}

/* loop in a2021 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_2028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2028,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* tcp.scm: 410  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2076,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 412  read-input */
t7=((C_word*)t0)[2];
f_1611(t7,t6);}}}

/* k2074 in loop in a2021 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 415  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2028(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t4=t3;
f_1987(2,t4,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 394  ##net#shutdown */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_fix((C_word)SD_RECEIVE));}}}

/* k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 395  ##net#close */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_1993(t3,C_SCHEME_FALSE);}}

/* k2012 in k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1993(t2,(C_word)C_eqp(C_fix(-1),t1));}

/* k1991 in k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1993,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 396  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1994 in k1991 in k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2005 in k1994 in k1991 in k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 399  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k2001 in k1994 in k1991 in k1985 in a1978 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 397  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 383  ##net#select */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k1952 in a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(t1,C_fix(-1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 385  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1957(2,t4,C_SCHEME_UNDEFINED);}}

/* k1964 in k1952 in a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1975 in k1964 in k1952 in a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 388  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1971 in k1964 in k1952 in a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 386  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1955 in k1952 in a1943 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1921 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 375  read-input */
t3=((C_word*)t0)[2];
f_1611(t3,t2);}
else{
t3=t2;
f_1926(2,t3,C_SCHEME_UNDEFINED);}}

/* k1924 in a1921 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1886,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1906,a[2]=t2,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1807,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word)li43),tmp=(C_word)a,a+=9,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1870,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp):C_SCHEME_FALSE);
/* tcp.scm: 468  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}

/* f_1870 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1880,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 492  output */
t4=((C_word*)t0)[2];
f_1685(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1878 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[70]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1854(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1854(t5,C_SCHEME_FALSE);}}}

/* k1852 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1854,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 482  output */
t3=((C_word*)t0)[2];
f_1685(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1815(t2,C_SCHEME_UNDEFINED);}}

/* k1855 in k1852 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[69]);
t3=((C_word*)t0)[2];
f_1815(t3,t2);}

/* k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1815,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(2)))){
t3=t2;
f_1818(2,t3,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 484  ##net#shutdown */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix((C_word)SD_SEND));}}

/* k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 485  ##net#close */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_1824(t3,C_SCHEME_FALSE);}}

/* k1843 in k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1824(t2,(C_word)C_eqp(C_fix(-1),t1));}

/* k1822 in k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 486  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1825 in k1822 in k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1836 in k1825 in k1822 in k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 488  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1832 in k1825 in k1822 in k1816 in k1813 in a1806 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 487  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* f_1906 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1906,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 477  output */
t4=((C_word*)t0)[2];
f_1685(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1886 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1886,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 471  ##sys#string-append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1889 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 473  output */
t5=((C_word*)t0)[2];
f_1685(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1898 in k1889 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[67]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1778 in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[64]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[65]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[66]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[66]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 500  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1685,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1695,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1695(t7,t1,t3,C_fix(0));}

/* loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1695,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 445  ##net#send */
t6=*((C_word*)lf[10]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t5,((C_word*)t0)[4],((C_word*)t0)[2],t3,t4,C_fix(0));}

/* k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 449  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[24]+1),t6);}
else{
t5=t4;
f_1717(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 460  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[5]))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],t1);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],t1);
/* tcp.scm: 466  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1695(t5,((C_word*)t0)[6],t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1747 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1760,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1758 in k1747 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 463  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k1754 in k1747 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 461  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1715 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 452  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1718 in k1715 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 453  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1721 in k1718 in k1715 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 455  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[29],lf[62],((C_word*)t0)[2]);}
else{
t3=t2;
f_1726(2,t3,C_SCHEME_UNDEFINED);}}

/* k1724 in k1721 in k1718 in k1715 in k1700 in loop in output in k1682 in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 458  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1695(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1617(t5,t1);}

/* loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 348  ##net#recv */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_fix(1024),C_fix(0));}

/* k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[4]);
/* tcp.scm: 352  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[24]+1),t6);}
else{
t5=t4;
f_1636(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 363  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t4=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1666 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1677 in k1666 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 366  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[61],t1);}

/* k1673 in k1666 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 364  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1634 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 355  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1637 in k1634 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 356  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1640 in k1637 in k1634 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 358  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[29],lf[58],((C_word*)t0)[2]);}
else{
t3=t2;
f_1645(2,t3,C_SCHEME_UNDEFINED);}}

/* k1643 in k1640 in k1637 in k1634 in k1619 in loop in read-input in k1608 in k1605 in k1602 in k1599 in k1593 in k1590 in ##net#io-ports in k1584 in k1580 in k1576 in k1572 in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 361  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1617(t2,((C_word*)t0)[2]);}

/* check in k1549 in k1124 in k926 in k923 in k920 */
static void C_fcall f_1557(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1557,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1559,a[2]=t2,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));}

/* f_1559 in check in k1549 in k1124 in k926 in k923 in k920 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1559,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k1124 in k926 in k923 in k920 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1516,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[45]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1547,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 303  ##net#close */
t6=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1545 in tcp-close in k1124 in k926 in k923 in k920 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 304  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1530 in k1545 in tcp-close in k1124 in k926 in k923 in k920 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1541 in k1530 in k1545 in tcp-close in k1124 in k926 in k923 in k920 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k1537 in k1530 in k1545 in tcp-close in k1124 in k926 in k923 in k920 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[48],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k1124 in k926 in k923 in k920 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1507,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[45]):C_SCHEME_FALSE));}

/* tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1409r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1409r(t0,t1,t2,t3);}}

static void C_ccall f_1409r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=t4,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=t5,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w324360 */
t7=t6;
f_1459(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host325356 */
t9=t5;
f_1454(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body322331 */
t11=t4;
f_1411(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w324 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_fcall f_1459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1459,NULL,2,t0,t1);}
/* def-host325356 */
t2=((C_word*)t0)[2];
f_1454(t2,t1,C_fix(10));}

/* def-host325 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1454,NULL,3,t0,t1,t2);}
/* body322331 */
t3=((C_word*)t0)[2];
f_1411(t3,t1,t2,C_SCHEME_FALSE);}

/* body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1417,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1423,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 290  ##net#listen */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,((C_word*)t0)[3]);}

/* k1428 in a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 292  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1433(2,t4,C_SCHEME_UNDEFINED);}}

/* k1440 in k1428 in a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1451 in k1440 in k1428 in a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1447 in k1440 in k1428 in a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1431 in k1428 in a1422 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[45],((C_word*)t0)[2]));}

/* a1416 in body322 in tcp-listen in k1124 in k926 in k923 in k920 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
/* tcp.scm: 288  ##net#bind-socket */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_fix((C_word)SOCK_STREAM),((C_word*)t0)[2]);}

/* ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1299,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1306,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 261  ##sys#signal-hook */
t9=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[43],lf[36],lf[44],t2);}
else{
t9=t6;
f_1306(2,t9,C_SCHEME_UNDEFINED);}}

/* k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 262  ##net#socket */
t3=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix((C_word)AF_INET),((C_word*)t0)[2],C_fix(0));}

/* k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 264  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1312(2,t4,C_SCHEME_UNDEFINED);}}

/* k1390 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 265  ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_1381 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1381,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub289(C_SCHEME_UNDEFINED,t3));}

/* k1378 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 271  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_1315(2,t3,C_SCHEME_UNDEFINED);}}

/* k1363 in k1378 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1374 in k1363 in k1378 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[40],t1);}

/* k1370 in k1363 in k1378 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[36],t1,((C_word*)t0)[2]);}

/* k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 273  make-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 275  ##net#gethostaddr */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* tcp.scm: 277  ##net#fresh-addr */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k1351 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1321(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 276  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],lf[38],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 278  ##net#bind */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 280  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1327(2,t4,C_SCHEME_UNDEFINED);}}

/* k1334 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1345 in k1334 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[37],t1);}

/* k1341 in k1334 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ##net#bind-socket in k1124 in k926 in k923 in k920 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 282  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#fresh-addr in k1124 in k926 in k923 in k920 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1285,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub254(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1213,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1222,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1222(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1222,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 232  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1245,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* tcp.scm: 236  substring */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 245  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 237  substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1252,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 238  ##net#getservbyname */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k1250 in k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 240  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1255(2,t4,C_SCHEME_UNDEFINED);}}

/* k1259 in k1250 in k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1270 in k1259 in k1250 in k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 242  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[32],t1);}

/* k1266 in k1259 in k1250 in k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],t1,((C_word*)t0)[2]);}

/* k1253 in k1250 in k1247 in k1243 in loop in ##net#parse-host in k1124 in k926 in k923 in k920 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 235  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k1124 in k926 in k923 in k920 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1198,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 220  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a1197 in yield in k1124 in k926 in k923 in k920 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1198,3,t0,t1,t2);}
t3=*((C_word*)lf[24]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1207,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 224  ##sys#schedule */
t6=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1206 in a1197 in yield in k1124 in k926 in k923 in k920 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
/* tcp.scm: 223  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k1124 in k926 in k923 in k920 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1167,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1176,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
/* ##sys#make-c-string */
t8=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=t6;
f_1176(2,t7,C_SCHEME_FALSE);}}

/* k1174 in ##net#gethostaddr in k1124 in k926 in k923 in k920 */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub204(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select-write in k1124 in k926 in k923 in k920 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1160,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub196(C_SCHEME_UNDEFINED,t3));}

/* ##net#select in k1124 in k926 in k923 in k920 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1153,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub190(C_SCHEME_UNDEFINED,t3));}

/* ##net#getservbyname in k1124 in k926 in k923 in k920 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1128,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1133,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t6=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t5=t4;
f_1133(2,t5,C_SCHEME_FALSE);}}

/* k1131 in ##net#getservbyname in k1124 in k926 in k923 in k920 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1137,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t4=t3;
f_1137(2,t4,C_SCHEME_FALSE);}}

/* k1135 in k1131 in ##net#getservbyname in k1124 in k926 in k923 in k920 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub177(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1));}

/* ##net#startup in k926 in k923 in k920 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub168(C_SCHEME_UNDEFINED));}

/* ##net#getpeername in k926 in k923 in k920 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1111,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub161(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* ##net#getpeerport in k926 in k923 in k920 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1104,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub155(C_SCHEME_UNDEFINED,t3));}

/* ##net#getsockport in k926 in k923 in k920 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1097,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub149(C_SCHEME_UNDEFINED,t3));}

/* ##net#getsockname in k926 in k923 in k920 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1086,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub141(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* ##net#make-nonblocking in k926 in k923 in k920 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1079,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub135(C_SCHEME_UNDEFINED,t3));}

/* ##net#send in k926 in k923 in k920 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1053,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_foreign_fixnum_argumentp(t2);
t8=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t4);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub122(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* ##net#connect in k926 in k923 in k920 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1035,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub107(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#shutdown in k926 in k923 in k920 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1024,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub98(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#recv in k926 in k923 in k920 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1002,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_foreign_fixnum_argumentp(t2);
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t4);
t9=(C_word)C_i_foreign_fixnum_argumentp(t5);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)stub85(C_SCHEME_UNDEFINED,t6,t7,t8,t9));}

/* ##net#close in k926 in k923 in k920 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_995,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub76(C_SCHEME_UNDEFINED,t3));}

/* ##net#accept in k926 in k923 in k920 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_974,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t7=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub62(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#listen in k926 in k923 in k920 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_963,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub53(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#bind in k926 in k923 in k920 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_945,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub41(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#socket in k926 in k923 in k920 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_930,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub31(C_SCHEME_UNDEFINED,t5,t6,t7));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[255] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_922tcp.scm",(void*)f_922},
{"f_925tcp.scm",(void*)f_925},
{"f_928tcp.scm",(void*)f_928},
{"f_2758tcp.scm",(void*)f_2758},
{"f_1126tcp.scm",(void*)f_1126},
{"f_1551tcp.scm",(void*)f_1551},
{"f_2755tcp.scm",(void*)f_2755},
{"f_1574tcp.scm",(void*)f_1574},
{"f_2751tcp.scm",(void*)f_2751},
{"f_1578tcp.scm",(void*)f_1578},
{"f_2747tcp.scm",(void*)f_2747},
{"f_1582tcp.scm",(void*)f_1582},
{"f_2743tcp.scm",(void*)f_2743},
{"f_1586tcp.scm",(void*)f_1586},
{"f_2732tcp.scm",(void*)f_2732},
{"f_2712tcp.scm",(void*)f_2712},
{"f_2716tcp.scm",(void*)f_2716},
{"f_2723tcp.scm",(void*)f_2723},
{"f_2683tcp.scm",(void*)f_2683},
{"f_2693tcp.scm",(void*)f_2693},
{"f_2710tcp.scm",(void*)f_2710},
{"f_2706tcp.scm",(void*)f_2706},
{"f_2696tcp.scm",(void*)f_2696},
{"f_2638tcp.scm",(void*)f_2638},
{"f_2642tcp.scm",(void*)f_2642},
{"f_2649tcp.scm",(void*)f_2649},
{"f_2681tcp.scm",(void*)f_2681},
{"f_2677tcp.scm",(void*)f_2677},
{"f_2652tcp.scm",(void*)f_2652},
{"f_2656tcp.scm",(void*)f_2656},
{"f_2670tcp.scm",(void*)f_2670},
{"f_2666tcp.scm",(void*)f_2666},
{"f_2659tcp.scm",(void*)f_2659},
{"f_2593tcp.scm",(void*)f_2593},
{"f_2597tcp.scm",(void*)f_2597},
{"f_2604tcp.scm",(void*)f_2604},
{"f_2636tcp.scm",(void*)f_2636},
{"f_2632tcp.scm",(void*)f_2632},
{"f_2607tcp.scm",(void*)f_2607},
{"f_2611tcp.scm",(void*)f_2611},
{"f_2625tcp.scm",(void*)f_2625},
{"f_2621tcp.scm",(void*)f_2621},
{"f_2614tcp.scm",(void*)f_2614},
{"f_2583tcp.scm",(void*)f_2583},
{"f_2591tcp.scm",(void*)f_2591},
{"f_2336tcp.scm",(void*)f_2336},
{"f_2340tcp.scm",(void*)f_2340},
{"f_2343tcp.scm",(void*)f_2343},
{"f_2559tcp.scm",(void*)f_2559},
{"f_2553tcp.scm",(void*)f_2553},
{"f_2545tcp.scm",(void*)f_2545},
{"f_2349tcp.scm",(void*)f_2349},
{"f_2355tcp.scm",(void*)f_2355},
{"f_2358tcp.scm",(void*)f_2358},
{"f_2531tcp.scm",(void*)f_2531},
{"f_2542tcp.scm",(void*)f_2542},
{"f_2538tcp.scm",(void*)f_2538},
{"f_2381tcp.scm",(void*)f_2381},
{"f_2522tcp.scm",(void*)f_2522},
{"f_2384tcp.scm",(void*)f_2384},
{"f_2505tcp.scm",(void*)f_2505},
{"f_2508tcp.scm",(void*)f_2508},
{"f_2519tcp.scm",(void*)f_2519},
{"f_2515tcp.scm",(void*)f_2515},
{"f_2387tcp.scm",(void*)f_2387},
{"f_2502tcp.scm",(void*)f_2502},
{"f_2444tcp.scm",(void*)f_2444},
{"f_2448tcp.scm",(void*)f_2448},
{"f_2451tcp.scm",(void*)f_2451},
{"f_2460tcp.scm",(void*)f_2460},
{"f_2463tcp.scm",(void*)f_2463},
{"f_2466tcp.scm",(void*)f_2466},
{"f_2469tcp.scm",(void*)f_2469},
{"f_2390tcp.scm",(void*)f_2390},
{"f_2393tcp.scm",(void*)f_2393},
{"f_2430tcp.scm",(void*)f_2430},
{"f_2426tcp.scm",(void*)f_2426},
{"f_2413tcp.scm",(void*)f_2413},
{"f_2409tcp.scm",(void*)f_2409},
{"f_2396tcp.scm",(void*)f_2396},
{"f_2360tcp.scm",(void*)f_2360},
{"f_2364tcp.scm",(void*)f_2364},
{"f_2367tcp.scm",(void*)f_2367},
{"f_2378tcp.scm",(void*)f_2378},
{"f_2374tcp.scm",(void*)f_2374},
{"f_2325tcp.scm",(void*)f_2325},
{"f_2318tcp.scm",(void*)f_2318},
{"f_2282tcp.scm",(void*)f_2282},
{"f_2289tcp.scm",(void*)f_2289},
{"f_2301tcp.scm",(void*)f_2301},
{"f_2312tcp.scm",(void*)f_2312},
{"f_2308tcp.scm",(void*)f_2308},
{"f_2292tcp.scm",(void*)f_2292},
{"f_2196tcp.scm",(void*)f_2196},
{"f_2206tcp.scm",(void*)f_2206},
{"f_2211tcp.scm",(void*)f_2211},
{"f_2280tcp.scm",(void*)f_2280},
{"f_2247tcp.scm",(void*)f_2247},
{"f_2250tcp.scm",(void*)f_2250},
{"f_2253tcp.scm",(void*)f_2253},
{"f_2256tcp.scm",(void*)f_2256},
{"f_2221tcp.scm",(void*)f_2221},
{"f_2233tcp.scm",(void*)f_2233},
{"f_2244tcp.scm",(void*)f_2244},
{"f_2240tcp.scm",(void*)f_2240},
{"f_2224tcp.scm",(void*)f_2224},
{"f_1588tcp.scm",(void*)f_1588},
{"f_2180tcp.scm",(void*)f_2180},
{"f_2183tcp.scm",(void*)f_2183},
{"f_2194tcp.scm",(void*)f_2194},
{"f_2190tcp.scm",(void*)f_2190},
{"f_1592tcp.scm",(void*)f_1592},
{"f_1595tcp.scm",(void*)f_1595},
{"f_1601tcp.scm",(void*)f_1601},
{"f_1604tcp.scm",(void*)f_1604},
{"f_1607tcp.scm",(void*)f_1607},
{"f_1610tcp.scm",(void*)f_1610},
{"f_2087tcp.scm",(void*)f_2087},
{"f_2093tcp.scm",(void*)f_2093},
{"f_2162tcp.scm",(void*)f_2162},
{"f_2105tcp.scm",(void*)f_2105},
{"f_2109tcp.scm",(void*)f_2109},
{"f_2119tcp.scm",(void*)f_2119},
{"f_2135tcp.scm",(void*)f_2135},
{"f_2022tcp.scm",(void*)f_2022},
{"f_2028tcp.scm",(void*)f_2028},
{"f_2076tcp.scm",(void*)f_2076},
{"f_1979tcp.scm",(void*)f_1979},
{"f_1987tcp.scm",(void*)f_1987},
{"f_2014tcp.scm",(void*)f_2014},
{"f_1993tcp.scm",(void*)f_1993},
{"f_1996tcp.scm",(void*)f_1996},
{"f_2007tcp.scm",(void*)f_2007},
{"f_2003tcp.scm",(void*)f_2003},
{"f_1944tcp.scm",(void*)f_1944},
{"f_1954tcp.scm",(void*)f_1954},
{"f_1966tcp.scm",(void*)f_1966},
{"f_1977tcp.scm",(void*)f_1977},
{"f_1973tcp.scm",(void*)f_1973},
{"f_1957tcp.scm",(void*)f_1957},
{"f_1922tcp.scm",(void*)f_1922},
{"f_1926tcp.scm",(void*)f_1926},
{"f_1684tcp.scm",(void*)f_1684},
{"f_1870tcp.scm",(void*)f_1870},
{"f_1880tcp.scm",(void*)f_1880},
{"f_1807tcp.scm",(void*)f_1807},
{"f_1854tcp.scm",(void*)f_1854},
{"f_1857tcp.scm",(void*)f_1857},
{"f_1815tcp.scm",(void*)f_1815},
{"f_1818tcp.scm",(void*)f_1818},
{"f_1845tcp.scm",(void*)f_1845},
{"f_1824tcp.scm",(void*)f_1824},
{"f_1827tcp.scm",(void*)f_1827},
{"f_1838tcp.scm",(void*)f_1838},
{"f_1834tcp.scm",(void*)f_1834},
{"f_1906tcp.scm",(void*)f_1906},
{"f_1886tcp.scm",(void*)f_1886},
{"f_1891tcp.scm",(void*)f_1891},
{"f_1900tcp.scm",(void*)f_1900},
{"f_1780tcp.scm",(void*)f_1780},
{"f_1685tcp.scm",(void*)f_1685},
{"f_1695tcp.scm",(void*)f_1695},
{"f_1702tcp.scm",(void*)f_1702},
{"f_1749tcp.scm",(void*)f_1749},
{"f_1760tcp.scm",(void*)f_1760},
{"f_1756tcp.scm",(void*)f_1756},
{"f_1717tcp.scm",(void*)f_1717},
{"f_1720tcp.scm",(void*)f_1720},
{"f_1723tcp.scm",(void*)f_1723},
{"f_1726tcp.scm",(void*)f_1726},
{"f_1611tcp.scm",(void*)f_1611},
{"f_1617tcp.scm",(void*)f_1617},
{"f_1621tcp.scm",(void*)f_1621},
{"f_1668tcp.scm",(void*)f_1668},
{"f_1679tcp.scm",(void*)f_1679},
{"f_1675tcp.scm",(void*)f_1675},
{"f_1636tcp.scm",(void*)f_1636},
{"f_1639tcp.scm",(void*)f_1639},
{"f_1642tcp.scm",(void*)f_1642},
{"f_1645tcp.scm",(void*)f_1645},
{"f_1557tcp.scm",(void*)f_1557},
{"f_1559tcp.scm",(void*)f_1559},
{"f_1516tcp.scm",(void*)f_1516},
{"f_1547tcp.scm",(void*)f_1547},
{"f_1532tcp.scm",(void*)f_1532},
{"f_1543tcp.scm",(void*)f_1543},
{"f_1539tcp.scm",(void*)f_1539},
{"f_1507tcp.scm",(void*)f_1507},
{"f_1409tcp.scm",(void*)f_1409},
{"f_1459tcp.scm",(void*)f_1459},
{"f_1454tcp.scm",(void*)f_1454},
{"f_1411tcp.scm",(void*)f_1411},
{"f_1423tcp.scm",(void*)f_1423},
{"f_1430tcp.scm",(void*)f_1430},
{"f_1442tcp.scm",(void*)f_1442},
{"f_1453tcp.scm",(void*)f_1453},
{"f_1449tcp.scm",(void*)f_1449},
{"f_1433tcp.scm",(void*)f_1433},
{"f_1417tcp.scm",(void*)f_1417},
{"f_1299tcp.scm",(void*)f_1299},
{"f_1306tcp.scm",(void*)f_1306},
{"f_1309tcp.scm",(void*)f_1309},
{"f_1392tcp.scm",(void*)f_1392},
{"f_1312tcp.scm",(void*)f_1312},
{"f_1381tcp.scm",(void*)f_1381},
{"f_1380tcp.scm",(void*)f_1380},
{"f_1365tcp.scm",(void*)f_1365},
{"f_1376tcp.scm",(void*)f_1376},
{"f_1372tcp.scm",(void*)f_1372},
{"f_1315tcp.scm",(void*)f_1315},
{"f_1318tcp.scm",(void*)f_1318},
{"f_1353tcp.scm",(void*)f_1353},
{"f_1321tcp.scm",(void*)f_1321},
{"f_1324tcp.scm",(void*)f_1324},
{"f_1336tcp.scm",(void*)f_1336},
{"f_1347tcp.scm",(void*)f_1347},
{"f_1343tcp.scm",(void*)f_1343},
{"f_1327tcp.scm",(void*)f_1327},
{"f_1285tcp.scm",(void*)f_1285},
{"f_1213tcp.scm",(void*)f_1213},
{"f_1222tcp.scm",(void*)f_1222},
{"f_1245tcp.scm",(void*)f_1245},
{"f_1249tcp.scm",(void*)f_1249},
{"f_1252tcp.scm",(void*)f_1252},
{"f_1261tcp.scm",(void*)f_1261},
{"f_1272tcp.scm",(void*)f_1272},
{"f_1268tcp.scm",(void*)f_1268},
{"f_1255tcp.scm",(void*)f_1255},
{"f_1192tcp.scm",(void*)f_1192},
{"f_1198tcp.scm",(void*)f_1198},
{"f_1207tcp.scm",(void*)f_1207},
{"f_1167tcp.scm",(void*)f_1167},
{"f_1176tcp.scm",(void*)f_1176},
{"f_1160tcp.scm",(void*)f_1160},
{"f_1153tcp.scm",(void*)f_1153},
{"f_1128tcp.scm",(void*)f_1128},
{"f_1133tcp.scm",(void*)f_1133},
{"f_1137tcp.scm",(void*)f_1137},
{"f_1122tcp.scm",(void*)f_1122},
{"f_1111tcp.scm",(void*)f_1111},
{"f_1104tcp.scm",(void*)f_1104},
{"f_1097tcp.scm",(void*)f_1097},
{"f_1086tcp.scm",(void*)f_1086},
{"f_1079tcp.scm",(void*)f_1079},
{"f_1053tcp.scm",(void*)f_1053},
{"f_1035tcp.scm",(void*)f_1035},
{"f_1024tcp.scm",(void*)f_1024},
{"f_1002tcp.scm",(void*)f_1002},
{"f_995tcp.scm",(void*)f_995},
{"f_974tcp.scm",(void*)f_974},
{"f_963tcp.scm",(void*)f_963},
{"f_945tcp.scm",(void*)f_945},
{"f_930tcp.scm",(void*)f_930},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
