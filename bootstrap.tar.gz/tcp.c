/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-14 09:36
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[114];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,115,111,99,107,101,116,32,97,51,48,51,51,32,97,50,57,51,52,32,97,50,56,51,53,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,30),40,35,35,110,101,116,35,98,105,110,100,32,97,52,48,52,52,32,97,51,57,52,53,32,97,51,56,52,54,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,26),40,35,35,110,101,116,35,108,105,115,116,101,110,32,97,53,50,53,53,32,97,53,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,97,99,99,101,112,116,32,97,54,49,54,54,32,97,54,48,54,55,32,97,53,57,54,56,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,35,35,110,101,116,35,99,108,111,115,101,32,97,55,53,55,56,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,35,35,110,101,116,35,114,101,99,118,32,97,56,52,56,56,32,97,56,51,56,57,32,97,56,50,57,48,32,97,56,49,57,49,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,30),40,35,35,110,101,116,35,115,104,117,116,100,111,119,110,32,97,57,55,49,48,48,32,97,57,54,49,48,49,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,39),40,35,35,110,101,116,35,99,111,110,110,101,99,116,32,97,49,48,54,49,49,48,32,97,49,48,53,49,49,49,32,97,49,48,52,49,49,50,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,52),40,35,35,110,101,116,35,115,101,110,100,32,97,49,50,49,49,50,53,32,97,49,50,48,49,50,54,32,97,49,49,57,49,50,55,32,97,49,49,56,49,50,56,32,97,49,49,55,49,50,57,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,32),40,35,35,110,101,116,35,109,97,107,101,45,110,111,110,98,108,111,99,107,105,110,103,32,97,49,51,52,49,51,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,115,111,99,107,110,97,109,101,32,97,49,52,48,49,52,51,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,115,111,99,107,112,111,114,116,32,97,49,52,56,49,53,49,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,112,101,101,114,112,111,114,116,32,97,49,53,52,49,53,55,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,27),40,35,35,110,101,116,35,103,101,116,112,101,101,114,110,97,109,101,32,97,49,54,48,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,15),40,35,35,110,101,116,35,115,116,97,114,116,117,112,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,37),40,35,35,110,101,116,35,103,101,116,115,101,114,118,98,121,110,97,109,101,32,97,49,55,54,49,56,49,32,97,49,55,53,49,56,50,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,101,108,101,99,116,32,97,49,56,57,49,57,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,28),40,35,35,110,101,116,35,115,101,108,101,99,116,45,119,114,105,116,101,32,97,49,57,53,49,57,56,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,50,48,51,50,48,56,32,97,50,48,50,50,48,57,32,97,50,48,49,50,49,48,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,50,49,48,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,97,49,50,48,49,32,114,101,116,117,114,110,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,51,53,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,35),40,35,35,110,101,116,35,112,97,114,115,101,45,104,111,115,116,32,104,111,115,116,50,50,56,32,112,114,111,116,111,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,34),40,35,35,110,101,116,35,102,114,101,115,104,45,97,100,100,114,32,97,50,53,51,50,53,55,32,97,50,53,50,50,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,56,53,32,97,50,56,56,50,57,49,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,44),40,35,35,110,101,116,35,98,105,110,100,45,115,111,99,107,101,116,32,112,111,114,116,50,54,52,32,115,116,121,108,101,50,54,53,32,104,111,115,116,50,54,54,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,52,50,48,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,32),40,97,49,52,50,54,32,115,51,51,54,51,51,55,51,52,50,32,97,100,100,114,51,51,56,51,51,57,51,52,51,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,51,50,50,32,119,51,51,50,32,104,111,115,116,51,51,51,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,51,50,53,32,37,119,51,50,48,51,53,55,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,51,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,51,49,50,32,46,32,109,111,114,101,51,49,51,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,51,55,51,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,51,55,57,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,54,51,32,120,52,48,49,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,51,57,57,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,53,56,56,32,111,102,102,115,101,116,53,56,57,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,53,56,52,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,102,95,49,56,57,48,32,115,54,50,52,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,102,95,49,57,49,48,32,115,54,51,48,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,56,49,48,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,8),40,102,95,49,56,55,52,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,57,50,53,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,57,52,55,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,57,56,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,53,50,49,32,109,53,50,50,32,115,116,97,114,116,53,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,34),40,97,50,48,50,53,32,112,53,49,52,32,110,53,49,53,32,100,101,115,116,53,49,54,32,115,116,97,114,116,53,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,97,50,49,48,56,32,112,111,115,50,53,53,55,32,110,101,120,116,53,53,56,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,53,52,56,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,21),40,97,50,48,57,48,32,112,53,52,51,32,108,105,109,105,116,53,52,52,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,52,49,55,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,54,54,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,54,57,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,115,111,99,107,101,116,45,101,114,114,111,114,32,97,55,48,54,55,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,26),40,103,101,110,101,114,97,108,45,115,116,114,101,114,114,111,114,32,97,55,49,50,55,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,7),40,97,50,53,53,54,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,29),40,97,50,53,54,50,32,104,111,115,116,55,51,56,55,52,49,32,112,111,114,116,55,51,57,55,52,50,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,55,50,49,32,46,32,109,111,114,101,55,50,50,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,56,48,53,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,56,49,49,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,56,51,48,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,56,52,57,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,56,54,51,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,56,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2336 */
static C_word C_fcall stub713(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub713(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k2325 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub707(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub707(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from k1388 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k1296 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k1182 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from k1167 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1160 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1139 in k1135 in ##net#getservbyname in k1128 in k930 in k927 in k924 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup in k930 in k927 in k924 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub168(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from k1122 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1111 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1104 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k1097 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub141(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k1086 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1076 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k1050 */
static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k1035 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k1021 */
static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k1002 */
static C_word C_fcall stub76(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub76(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k989 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k974 */
static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k960 */
static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k945 */
static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_fcall f_2448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_fcall f_2215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_fcall f_1608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2097)
static void C_fcall f_2097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2032)
static void C_fcall f_2032(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_fcall f_1997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_fcall f_1858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_fcall f_1819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1699)
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_fcall f_1615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_fcall f_1621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1463)
static void C_fcall f_1463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_fcall f_1458(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1415)
static void C_fcall f_1415(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;

C_noret_decl(trf_2448)
static void C_fcall trf_2448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2448(t0,t1);}

C_noret_decl(trf_2364)
static void C_fcall trf_2364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2364(t0,t1);}

C_noret_decl(trf_2215)
static void C_fcall trf_2215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2215(t0,t1);}

C_noret_decl(trf_1608)
static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1608(t0,t1);}

C_noret_decl(trf_2097)
static void C_fcall trf_2097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2097(t0,t1,t2);}

C_noret_decl(trf_2032)
static void C_fcall trf_2032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2032(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2032(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1997)
static void C_fcall trf_1997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1997(t0,t1);}

C_noret_decl(trf_1858)
static void C_fcall trf_1858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1858(t0,t1);}

C_noret_decl(trf_1819)
static void C_fcall trf_1819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1819(t0,t1);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1828(t0,t1);}

C_noret_decl(trf_1689)
static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1689(t0,t1,t2);}

C_noret_decl(trf_1699)
static void C_fcall trf_1699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1699(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1699(t0,t1,t2,t3);}

C_noret_decl(trf_1615)
static void C_fcall trf_1615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1615(t0,t1);}

C_noret_decl(trf_1621)
static void C_fcall trf_1621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1621(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1463)
static void C_fcall trf_1463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1463(t0,t1);}

C_noret_decl(trf_1458)
static void C_fcall trf_1458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1458(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1458(t0,t1,t2);}

C_noret_decl(trf_1415)
static void C_fcall trf_1415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1415(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1415(t0,t1,t2,t3);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1226(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(700)){
C_save(t1);
C_rereclaim2(700*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,114);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],10,"\003netsocket");
lf[3]=C_h_intern(&lf[3],8,"\003netbind");
lf[4]=C_h_intern(&lf[4],10,"\003netlisten");
lf[5]=C_h_intern(&lf[5],10,"\003netaccept");
lf[6]=C_h_intern(&lf[6],9,"\003netclose");
lf[7]=C_h_intern(&lf[7],8,"\003netrecv");
lf[8]=C_h_intern(&lf[8],12,"\003netshutdown");
lf[9]=C_h_intern(&lf[9],11,"\003netconnect");
lf[10]=C_h_intern(&lf[10],8,"\003netsend");
lf[11]=C_h_intern(&lf[11],20,"\003netmake-nonblocking");
lf[12]=C_h_intern(&lf[12],15,"\003netgetsockname");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_h_intern(&lf[14],15,"\003netgetsockport");
lf[15]=C_h_intern(&lf[15],15,"\003netgetpeerport");
lf[16]=C_h_intern(&lf[16],15,"\003netgetpeername");
lf[17]=C_h_intern(&lf[17],11,"\003netstartup");
lf[18]=C_h_intern(&lf[18],17,"\003netgetservbyname");
lf[19]=C_h_intern(&lf[19],17,"\003sysmake-c-string");
lf[20]=C_h_intern(&lf[20],10,"\003netselect");
lf[21]=C_h_intern(&lf[21],16,"\003netselect-write");
lf[22]=C_h_intern(&lf[22],15,"\003netgethostaddr");
lf[23]=C_h_intern(&lf[23],5,"yield");
lf[24]=C_h_intern(&lf[24],18,"\003syscurrent-thread");
lf[25]=C_h_intern(&lf[25],12,"\003sysschedule");
lf[26]=C_h_intern(&lf[26],9,"substring");
lf[27]=C_h_intern(&lf[27],14,"\003netparse-host");
lf[28]=C_h_intern(&lf[28],15,"\003syssignal-hook");
lf[29]=C_h_intern(&lf[29],14,"\000network-error");
lf[30]=C_h_intern(&lf[30],11,"tcp-connect");
lf[31]=C_h_intern(&lf[31],17,"\003sysstring-append");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[33]=C_h_intern(&lf[33],16,"\003sysupdate-errno");
lf[34]=C_h_intern(&lf[34],14,"\003netfresh-addr");
lf[35]=C_h_intern(&lf[35],15,"\003netbind-socket");
lf[36]=C_h_intern(&lf[36],10,"tcp-listen");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[39]=C_h_intern(&lf[39],11,"make-string");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[41]=C_h_intern(&lf[41],9,"\003syserror");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[43]=C_h_intern(&lf[43],13,"\000domain-error");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[45]=C_h_intern(&lf[45],12,"tcp-listener");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[47]=C_h_intern(&lf[47],13,"tcp-listener\077");
lf[48]=C_h_intern(&lf[48],9,"tcp-close");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[50]=C_h_intern(&lf[50],15,"tcp-buffer-size");
lf[51]=C_h_intern(&lf[51],16,"tcp-read-timeout");
lf[52]=C_h_intern(&lf[52],17,"tcp-write-timeout");
lf[53]=C_h_intern(&lf[53],19,"tcp-connect-timeout");
lf[54]=C_h_intern(&lf[54],18,"tcp-accept-timeout");
lf[55]=C_h_intern(&lf[55],15,"make-input-port");
lf[56]=C_h_intern(&lf[56],16,"make-output-port");
lf[57]=C_h_intern(&lf[57],12,"\003netio-ports");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[59]=C_h_intern(&lf[59],25,"\003systhread-block-for-i/o!");
lf[60]=C_h_intern(&lf[60],29,"\003systhread-block-for-timeout!");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[66]=C_h_intern(&lf[66],6,"socket");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],15,"\003sysmake-string");
lf[75]=C_h_intern(&lf[75],20,"\003sysscan-buffer-line");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[78]=C_h_intern(&lf[78],10,"tcp-accept");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[81]=C_h_intern(&lf[81],17,"tcp-accept-ready\077");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[83]=C_h_intern(&lf[83],16,"get-socket-error");
lf[84]=C_h_intern(&lf[84],16,"general-strerror");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[89]=C_h_intern(&lf[89],4,"\000all");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[95]=C_h_intern(&lf[95],20,"\003systcp-port->fileno");
lf[96]=C_h_intern(&lf[96],5,"error");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)argument does not appear to be a TCP port");
lf[98]=C_h_intern(&lf[98],13,"\003sysport-data");
lf[99]=C_h_intern(&lf[99],13,"tcp-addresses");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[102]=C_h_intern(&lf[102],14,"\003syscheck-port");
lf[103]=C_h_intern(&lf[103],16,"tcp-port-numbers");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[106]=C_h_intern(&lf[106],17,"tcp-listener-port");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[108]=C_h_intern(&lf[108],16,"tcp-abandon-port");
lf[109]=C_h_intern(&lf[109],19,"tcp-listener-fileno");
lf[110]=C_h_intern(&lf[110],14,"make-parameter");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[112]=C_h_intern(&lf[112],17,"register-feature!");
lf[113]=C_h_intern(&lf[113],3,"tcp");
C_register_lf2(lf,114,create_ptable());
t2=C_mutate(&lf[0] /* (set! c370 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_926,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k924 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k927 in k924 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 91   register-feature! */
t3=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[113]);}

/* k930 in k927 in k924 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[51],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! socket ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! bind ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_949,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[7]+1 /* (set! recv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[8]+1 /* (set! shutdown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[9]+1 /* (set! connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[10]+1 /* (set! send ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[11]+1 /* (set! make-nonblocking ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[12]+1 /* (set! getsockname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1090,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! getsockport ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! getpeerport ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! getpeername ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[17]+1 /* (set! startup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 175  ##net#startup */
t19=*((C_word*)lf[17]+1);
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}

/* k2774 in k930 in k927 in k924 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_1130(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 176  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],lf[111]);}}

/* k1128 in k930 in k927 in k924 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1 /* (set! getservbyname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[20]+1 /* (set! select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[21]+1 /* (set! select-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1164,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[22]+1 /* (set! gethostaddr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[23]+1 /* (set! yield ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[26]+1);
t8=C_mutate((C_word*)lf[27]+1 /* (set! parse-host ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1217,a[2]=t7,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[34]+1 /* (set! fresh-addr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1289,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! bind-socket ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[36]+1 /* (set! tcp-listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[47]+1 /* (set! tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[48]+1 /* (set! tcp-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1520,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 310  make-parameter */
t15=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,C_SCHEME_FALSE);}

/* k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[51] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[52] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[53] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[54] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 321  check */
f_1561(t9,lf[51]);}

/* k2771 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 321  make-parameter */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1 /* (set! tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 322  check */
f_1561(t4,lf[52]);}

/* k2767 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 322  make-parameter */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1 /* (set! tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 323  check */
f_1561(t4,lf[53]);}

/* k2763 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 323  make-parameter */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=C_mutate((C_word*)lf[53]+1 /* (set! tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  check */
f_1561(t4,lf[54]);}

/* k2759 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  make-parameter */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1 /* (set! tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[55]+1);
t4=*((C_word*)lf[56]+1);
t5=*((C_word*)lf[50]+1);
t6=*((C_word*)lf[39]+1);
t7=C_mutate((C_word*)lf[57]+1 /* (set! io-ports ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1592,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word)li53),tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[78]+1 /* (set! tcp-accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[81]+1 /* (set! tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[83]+1 /* (set! get-socket-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! general-strerror ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[30]+1 /* (set! tcp-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[95]+1 /* (set! tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2587,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[99]+1 /* (set! tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2605,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[103]+1 /* (set! tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[106]+1 /* (set! tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[108]+1 /* (set! tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2730,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[109]+1 /* (set! tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2750,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2750,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[109]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 634  ##sys#check-port */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[108]);}

/* k2732 in tcp-abandon-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 636  ##sys#port-data */
t3=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2739 in k2732 in tcp-abandon-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2701,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[106]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2711,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 626  ##net#getsockport */
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2709 in tcp-listener-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2728,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t4=t2;
f_2714(2,t4,C_SCHEME_UNDEFINED);}}

/* k2726 in k2709 in tcp-listener-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 629  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[107],t1);}

/* k2722 in k2709 in tcp-listener-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[106],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2712 in k2709 in tcp-listener-port in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2653,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 615  ##sys#check-port */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[103]);}

/* k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 616  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2667,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 618  ##net#getsockport */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2670(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2699,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2697 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 619  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[105],t1);}

/* k2693 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 619  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[103],t1,((C_word*)t0)[2]);}

/* k2668 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 620  ##net#getpeerport */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2672 in k2668 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2677(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2686 in k2672 in k2668 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 621  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[104],t1);}

/* k2682 in k2672 in k2668 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 621  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[103],t1,((C_word*)t0)[2]);}

/* k2675 in k2672 in k2668 in k2665 in k2658 in k2655 in tcp-port-numbers in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 617  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 606  ##sys#check-port */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[99]);}

/* k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 607  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 609  ##net#getsockname */
t3=*((C_word*)lf[12]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2622(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2649 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[101],t1);}

/* k2645 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[99],t1,((C_word*)t0)[2]);}

/* k2620 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 611  ##net#getpeername */
t3=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2624 in k2620 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2629(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2638 in k2624 in k2620 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 612  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[100],t1);}

/* k2634 in k2624 in k2620 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 612  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[99],t1,((C_word*)t0)[2]);}

/* k2627 in k2624 in k2620 in k2617 in k2610 in k2607 in tcp-addresses in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2587,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 600  ##sys#port-data */
t4=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2589 in ##sys#tcp-port->fileno in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_vectorp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}
else{
/* tcp.scm: 603  error */
t2=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[95],lf[97],((C_word*)t0)[2]);}}

/* tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2340r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2340r(t0,t1,t2,t3);}}

static void C_ccall f_2340r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2344(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2344(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 551  tcp-connect-timeout */
t5=*((C_word*)lf[53]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2353,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2353(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[4],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}}

/* a2562 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2563,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2556 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
/* tcp.scm: 554  ##net#parse-host */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[94]);}

/* k2547 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_2353(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 555  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],lf[93],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 557  make-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2362,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 558  ##net#socket */
t3=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));}

/* k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2364,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 566  ##sys#update-errno */
t6=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2385(2,t5,C_SCHEME_UNDEFINED);}}

/* k2533 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2544 in k2533 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[92],t1);}

/* k2540 in k2533 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[30],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 568  ##net#gethostaddr */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2524 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2388(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 569  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],lf[91],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 570  ##net#make-nonblocking */
t4=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}

/* k2507 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_2391(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 571  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2510 in k2507 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2521 in k2510 in k2507 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[90],t1);}

/* k2517 in k2510 in k2507 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2506,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 573  ##net#connect */
t4=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2],C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2448(t7,((C_word*)t0)[2]);}
else{
/* tcp.scm: 591  fail */
t4=((C_word*)t0)[3];
f_2364(t4,((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[2];
f_2394(2,t3,C_SCHEME_UNDEFINED);}}

/* loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_2448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2448,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 576  ##net#select-write */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(t1,C_fix(-1));
if(C_truep(t3)){
/* tcp.scm: 577  fail */
t4=((C_word*)t0)[2];
f_2364(t4,t2);}
else{
t4=t2;
f_2455(2,t4,C_SCHEME_UNDEFINED);}}

/* k2453 in k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 580  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[24]+1),t5);}
else{
t4=t3;
f_2464(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2462 in k2453 in k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 583  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[89]);}

/* k2465 in k2462 in k2453 in k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 584  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2468 in k2465 in k2462 in k2453 in k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 586  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[29],lf[30],lf[88],((C_word*)t0)[2]);}
else{
t3=t2;
f_2473(2,t3,C_SCHEME_UNDEFINED);}}

/* k2471 in k2468 in k2465 in k2462 in k2453 in k2450 in loop in k2504 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 590  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2448(t2,((C_word*)t0)[2]);}

/* k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 592  get-socket-error */
t3=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=t1;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t5=t1;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 596  general-strerror */
t8=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t1);}
else{
t6=t2;
f_2400(2,t6,C_SCHEME_UNDEFINED);}}}

/* k2432 in k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 596  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k2428 in k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 596  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2415 in k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 594  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2411 in k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 594  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],lf[30],t1);}

/* k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 597  ##net#io-ports */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_2364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2364,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 560  ##net#close */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2366 in fail in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 561  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2369 in k2366 in fail in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2380 in k2369 in k2366 in fail in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 563  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2376 in k2369 in k2366 in fail in k2360 in k2357 in k2351 in k2345 in k2342 in tcp-connect in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 562  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[30],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* general-strerror in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2329,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub713(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* get-socket-error in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2322,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub707(C_SCHEME_UNDEFINED,t3));}

/* tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2286,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[81]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* tcp.scm: 531  ##net#select */
t6=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2291 in tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 533  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2296(2,t4,C_SCHEME_UNDEFINED);}}

/* k2303 in k2291 in tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2314 in k2303 in k2291 in tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 535  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2310 in k2303 in k2291 in tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 534  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[81],t1,((C_word*)t0)[2]);}

/* k2294 in k2291 in tcp-accept-ready? in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[45]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2210,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 505  tcp-accept-timeout */
t6=*((C_word*)lf[54]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2215,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2215(t5,((C_word*)t0)[2]);}

/* loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_2215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2215,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 507  ##net#select */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 508  ##net#accept */
t4=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 517  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[24]+1),t5);}
else{
t4=t3;
f_2251(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2249 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 520  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2252 in k2249 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 521  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2255 in k2252 in k2249 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 523  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[29],lf[78],lf[80],((C_word*)t0)[2]);}
else{
t3=t2;
f_2260(2,t3,C_SCHEME_UNDEFINED);}}

/* k2258 in k2255 in k2252 in k2249 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 527  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2215(t2,((C_word*)t0)[2]);}

/* k2223 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2228,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 510  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2228(2,t4,C_SCHEME_UNDEFINED);}}

/* k2235 in k2223 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2248,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2246 in k2235 in k2223 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 512  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[79],t1);}

/* k2242 in k2235 in k2223 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 511  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[78],t1,((C_word*)t0)[2]);}

/* k2226 in k2223 in k2282 in loop in k2208 in tcp-accept in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 514  ##net#io-ports */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 332  ##net#make-nonblocking */
t5=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2182 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_1596(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 333  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2185 in k2182 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2196 in k2185 in k2182 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k2192 in k2185 in k2182 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],t1);}

/* k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 335  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=t4,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 341  tbs */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1608(t4,(C_truep(t3)?lf[76]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1608(t3,C_SCHEME_FALSE);}}

/* k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 343  tcp-read-timeout */
t5=*((C_word*)lf[51]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 344  tcp-write-timeout */
t3=*((C_word*)lf[52]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1926,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2026,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2091,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[11],a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 372  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t9))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2091,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2097,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li51),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_2097(t7,t1,C_SCHEME_FALSE);}

/* loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_2097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2097,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li50),tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 419  ##sys#scan-buffer-line */
t4=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2166,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 436  read-input */
t4=((C_word*)t0)[3];
f_1615(t4,t3);}}

/* k2164 in loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 438  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2097(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a2108 in loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2109,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 424  ##sys#make-string */
t6=*((C_word*)lf[74]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k2111 in a2108 in loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2123,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 428  read-input */
t6=((C_word*)t0)[3];
f_1615(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 434  ##sys#string-append */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k2121 in k2111 in a2108 in loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[73]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 431  ##sys#string-append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_2139(2,t3,((C_word*)t0)[2]);}}}

/* k2137 in k2121 in k2111 in a2108 in loop in a2090 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 431  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2097(t2,((C_word*)t0)[2],t1);}

/* a2025 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2026,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li48),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2032(t9,t1,t3,C_fix(0),t5);}

/* loop in a2025 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_2032(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2032,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* tcp.scm: 410  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2080,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 412  read-input */
t7=((C_word*)t0)[2];
f_1615(t7,t6);}}}

/* k2078 in loop in a2025 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 415  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2032(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t4=t3;
f_1991(2,t4,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 394  ##net#shutdown */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_fix((C_word)SD_RECEIVE));}}}

/* k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 395  ##net#close */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_1997(t3,C_SCHEME_FALSE);}}

/* k2016 in k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1997(t2,(C_word)C_eqp(C_fix(-1),t1));}

/* k1995 in k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1997,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 396  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1998 in k1995 in k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2009 in k1998 in k1995 in k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 399  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k2005 in k1998 in k1995 in k1989 in a1982 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 397  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 383  ##net#select */
t4=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k1956 in a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(t1,C_fix(-1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 385  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1961(2,t4,C_SCHEME_UNDEFINED);}}

/* k1968 in k1956 in a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1979 in k1968 in k1956 in a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 388  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1975 in k1968 in k1956 in a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 386  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1959 in k1956 in a1947 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1925 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 375  read-input */
t3=((C_word*)t0)[2];
f_1615(t3,t2);}
else{
t3=t2;
f_1930(2,t3,C_SCHEME_UNDEFINED);}}

/* k1928 in a1925 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1890,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=t2,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1811,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word)li43),tmp=(C_word)a,a+=9,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1874,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp):C_SCHEME_FALSE);
/* tcp.scm: 468  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}

/* f_1874 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 492  output */
t4=((C_word*)t0)[2];
f_1689(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1882 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[70]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1858(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1858(t5,C_SCHEME_FALSE);}}}

/* k1856 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1858,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 482  output */
t3=((C_word*)t0)[2];
f_1689(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1819(t2,C_SCHEME_UNDEFINED);}}

/* k1859 in k1856 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[69]);
t3=((C_word*)t0)[2];
f_1819(t3,t2);}

/* k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1819,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(2)))){
t3=t2;
f_1822(2,t3,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 484  ##net#shutdown */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix((C_word)SD_SEND));}}

/* k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 485  ##net#close */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_1828(t3,C_SCHEME_FALSE);}}

/* k1847 in k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1828(t2,(C_word)C_eqp(C_fix(-1),t1));}

/* k1826 in k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 486  ##sys#update-errno */
t3=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1829 in k1826 in k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1840 in k1829 in k1826 in k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 488  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1836 in k1829 in k1826 in k1820 in k1817 in a1810 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 487  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* f_1910 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1910,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 477  output */
t4=((C_word*)t0)[2];
f_1689(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1890 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1890,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 471  ##sys#string-append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1893 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 473  output */
t5=((C_word*)t0)[2];
f_1689(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1902 in k1893 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[67]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1782 in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[64]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[65]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[66]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[66]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 500  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1689,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1699,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1699(t7,t1,t3,C_fix(0));}

/* loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1699(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1699,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 445  ##net#send */
t6=*((C_word*)lf[10]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t5,((C_word*)t0)[4],((C_word*)t0)[2],t3,t4,C_fix(0));}

/* k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 449  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[24]+1),t6);}
else{
t5=t4;
f_1721(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 460  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,((C_word*)t0)[5]))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],t1);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],t1);
/* tcp.scm: 466  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1699(t5,((C_word*)t0)[6],t3,t4);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1751 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1762 in k1751 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 463  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k1758 in k1751 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 461  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1719 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 452  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1722 in k1719 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 453  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1725 in k1722 in k1719 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 455  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[29],lf[62],((C_word*)t0)[2]);}
else{
t3=t2;
f_1730(2,t3,C_SCHEME_UNDEFINED);}}

/* k1728 in k1725 in k1722 in k1719 in k1704 in loop in output in k1686 in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 458  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1699(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1615,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1621(t5,t1);}

/* loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1621,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 348  ##net#recv */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],C_fix(1024),C_fix(0));}

/* k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[4]);
/* tcp.scm: 352  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[24]+1),t6);}
else{
t5=t4;
f_1640(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 363  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t4=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1670 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1683,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1681 in k1670 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 366  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[61],t1);}

/* k1677 in k1670 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 364  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[2]);}

/* k1638 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 355  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[24]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1641 in k1638 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 356  yield */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1644 in k1641 in k1638 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[24]+1),C_fix(13)))){
/* tcp.scm: 358  ##sys#signal-hook */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[29],lf[58],((C_word*)t0)[2]);}
else{
t3=t2;
f_1649(2,t3,C_SCHEME_UNDEFINED);}}

/* k1647 in k1644 in k1641 in k1638 in k1623 in loop in read-input in k1612 in k1609 in k1606 in k1603 in k1597 in k1594 in ##net#io-ports in k1588 in k1584 in k1580 in k1576 in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 361  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1621(t2,((C_word*)t0)[2]);}

/* check in k1553 in k1128 in k930 in k927 in k924 */
static void C_fcall f_1561(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1563,a[2]=t2,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));}

/* f_1563 in check in k1553 in k1128 in k930 in k927 in k924 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1563,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k1128 in k930 in k927 in k924 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1520,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[45]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1551,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 303  ##net#close */
t6=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1549 in tcp-close in k1128 in k930 in k927 in k924 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 304  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1534 in k1549 in tcp-close in k1128 in k930 in k927 in k924 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1545 in k1534 in k1549 in tcp-close in k1128 in k930 in k927 in k924 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k1541 in k1534 in k1549 in tcp-close in k1128 in k930 in k927 in k924 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[48],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k1128 in k930 in k927 in k924 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1511,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[45]):C_SCHEME_FALSE));}

/* tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1413r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1413r(t0,t1,t2,t3);}}

static void C_ccall f_1413r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1415,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1458,a[2]=t4,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=t5,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w324360 */
t7=t6;
f_1463(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host325356 */
t9=t5;
f_1458(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body322331 */
t11=t4;
f_1415(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w324 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_fcall f_1463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1463,NULL,2,t0,t1);}
/* def-host325356 */
t2=((C_word*)t0)[2];
f_1458(t2,t1,C_fix(10));}

/* def-host325 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_fcall f_1458(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1458,NULL,3,t0,t1,t2);}
/* body322331 */
t3=((C_word*)t0)[2];
f_1415(t3,t1,t2,C_SCHEME_FALSE);}

/* body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_fcall f_1415(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1415,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1421,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1427,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 290  ##net#listen */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,((C_word*)t0)[3]);}

/* k1432 in a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 292  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1437(2,t4,C_SCHEME_UNDEFINED);}}

/* k1444 in k1432 in a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1455 in k1444 in k1432 in a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1451 in k1444 in k1432 in a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1435 in k1432 in a1426 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[45],((C_word*)t0)[2]));}

/* a1420 in body322 in tcp-listen in k1128 in k930 in k927 in k924 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
/* tcp.scm: 288  ##net#bind-socket */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_fix((C_word)SOCK_STREAM),((C_word*)t0)[2]);}

/* ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1303,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1310,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 261  ##sys#signal-hook */
t9=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[43],lf[36],lf[44],t2);}
else{
t9=t6;
f_1310(2,t9,C_SCHEME_UNDEFINED);}}

/* k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 262  ##net#socket */
t3=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix((C_word)AF_INET),((C_word*)t0)[2],C_fix(0));}

/* k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 264  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1316(2,t4,C_SCHEME_UNDEFINED);}}

/* k1394 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 265  ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_1385 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1385,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub289(C_SCHEME_UNDEFINED,t3));}

/* k1382 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1384,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 271  ##sys#update-errno */
t4=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_1319(2,t3,C_SCHEME_UNDEFINED);}}

/* k1367 in k1382 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1380,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1378 in k1367 in k1382 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[40],t1);}

/* k1374 in k1367 in k1382 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[36],t1,((C_word*)t0)[2]);}

/* k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 273  make-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 275  ##net#gethostaddr */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* tcp.scm: 277  ##net#fresh-addr */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k1355 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1325(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 276  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],lf[38],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 278  ##net#bind */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 280  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1331(2,t4,C_SCHEME_UNDEFINED);}}

/* k1338 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1349 in k1338 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[37],t1);}

/* k1345 in k1338 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[29],lf[36],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1329 in k1326 in k1323 in k1320 in k1317 in k1314 in k1311 in k1308 in ##net#bind-socket in k1128 in k930 in k927 in k924 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 282  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#fresh-addr in k1128 in k930 in k927 in k924 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1289,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub254(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1217,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1226,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1226(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1226,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 232  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1249,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* tcp.scm: 236  substring */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 245  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 237  substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1256,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 238  ##net#getservbyname */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k1254 in k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1259,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 240  ##sys#update-errno */
t5=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1259(2,t4,C_SCHEME_UNDEFINED);}}

/* k1263 in k1254 in k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1274 in k1263 in k1254 in k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 242  ##sys#string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[32],t1);}

/* k1270 in k1263 in k1254 in k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[28]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[29],lf[30],t1,((C_word*)t0)[2]);}

/* k1257 in k1254 in k1251 in k1247 in loop in ##net#parse-host in k1128 in k930 in k927 in k924 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 235  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k1128 in k930 in k927 in k924 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1202,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 220  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a1201 in yield in k1128 in k930 in k927 in k924 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1202,3,t0,t1,t2);}
t3=*((C_word*)lf[24]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1211,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 224  ##sys#schedule */
t6=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1210 in a1201 in yield in k1128 in k930 in k927 in k924 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1211,2,t0,t1);}
/* tcp.scm: 223  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k1128 in k930 in k927 in k924 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1171,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1180,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
/* ##sys#make-c-string */
t8=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=t6;
f_1180(2,t7,C_SCHEME_FALSE);}}

/* k1178 in ##net#gethostaddr in k1128 in k930 in k927 in k924 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub204(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select-write in k1128 in k930 in k927 in k924 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1164,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub196(C_SCHEME_UNDEFINED,t3));}

/* ##net#select in k1128 in k930 in k927 in k924 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1157,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub190(C_SCHEME_UNDEFINED,t3));}

/* ##net#getservbyname in k1128 in k930 in k927 in k924 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1132,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1137,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t6=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t5=t4;
f_1137(2,t5,C_SCHEME_FALSE);}}

/* k1135 in ##net#getservbyname in k1128 in k930 in k927 in k924 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1137,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1141,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t4=t3;
f_1141(2,t4,C_SCHEME_FALSE);}}

/* k1139 in k1135 in ##net#getservbyname in k1128 in k930 in k927 in k924 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub177(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1));}

/* ##net#startup in k930 in k927 in k924 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub168(C_SCHEME_UNDEFINED));}

/* ##net#getpeername in k930 in k927 in k924 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1115,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub161(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* ##net#getpeerport in k930 in k927 in k924 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1108,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub155(C_SCHEME_UNDEFINED,t3));}

/* ##net#getsockport in k930 in k927 in k924 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1101,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub149(C_SCHEME_UNDEFINED,t3));}

/* ##net#getsockname in k930 in k927 in k924 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1090,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub141(t3,t4);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,C_fix(0));}

/* ##net#make-nonblocking in k930 in k927 in k924 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1083,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub135(C_SCHEME_UNDEFINED,t3));}

/* ##net#send in k930 in k927 in k924 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1057,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_foreign_fixnum_argumentp(t2);
t8=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t4);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub122(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* ##net#connect in k930 in k927 in k924 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1039,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub107(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#shutdown in k930 in k927 in k924 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1028,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub98(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#recv in k930 in k927 in k924 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1006,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_foreign_fixnum_argumentp(t2);
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t4);
t9=(C_word)C_i_foreign_fixnum_argumentp(t5);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)stub85(C_SCHEME_UNDEFINED,t6,t7,t8,t9));}

/* ##net#close in k930 in k927 in k924 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_999,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub76(C_SCHEME_UNDEFINED,t3));}

/* ##net#accept in k930 in k927 in k924 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_978,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t7=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub62(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#listen in k930 in k927 in k924 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_967,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub53(C_SCHEME_UNDEFINED,t4,t5));}

/* ##net#bind in k930 in k927 in k924 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_949,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub41(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* ##net#socket in k930 in k927 in k924 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_934,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub31(C_SCHEME_UNDEFINED,t5,t6,t7));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[257] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_926tcp.scm",(void*)f_926},
{"f_929tcp.scm",(void*)f_929},
{"f_932tcp.scm",(void*)f_932},
{"f_2776tcp.scm",(void*)f_2776},
{"f_1130tcp.scm",(void*)f_1130},
{"f_1555tcp.scm",(void*)f_1555},
{"f_2773tcp.scm",(void*)f_2773},
{"f_1578tcp.scm",(void*)f_1578},
{"f_2769tcp.scm",(void*)f_2769},
{"f_1582tcp.scm",(void*)f_1582},
{"f_2765tcp.scm",(void*)f_2765},
{"f_1586tcp.scm",(void*)f_1586},
{"f_2761tcp.scm",(void*)f_2761},
{"f_1590tcp.scm",(void*)f_1590},
{"f_2750tcp.scm",(void*)f_2750},
{"f_2730tcp.scm",(void*)f_2730},
{"f_2734tcp.scm",(void*)f_2734},
{"f_2741tcp.scm",(void*)f_2741},
{"f_2701tcp.scm",(void*)f_2701},
{"f_2711tcp.scm",(void*)f_2711},
{"f_2728tcp.scm",(void*)f_2728},
{"f_2724tcp.scm",(void*)f_2724},
{"f_2714tcp.scm",(void*)f_2714},
{"f_2653tcp.scm",(void*)f_2653},
{"f_2657tcp.scm",(void*)f_2657},
{"f_2660tcp.scm",(void*)f_2660},
{"f_2667tcp.scm",(void*)f_2667},
{"f_2699tcp.scm",(void*)f_2699},
{"f_2695tcp.scm",(void*)f_2695},
{"f_2670tcp.scm",(void*)f_2670},
{"f_2674tcp.scm",(void*)f_2674},
{"f_2688tcp.scm",(void*)f_2688},
{"f_2684tcp.scm",(void*)f_2684},
{"f_2677tcp.scm",(void*)f_2677},
{"f_2605tcp.scm",(void*)f_2605},
{"f_2609tcp.scm",(void*)f_2609},
{"f_2612tcp.scm",(void*)f_2612},
{"f_2619tcp.scm",(void*)f_2619},
{"f_2651tcp.scm",(void*)f_2651},
{"f_2647tcp.scm",(void*)f_2647},
{"f_2622tcp.scm",(void*)f_2622},
{"f_2626tcp.scm",(void*)f_2626},
{"f_2640tcp.scm",(void*)f_2640},
{"f_2636tcp.scm",(void*)f_2636},
{"f_2629tcp.scm",(void*)f_2629},
{"f_2587tcp.scm",(void*)f_2587},
{"f_2591tcp.scm",(void*)f_2591},
{"f_2340tcp.scm",(void*)f_2340},
{"f_2344tcp.scm",(void*)f_2344},
{"f_2347tcp.scm",(void*)f_2347},
{"f_2563tcp.scm",(void*)f_2563},
{"f_2557tcp.scm",(void*)f_2557},
{"f_2549tcp.scm",(void*)f_2549},
{"f_2353tcp.scm",(void*)f_2353},
{"f_2359tcp.scm",(void*)f_2359},
{"f_2362tcp.scm",(void*)f_2362},
{"f_2535tcp.scm",(void*)f_2535},
{"f_2546tcp.scm",(void*)f_2546},
{"f_2542tcp.scm",(void*)f_2542},
{"f_2385tcp.scm",(void*)f_2385},
{"f_2526tcp.scm",(void*)f_2526},
{"f_2388tcp.scm",(void*)f_2388},
{"f_2509tcp.scm",(void*)f_2509},
{"f_2512tcp.scm",(void*)f_2512},
{"f_2523tcp.scm",(void*)f_2523},
{"f_2519tcp.scm",(void*)f_2519},
{"f_2391tcp.scm",(void*)f_2391},
{"f_2506tcp.scm",(void*)f_2506},
{"f_2448tcp.scm",(void*)f_2448},
{"f_2452tcp.scm",(void*)f_2452},
{"f_2455tcp.scm",(void*)f_2455},
{"f_2464tcp.scm",(void*)f_2464},
{"f_2467tcp.scm",(void*)f_2467},
{"f_2470tcp.scm",(void*)f_2470},
{"f_2473tcp.scm",(void*)f_2473},
{"f_2394tcp.scm",(void*)f_2394},
{"f_2397tcp.scm",(void*)f_2397},
{"f_2434tcp.scm",(void*)f_2434},
{"f_2430tcp.scm",(void*)f_2430},
{"f_2417tcp.scm",(void*)f_2417},
{"f_2413tcp.scm",(void*)f_2413},
{"f_2400tcp.scm",(void*)f_2400},
{"f_2364tcp.scm",(void*)f_2364},
{"f_2368tcp.scm",(void*)f_2368},
{"f_2371tcp.scm",(void*)f_2371},
{"f_2382tcp.scm",(void*)f_2382},
{"f_2378tcp.scm",(void*)f_2378},
{"f_2329tcp.scm",(void*)f_2329},
{"f_2322tcp.scm",(void*)f_2322},
{"f_2286tcp.scm",(void*)f_2286},
{"f_2293tcp.scm",(void*)f_2293},
{"f_2305tcp.scm",(void*)f_2305},
{"f_2316tcp.scm",(void*)f_2316},
{"f_2312tcp.scm",(void*)f_2312},
{"f_2296tcp.scm",(void*)f_2296},
{"f_2200tcp.scm",(void*)f_2200},
{"f_2210tcp.scm",(void*)f_2210},
{"f_2215tcp.scm",(void*)f_2215},
{"f_2284tcp.scm",(void*)f_2284},
{"f_2251tcp.scm",(void*)f_2251},
{"f_2254tcp.scm",(void*)f_2254},
{"f_2257tcp.scm",(void*)f_2257},
{"f_2260tcp.scm",(void*)f_2260},
{"f_2225tcp.scm",(void*)f_2225},
{"f_2237tcp.scm",(void*)f_2237},
{"f_2248tcp.scm",(void*)f_2248},
{"f_2244tcp.scm",(void*)f_2244},
{"f_2228tcp.scm",(void*)f_2228},
{"f_1592tcp.scm",(void*)f_1592},
{"f_2184tcp.scm",(void*)f_2184},
{"f_2187tcp.scm",(void*)f_2187},
{"f_2198tcp.scm",(void*)f_2198},
{"f_2194tcp.scm",(void*)f_2194},
{"f_1596tcp.scm",(void*)f_1596},
{"f_1599tcp.scm",(void*)f_1599},
{"f_1605tcp.scm",(void*)f_1605},
{"f_1608tcp.scm",(void*)f_1608},
{"f_1611tcp.scm",(void*)f_1611},
{"f_1614tcp.scm",(void*)f_1614},
{"f_2091tcp.scm",(void*)f_2091},
{"f_2097tcp.scm",(void*)f_2097},
{"f_2166tcp.scm",(void*)f_2166},
{"f_2109tcp.scm",(void*)f_2109},
{"f_2113tcp.scm",(void*)f_2113},
{"f_2123tcp.scm",(void*)f_2123},
{"f_2139tcp.scm",(void*)f_2139},
{"f_2026tcp.scm",(void*)f_2026},
{"f_2032tcp.scm",(void*)f_2032},
{"f_2080tcp.scm",(void*)f_2080},
{"f_1983tcp.scm",(void*)f_1983},
{"f_1991tcp.scm",(void*)f_1991},
{"f_2018tcp.scm",(void*)f_2018},
{"f_1997tcp.scm",(void*)f_1997},
{"f_2000tcp.scm",(void*)f_2000},
{"f_2011tcp.scm",(void*)f_2011},
{"f_2007tcp.scm",(void*)f_2007},
{"f_1948tcp.scm",(void*)f_1948},
{"f_1958tcp.scm",(void*)f_1958},
{"f_1970tcp.scm",(void*)f_1970},
{"f_1981tcp.scm",(void*)f_1981},
{"f_1977tcp.scm",(void*)f_1977},
{"f_1961tcp.scm",(void*)f_1961},
{"f_1926tcp.scm",(void*)f_1926},
{"f_1930tcp.scm",(void*)f_1930},
{"f_1688tcp.scm",(void*)f_1688},
{"f_1874tcp.scm",(void*)f_1874},
{"f_1884tcp.scm",(void*)f_1884},
{"f_1811tcp.scm",(void*)f_1811},
{"f_1858tcp.scm",(void*)f_1858},
{"f_1861tcp.scm",(void*)f_1861},
{"f_1819tcp.scm",(void*)f_1819},
{"f_1822tcp.scm",(void*)f_1822},
{"f_1849tcp.scm",(void*)f_1849},
{"f_1828tcp.scm",(void*)f_1828},
{"f_1831tcp.scm",(void*)f_1831},
{"f_1842tcp.scm",(void*)f_1842},
{"f_1838tcp.scm",(void*)f_1838},
{"f_1910tcp.scm",(void*)f_1910},
{"f_1890tcp.scm",(void*)f_1890},
{"f_1895tcp.scm",(void*)f_1895},
{"f_1904tcp.scm",(void*)f_1904},
{"f_1784tcp.scm",(void*)f_1784},
{"f_1689tcp.scm",(void*)f_1689},
{"f_1699tcp.scm",(void*)f_1699},
{"f_1706tcp.scm",(void*)f_1706},
{"f_1753tcp.scm",(void*)f_1753},
{"f_1764tcp.scm",(void*)f_1764},
{"f_1760tcp.scm",(void*)f_1760},
{"f_1721tcp.scm",(void*)f_1721},
{"f_1724tcp.scm",(void*)f_1724},
{"f_1727tcp.scm",(void*)f_1727},
{"f_1730tcp.scm",(void*)f_1730},
{"f_1615tcp.scm",(void*)f_1615},
{"f_1621tcp.scm",(void*)f_1621},
{"f_1625tcp.scm",(void*)f_1625},
{"f_1672tcp.scm",(void*)f_1672},
{"f_1683tcp.scm",(void*)f_1683},
{"f_1679tcp.scm",(void*)f_1679},
{"f_1640tcp.scm",(void*)f_1640},
{"f_1643tcp.scm",(void*)f_1643},
{"f_1646tcp.scm",(void*)f_1646},
{"f_1649tcp.scm",(void*)f_1649},
{"f_1561tcp.scm",(void*)f_1561},
{"f_1563tcp.scm",(void*)f_1563},
{"f_1520tcp.scm",(void*)f_1520},
{"f_1551tcp.scm",(void*)f_1551},
{"f_1536tcp.scm",(void*)f_1536},
{"f_1547tcp.scm",(void*)f_1547},
{"f_1543tcp.scm",(void*)f_1543},
{"f_1511tcp.scm",(void*)f_1511},
{"f_1413tcp.scm",(void*)f_1413},
{"f_1463tcp.scm",(void*)f_1463},
{"f_1458tcp.scm",(void*)f_1458},
{"f_1415tcp.scm",(void*)f_1415},
{"f_1427tcp.scm",(void*)f_1427},
{"f_1434tcp.scm",(void*)f_1434},
{"f_1446tcp.scm",(void*)f_1446},
{"f_1457tcp.scm",(void*)f_1457},
{"f_1453tcp.scm",(void*)f_1453},
{"f_1437tcp.scm",(void*)f_1437},
{"f_1421tcp.scm",(void*)f_1421},
{"f_1303tcp.scm",(void*)f_1303},
{"f_1310tcp.scm",(void*)f_1310},
{"f_1313tcp.scm",(void*)f_1313},
{"f_1396tcp.scm",(void*)f_1396},
{"f_1316tcp.scm",(void*)f_1316},
{"f_1385tcp.scm",(void*)f_1385},
{"f_1384tcp.scm",(void*)f_1384},
{"f_1369tcp.scm",(void*)f_1369},
{"f_1380tcp.scm",(void*)f_1380},
{"f_1376tcp.scm",(void*)f_1376},
{"f_1319tcp.scm",(void*)f_1319},
{"f_1322tcp.scm",(void*)f_1322},
{"f_1357tcp.scm",(void*)f_1357},
{"f_1325tcp.scm",(void*)f_1325},
{"f_1328tcp.scm",(void*)f_1328},
{"f_1340tcp.scm",(void*)f_1340},
{"f_1351tcp.scm",(void*)f_1351},
{"f_1347tcp.scm",(void*)f_1347},
{"f_1331tcp.scm",(void*)f_1331},
{"f_1289tcp.scm",(void*)f_1289},
{"f_1217tcp.scm",(void*)f_1217},
{"f_1226tcp.scm",(void*)f_1226},
{"f_1249tcp.scm",(void*)f_1249},
{"f_1253tcp.scm",(void*)f_1253},
{"f_1256tcp.scm",(void*)f_1256},
{"f_1265tcp.scm",(void*)f_1265},
{"f_1276tcp.scm",(void*)f_1276},
{"f_1272tcp.scm",(void*)f_1272},
{"f_1259tcp.scm",(void*)f_1259},
{"f_1196tcp.scm",(void*)f_1196},
{"f_1202tcp.scm",(void*)f_1202},
{"f_1211tcp.scm",(void*)f_1211},
{"f_1171tcp.scm",(void*)f_1171},
{"f_1180tcp.scm",(void*)f_1180},
{"f_1164tcp.scm",(void*)f_1164},
{"f_1157tcp.scm",(void*)f_1157},
{"f_1132tcp.scm",(void*)f_1132},
{"f_1137tcp.scm",(void*)f_1137},
{"f_1141tcp.scm",(void*)f_1141},
{"f_1126tcp.scm",(void*)f_1126},
{"f_1115tcp.scm",(void*)f_1115},
{"f_1108tcp.scm",(void*)f_1108},
{"f_1101tcp.scm",(void*)f_1101},
{"f_1090tcp.scm",(void*)f_1090},
{"f_1083tcp.scm",(void*)f_1083},
{"f_1057tcp.scm",(void*)f_1057},
{"f_1039tcp.scm",(void*)f_1039},
{"f_1028tcp.scm",(void*)f_1028},
{"f_1006tcp.scm",(void*)f_1006},
{"f_999tcp.scm",(void*)f_999},
{"f_978tcp.scm",(void*)f_978},
{"f_967tcp.scm",(void*)f_967},
{"f_949tcp.scm",(void*)f_949},
{"f_934tcp.scm",(void*)f_934},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
