/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-11 20:07
   Version 3.0.6 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 9483	compiled 2008-03-11 on tablet (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[97];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,111,99,107,101,116,32,97,49,54,32,97,48,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,13),40,35,35,110,101,116,35,99,108,111,115,101,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,104,117,116,100,111,119,110,32,97,53,50,53,55,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,24),40,35,35,110,101,116,35,109,97,107,101,45,110,111,110,98,108,111,99,107,105,110,103,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,35,35,110,101,116,35,103,101,116,115,111,99,107,112,111,114,116,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,14),40,35,35,110,101,116,35,115,101,108,101,99,116,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,49,50,54,49,51,49,32,97,49,50,53,49,51,50,32,97,49,50,52,49,51,51,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,97,55,52,56,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,97,55,51,57,32,114,101,116,117,114,110,49,51,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,35),40,35,35,110,101,116,35,112,97,114,115,101,45,104,111,115,116,32,104,111,115,116,49,52,48,32,112,114,111,116,111,49,52,49,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,102,95,57,50,51,32,97,49,54,54,49,54,57,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,97,57,53,56,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,97,57,54,52,32,115,49,57,50,49,57,52,32,97,100,100,114,49,57,51,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,56,52,32,119,49,57,48,32,104,111,115,116,49,57,49,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,49,56,55,32,37,119,49,56,50,50,48,51,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,49,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,49,56,48,32,46,32,109,111,114,101,49,56,49,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,50,49,48,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,50,49,49,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,102,95,49,49,49,51,32,120,50,49,56,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,50,49,55,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,50,57,53,32,111,102,102,115,101,116,50,57,54,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,50,57,51,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,102,95,49,52,52,48,32,115,51,48,54,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,13),40,102,95,49,52,54,48,32,115,51,48,57,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,48,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,49,52,50,52,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,52,57,55,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,50,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,50,54,56,32,109,50,54,57,32,115,116,97,114,116,50,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,34),40,97,49,53,55,53,32,112,50,54,51,32,110,50,54,52,32,100,101,115,116,50,54,53,32,115,116,97,114,116,50,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,23),40,97,49,54,53,56,32,112,111,115,50,50,56,49,32,110,101,120,116,50,56,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,50,56,48,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,21),40,97,49,54,52,48,32,112,50,55,55,32,108,105,109,105,116,50,55,56,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,50,50,57,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,51,50,51,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,51,51,54,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,50,49,48,54,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,29),40,97,50,49,49,50,32,104,111,115,116,51,53,54,51,53,56,32,112,111,114,116,51,53,55,51,53,57,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,51,53,48,32,46,32,109,111,114,101,51,53,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,51,56,55,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,51,56,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,51,57,52,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,52,48,48,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,52,48,53,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,52,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1886 */
static C_word C_fcall stub346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k1875 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub342(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from k926 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub167(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub167(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k834 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k720 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from k705 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub121(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k698 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub104(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub104(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from k660 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub100(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k649 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k642 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub92(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k635 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k624 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub83(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub83(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k614 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k588 */
static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k573 */
static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k559 */
static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k540 */
static C_word C_fcall stub37(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub37(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k527 */
static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k512 */
static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k498 */
static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k483 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_ccall f_668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_fcall f_1998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_fcall f_1914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_fcall f_1765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_fcall f_1142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_fcall f_1158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1647)
static void C_fcall f_1647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1582)
static void C_fcall f_1582(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_fcall f_1408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_fcall f_1378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_fcall f_1239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_fcall f_1165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_fcall f_1171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_fcall f_1111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_fcall f_996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_953)
static void C_fcall f_953(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_ccall f_860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static void C_ccall f_869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_fcall f_755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_764)
static void C_fcall f_764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_fcall f_734(C_word t0) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_fcall f_709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static C_word C_fcall f_695(C_word t0);
C_noret_decl(f_639)
static C_word C_fcall f_639(C_word t0);
C_noret_decl(f_621)
static C_word C_fcall f_621(C_word t0);
C_noret_decl(f_566)
static C_word C_fcall f_566(C_word t0,C_word t1);
C_noret_decl(f_537)
static C_word C_fcall f_537(C_word t0);
C_noret_decl(f_472)
static C_word C_fcall f_472(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_1998)
static void C_fcall trf_1998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1998(t0,t1);}

C_noret_decl(trf_1914)
static void C_fcall trf_1914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1914(t0,t1);}

C_noret_decl(trf_1765)
static void C_fcall trf_1765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1765(t0,t1);}

C_noret_decl(trf_1142)
static void C_fcall trf_1142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1142(t0,t1,t2);}

C_noret_decl(trf_1158)
static void C_fcall trf_1158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1158(t0,t1);}

C_noret_decl(trf_1647)
static void C_fcall trf_1647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1647(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1647(t0,t1,t2);}

C_noret_decl(trf_1582)
static void C_fcall trf_1582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1582(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1582(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1547(t0,t1);}

C_noret_decl(trf_1408)
static void C_fcall trf_1408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1408(t0,t1);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1369(t0,t1);}

C_noret_decl(trf_1378)
static void C_fcall trf_1378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1378(t0,t1);}

C_noret_decl(trf_1239)
static void C_fcall trf_1239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1239(t0,t1,t2);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1249(t0,t1,t2,t3);}

C_noret_decl(trf_1165)
static void C_fcall trf_1165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1165(t0,t1);}

C_noret_decl(trf_1171)
static void C_fcall trf_1171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1171(t0,t1);}

C_noret_decl(trf_1111)
static void C_fcall trf_1111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1111(t0,t1);}

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1001(t0,t1);}

C_noret_decl(trf_996)
static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_996(t0,t1,t2);}

C_noret_decl(trf_953)
static void C_fcall trf_953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_953(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_953(t0,t1,t2,t3);}

C_noret_decl(trf_755)
static void C_fcall trf_755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_755(t0,t1,t2,t3);}

C_noret_decl(trf_764)
static void C_fcall trf_764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_764(t0,t1,t2);}

C_noret_decl(trf_734)
static void C_fcall trf_734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_734(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_734(t0);}

C_noret_decl(trf_709)
static void C_fcall trf_709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_709(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,97);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[9]=C_h_intern(&lf[9],17,"\003sysmake-c-string");
lf[11]=C_h_intern(&lf[11],18,"\003syscurrent-thread");
lf[12]=C_h_intern(&lf[12],12,"\003sysschedule");
lf[13]=C_h_intern(&lf[13],9,"substring");
lf[15]=C_h_intern(&lf[15],15,"\003syssignal-hook");
lf[16]=C_h_intern(&lf[16],14,"\000network-error");
lf[17]=C_h_intern(&lf[17],11,"tcp-connect");
lf[18]=C_h_intern(&lf[18],17,"\003sysstring-append");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[20]=C_h_intern(&lf[20],17,"\003syspeek-c-string");
lf[21]=C_h_intern(&lf[21],16,"\003sysupdate-errno");
lf[22]=C_h_intern(&lf[22],10,"tcp-listen");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[25]=C_h_intern(&lf[25],11,"make-string");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[29]=C_h_intern(&lf[29],13,"\000domain-error");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[31]=C_h_intern(&lf[31],12,"tcp-listener");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[33]=C_h_intern(&lf[33],13,"tcp-listener\077");
lf[34]=C_h_intern(&lf[34],9,"tcp-close");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[36]=C_h_intern(&lf[36],15,"tcp-buffer-size");
lf[37]=C_h_intern(&lf[37],19,"\003sysundefined-value");
lf[38]=C_h_intern(&lf[38],16,"tcp-read-timeout");
lf[39]=C_h_intern(&lf[39],17,"tcp-write-timeout");
lf[40]=C_h_intern(&lf[40],19,"tcp-connect-timeout");
lf[41]=C_h_intern(&lf[41],18,"tcp-accept-timeout");
lf[42]=C_h_intern(&lf[42],15,"make-input-port");
lf[43]=C_h_intern(&lf[43],16,"make-output-port");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[46]=C_h_intern(&lf[46],25,"\003systhread-block-for-i/o!");
lf[47]=C_h_intern(&lf[47],29,"\003systhread-block-for-timeout!");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[53]=C_h_intern(&lf[53],6,"socket");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[61]=C_h_intern(&lf[61],15,"\003sysmake-string");
lf[62]=C_h_intern(&lf[62],20,"\003sysscan-buffer-line");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[65]=C_h_intern(&lf[65],10,"tcp-accept");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[68]=C_h_intern(&lf[68],17,"tcp-accept-ready\077");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[74]=C_h_intern(&lf[74],4,"\000all");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[80]=C_h_intern(&lf[80],20,"\003systcp-port->fileno");
lf[81]=C_h_intern(&lf[81],13,"\003sysport-data");
lf[82]=C_h_intern(&lf[82],13,"tcp-addresses");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[85]=C_h_intern(&lf[85],16,"tcp-port-numbers");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[88]=C_h_intern(&lf[88],17,"tcp-listener-port");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[90]=C_h_intern(&lf[90],16,"tcp-abandon-port");
lf[91]=C_h_intern(&lf[91],14,"\003syscheck-port");
lf[92]=C_h_intern(&lf[92],19,"tcp-listener-fileno");
lf[93]=C_h_intern(&lf[93],14,"make-parameter");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[95]=C_h_intern(&lf[95],17,"register-feature!");
lf[96]=C_h_intern(&lf[96],3,"tcp");
C_register_lf2(lf,97,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_464,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k462 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k465 in k462 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 89   register-feature! */
t3=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[96]);}

/* k468 in k465 in k462 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_470,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_472,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_566,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_621,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub104(C_SCHEME_UNDEFINED))){
t8=t7;
f_668(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 190  ##sys#signal-hook */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[16],lf[94]);}}

/* k666 in k468 in k465 in k462 */
static void C_ccall f_668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_668,2,t0,t1);}
t2=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[13]+1);
t6=C_mutate(&lf[14],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_755,a[2]=t5,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  make-parameter */
t11=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=*((C_word*)lf[37]+1);
t4=C_mutate((C_word*)lf[38]+1,t3);
t5=*((C_word*)lf[37]+1);
t6=C_mutate((C_word*)lf[39]+1,t5);
t7=*((C_word*)lf[37]+1);
t8=C_mutate((C_word*)lf[40]+1,t7);
t9=*((C_word*)lf[37]+1);
t10=C_mutate((C_word*)lf[41]+1,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1128,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 335  check */
f_1111(t13,lf[38]);}

/* k2307 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 335  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 336  check */
f_1111(t4,lf[39]);}

/* k2303 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 336  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 337  check */
f_1111(t4,lf[40]);}

/* k2299 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 337  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 338  check */
f_1111(t4,lf[41]);}

/* k2295 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 338  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=*((C_word*)lf[42]+1);
t4=*((C_word*)lf[43]+1);
t5=*((C_word*)lf[36]+1);
t6=*((C_word*)lf[25]+1);
t7=C_mutate(&lf[44],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1142,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2137,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2286,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2270,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 643  ##sys#check-port */
t4=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[90]);}

/* k2268 in tcp-abandon-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 645  ##sys#port-data */
t3=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2275 in k2268 in tcp-abandon-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2237,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[88]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_639(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2260,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2250(2,t8,C_SCHEME_UNDEFINED);}}

/* k2262 in tcp-listener-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 638  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[89],t1);}

/* k2258 in tcp-listener-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 637  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[88],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2248 in tcp-listener-port in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2192,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 625  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=f_639(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2206(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2233 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k2229 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[85],t1,((C_word*)t0)[2]);}

/* k2204 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=(C_word)stub96(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2213,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2213(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2222 in k2204 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2218 in k2204 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[85],t1,((C_word*)t0)[2]);}

/* k2211 in k2204 in k2194 in tcp-port-numbers in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2147,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 617  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2158,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub87(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2161(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2190,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2188 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[84],t1);}

/* k2184 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[82],t1,((C_word*)t0)[2]);}

/* k2159 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub100(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2163 in k2159 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2168(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2177 in k2163 in k2159 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k2173 in k2163 in k2159 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[82],t1,((C_word*)t0)[2]);}

/* k2166 in k2163 in k2159 in k2156 in k2149 in tcp-addresses in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 618  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2137,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 614  ##sys#port-data */
t4=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2143 in ##sys#tcp-port->fileno in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1890r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1890r(t0,t1,t2,t3);}}

static void C_ccall f_1890r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1894(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1894(2,t7,(C_word)C_i_car(t3));}
else{
/* tcp.scm: 564  ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 565  tcp-connect-timeout */
t5=*((C_word*)lf[40]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1903,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_1903(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 568  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}}

/* a2112 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2113,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2106 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
/* tcp.scm: 568  ##net#parse-host */
t2=lf[14];
f_755(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[79]);}

/* k2097 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1903(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 569  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[78],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 571  make-string */
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=f_472(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 580  ##sys#update-errno */
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1935(2,t6,C_SCHEME_UNDEFINED);}}

/* k2083 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2094 in k2083 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k2090 in k2083 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 582  ##net#gethostaddr */
f_709(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2074 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1938(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 583  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[76],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_621(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_1941(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 585  ##sys#update-errno */
t5=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2060 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2071 in k2060 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[75],t1);}

/* k2067 in k2060 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=(C_word)stub61(C_SCHEME_UNDEFINED,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t10)){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[6],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_1998(t14,t2);}
else{
/* tcp.scm: 605  fail */
t11=((C_word*)t0)[2];
f_1914(t11,t2);}}
else{
t10=t2;
f_1944(2,t10,C_SCHEME_UNDEFINED);}}

/* loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1998,NULL,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub121(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
/* tcp.scm: 591  fail */
t6=((C_word*)t0)[2];
f_1914(t6,t4);}
else{
t6=t4;
f_2005(2,t6,C_SCHEME_UNDEFINED);}}

/* k2003 in loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 594  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[11]+1),t5);}
else{
t4=t3;
f_2014(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2012 in k2003 in loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 597  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[74]);}

/* k2015 in k2012 in k2003 in loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 598  yield */
f_734(t2);}

/* k2018 in k2015 in k2012 in k2003 in loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 600  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[17],lf[73],((C_word*)t0)[2]);}
else{
t3=t2;
f_2023(2,t3,C_SCHEME_UNDEFINED);}}

/* k2021 in k2018 in k2015 in k2012 in k2003 in loop in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 604  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1998(t2,((C_word*)t0)[2]);}

/* k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=(C_word)stub342(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)C_i_foreign_fixnum_argumentp(t3);
t10=(C_word)stub346(t8,t9);
/* ##sys#peek-c-string */
t11=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_fix(0));}
else{
t6=t4;
f_1950(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1982 in k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k1978 in k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1965 in k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1961 in k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1948 in k1942 in k1939 in k1936 in k1933 in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 611  ##net#io-ports */
t2=lf[44];
f_1142(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1914,NULL,2,t0,t1);}
t2=f_537(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 575  ##sys#update-errno */
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1919 in fail in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1930 in k1919 in fail in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[70],t1);}

/* k1926 in k1919 in fail in k1907 in k1901 in k1895 in k1892 in tcp-connect in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 576  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1836,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[68]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_695(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 547  ##sys#update-errno */
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1846(2,t8,C_SCHEME_UNDEFINED);}}

/* k1853 in tcp-accept-ready? in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1864 in k1853 in tcp-accept-ready? in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 549  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1860 in k1853 in tcp-accept-ready? in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 548  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[68],t1,((C_word*)t0)[2]);}

/* k1844 in tcp-accept-ready? in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1750,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1760,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 519  tcp-accept-timeout */
t6=*((C_word*)lf[41]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1765,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1765(t5,((C_word*)t0)[2]);}

/* loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1765,NULL,2,t0,t1);}
t2=f_695(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t5=(C_word)stub27(C_SCHEME_UNDEFINED,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 524  ##sys#update-errno */
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1778(2,t8,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 531  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[11]+1),t6);}
else{
t5=t4;
f_1801(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1799 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 534  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1802 in k1799 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 535  yield */
f_734(t2);}

/* k1805 in k1802 in k1799 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 537  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t3=t2;
f_1810(2,t3,C_SCHEME_UNDEFINED);}}

/* k1808 in k1805 in k1802 in k1799 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 541  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1765(t2,((C_word*)t0)[2]);}

/* k1785 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1796 in k1785 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 526  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k1792 in k1785 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 525  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[65],t1,((C_word*)t0)[2]);}

/* k1776 in loop in k1758 in tcp-accept in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 528  ##net#io-ports */
t2=lf[44];
f_1142(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1142,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_621(t2);
if(C_truep(t4)){
t5=t3;
f_1146(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 347  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1735 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1746 in k1735 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k1742 in k1735 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[16],t1);}

/* k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 349  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1149,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 355  tbs */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1158(t4,(C_truep(t3)?lf[63]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1158(t3,C_SCHEME_FALSE);}}

/* k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1158,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 357  tcp-read-timeout */
t5=*((C_word*)lf[38]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 358  tcp-write-timeout */
t3=*((C_word*)lf[39]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word)li24),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1476,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1576,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1641,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li38),tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 386  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t9))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1641,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1647,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1647(t7,t1,C_SCHEME_FALSE);}

/* loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1647,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li36),tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 433  ##sys#scan-buffer-line */
t4=*((C_word*)lf[62]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1716,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 450  read-input */
t4=((C_word*)t0)[3];
f_1165(t4,t3);}}

/* k1714 in loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 452  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1647(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1658 in loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1659,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 438  ##sys#make-string */
t6=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k1661 in a1658 in loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1673,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 442  read-input */
t6=((C_word*)t0)[3];
f_1165(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 448  ##sys#string-append */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k1671 in k1661 in a1658 in loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[60]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 445  ##sys#string-append */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_1689(2,t3,((C_word*)t0)[2]);}}}

/* k1687 in k1671 in k1661 in a1658 in loop in a1640 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 445  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1647(t2,((C_word*)t0)[2],t1);}

/* a1575 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1576,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li34),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_1582(t9,t1,t3,C_fix(0),t5);}

/* loop in a1575 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1582(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1582,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* tcp.scm: 424  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1630,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 426  read-input */
t7=((C_word*)t0)[2];
f_1165(t7,t6);}}}

/* k1628 in loop in a1575 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 429  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1582(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1532 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_566(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_537(((C_word*)t0)[3]);
t6=t4;
f_1547(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1547(t5,C_SCHEME_FALSE);}}}

/* k1545 in a1532 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 410  ##sys#update-errno */
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1548 in k1545 in a1532 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1559 in k1548 in k1545 in a1532 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 413  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k1555 in k1548 in k1545 in a1532 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 411  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* a1497 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_695(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 399  ##sys#update-errno */
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1511(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1518 in a1497 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1529 in k1518 in a1497 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 402  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k1525 in k1518 in a1497 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 400  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1509 in a1497 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1475 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 389  read-input */
t3=((C_word*)t0)[2];
f_1165(t3,t2);}
else{
t3=t2;
f_1480(2,t3,C_SCHEME_UNDEFINED);}}

/* k1478 in a1475 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1440,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1361,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word)li29),tmp=(C_word)a,a+=9,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1424,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp):C_SCHEME_FALSE);
/* tcp.scm: 482  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}

/* f_1424 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1434,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 506  output */
t4=((C_word*)t0)[2];
f_1239(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1432 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[57]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1408,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1408(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1408(t5,C_SCHEME_FALSE);}}}

/* k1406 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1408,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 496  output */
t3=((C_word*)t0)[2];
f_1239(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1369(t2,C_SCHEME_UNDEFINED);}}

/* k1409 in k1406 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[56]);
t3=((C_word*)t0)[2];
f_1369(t3,t2);}

/* k1367 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_566(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_537(((C_word*)t0)[4]);
t5=t3;
f_1378(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1378(t4,C_SCHEME_FALSE);}}

/* k1376 in k1367 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1378,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 500  ##sys#update-errno */
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1379 in k1376 in k1367 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1390 in k1379 in k1376 in k1367 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 502  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[55],t1);}

/* k1386 in k1379 in k1376 in k1367 in a1360 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 501  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* f_1460 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1460,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 491  output */
t4=((C_word*)t0)[2];
f_1239(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1440 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 485  ##sys#string-append */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1443 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 487  output */
t5=((C_word*)t0)[2];
f_1239(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1452 in k1443 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[54]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1332 in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[51]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[52]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[53]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[53]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 514  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1239,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li25),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1249(t7,t1,t3,C_fix(0));}

/* loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1249(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1249,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_word)C_i_foreign_fixnum_argumentp(t5);
t9=(C_truep(t6)?(C_word)C_i_foreign_block_argumentp(t6):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t7);
t11=(C_word)C_i_foreign_fixnum_argumentp(t4);
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t13=(C_word)stub73(C_SCHEME_UNDEFINED,t8,t9,t10,t11,t12);
t14=(C_word)C_eqp(C_fix(-1),t13);
if(C_truep(t14)){
t15=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t17=(C_word)C_fudge(C_fix(16));
t18=(C_word)C_fixnum_plus(t17,((C_word*)t0)[2]);
/* tcp.scm: 463  ##sys#thread-block-for-timeout! */
t19=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t16,*((C_word*)lf[11]+1),t18);}
else{
t17=t16;
f_1271(2,t17,C_SCHEME_UNDEFINED);}}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 474  ##sys#update-errno */
t17=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t13,t2))){
t15=(C_word)C_fixnum_difference(t2,t13);
t16=(C_word)C_fixnum_plus(t3,t13);
/* tcp.scm: 480  loop */
t23=t1;
t24=t15;
t25=t16;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}}}

/* k1301 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1312 in k1301 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 477  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[50],t1);}

/* k1308 in k1301 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 475  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1269 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 466  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1272 in k1269 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 467  yield */
f_734(t2);}

/* k1275 in k1272 in k1269 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 469  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[49],((C_word*)t0)[2]);}
else{
t3=t2;
f_1280(2,t3,C_SCHEME_UNDEFINED);}}

/* k1278 in k1275 in k1272 in k1269 in loop in output in k1236 in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1249(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1165,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li23),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1171(t5,t1);}

/* loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1171,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1024));
t7=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t8=(C_word)stub44(C_SCHEME_UNDEFINED,t4,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t12=(C_word)C_fudge(C_fix(16));
t13=(C_word)C_fixnum_plus(t12,((C_word*)t0)[4]);
/* tcp.scm: 366  ##sys#thread-block-for-timeout! */
t14=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t11,*((C_word*)lf[11]+1),t13);}
else{
t12=t11;
f_1190(2,t12,C_SCHEME_UNDEFINED);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 377  ##sys#update-errno */
t12=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
t10=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t11=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}

/* k1220 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1231 in k1220 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 380  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1227 in k1220 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 378  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1188 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 369  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1191 in k1188 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 370  yield */
f_734(t2);}

/* k1194 in k1191 in k1188 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 372  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[45],((C_word*)t0)[2]);}
else{
t3=t2;
f_1199(2,t3,C_SCHEME_UNDEFINED);}}

/* k1197 in k1194 in k1191 in k1188 in loop in read-input in k1162 in k1159 in k1156 in k1153 in k1147 in k1144 in ##net#io-ports in k1138 in k1134 in k1130 in k1126 in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 375  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1171(t2,((C_word*)t0)[2]);}

/* check in k1091 in k666 in k468 in k465 in k462 */
static void C_fcall f_1111(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1111,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1113,a[2]=t2,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));}

/* f_1113 in check in k1091 in k666 in k468 in k465 in k462 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1113,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k666 in k468 in k465 in k462 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1058,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_537(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1074,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 318  ##sys#update-errno */
t8=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k1072 in tcp-close in k666 in k468 in k465 in k462 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1083 in k1072 in tcp-close in k666 in k468 in k465 in k462 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[35],t1);}

/* k1079 in k1072 in tcp-close in k666 in k468 in k465 in k462 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[34],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k666 in k468 in k465 in k462 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1049,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[31]):C_SCHEME_FALSE));}

/* tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_951r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_951r(t0,t1,t2,t3);}}

static void C_ccall f_951r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_953,a[2]=t2,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_996,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1001,a[2]=t5,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w186204 */
t7=t6;
f_1001(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host187202 */
t9=t5;
f_996(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body184189 */
t11=t4;
f_953(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w186 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_fcall f_1001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,2,t0,t1);}
/* def-host187202 */
t2=((C_word*)t0)[2];
f_996(t2,t1,C_fix(10));}

/* def-host187 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_fcall f_996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,3,t0,t1,t2);}
/* body184189 */
t3=((C_word*)t0)[2];
f_953(t3,t1,t2,C_SCHEME_FALSE);}

/* body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_fcall f_953(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_953,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_959,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a964 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_965,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_fixnum_argumentp(t6);
t9=(C_word)stub20(C_SCHEME_UNDEFINED,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_975,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 306  ##sys#update-errno */
t13=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=t10;
f_975(2,t12,C_SCHEME_UNDEFINED);}}

/* k982 in a964 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k993 in k982 in a964 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[32],t1);}

/* k989 in k982 in a964 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k973 in a964 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[31],((C_word*)t0)[2]));}

/* a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_848,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 275  ##sys#signal-hook */
t9=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[29],lf[22],lf[30],t2);}
else{
t9=t6;
f_848(2,t9,C_SCHEME_UNDEFINED);}}

/* k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_848,2,t0,t1);}
t2=f_472(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 278  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_854(2,t5,C_SCHEME_UNDEFINED);}}

/* k932 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 279  ##sys#error */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[28]);}

/* k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_922,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_923 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_923,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub167(C_SCHEME_UNDEFINED,t3));}

/* k920 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_922,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 285  ##sys#update-errno */
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_857(2,t3,C_SCHEME_UNDEFINED);}}

/* k905 in k920 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k916 in k905 in k920 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k912 in k905 in k920 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[22],t1,((C_word*)t0)[2]);}

/* k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 287  make-string */
t3=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 289  ##net#gethostaddr */
f_709(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t6=t2;
f_863(2,t6,(C_word)stub153(C_SCHEME_UNDEFINED,t4,t5));}}

/* k893 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_863(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 290  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],lf[24],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k861 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)stub11(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_869,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 294  ##sys#update-errno */
t11=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_869(2,t10,C_SCHEME_UNDEFINED);}}

/* k876 in k861 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k887 in k876 in k861 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k883 in k876 in k861 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k867 in k861 in k858 in k855 in k852 in k846 in a958 in body184 in tcp-listen in k666 in k468 in k465 in k462 */
static void C_ccall f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 296  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_fcall f_755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_755,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_764,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li10),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_764(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_fcall f_764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_764,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 246  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_787,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* tcp.scm: 250  substring */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 259  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_791,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 251  substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_791,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_675,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t6=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t5=t4;
f_675(2,t5,C_SCHEME_FALSE);}}

/* k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_679(2,t3,C_SCHEME_FALSE);}}

/* k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_679,2,t0,t1);}
t2=(C_word)stub108(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_797,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 254  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_797(2,t5,C_SCHEME_UNDEFINED);}}

/* k801 in k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k812 in k801 in k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 256  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[19],t1);}

/* k808 in k801 in k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 255  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],t1,((C_word*)t0)[2]);}

/* k795 in k677 in k673 in k789 in k785 in loop in ##net#parse-host in k666 in k468 in k465 in k462 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 249  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k666 in k468 in k465 in k462 */
static void C_fcall f_734(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_734,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 234  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a739 in yield in k666 in k468 in k465 in k462 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_740,3,t0,t1,t2);}
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_749,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 238  ##sys#schedule */
t6=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a748 in a739 in yield in k666 in k468 in k465 in k462 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
/* tcp.scm: 237  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k666 in k468 in k465 in k462 */
static void C_fcall f_709(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_709,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_718,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
/* ##sys#make-c-string */
t8=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=t6;
f_718(2,t7,C_SCHEME_FALSE);}}

/* k716 in ##net#gethostaddr in k666 in k468 in k465 in k462 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub127(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select in k666 in k468 in k465 in k462 */
static C_word C_fcall f_695(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub117(C_SCHEME_UNDEFINED,t2));}

/* ##net#getsockport in k468 in k465 in k462 */
static C_word C_fcall f_639(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub92(C_SCHEME_UNDEFINED,t2));}

/* ##net#make-nonblocking in k468 in k465 in k462 */
static C_word C_fcall f_621(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub83(C_SCHEME_UNDEFINED,t2));}

/* ##net#shutdown in k468 in k465 in k462 */
static C_word C_fcall f_566(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub54(C_SCHEME_UNDEFINED,t3,t4));}

/* ##net#close in k468 in k465 in k462 */
static C_word C_fcall f_537(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub37(C_SCHEME_UNDEFINED,t2));}

/* ##net#socket in k468 in k465 in k462 */
static C_word C_fcall f_472(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub3(C_SCHEME_UNDEFINED,t4,t5,t6));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_464tcp.scm",(void*)f_464},
{"f_467tcp.scm",(void*)f_467},
{"f_470tcp.scm",(void*)f_470},
{"f_668tcp.scm",(void*)f_668},
{"f_1093tcp.scm",(void*)f_1093},
{"f_2309tcp.scm",(void*)f_2309},
{"f_1128tcp.scm",(void*)f_1128},
{"f_2305tcp.scm",(void*)f_2305},
{"f_1132tcp.scm",(void*)f_1132},
{"f_2301tcp.scm",(void*)f_2301},
{"f_1136tcp.scm",(void*)f_1136},
{"f_2297tcp.scm",(void*)f_2297},
{"f_1140tcp.scm",(void*)f_1140},
{"f_2286tcp.scm",(void*)f_2286},
{"f_2266tcp.scm",(void*)f_2266},
{"f_2270tcp.scm",(void*)f_2270},
{"f_2277tcp.scm",(void*)f_2277},
{"f_2237tcp.scm",(void*)f_2237},
{"f_2264tcp.scm",(void*)f_2264},
{"f_2260tcp.scm",(void*)f_2260},
{"f_2250tcp.scm",(void*)f_2250},
{"f_2192tcp.scm",(void*)f_2192},
{"f_2196tcp.scm",(void*)f_2196},
{"f_2235tcp.scm",(void*)f_2235},
{"f_2231tcp.scm",(void*)f_2231},
{"f_2206tcp.scm",(void*)f_2206},
{"f_2224tcp.scm",(void*)f_2224},
{"f_2220tcp.scm",(void*)f_2220},
{"f_2213tcp.scm",(void*)f_2213},
{"f_2147tcp.scm",(void*)f_2147},
{"f_2151tcp.scm",(void*)f_2151},
{"f_2158tcp.scm",(void*)f_2158},
{"f_2190tcp.scm",(void*)f_2190},
{"f_2186tcp.scm",(void*)f_2186},
{"f_2161tcp.scm",(void*)f_2161},
{"f_2165tcp.scm",(void*)f_2165},
{"f_2179tcp.scm",(void*)f_2179},
{"f_2175tcp.scm",(void*)f_2175},
{"f_2168tcp.scm",(void*)f_2168},
{"f_2137tcp.scm",(void*)f_2137},
{"f_2145tcp.scm",(void*)f_2145},
{"f_1890tcp.scm",(void*)f_1890},
{"f_1894tcp.scm",(void*)f_1894},
{"f_1897tcp.scm",(void*)f_1897},
{"f_2113tcp.scm",(void*)f_2113},
{"f_2107tcp.scm",(void*)f_2107},
{"f_2099tcp.scm",(void*)f_2099},
{"f_1903tcp.scm",(void*)f_1903},
{"f_1909tcp.scm",(void*)f_1909},
{"f_2085tcp.scm",(void*)f_2085},
{"f_2096tcp.scm",(void*)f_2096},
{"f_2092tcp.scm",(void*)f_2092},
{"f_1935tcp.scm",(void*)f_1935},
{"f_2076tcp.scm",(void*)f_2076},
{"f_1938tcp.scm",(void*)f_1938},
{"f_2062tcp.scm",(void*)f_2062},
{"f_2073tcp.scm",(void*)f_2073},
{"f_2069tcp.scm",(void*)f_2069},
{"f_1941tcp.scm",(void*)f_1941},
{"f_1998tcp.scm",(void*)f_1998},
{"f_2005tcp.scm",(void*)f_2005},
{"f_2014tcp.scm",(void*)f_2014},
{"f_2017tcp.scm",(void*)f_2017},
{"f_2020tcp.scm",(void*)f_2020},
{"f_2023tcp.scm",(void*)f_2023},
{"f_1944tcp.scm",(void*)f_1944},
{"f_1984tcp.scm",(void*)f_1984},
{"f_1980tcp.scm",(void*)f_1980},
{"f_1967tcp.scm",(void*)f_1967},
{"f_1963tcp.scm",(void*)f_1963},
{"f_1950tcp.scm",(void*)f_1950},
{"f_1914tcp.scm",(void*)f_1914},
{"f_1921tcp.scm",(void*)f_1921},
{"f_1932tcp.scm",(void*)f_1932},
{"f_1928tcp.scm",(void*)f_1928},
{"f_1836tcp.scm",(void*)f_1836},
{"f_1855tcp.scm",(void*)f_1855},
{"f_1866tcp.scm",(void*)f_1866},
{"f_1862tcp.scm",(void*)f_1862},
{"f_1846tcp.scm",(void*)f_1846},
{"f_1750tcp.scm",(void*)f_1750},
{"f_1760tcp.scm",(void*)f_1760},
{"f_1765tcp.scm",(void*)f_1765},
{"f_1801tcp.scm",(void*)f_1801},
{"f_1804tcp.scm",(void*)f_1804},
{"f_1807tcp.scm",(void*)f_1807},
{"f_1810tcp.scm",(void*)f_1810},
{"f_1787tcp.scm",(void*)f_1787},
{"f_1798tcp.scm",(void*)f_1798},
{"f_1794tcp.scm",(void*)f_1794},
{"f_1778tcp.scm",(void*)f_1778},
{"f_1142tcp.scm",(void*)f_1142},
{"f_1737tcp.scm",(void*)f_1737},
{"f_1748tcp.scm",(void*)f_1748},
{"f_1744tcp.scm",(void*)f_1744},
{"f_1146tcp.scm",(void*)f_1146},
{"f_1149tcp.scm",(void*)f_1149},
{"f_1155tcp.scm",(void*)f_1155},
{"f_1158tcp.scm",(void*)f_1158},
{"f_1161tcp.scm",(void*)f_1161},
{"f_1164tcp.scm",(void*)f_1164},
{"f_1641tcp.scm",(void*)f_1641},
{"f_1647tcp.scm",(void*)f_1647},
{"f_1716tcp.scm",(void*)f_1716},
{"f_1659tcp.scm",(void*)f_1659},
{"f_1663tcp.scm",(void*)f_1663},
{"f_1673tcp.scm",(void*)f_1673},
{"f_1689tcp.scm",(void*)f_1689},
{"f_1576tcp.scm",(void*)f_1576},
{"f_1582tcp.scm",(void*)f_1582},
{"f_1630tcp.scm",(void*)f_1630},
{"f_1533tcp.scm",(void*)f_1533},
{"f_1547tcp.scm",(void*)f_1547},
{"f_1550tcp.scm",(void*)f_1550},
{"f_1561tcp.scm",(void*)f_1561},
{"f_1557tcp.scm",(void*)f_1557},
{"f_1498tcp.scm",(void*)f_1498},
{"f_1520tcp.scm",(void*)f_1520},
{"f_1531tcp.scm",(void*)f_1531},
{"f_1527tcp.scm",(void*)f_1527},
{"f_1511tcp.scm",(void*)f_1511},
{"f_1476tcp.scm",(void*)f_1476},
{"f_1480tcp.scm",(void*)f_1480},
{"f_1238tcp.scm",(void*)f_1238},
{"f_1424tcp.scm",(void*)f_1424},
{"f_1434tcp.scm",(void*)f_1434},
{"f_1361tcp.scm",(void*)f_1361},
{"f_1408tcp.scm",(void*)f_1408},
{"f_1411tcp.scm",(void*)f_1411},
{"f_1369tcp.scm",(void*)f_1369},
{"f_1378tcp.scm",(void*)f_1378},
{"f_1381tcp.scm",(void*)f_1381},
{"f_1392tcp.scm",(void*)f_1392},
{"f_1388tcp.scm",(void*)f_1388},
{"f_1460tcp.scm",(void*)f_1460},
{"f_1440tcp.scm",(void*)f_1440},
{"f_1445tcp.scm",(void*)f_1445},
{"f_1454tcp.scm",(void*)f_1454},
{"f_1334tcp.scm",(void*)f_1334},
{"f_1239tcp.scm",(void*)f_1239},
{"f_1249tcp.scm",(void*)f_1249},
{"f_1303tcp.scm",(void*)f_1303},
{"f_1314tcp.scm",(void*)f_1314},
{"f_1310tcp.scm",(void*)f_1310},
{"f_1271tcp.scm",(void*)f_1271},
{"f_1274tcp.scm",(void*)f_1274},
{"f_1277tcp.scm",(void*)f_1277},
{"f_1280tcp.scm",(void*)f_1280},
{"f_1165tcp.scm",(void*)f_1165},
{"f_1171tcp.scm",(void*)f_1171},
{"f_1222tcp.scm",(void*)f_1222},
{"f_1233tcp.scm",(void*)f_1233},
{"f_1229tcp.scm",(void*)f_1229},
{"f_1190tcp.scm",(void*)f_1190},
{"f_1193tcp.scm",(void*)f_1193},
{"f_1196tcp.scm",(void*)f_1196},
{"f_1199tcp.scm",(void*)f_1199},
{"f_1111tcp.scm",(void*)f_1111},
{"f_1113tcp.scm",(void*)f_1113},
{"f_1058tcp.scm",(void*)f_1058},
{"f_1074tcp.scm",(void*)f_1074},
{"f_1085tcp.scm",(void*)f_1085},
{"f_1081tcp.scm",(void*)f_1081},
{"f_1049tcp.scm",(void*)f_1049},
{"f_951tcp.scm",(void*)f_951},
{"f_1001tcp.scm",(void*)f_1001},
{"f_996tcp.scm",(void*)f_996},
{"f_953tcp.scm",(void*)f_953},
{"f_965tcp.scm",(void*)f_965},
{"f_984tcp.scm",(void*)f_984},
{"f_995tcp.scm",(void*)f_995},
{"f_991tcp.scm",(void*)f_991},
{"f_975tcp.scm",(void*)f_975},
{"f_959tcp.scm",(void*)f_959},
{"f_848tcp.scm",(void*)f_848},
{"f_934tcp.scm",(void*)f_934},
{"f_854tcp.scm",(void*)f_854},
{"f_923tcp.scm",(void*)f_923},
{"f_922tcp.scm",(void*)f_922},
{"f_907tcp.scm",(void*)f_907},
{"f_918tcp.scm",(void*)f_918},
{"f_914tcp.scm",(void*)f_914},
{"f_857tcp.scm",(void*)f_857},
{"f_860tcp.scm",(void*)f_860},
{"f_895tcp.scm",(void*)f_895},
{"f_863tcp.scm",(void*)f_863},
{"f_878tcp.scm",(void*)f_878},
{"f_889tcp.scm",(void*)f_889},
{"f_885tcp.scm",(void*)f_885},
{"f_869tcp.scm",(void*)f_869},
{"f_755tcp.scm",(void*)f_755},
{"f_764tcp.scm",(void*)f_764},
{"f_787tcp.scm",(void*)f_787},
{"f_791tcp.scm",(void*)f_791},
{"f_675tcp.scm",(void*)f_675},
{"f_679tcp.scm",(void*)f_679},
{"f_803tcp.scm",(void*)f_803},
{"f_814tcp.scm",(void*)f_814},
{"f_810tcp.scm",(void*)f_810},
{"f_797tcp.scm",(void*)f_797},
{"f_734tcp.scm",(void*)f_734},
{"f_740tcp.scm",(void*)f_740},
{"f_749tcp.scm",(void*)f_749},
{"f_709tcp.scm",(void*)f_709},
{"f_718tcp.scm",(void*)f_718},
{"f_695tcp.scm",(void*)f_695},
{"f_639tcp.scm",(void*)f_639},
{"f_621tcp.scm",(void*)f_621},
{"f_566tcp.scm",(void*)f_566},
{"f_537tcp.scm",(void*)f_537},
{"f_472tcp.scm",(void*)f_472},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
