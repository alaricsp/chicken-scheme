/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-02 09:51
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[97];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,111,99,107,101,116,32,97,49,54,32,97,48,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,13),40,35,35,110,101,116,35,99,108,111,115,101,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,115,104,117,116,100,111,119,110,32,97,53,50,53,55,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,24),40,35,35,110,101,116,35,109,97,107,101,45,110,111,110,98,108,111,99,107,105,110,103,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,35,35,110,101,116,35,103,101,116,115,111,99,107,112,111,114,116,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,14),40,35,35,110,101,116,35,115,101,108,101,99,116,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,49,50,54,49,51,49,32,97,49,50,53,49,51,50,32,97,49,50,52,49,51,51,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,97,55,53,50,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,97,55,52,51,32,114,101,116,117,114,110,49,51,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,35),40,35,35,110,101,116,35,112,97,114,115,101,45,104,111,115,116,32,104,111,115,116,49,52,48,32,112,114,111,116,111,49,52,49,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,102,95,57,50,55,32,97,49,54,54,49,54,57,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,97,57,54,50,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,97,57,54,56,32,115,49,57,50,49,57,52,32,97,100,100,114,49,57,51,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,56,52,32,119,49,57,48,32,104,111,115,116,49,57,49,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,49,56,55,32,37,119,49,56,50,50,48,51,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,49,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,49,56,48,32,46,32,109,111,114,101,49,56,49,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,50,49,48,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,50,49,49,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,102,95,49,49,49,55,32,120,50,49,56,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,50,49,55,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,50,57,53,32,111,102,102,115,101,116,50,57,54,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,50,57,51,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,102,95,49,52,52,52,32,115,51,48,54,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,13),40,102,95,49,52,54,52,32,115,51,48,57,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,52,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,49,52,50,56,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,57,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,53,48,49,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,49,53,51,54,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,50,54,56,32,109,50,54,57,32,115,116,97,114,116,50,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,34),40,97,49,53,55,57,32,112,50,54,51,32,110,50,54,52,32,100,101,115,116,50,54,53,32,115,116,97,114,116,50,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,23),40,97,49,54,54,50,32,112,111,115,50,50,56,49,32,110,101,120,116,50,56,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,50,56,48,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,21),40,97,49,54,52,52,32,112,50,55,55,32,108,105,109,105,116,50,55,56,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,50,50,57,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,51,50,51,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,51,51,54,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,50,49,49,48,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,29),40,97,50,49,49,54,32,104,111,115,116,51,53,54,51,53,56,32,112,111,114,116,51,53,55,51,53,57,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,51,53,48,32,46,32,109,111,114,101,51,53,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,51,56,55,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,51,56,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,51,57,52,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,52,48,48,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,52,48,53,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,52,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1890 */
static C_word C_fcall stub346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from k1879 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub342(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from k930 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub167(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub167(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k838 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k724 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from k709 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub121(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k702 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub108(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub104(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub104(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from k664 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub100(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k653 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k646 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub92(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from k639 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from k628 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub83(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub83(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k618 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k592 */
static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub61(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k577 */
static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub54(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k563 */
static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k544 */
static C_word C_fcall stub37(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub37(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k531 */
static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k516 */
static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k502 */
static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k487 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_fcall f_2002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_fcall f_1162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_fcall f_1412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_fcall f_1373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_fcall f_1382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_fcall f_1243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1253)
static void C_fcall f_1253(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_fcall f_1169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_fcall f_1175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_fcall f_1115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1005)
static void C_fcall f_1005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_fcall f_1000(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_957)
static void C_fcall f_957(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_fcall f_759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_768)
static void C_fcall f_768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_fcall f_738(C_word t0) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_753)
static void C_ccall f_753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_fcall f_713(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static C_word C_fcall f_699(C_word t0);
C_noret_decl(f_643)
static C_word C_fcall f_643(C_word t0);
C_noret_decl(f_625)
static C_word C_fcall f_625(C_word t0);
C_noret_decl(f_570)
static C_word C_fcall f_570(C_word t0,C_word t1);
C_noret_decl(f_541)
static C_word C_fcall f_541(C_word t0);
C_noret_decl(f_476)
static C_word C_fcall f_476(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_2002)
static void C_fcall trf_2002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2002(t0,t1);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1918(t0,t1);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1769(t0,t1);}

C_noret_decl(trf_1146)
static void C_fcall trf_1146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1146(t0,t1,t2);}

C_noret_decl(trf_1162)
static void C_fcall trf_1162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1162(t0,t1);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1651(t0,t1,t2);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1586(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1551(t0,t1);}

C_noret_decl(trf_1412)
static void C_fcall trf_1412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1412(t0,t1);}

C_noret_decl(trf_1373)
static void C_fcall trf_1373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1373(t0,t1);}

C_noret_decl(trf_1382)
static void C_fcall trf_1382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1382(t0,t1);}

C_noret_decl(trf_1243)
static void C_fcall trf_1243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1243(t0,t1,t2);}

C_noret_decl(trf_1253)
static void C_fcall trf_1253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1253(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1253(t0,t1,t2,t3);}

C_noret_decl(trf_1169)
static void C_fcall trf_1169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1169(t0,t1);}

C_noret_decl(trf_1175)
static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1175(t0,t1);}

C_noret_decl(trf_1115)
static void C_fcall trf_1115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1115(t0,t1);}

C_noret_decl(trf_1005)
static void C_fcall trf_1005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1005(t0,t1);}

C_noret_decl(trf_1000)
static void C_fcall trf_1000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1000(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1000(t0,t1,t2);}

C_noret_decl(trf_957)
static void C_fcall trf_957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_957(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_957(t0,t1,t2,t3);}

C_noret_decl(trf_759)
static void C_fcall trf_759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_759(t0,t1,t2,t3);}

C_noret_decl(trf_768)
static void C_fcall trf_768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_768(t0,t1,t2);}

C_noret_decl(trf_738)
static void C_fcall trf_738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_738(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_738(t0);}

C_noret_decl(trf_713)
static void C_fcall trf_713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_713(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_713(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,97);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[9]=C_h_intern(&lf[9],17,"\003sysmake-c-string");
lf[11]=C_h_intern(&lf[11],18,"\003syscurrent-thread");
lf[12]=C_h_intern(&lf[12],12,"\003sysschedule");
lf[13]=C_h_intern(&lf[13],9,"substring");
lf[15]=C_h_intern(&lf[15],15,"\003syssignal-hook");
lf[16]=C_h_intern(&lf[16],14,"\000network-error");
lf[17]=C_h_intern(&lf[17],11,"tcp-connect");
lf[18]=C_h_intern(&lf[18],17,"\003sysstring-append");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[20]=C_h_intern(&lf[20],17,"\003syspeek-c-string");
lf[21]=C_h_intern(&lf[21],16,"\003sysupdate-errno");
lf[22]=C_h_intern(&lf[22],10,"tcp-listen");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[25]=C_h_intern(&lf[25],11,"make-string");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[29]=C_h_intern(&lf[29],13,"\000domain-error");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[31]=C_h_intern(&lf[31],12,"tcp-listener");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[33]=C_h_intern(&lf[33],13,"tcp-listener\077");
lf[34]=C_h_intern(&lf[34],9,"tcp-close");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[36]=C_h_intern(&lf[36],15,"tcp-buffer-size");
lf[37]=C_h_intern(&lf[37],19,"\003sysundefined-value");
lf[38]=C_h_intern(&lf[38],16,"tcp-read-timeout");
lf[39]=C_h_intern(&lf[39],17,"tcp-write-timeout");
lf[40]=C_h_intern(&lf[40],19,"tcp-connect-timeout");
lf[41]=C_h_intern(&lf[41],18,"tcp-accept-timeout");
lf[42]=C_h_intern(&lf[42],15,"make-input-port");
lf[43]=C_h_intern(&lf[43],16,"make-output-port");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[46]=C_h_intern(&lf[46],25,"\003systhread-block-for-i/o!");
lf[47]=C_h_intern(&lf[47],29,"\003systhread-block-for-timeout!");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[53]=C_h_intern(&lf[53],6,"socket");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[61]=C_h_intern(&lf[61],15,"\003sysmake-string");
lf[62]=C_h_intern(&lf[62],20,"\003sysscan-buffer-line");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[65]=C_h_intern(&lf[65],10,"tcp-accept");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[68]=C_h_intern(&lf[68],17,"tcp-accept-ready\077");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[74]=C_h_intern(&lf[74],4,"\000all");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[80]=C_h_intern(&lf[80],20,"\003systcp-port->fileno");
lf[81]=C_h_intern(&lf[81],13,"\003sysport-data");
lf[82]=C_h_intern(&lf[82],13,"tcp-addresses");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[85]=C_h_intern(&lf[85],16,"tcp-port-numbers");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[88]=C_h_intern(&lf[88],17,"tcp-listener-port");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[90]=C_h_intern(&lf[90],16,"tcp-abandon-port");
lf[91]=C_h_intern(&lf[91],14,"\003syscheck-port");
lf[92]=C_h_intern(&lf[92],19,"tcp-listener-fileno");
lf[93]=C_h_intern(&lf[93],14,"make-parameter");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[95]=C_h_intern(&lf[95],17,"register-feature!");
lf[96]=C_h_intern(&lf[96],3,"tcp");
C_register_lf2(lf,97,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k463 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k466 in k463 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k469 in k466 in k463 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 89   register-feature! */
t3=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[96]);}

/* k472 in k469 in k466 in k463 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_476,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_541,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_625,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_643,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub104(C_SCHEME_UNDEFINED))){
t8=t7;
f_672(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 190  ##sys#signal-hook */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[16],lf[94]);}}

/* k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_672,2,t0,t1);}
t2=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_713,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[13]+1);
t6=C_mutate(&lf[14],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_759,a[2]=t5,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  make-parameter */
t11=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=*((C_word*)lf[37]+1);
t4=C_mutate((C_word*)lf[38]+1,t3);
t5=*((C_word*)lf[37]+1);
t6=C_mutate((C_word*)lf[39]+1,t5);
t7=*((C_word*)lf[37]+1);
t8=C_mutate((C_word*)lf[40]+1,t7);
t9=*((C_word*)lf[37]+1);
t10=C_mutate((C_word*)lf[41]+1,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1115,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1132,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 335  check */
f_1115(t13,lf[38]);}

/* k2311 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 335  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 336  check */
f_1115(t4,lf[39]);}

/* k2307 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 336  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 337  check */
f_1115(t4,lf[40]);}

/* k2303 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 337  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 338  check */
f_1115(t4,lf[41]);}

/* k2299 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 338  make-parameter */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=*((C_word*)lf[42]+1);
t4=*((C_word*)lf[43]+1);
t5=*((C_word*)lf[36]+1);
t6=*((C_word*)lf[25]+1);
t7=C_mutate(&lf[44],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1146,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2151,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2290,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2270,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 643  ##sys#check-port */
t4=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[90]);}

/* k2272 in tcp-abandon-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 645  ##sys#port-data */
t3=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2279 in k2272 in tcp-abandon-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2241,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[88]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_643(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2264,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2254(2,t8,C_SCHEME_UNDEFINED);}}

/* k2266 in tcp-listener-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 638  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[89],t1);}

/* k2262 in tcp-listener-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 637  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[88],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2252 in tcp-listener-port in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2196,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 625  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=f_643(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2210(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2237 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k2233 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[85],t1,((C_word*)t0)[2]);}

/* k2208 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=(C_word)stub96(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2217,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2217(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2226 in k2208 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2222 in k2208 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 630  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[85],t1,((C_word*)t0)[2]);}

/* k2215 in k2208 in k2198 in tcp-port-numbers in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2151,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2155,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 617  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2162,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub87(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2165(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2192 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[84],t1);}

/* k2188 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 620  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[82],t1,((C_word*)t0)[2]);}

/* k2163 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub100(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2167 in k2163 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2172(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2183,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2181 in k2167 in k2163 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k2177 in k2167 in k2163 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 622  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[82],t1,((C_word*)t0)[2]);}

/* k2170 in k2167 in k2163 in k2160 in k2153 in tcp-addresses in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 618  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 614  ##sys#port-data */
t4=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2147 in ##sys#tcp-port->fileno in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1894r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1894r(t0,t1,t2,t3);}}

static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1898,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1898(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1898(2,t7,(C_word)C_i_car(t3));}
else{
/* tcp.scm: 564  ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 565  tcp-connect-timeout */
t5=*((C_word*)lf[40]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1907,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_1907(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 568  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}}

/* a2116 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2117,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2110 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
/* tcp.scm: 568  ##net#parse-host */
t2=lf[14];
f_759(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[79]);}

/* k2101 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1907(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 569  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[78],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 571  make-string */
t4=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=f_476(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word)li43),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 580  ##sys#update-errno */
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1939(2,t6,C_SCHEME_UNDEFINED);}}

/* k2087 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2098 in k2087 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[77],t1);}

/* k2094 in k2087 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 582  ##net#gethostaddr */
f_713(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2078 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1942(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 583  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],lf[76],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_625(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_1945(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2066,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 585  ##sys#update-errno */
t5=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2064 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2075 in k2064 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[75],t1);}

/* k2071 in k2064 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=(C_word)stub61(C_SCHEME_UNDEFINED,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t10)){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[6],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2002(t14,t2);}
else{
/* tcp.scm: 605  fail */
t11=((C_word*)t0)[2];
f_1918(t11,t2);}}
else{
t10=t2;
f_1948(2,t10,C_SCHEME_UNDEFINED);}}

/* loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_2002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2002,NULL,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub121(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
/* tcp.scm: 591  fail */
t6=((C_word*)t0)[2];
f_1918(t6,t4);}
else{
t6=t4;
f_2009(2,t6,C_SCHEME_UNDEFINED);}}

/* k2007 in loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 594  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,*((C_word*)lf[11]+1),t5);}
else{
t4=t3;
f_2018(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2016 in k2007 in loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 597  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[74]);}

/* k2019 in k2016 in k2007 in loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 598  yield */
f_738(t2);}

/* k2022 in k2019 in k2016 in k2007 in loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 600  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[17],lf[73],((C_word*)t0)[2]);}
else{
t3=t2;
f_2027(2,t3,C_SCHEME_UNDEFINED);}}

/* k2025 in k2022 in k2019 in k2016 in k2007 in loop in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 604  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2002(t2,((C_word*)t0)[2]);}

/* k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=(C_word)stub342(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1967,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1971,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1988,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)C_i_foreign_fixnum_argumentp(t3);
t10=(C_word)stub346(t8,t9);
/* ##sys#peek-c-string */
t11=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_fix(0));}
else{
t6=t4;
f_1954(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1986 in k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k1982 in k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 610  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1969 in k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1965 in k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 608  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[16],lf[17],t1);}

/* k1952 in k1946 in k1943 in k1940 in k1937 in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 611  ##net#io-ports */
t2=lf[44];
f_1146(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,2,t0,t1);}
t2=f_541(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 575  ##sys#update-errno */
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1923 in fail in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1934 in k1923 in fail in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[70],t1);}

/* k1930 in k1923 in fail in k1911 in k1905 in k1899 in k1896 in tcp-connect in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 576  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[17],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1840,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[31],lf[68]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_699(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1859,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 547  ##sys#update-errno */
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1850(2,t8,C_SCHEME_UNDEFINED);}}

/* k1857 in tcp-accept-ready? in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1868 in k1857 in tcp-accept-ready? in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 549  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1864 in k1857 in tcp-accept-ready? in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 548  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[68],t1,((C_word*)t0)[2]);}

/* k1848 in tcp-accept-ready? in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1754,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1764,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 519  tcp-accept-timeout */
t6=*((C_word*)lf[41]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1769,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1769(t5,((C_word*)t0)[2]);}

/* loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,2,t0,t1);}
t2=f_699(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t5=(C_word)stub27(C_SCHEME_UNDEFINED,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 524  ##sys#update-errno */
t9=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1782(2,t8,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 531  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,*((C_word*)lf[11]+1),t6);}
else{
t5=t4;
f_1805(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1803 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 534  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1806 in k1803 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 535  yield */
f_738(t2);}

/* k1809 in k1806 in k1803 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 537  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[16],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t3=t2;
f_1814(2,t3,C_SCHEME_UNDEFINED);}}

/* k1812 in k1809 in k1806 in k1803 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 541  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1769(t2,((C_word*)t0)[2]);}

/* k1789 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1800 in k1789 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 526  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k1796 in k1789 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 525  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[65],t1,((C_word*)t0)[2]);}

/* k1780 in loop in k1762 in tcp-accept in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 528  ##net#io-ports */
t2=lf[44];
f_1146(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1146,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_625(t2);
if(C_truep(t4)){
t5=t3;
f_1150(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 347  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1739 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1750 in k1739 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k1746 in k1739 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 348  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[16],t1);}

/* k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 349  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 355  tbs */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1162(t4,(C_truep(t3)?lf[63]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1162(t3,C_SCHEME_FALSE);}}

/* k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1162,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 357  tcp-read-timeout */
t5=*((C_word*)lf[38]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 358  tcp-write-timeout */
t3=*((C_word*)lf[39]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[53],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word)li24),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1480,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1580,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1645,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word)li38),tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 386  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t9))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1645,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1651,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1651(t7,t1,C_SCHEME_FALSE);}

/* loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li36),tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 433  ##sys#scan-buffer-line */
t4=*((C_word*)lf[62]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1720,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 450  read-input */
t4=((C_word*)t0)[3];
f_1169(t4,t3);}}

/* k1718 in loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 452  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1651(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1662 in loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1663,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 438  ##sys#make-string */
t6=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k1665 in a1662 in loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1677,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 442  read-input */
t6=((C_word*)t0)[3];
f_1169(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 448  ##sys#string-append */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k1675 in k1665 in a1662 in loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[60]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 445  ##sys#string-append */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_1693(2,t3,((C_word*)t0)[2]);}}}

/* k1691 in k1675 in k1665 in a1662 in loop in a1644 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 445  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1651(t2,((C_word*)t0)[2],t1);}

/* a1579 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1580,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li34),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_1586(t9,t1,t3,C_fix(0),t5);}

/* loop in a1579 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1586,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* tcp.scm: 424  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1634,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 426  read-input */
t7=((C_word*)t0)[2];
f_1169(t7,t6);}}}

/* k1632 in loop in a1579 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 429  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1586(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1536 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_570(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_541(((C_word*)t0)[3]);
t6=t4;
f_1551(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1551(t5,C_SCHEME_FALSE);}}}

/* k1549 in a1536 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 410  ##sys#update-errno */
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1552 in k1549 in a1536 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1563 in k1552 in k1549 in a1536 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 413  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k1559 in k1552 in k1549 in a1536 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 411  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* a1501 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_699(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 399  ##sys#update-errno */
t7=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1515(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1522 in a1501 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1533 in k1522 in a1501 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 402  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k1529 in k1522 in a1501 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 400  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1513 in a1501 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1479 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 389  read-input */
t3=((C_word*)t0)[2];
f_1169(t3,t2);}
else{
t3=t2;
f_1484(2,t3,C_SCHEME_UNDEFINED);}}

/* k1482 in a1479 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1444,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1365,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word)li29),tmp=(C_word)a,a+=9,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1428,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp):C_SCHEME_FALSE);
/* tcp.scm: 482  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t4,t5,t6);}

/* f_1428 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 506  output */
t4=((C_word*)t0)[2];
f_1243(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1436 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[57]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1412(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1412(t5,C_SCHEME_FALSE);}}}

/* k1410 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1412,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 496  output */
t3=((C_word*)t0)[2];
f_1243(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1373(t2,C_SCHEME_UNDEFINED);}}

/* k1413 in k1410 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[56]);
t3=((C_word*)t0)[2];
f_1373(t3,t2);}

/* k1371 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1373,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_570(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_541(((C_word*)t0)[4]);
t5=t3;
f_1382(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1382(t4,C_SCHEME_FALSE);}}

/* k1380 in k1371 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1382,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 500  ##sys#update-errno */
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1383 in k1380 in k1371 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1394 in k1383 in k1380 in k1371 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 502  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[55],t1);}

/* k1390 in k1383 in k1380 in k1371 in a1364 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 501  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* f_1464 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1464,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 491  output */
t4=((C_word*)t0)[2];
f_1243(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1444 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 485  ##sys#string-append */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1447 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 487  output */
t5=((C_word*)t0)[2];
f_1243(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1456 in k1447 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[54]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1336 in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[51]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[52]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[53]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[53]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 514  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1243,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li25),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1253(t7,t1,t3,C_fix(0));}

/* loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1253(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1253,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_word)C_i_foreign_fixnum_argumentp(t5);
t9=(C_truep(t6)?(C_word)C_i_foreign_block_argumentp(t6):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t7);
t11=(C_word)C_i_foreign_fixnum_argumentp(t4);
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t13=(C_word)stub73(C_SCHEME_UNDEFINED,t8,t9,t10,t11,t12);
t14=(C_word)C_eqp(C_fix(-1),t13);
if(C_truep(t14)){
t15=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t17=(C_word)C_fudge(C_fix(16));
t18=(C_word)C_fixnum_plus(t17,((C_word*)t0)[2]);
/* tcp.scm: 463  ##sys#thread-block-for-timeout! */
t19=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t16,*((C_word*)lf[11]+1),t18);}
else{
t17=t16;
f_1275(2,t17,C_SCHEME_UNDEFINED);}}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 474  ##sys#update-errno */
t17=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t13,t2))){
t15=(C_word)C_fixnum_difference(t2,t13);
t16=(C_word)C_fixnum_plus(t3,t13);
/* tcp.scm: 480  loop */
t23=t1;
t24=t15;
t25=t16;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}}}

/* k1305 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1316 in k1305 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 477  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[50],t1);}

/* k1312 in k1305 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 475  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1273 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 466  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1276 in k1273 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 467  yield */
f_738(t2);}

/* k1279 in k1276 in k1273 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 469  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[49],((C_word*)t0)[2]);}
else{
t3=t2;
f_1284(2,t3,C_SCHEME_UNDEFINED);}}

/* k1282 in k1279 in k1276 in k1273 in loop in output in k1240 in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1253(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1169,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li23),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1175(t5,t1);}

/* loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1024));
t7=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t8=(C_word)stub44(C_SCHEME_UNDEFINED,t4,t5,t6,t7);
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t12=(C_word)C_fudge(C_fix(16));
t13=(C_word)C_fixnum_plus(t12,((C_word*)t0)[4]);
/* tcp.scm: 366  ##sys#thread-block-for-timeout! */
t14=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t11,*((C_word*)lf[11]+1),t13);}
else{
t12=t11;
f_1194(2,t12,C_SCHEME_UNDEFINED);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 377  ##sys#update-errno */
t12=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
t10=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t11=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}

/* k1224 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1237,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1235 in k1224 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 380  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1231 in k1224 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 378  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[16],t1,((C_word*)t0)[2]);}

/* k1192 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 369  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[11]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1195 in k1192 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 370  yield */
f_738(t2);}

/* k1198 in k1195 in k1192 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[11]+1),C_fix(13)))){
/* tcp.scm: 372  ##sys#signal-hook */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],lf[45],((C_word*)t0)[2]);}
else{
t3=t2;
f_1203(2,t3,C_SCHEME_UNDEFINED);}}

/* k1201 in k1198 in k1195 in k1192 in loop in read-input in k1166 in k1163 in k1160 in k1157 in k1151 in k1148 in ##net#io-ports in k1142 in k1138 in k1134 in k1130 in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 375  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1175(t2,((C_word*)t0)[2]);}

/* check in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1115(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1115,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1117,a[2]=t2,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp));}

/* f_1117 in check in k1095 in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1117,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1062,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[31]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_541(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1078,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 318  ##sys#update-errno */
t8=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k1076 in tcp-close in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1087 in k1076 in tcp-close in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[35],t1);}

/* k1083 in k1076 in tcp-close in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 319  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[34],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1053,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[31]):C_SCHEME_FALSE));}

/* tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_955r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_955r(t0,t1,t2,t3);}}

static void C_ccall f_955r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_957,a[2]=t2,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1000,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1005,a[2]=t5,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w186204 */
t7=t6;
f_1005(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host187202 */
t9=t5;
f_1000(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body184189 */
t11=t4;
f_957(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w186 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1005,NULL,2,t0,t1);}
/* def-host187202 */
t2=((C_word*)t0)[2];
f_1000(t2,t1,C_fix(10));}

/* def-host187 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_1000(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1000,NULL,3,t0,t1,t2);}
/* body184189 */
t3=((C_word*)t0)[2];
f_957(t3,t1,t2,C_SCHEME_FALSE);}

/* body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_957(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_957,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_963,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a968 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_969,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_fixnum_argumentp(t6);
t9=(C_word)stub20(C_SCHEME_UNDEFINED,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_979,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 306  ##sys#update-errno */
t13=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=t10;
f_979(2,t12,C_SCHEME_UNDEFINED);}}

/* k986 in a968 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k997 in k986 in a968 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[32],t1);}

/* k993 in k986 in a968 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 307  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k977 in a968 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[31],((C_word*)t0)[2]));}

/* a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_852,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 275  ##sys#signal-hook */
t9=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[29],lf[22],lf[30],t2);}
else{
t9=t6;
f_852(2,t9,C_SCHEME_UNDEFINED);}}

/* k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=f_476(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 278  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_858(2,t5,C_SCHEME_UNDEFINED);}}

/* k936 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 279  ##sys#error */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[28]);}

/* k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_927,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_927 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_927,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub167(C_SCHEME_UNDEFINED,t3));}

/* k924 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_926,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 285  ##sys#update-errno */
t4=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_861(2,t3,C_SCHEME_UNDEFINED);}}

/* k909 in k924 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k920 in k909 in k924 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k916 in k909 in k924 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 286  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[22],t1,((C_word*)t0)[2]);}

/* k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 287  make-string */
t3=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 289  ##net#gethostaddr */
f_713(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t6=t2;
f_867(2,t6,(C_word)stub153(C_SCHEME_UNDEFINED,t4,t5));}}

/* k897 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_867(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 290  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],lf[24],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k865 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)stub11(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 294  ##sys#update-errno */
t11=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_873(2,t10,C_SCHEME_UNDEFINED);}}

/* k880 in k865 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_893,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k891 in k880 in k865 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k887 in k880 in k865 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 295  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[16],lf[22],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k871 in k865 in k862 in k859 in k856 in k850 in a962 in body184 in tcp-listen in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 296  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_759,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_768,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li10),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_768(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_768,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 246  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_791,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* tcp.scm: 250  substring */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 259  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_795,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 251  substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_795,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_679,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t6=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t5=t4;
f_679(2,t5,C_SCHEME_FALSE);}}

/* k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_683(2,t3,C_SCHEME_FALSE);}}

/* k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_683,2,t0,t1);}
t2=(C_word)stub108(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_801,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 254  ##sys#update-errno */
t6=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_801(2,t5,C_SCHEME_UNDEFINED);}}

/* k805 in k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k816 in k805 in k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 256  ##sys#string-append */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[19],t1);}

/* k812 in k805 in k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 255  ##sys#signal-hook */
t2=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[16],lf[17],t1,((C_word*)t0)[2]);}

/* k799 in k681 in k677 in k793 in k789 in loop in ##net#parse-host in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 249  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_738(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_738,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 234  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a743 in yield in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_744,3,t0,t1,t2);}
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_753,a[2]=t2,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 238  ##sys#schedule */
t6=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a752 in a743 in yield in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
/* tcp.scm: 237  return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k670 in k472 in k469 in k466 in k463 */
static void C_fcall f_713(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_713,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_722,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=(C_word)C_i_foreign_string_argumentp(t3);
/* ##sys#make-c-string */
t8=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=t6;
f_722(2,t7,C_SCHEME_FALSE);}}

/* k720 in ##net#gethostaddr in k670 in k472 in k469 in k466 in k463 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub127(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

/* ##net#select in k670 in k472 in k469 in k466 in k463 */
static C_word C_fcall f_699(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub117(C_SCHEME_UNDEFINED,t2));}

/* ##net#getsockport in k472 in k469 in k466 in k463 */
static C_word C_fcall f_643(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub92(C_SCHEME_UNDEFINED,t2));}

/* ##net#make-nonblocking in k472 in k469 in k466 in k463 */
static C_word C_fcall f_625(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub83(C_SCHEME_UNDEFINED,t2));}

/* ##net#shutdown in k472 in k469 in k466 in k463 */
static C_word C_fcall f_570(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub54(C_SCHEME_UNDEFINED,t3,t4));}

/* ##net#close in k472 in k469 in k466 in k463 */
static C_word C_fcall f_541(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub37(C_SCHEME_UNDEFINED,t2));}

/* ##net#socket in k472 in k469 in k466 in k463 */
static C_word C_fcall f_476(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub3(C_SCHEME_UNDEFINED,t4,t5,t6));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[214] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_465tcp.scm",(void*)f_465},
{"f_468tcp.scm",(void*)f_468},
{"f_471tcp.scm",(void*)f_471},
{"f_474tcp.scm",(void*)f_474},
{"f_672tcp.scm",(void*)f_672},
{"f_1097tcp.scm",(void*)f_1097},
{"f_2313tcp.scm",(void*)f_2313},
{"f_1132tcp.scm",(void*)f_1132},
{"f_2309tcp.scm",(void*)f_2309},
{"f_1136tcp.scm",(void*)f_1136},
{"f_2305tcp.scm",(void*)f_2305},
{"f_1140tcp.scm",(void*)f_1140},
{"f_2301tcp.scm",(void*)f_2301},
{"f_1144tcp.scm",(void*)f_1144},
{"f_2290tcp.scm",(void*)f_2290},
{"f_2270tcp.scm",(void*)f_2270},
{"f_2274tcp.scm",(void*)f_2274},
{"f_2281tcp.scm",(void*)f_2281},
{"f_2241tcp.scm",(void*)f_2241},
{"f_2268tcp.scm",(void*)f_2268},
{"f_2264tcp.scm",(void*)f_2264},
{"f_2254tcp.scm",(void*)f_2254},
{"f_2196tcp.scm",(void*)f_2196},
{"f_2200tcp.scm",(void*)f_2200},
{"f_2239tcp.scm",(void*)f_2239},
{"f_2235tcp.scm",(void*)f_2235},
{"f_2210tcp.scm",(void*)f_2210},
{"f_2228tcp.scm",(void*)f_2228},
{"f_2224tcp.scm",(void*)f_2224},
{"f_2217tcp.scm",(void*)f_2217},
{"f_2151tcp.scm",(void*)f_2151},
{"f_2155tcp.scm",(void*)f_2155},
{"f_2162tcp.scm",(void*)f_2162},
{"f_2194tcp.scm",(void*)f_2194},
{"f_2190tcp.scm",(void*)f_2190},
{"f_2165tcp.scm",(void*)f_2165},
{"f_2169tcp.scm",(void*)f_2169},
{"f_2183tcp.scm",(void*)f_2183},
{"f_2179tcp.scm",(void*)f_2179},
{"f_2172tcp.scm",(void*)f_2172},
{"f_2141tcp.scm",(void*)f_2141},
{"f_2149tcp.scm",(void*)f_2149},
{"f_1894tcp.scm",(void*)f_1894},
{"f_1898tcp.scm",(void*)f_1898},
{"f_1901tcp.scm",(void*)f_1901},
{"f_2117tcp.scm",(void*)f_2117},
{"f_2111tcp.scm",(void*)f_2111},
{"f_2103tcp.scm",(void*)f_2103},
{"f_1907tcp.scm",(void*)f_1907},
{"f_1913tcp.scm",(void*)f_1913},
{"f_2089tcp.scm",(void*)f_2089},
{"f_2100tcp.scm",(void*)f_2100},
{"f_2096tcp.scm",(void*)f_2096},
{"f_1939tcp.scm",(void*)f_1939},
{"f_2080tcp.scm",(void*)f_2080},
{"f_1942tcp.scm",(void*)f_1942},
{"f_2066tcp.scm",(void*)f_2066},
{"f_2077tcp.scm",(void*)f_2077},
{"f_2073tcp.scm",(void*)f_2073},
{"f_1945tcp.scm",(void*)f_1945},
{"f_2002tcp.scm",(void*)f_2002},
{"f_2009tcp.scm",(void*)f_2009},
{"f_2018tcp.scm",(void*)f_2018},
{"f_2021tcp.scm",(void*)f_2021},
{"f_2024tcp.scm",(void*)f_2024},
{"f_2027tcp.scm",(void*)f_2027},
{"f_1948tcp.scm",(void*)f_1948},
{"f_1988tcp.scm",(void*)f_1988},
{"f_1984tcp.scm",(void*)f_1984},
{"f_1971tcp.scm",(void*)f_1971},
{"f_1967tcp.scm",(void*)f_1967},
{"f_1954tcp.scm",(void*)f_1954},
{"f_1918tcp.scm",(void*)f_1918},
{"f_1925tcp.scm",(void*)f_1925},
{"f_1936tcp.scm",(void*)f_1936},
{"f_1932tcp.scm",(void*)f_1932},
{"f_1840tcp.scm",(void*)f_1840},
{"f_1859tcp.scm",(void*)f_1859},
{"f_1870tcp.scm",(void*)f_1870},
{"f_1866tcp.scm",(void*)f_1866},
{"f_1850tcp.scm",(void*)f_1850},
{"f_1754tcp.scm",(void*)f_1754},
{"f_1764tcp.scm",(void*)f_1764},
{"f_1769tcp.scm",(void*)f_1769},
{"f_1805tcp.scm",(void*)f_1805},
{"f_1808tcp.scm",(void*)f_1808},
{"f_1811tcp.scm",(void*)f_1811},
{"f_1814tcp.scm",(void*)f_1814},
{"f_1791tcp.scm",(void*)f_1791},
{"f_1802tcp.scm",(void*)f_1802},
{"f_1798tcp.scm",(void*)f_1798},
{"f_1782tcp.scm",(void*)f_1782},
{"f_1146tcp.scm",(void*)f_1146},
{"f_1741tcp.scm",(void*)f_1741},
{"f_1752tcp.scm",(void*)f_1752},
{"f_1748tcp.scm",(void*)f_1748},
{"f_1150tcp.scm",(void*)f_1150},
{"f_1153tcp.scm",(void*)f_1153},
{"f_1159tcp.scm",(void*)f_1159},
{"f_1162tcp.scm",(void*)f_1162},
{"f_1165tcp.scm",(void*)f_1165},
{"f_1168tcp.scm",(void*)f_1168},
{"f_1645tcp.scm",(void*)f_1645},
{"f_1651tcp.scm",(void*)f_1651},
{"f_1720tcp.scm",(void*)f_1720},
{"f_1663tcp.scm",(void*)f_1663},
{"f_1667tcp.scm",(void*)f_1667},
{"f_1677tcp.scm",(void*)f_1677},
{"f_1693tcp.scm",(void*)f_1693},
{"f_1580tcp.scm",(void*)f_1580},
{"f_1586tcp.scm",(void*)f_1586},
{"f_1634tcp.scm",(void*)f_1634},
{"f_1537tcp.scm",(void*)f_1537},
{"f_1551tcp.scm",(void*)f_1551},
{"f_1554tcp.scm",(void*)f_1554},
{"f_1565tcp.scm",(void*)f_1565},
{"f_1561tcp.scm",(void*)f_1561},
{"f_1502tcp.scm",(void*)f_1502},
{"f_1524tcp.scm",(void*)f_1524},
{"f_1535tcp.scm",(void*)f_1535},
{"f_1531tcp.scm",(void*)f_1531},
{"f_1515tcp.scm",(void*)f_1515},
{"f_1480tcp.scm",(void*)f_1480},
{"f_1484tcp.scm",(void*)f_1484},
{"f_1242tcp.scm",(void*)f_1242},
{"f_1428tcp.scm",(void*)f_1428},
{"f_1438tcp.scm",(void*)f_1438},
{"f_1365tcp.scm",(void*)f_1365},
{"f_1412tcp.scm",(void*)f_1412},
{"f_1415tcp.scm",(void*)f_1415},
{"f_1373tcp.scm",(void*)f_1373},
{"f_1382tcp.scm",(void*)f_1382},
{"f_1385tcp.scm",(void*)f_1385},
{"f_1396tcp.scm",(void*)f_1396},
{"f_1392tcp.scm",(void*)f_1392},
{"f_1464tcp.scm",(void*)f_1464},
{"f_1444tcp.scm",(void*)f_1444},
{"f_1449tcp.scm",(void*)f_1449},
{"f_1458tcp.scm",(void*)f_1458},
{"f_1338tcp.scm",(void*)f_1338},
{"f_1243tcp.scm",(void*)f_1243},
{"f_1253tcp.scm",(void*)f_1253},
{"f_1307tcp.scm",(void*)f_1307},
{"f_1318tcp.scm",(void*)f_1318},
{"f_1314tcp.scm",(void*)f_1314},
{"f_1275tcp.scm",(void*)f_1275},
{"f_1278tcp.scm",(void*)f_1278},
{"f_1281tcp.scm",(void*)f_1281},
{"f_1284tcp.scm",(void*)f_1284},
{"f_1169tcp.scm",(void*)f_1169},
{"f_1175tcp.scm",(void*)f_1175},
{"f_1226tcp.scm",(void*)f_1226},
{"f_1237tcp.scm",(void*)f_1237},
{"f_1233tcp.scm",(void*)f_1233},
{"f_1194tcp.scm",(void*)f_1194},
{"f_1197tcp.scm",(void*)f_1197},
{"f_1200tcp.scm",(void*)f_1200},
{"f_1203tcp.scm",(void*)f_1203},
{"f_1115tcp.scm",(void*)f_1115},
{"f_1117tcp.scm",(void*)f_1117},
{"f_1062tcp.scm",(void*)f_1062},
{"f_1078tcp.scm",(void*)f_1078},
{"f_1089tcp.scm",(void*)f_1089},
{"f_1085tcp.scm",(void*)f_1085},
{"f_1053tcp.scm",(void*)f_1053},
{"f_955tcp.scm",(void*)f_955},
{"f_1005tcp.scm",(void*)f_1005},
{"f_1000tcp.scm",(void*)f_1000},
{"f_957tcp.scm",(void*)f_957},
{"f_969tcp.scm",(void*)f_969},
{"f_988tcp.scm",(void*)f_988},
{"f_999tcp.scm",(void*)f_999},
{"f_995tcp.scm",(void*)f_995},
{"f_979tcp.scm",(void*)f_979},
{"f_963tcp.scm",(void*)f_963},
{"f_852tcp.scm",(void*)f_852},
{"f_938tcp.scm",(void*)f_938},
{"f_858tcp.scm",(void*)f_858},
{"f_927tcp.scm",(void*)f_927},
{"f_926tcp.scm",(void*)f_926},
{"f_911tcp.scm",(void*)f_911},
{"f_922tcp.scm",(void*)f_922},
{"f_918tcp.scm",(void*)f_918},
{"f_861tcp.scm",(void*)f_861},
{"f_864tcp.scm",(void*)f_864},
{"f_899tcp.scm",(void*)f_899},
{"f_867tcp.scm",(void*)f_867},
{"f_882tcp.scm",(void*)f_882},
{"f_893tcp.scm",(void*)f_893},
{"f_889tcp.scm",(void*)f_889},
{"f_873tcp.scm",(void*)f_873},
{"f_759tcp.scm",(void*)f_759},
{"f_768tcp.scm",(void*)f_768},
{"f_791tcp.scm",(void*)f_791},
{"f_795tcp.scm",(void*)f_795},
{"f_679tcp.scm",(void*)f_679},
{"f_683tcp.scm",(void*)f_683},
{"f_807tcp.scm",(void*)f_807},
{"f_818tcp.scm",(void*)f_818},
{"f_814tcp.scm",(void*)f_814},
{"f_801tcp.scm",(void*)f_801},
{"f_738tcp.scm",(void*)f_738},
{"f_744tcp.scm",(void*)f_744},
{"f_753tcp.scm",(void*)f_753},
{"f_713tcp.scm",(void*)f_713},
{"f_722tcp.scm",(void*)f_722},
{"f_699tcp.scm",(void*)f_699},
{"f_643tcp.scm",(void*)f_643},
{"f_625tcp.scm",(void*)f_625},
{"f_570tcp.scm",(void*)f_570},
{"f_541tcp.scm",(void*)f_541},
{"f_476tcp.scm",(void*)f_476},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
